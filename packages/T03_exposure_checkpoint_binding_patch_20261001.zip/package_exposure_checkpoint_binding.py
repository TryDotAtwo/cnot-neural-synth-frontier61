import hashlib,json,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
files=['research_v3/data/model_exposure_journal_v1.py','research_v3/train/cuda_stream_v13.py','research_v3/tests/test_model_exposure_journal.py']
receipt={'schema':'own_exposure_checkpoint_binding_reference_v1','tests_passed':15,
 'command':'python -m unittest research_v3.tests.test_model_exposure_journal research_v3.tests.test_cuda_stream_exposure_admission research_v3.tests.test_T12_resume -q',
 'scope':'SQLite snapshot binding through real tensor checkpoint, reference resume tests; CUDA driver wiring inspected, not executed',
 'open':['native CUDA full training/resume','logical journal recovery identity and preserved ahead live branch','full panels and production acceptance'],
 'source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}}
name='T03_EXPOSURE_CHECKPOINT_BINDING_GATE_2026-10-01.json'
with (root/name).open('x',encoding='utf-8') as output:json.dump(receipt,output,indent=2)
ledger=json.loads((root/'NORMATIVE_REQUIREMENT_STATUS_V29_2026-10-01.json').read_text(encoding='utf-8'))
ledger['exposure_checkpoint_binding_update']=receipt
with (root/'NORMATIVE_REQUIREMENT_STATUS_V30_2026-10-01.json').open('x',encoding='utf-8') as output:json.dump(ledger,output,ensure_ascii=False,indent=2)
files += [name,'NORMATIVE_REQUIREMENT_STATUS_V30_2026-10-01.json','package_exposure_checkpoint_binding.py']
archive=root/'T03_exposure_checkpoint_binding_patch_20261001.zip'
manifest={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as output:
 for n in files:output.write(root/n,n)
 output.writestr('source_manifest.json',json.dumps({'files':manifest,'scope':receipt['scope'],'open':receipt['open']},indent=2))
with zipfile.ZipFile(archive) as check:
 assert check.testzip() is None
 assert all(hashlib.sha256(check.read(n)).hexdigest()==sha for n,sha in manifest.items())
print(json.dumps({'archive':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
