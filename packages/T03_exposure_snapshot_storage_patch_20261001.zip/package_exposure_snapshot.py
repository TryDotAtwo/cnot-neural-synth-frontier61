"""Publishable own storage primitive; full native resume remains open."""
import hashlib,json,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
files=['research_v3/data/model_exposure_journal_v1.py','research_v3/tests/test_model_exposure_journal.py']
receipt={'schema':'own_exposure_snapshot_reference_gate_v1','tests_passed':8,
 'command':'python -m unittest research_v3.tests.test_model_exposure_journal research_v3.tests.test_cuda_stream_exposure_admission -v',
 'scope':'fresh SQLite snapshot recovery, ahead live journal preserved; actual CPU stem forward/backward and admission guards',
 'negative_result_preserved':{'initial_test':'snapshot fsync on read-only Windows descriptor','error':'OSError: [Errno 9] Bad file descriptor','fix':'fsync writable descriptor'},
 'open':['checkpoint binding','logical journal identity across recovery paths','full model/optimizer/RNG/native CUDA resume','production training'],
 'source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}}
name='T03_EXPOSURE_SNAPSHOT_REFERENCE_GATE_2026-10-01.json'
with (root/name).open('x',encoding='utf-8') as output:json.dump(receipt,output,indent=2)
files += [name,'package_exposure_snapshot.py']
archive=root/'T03_exposure_snapshot_storage_patch_20261001.zip'
manifest={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as output:
 for n in files:output.write(root/n,n)
 output.writestr('source_manifest.json',json.dumps({'files':manifest,'scope':receipt['scope'],'open':receipt['open']},indent=2))
with zipfile.ZipFile(archive) as check:
 assert check.testzip() is None
 assert all(hashlib.sha256(check.read(n)).hexdigest()==sha for n,sha in manifest.items())
print(json.dumps({'archive':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size}))
