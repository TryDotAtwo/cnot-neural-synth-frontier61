"""Restartable stream of unique own-synthesizer root problems.

Each epoch contributes new root matrices. SQLite commits each verified root,
candidate audit and all selected-solution suffixes in one transaction.
"""
from dataclasses import asdict
import argparse
import hashlib
import json
from pathlib import Path
import sqlite3
from time import perf_counter

from .frozen import forbidden_views, historical_states
from .solver_programs import basis_program, solution_offsets, walk_with_solver
from .own_synthesis import source_hashes
from .fast_cost_v1 import install as install_fast_cost
from .composition_program_v1 import composition_program
from .stage35_pair_exact_v1 import generate as generate_stage35, verify_result as verify_stage35, SOURCE_SHA256 as STAGE35_SOURCE_SHA
from .stage18_bipartite_exact_v1 import generate as generate_stage18, verify_result as verify_stage18, SOURCE_NOTES_SHA256 as STAGE18_NOTES_SHA
from .records import SampleRecord
from ..contracts import AlphabetSpec
from .stage37_zero_excess_generator_v1 import generate as generate_stage37
from .stage37_zero_excess_exact_v1 import verify_result as verify_stage37, SOURCE_NOTES_SHA256 as STAGE37_SOURCE_SHA
install_fast_cost()


FAMILIES = ('walk_mixture', 'guarded_exact', 'basis_shear', 'composition')
SIZES = (8, 10, 13, 25, 26, 34, 45, 50, 58, 72, 90, 108, 122, 144)
SPLIT_SEED_OFFSET = {'train': 1_000_000_000, 'dev': 2_000_000_000, 'test': 3_000_000_000}
SCHEMA = 'own_solver_stream_v13_guarded_admitted_prelim'

DATA_SOURCE_FILES = ('contracts.py', 'gf2.py', 'words.py', 'symmetry.py',
                     'data/generators.py', 'data/paid_basis.py',
                     'data/solver_programs.py', 'data/own_synthesis.py',
                     'data/stream_solver_dataset_v13.py', 'data/fast_cost_v1.py',
                     'data/composition_program_v1.py', 'data/stage35_pair_exact_v1.py',
                     'data/stage18_bipartite_exact_v1.py', 'data/stream_reader_v13.py',
                     'data/stage37_zero_excess_exact_v1.py',
                     'data/stage37_zero_excess_generator_v1.py',
                     'data/stage23_forest_exact_v1.py',
                     'data/stage24_moving_root_exact_v1.py',
                     'data/stage25_swap_forest_exact_v1.py',
                     'data/stage36_saturated_frame_exact_v1.py',
                     'data/stream_reader.py', 'data/symmetry_records.py',
                     'data/frozen.py', 'data/records.py')


def data_source_hashes():
    root = Path(__file__).resolve().parents[1]
    return {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
            for name in DATA_SOURCE_FILES}


def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), allow_nan=False)


def root_key(record):
    return hashlib.sha256(canonical(record.state.key).encode('ascii')).hexdigest()


def matrix_identity(record):
    return canonical(record.state.key)


def epoch_seed(split, epoch, index, attempt, seed_base):
    if split not in SPLIT_SEED_OFFSET or not 0 <= epoch < 1000 or \
            not 0 <= index < 10_000 or not 0 <= attempt < 100:
        raise ValueError('invalid root identity')
    return seed_base + SPLIT_SEED_OFFSET[split] + epoch * 1_000_000 + index * 100 + attempt


def make_root(split, epoch, index, attempt, seed_base):
    family = FAMILIES[(index // len(SIZES)) % len(FAMILIES)]
    n = SIZES[index % len(SIZES)]
    seed = epoch_seed(split, epoch, index, attempt, seed_base)
    if family == 'guarded_exact':
        exact_kind = ('stage18_bipartite', 'stage35_pair', 'stage37_zero_excess')[
            (index // (len(SIZES) * len(FAMILIES))) % 3]
        if exact_kind == 'stage18_bipartite':
            result = generate_stage18(seed, n, split=split)
            valid = verify_stage18(result, AlphabetSpec.all_to_all(n))
            source = 'stage18_bipartite_exact_v1'
            evidence = 'acuaviva_2608.03825v1_notes_sha256:' + STAGE18_NOTES_SHA
            source_sha = STAGE18_NOTES_SHA
        elif exact_kind == 'stage35_pair':
            result = generate_stage35(seed, n, split=split)
            valid = verify_stage35(result, AlphabetSpec.all_to_all(n))
            source = 'stage35_pair_exact_v1'
            evidence = 'stage35_pair_theorem_sha256:' + STAGE35_SOURCE_SHA
            source_sha = STAGE35_SOURCE_SHA
        else:
            result = generate_stage37(seed, n, split=split)
            valid = verify_stage37(result, AlphabetSpec.all_to_all(n))
            source = 'stage37_zero_excess_exact_v1'
            evidence = 'stage37_zero_excess_theorem_sha256:' + STAGE37_SOURCE_SHA
            source_sha = STAGE37_SOURCE_SHA
        if result.status != 'exact' or not valid:
            raise ValueError('guarded exact generation failed full-word and theorem check')
        record = SampleRecord(result.state, (result.word,),
            f'{source}:{split}:{seed}:{n}', seed, source, split,
            exact_distance=result.distance, exact_evidence=evidence)
        audit = {'family':'guarded_exact','exact_kind':exact_kind,
            'scope_id':result.scope_id,'source_sha256':source_sha,
            'hypotheses':result.hypotheses,'witness':asdict(result)['witness'],
            'exact_distance':result.distance,'verified_word':True,
            'selected_producer':result.word.producer,
            'selected_length':result.word.physical_cost,
            'solver_called':False,'solver_status':'not_called_exact_certificate'}
    elif family == 'basis_shear':
        record, audit = basis_program(seed, n, split=split)
    elif family == 'composition':
        record, audit = composition_program(seed, n, split=split)
    else:
        steps = n * (1 + (seed % 3))
        walk_kind = 'ordinary_walk' if seed % 2 == 0 else 'poisson_walk'
        record, audit = walk_with_solver(walk_kind, seed, n, steps, split=split)
        audit = dict(audit, family='walk_mixture', walk_kind=walk_kind)
    return record, audit


def open_store(path, *, seed_base, source_sha=None, expected_dev_roots=448,
               expected_test_roots=448):
    path = Path(path)
    if source_sha is None:
        source_sha = source_hashes()
    manifest = {'schema': SCHEMA, 'seed_base': seed_base,
                'families': FAMILIES, 'sizes': SIZES,
                'epochs': 1000, 'new_unique_roots_per_epoch': 10_000,
                'target_unique_train_roots': 10_000_000,
                'claim_scope': 'preliminary; stage23-25/36/38 and normative panels remain open',
                'reader_module': 'research_v3.data.stream_reader_v13',
                'admission': 'parent_and_all_primitive_neighbors_before_forward',
                'expected_dev_roots': expected_dev_roots,
                'expected_test_roots': expected_test_roots,
                'split_seed_offsets': SPLIT_SEED_OFFSET,
                'compiler_source_sha256': source_sha,
                'dataset_source_sha256': data_source_hashes()}
    connection = sqlite3.connect(path)
    connection.execute('PRAGMA journal_mode=WAL')
    connection.execute('PRAGMA synchronous=FULL')
    connection.executescript('''
        CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS roots(
            matrix_hash TEXT NOT NULL, matrix_json TEXT NOT NULL,
            split TEXT NOT NULL, epoch INTEGER NOT NULL,
            position INTEGER NOT NULL, attempt INTEGER NOT NULL, family TEXT NOT NULL,
            n INTEGER NOT NULL, seed INTEGER NOT NULL, record_json TEXT NOT NULL,
            audit_json TEXT NOT NULL, suffix_offsets_json TEXT NOT NULL,
            root_digest TEXT NOT NULL,
            PRIMARY KEY(matrix_hash,matrix_json),
            UNIQUE(split, epoch, position));
        CREATE TABLE IF NOT EXISTS forbidden_hashes(state_hash TEXT PRIMARY KEY);
        CREATE TRIGGER IF NOT EXISTS immutable_roots_update BEFORE UPDATE ON roots
            BEGIN SELECT RAISE(ABORT,'stored root is immutable'); END;
        CREATE TRIGGER IF NOT EXISTS immutable_roots_delete BEFORE DELETE ON roots
            BEGIN SELECT RAISE(ABORT,'stored root is immutable'); END;
    ''')
    saved = connection.execute("SELECT value FROM metadata WHERE key='manifest'").fetchone()
    if saved is None:
        with connection:
            connection.execute("INSERT INTO metadata(key,value) VALUES('manifest',?)",
                               (canonical(manifest),))
    elif saved[0] != canonical(manifest):
        connection.close()
        raise ValueError('dataset generator or own compiler source drift')
    return connection, manifest


def seal_holdout(connection, historical=(), historical_source_hashes=None):
    """Freeze dev/test and historical symmetry views plus their full CNOT neighborhoods.

    A SHA collision can only over-filter a train state, never leak a held-out
    state. Root uniqueness separately compares complete serialized matrices.
    """
    manifest = json.loads(connection.execute(
        "SELECT value FROM metadata WHERE key='manifest'").fetchone()[0])
    counts = {split: connection.execute('SELECT COUNT(*) FROM roots WHERE split=?',
                                        (split,)).fetchone()[0] for split in ('dev', 'test')}
    if counts != {'dev': manifest['expected_dev_roots'],
                  'test': manifest['expected_test_roots']}:
        raise ValueError('dev/test roots must be complete before sealing holdout')
    existing = connection.execute("SELECT value FROM metadata WHERE key='holdout_seal'").fetchone()
    if existing is not None:
        raise ValueError('holdout already sealed')
    from ..contracts import AlphabetSpec, MatrixState
    roots = []
    panels = {'dev': [], 'test': []}
    lineage_splits = {}
    from .stream_reader_v13 import decode_record
    for split, matrix_hash, identity, raw, audit, offsets, root_digest in connection.execute(
            "SELECT split,matrix_hash,matrix_json,record_json,audit_json,suffix_offsets_json,root_digest "
            "FROM roots WHERE split IN ('dev','test') ORDER BY split,epoch,position"):
        if hashlib.sha256(canonical((identity, raw, audit, offsets)).encode('utf8')).hexdigest() != root_digest:
            raise ValueError('holdout root content digest mismatch')
        record = decode_record(raw)
        if record.split != split or canonical(record.state.key) != identity or root_key(record) != matrix_hash:
            raise ValueError('holdout root identity/split mismatch')
        unit = (record.source, record.seed)
        if unit in lineage_splits and lineage_splits[unit] != split:
            raise ValueError('holdout lineage crosses splits')
        lineage_splits[unit] = split
        panels[split].append(record.state)
        roots.append(record.state)
    panel_views = {split: forbidden_views(states) for split, states in panels.items()}
    historical_views = forbidden_views(historical)
    if panel_views['dev'] & panel_views['test'] or \
            (panel_views['dev'] | panel_views['test']) & historical_views:
        raise ValueError('holdout finite-symmetry overlap')
    roots.extend(historical)
    views = forbidden_views(roots)
    with connection:
        connection.execute('DELETE FROM forbidden_hashes')
        for n, alphabet_id, rows in sorted(views):
            if alphabet_id != AlphabetSpec.all_to_all(n).id:
                raise ValueError('held-out alphabet mismatch')
            def insert(packed_rows):
                digest = hashlib.sha256(canonical((n, alphabet_id, packed_rows)).encode('ascii')).hexdigest()
                connection.execute('INSERT OR IGNORE INTO forbidden_hashes(state_hash) VALUES(?)',
                                   (digest,))
            insert(rows)
            for control in range(n):
                for target in range(n):
                    if control == target:
                        continue
                    changed = rows[:target] + (rows[target] ^ rows[control],) + rows[target+1:]
                    insert(changed)
        seal = {'dev_roots': counts['dev'], 'test_roots': counts['test'],
                'historical_roots': len(historical), 'finite_symmetry_views': len(views),
                'historical_source_sha256': historical_source_hashes or {},
                'split_audit': {'dev_test_symmetry_overlap': 0,
                                'historical_symmetry_overlap': 0,
                                'cross_split_lineage_overlap': 0,
                                'scope': 'declared finite views; not complete orbits'},
                'forbidden_or_onehop_hashes': connection.execute(
                    'SELECT COUNT(*) FROM forbidden_hashes').fetchone()[0],
                'scope': 'full primitive one-hop from declared heldout finite symmetry views'}
        connection.execute("INSERT INTO metadata(key,value) VALUES('holdout_seal',?)",
                           (canonical(seal),))
    return seal


def admit_complete_neighbors(connection, records):
    """Reject whole parents; never remove a primitive from a full backup.

    XOR preserves invertibility, so scan canonical packed rows directly instead
    of doing an expensive GF(2) rank reconstruction for each neighbour. Hash
    collisions conservatively reject and cannot admit a forbidden matrix.
    """
    observed = 0
    for record in records:
        n, alphabet_id, rows = record.state.key
        if alphabet_id != AlphabetSpec.all_to_all(n).id:
            raise ValueError('admission requires full unit CNOT alphabet')
        def check(candidate):
            digest = hashlib.sha256(canonical((n, alphabet_id, candidate)).encode('ascii')).hexdigest()
            if connection.execute('SELECT 1 FROM forbidden_hashes WHERE state_hash=?',
                                  (digest,)).fetchone():
                raise ValueError('training parent or complete neighbor intersects holdout')
        check(rows)
        observed += 1
        for control in range(n):
            for target in range(n):
                if control != target:
                    check(rows[:target] + (rows[target] ^ rows[control],) + rows[target+1:])
                    observed += 1
    return observed


def safe_offsets(connection, record, offsets):
    """Reject train suffix states equal/adjacent to sealed heldout views."""
    chosen = min(record.verified_words, key=lambda word: word.physical_cost)
    needed = set(offsets)
    rows = list(record.state.packed_rows)
    allowed = []
    for offset, gate in enumerate(chosen.gates):
        if offset in needed:
            state_hash = hashlib.sha256(canonical((record.state.n, record.state.alphabet_id,
                                                    tuple(rows))).encode('ascii')).hexdigest()
            if connection.execute('SELECT 1 FROM forbidden_hashes WHERE state_hash=?',
                                  (state_hash,)).fetchone() is None:
                # Screen the complete local operator, including neighbours of
                # suffixes. Avoid constructing every neighbour MatrixState.
                from dataclasses import replace
                from ..contracts import MatrixState
                candidate = replace(record, state=MatrixState(record.state.n, tuple(rows),
                                                               record.state.alphabet_id))
                try:
                    admit_complete_neighbors(connection, (candidate,))
                except ValueError as error:
                    if 'intersects holdout' not in str(error):
                        raise
                else:
                    allowed.append(offset)
        rows[gate.target] ^= rows[gate.control]
    if tuple(rows) != tuple(1 << i for i in range(record.state.n)):
        raise ValueError('selected root certificate changed endpoint')
    return tuple(allowed)


def build_epoch(connection, *, split, epoch, count, seed_base, on_root=None):
    if split not in SPLIT_SEED_OFFSET or type(epoch) is not int or epoch < 0 or \
            type(count) is not int or not 1 <= count <= 10_000 or epoch >= 1000:
        raise ValueError('invalid split/epoch/count')
    manifest = json.loads(connection.execute("SELECT value FROM metadata WHERE key='manifest'").fetchone()[0])
    if manifest['schema'] != SCHEMA or manifest['seed_base'] != seed_base:
        raise ValueError('stream schema/seed mismatch')
    if manifest['dataset_source_sha256'] != data_source_hashes() or \
            manifest['compiler_source_sha256'] != source_hashes():
        raise ValueError('dataset generator or own compiler source drift')
    if split == 'train' and connection.execute(
            "SELECT 1 FROM metadata WHERE key='holdout_seal'").fetchone() is None:
        raise ValueError('holdout must be sealed before generating train roots')
    if split != 'train' and connection.execute(
            "SELECT 1 FROM metadata WHERE key='holdout_seal'").fetchone() is not None:
        raise ValueError('sealed dev/test roots cannot be extended')
    started = perf_counter()
    present, first, last = connection.execute(
        'SELECT COUNT(*),MIN(position),MAX(position) FROM roots WHERE split=? AND epoch=?',
        (split, epoch)).fetchone()
    if (present and (first != 0 or last != present - 1)) or present > count:
        raise ValueError('non-contiguous or oversized resumed epoch')
    stats = {'split': split, 'epoch': epoch, 'requested_roots': count,
             'already_present': present, 'new_roots': 0,
             'duplicate_candidates': 0, 'suffix_states': 0,
             'rejected_holdout_suffixes': 0, 'rejected_holdout_roots': 0,
             'solver_attempts': 0, 'solver_successes': 0,
             'verified_certificates': 0,
             'synth_improvements': 0, 'synth_failures': 0}
    for index in range(present, count):
        attempt = 0
        while True:
            if attempt >= 100:
                raise RuntimeError('100 duplicate root draws for one position')
            record, audit = make_root(split, epoch, index, attempt, seed_base)
            from .stream_reader_v13 import decode_record
            decode_record(canonical(asdict(record)))
            if record.split != split:
                raise ValueError('generated root has wrong split')
            stats['solver_attempts'] += bool(audit['solver_called'])
            stats['solver_successes'] += audit['solver_status'] == 'verified'
            stats['synth_failures'] += audit['solver_status'] == 'failed_or_invalid'
            key = root_key(record)
            full_matrix = matrix_identity(record)
            colliding = connection.execute('SELECT matrix_json FROM roots WHERE matrix_hash=?',
                                           (key,)).fetchall()
            if any(row[0] == full_matrix for row in colliding) or \
                    (split == 'train' and record.upper_bound == 0):
                stats['duplicate_candidates'] += 1
                attempt += 1
                continue
            offsets = solution_offsets(record) if split == 'train' else ()
            if split == 'train':
                safe = safe_offsets(connection, record, offsets)
                stats['rejected_holdout_suffixes'] += len(offsets) - len(safe)
                if 0 not in safe:
                    stats['rejected_holdout_roots'] += 1
                    attempt += 1
                    continue
                offsets = safe
            break
        with connection:
            record_json = canonical(asdict(record))
            audit_json = canonical(audit)
            suffix_json = canonical(offsets)
            root_digest = hashlib.sha256(canonical((full_matrix, record_json,
                                                    audit_json, suffix_json)).encode('utf-8')).hexdigest()
            connection.execute('''INSERT INTO roots
                (matrix_hash,matrix_json,split,epoch,position,attempt,family,n,seed,record_json,audit_json,suffix_offsets_json,root_digest)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                (key, full_matrix, split, epoch, index, attempt, audit['family'], record.state.n,
                 record.seed, record_json, audit_json, suffix_json, root_digest))
        stats['new_roots'] += 1
        stats['suffix_states'] += len(offsets)
        stats['verified_certificates'] += len(record.verified_words)
        stats['synth_improvements'] += bool(audit.get('synth_improved'))
        if on_root is not None:
            on_root(index, record, audit, stats)
    stats['total_roots_in_epoch'] = connection.execute(
        'SELECT COUNT(*) FROM roots WHERE split=? AND epoch=?', (split, epoch)).fetchone()[0]
    stats['seconds'] = perf_counter() - started
    return stats


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', type=Path, required=True)
    parser.add_argument('--split', choices=tuple(SPLIT_SEED_OFFSET))
    parser.add_argument('--epoch', type=int)
    parser.add_argument('--count', type=int)
    parser.add_argument('--seed-base', type=int, default=3700)
    parser.add_argument('--expected-dev-roots', type=int, default=128)
    parser.add_argument('--expected-test-roots', type=int, default=128)
    parser.add_argument('--seal-holdout', action='store_true')
    parser.add_argument('--stage17-root', type=Path,
                        default=Path(__file__).resolve().parents[3])
    parser.add_argument('--status', action='store_true')
    args = parser.parse_args()
    if not args.db.parent.is_dir():
        raise FileNotFoundError(args.db.parent)
    if args.status:
        if not args.db.is_file():
            raise FileNotFoundError(args.db)
        # Status must never switch journal mode or create a WAL sidecar.
        connection = sqlite3.connect(args.db.resolve().as_uri() + '?immutable=1',
                                     uri=True)
        try:
            saved = connection.execute(
                "SELECT value FROM metadata WHERE key='manifest'").fetchone()
            if saved is None:
                raise ValueError('dataset manifest missing')
            manifest = json.loads(saved[0])
            rows = connection.execute(
                'SELECT split,COUNT(*) FROM roots GROUP BY split').fetchall()
            seal = connection.execute(
                "SELECT value FROM metadata WHERE key='holdout_seal'").fetchone()
        finally:
            connection.close()
        print(canonical({'manifest': manifest, 'root_counts': dict(rows),
                         'holdout_seal': None if seal is None else json.loads(seal[0]),
                         'current_source_matches_manifest':
                         manifest.get('compiler_source_sha256') == source_hashes() and
                         manifest.get('dataset_source_sha256') == data_source_hashes()}))
        return
    connection, manifest = open_store(args.db, seed_base=args.seed_base,
                                      expected_dev_roots=args.expected_dev_roots,
                                      expected_test_roots=args.expected_test_roots)
    try:
        if args.seal_holdout:
            if args.split is not None or args.epoch is not None or args.count is not None:
                raise ValueError('seal request cannot include generation arguments')
            historical, historical_sources = historical_states(args.stage17_root)
            print(canonical({'holdout_seal': seal_holdout(connection, historical,
                                                         historical_sources)}), flush=True)
            return
        if args.split is None or args.epoch is None:
            raise ValueError('generation requires split and epoch')
        count = args.count if args.count is not None else (
            10_000 if args.split == 'train' else
            args.expected_dev_roots if args.split == 'dev' else args.expected_test_roots)
        result = build_epoch(connection, split=args.split, epoch=args.epoch,
                             count=count, seed_base=args.seed_base,
                             on_root=lambda i, record, audit, _: print(canonical({
                                 'position': i, 'family': audit['family'], 'n': record.state.n,
                                 'best': record.upper_bound, 'solver': audit.get('synthesizer', {}).get('status'),
                                 'selected': audit['selected_producer']}), flush=True))
        print(canonical({'manifest_sha256': hashlib.sha256(canonical(manifest).encode()).hexdigest(),
                         'result': result}), flush=True)
    finally:
        connection.close()


if __name__ == '__main__':
    main()
