import hashlib,json,zipfile
from pathlib import Path
from research_v3.gpu.frozen_bank_v13 import _portable_historical_states
root=Path(__file__).resolve().parent
states,sources=_portable_historical_states(root/'historical_stage17_own_v1')
files=['research_v3/train/cuda_stream_v13.py','research_v3/data/model_exposure_journal_v1.py','research_v3/data/splits.py','research_v3/tests/test_historical_quarantine_admission.py']
receipt={'status':'reference_admission_checked_native_open','tests_passed':10,
 'command':'python -m unittest research_v3.tests.test_historical_quarantine_admission research_v3.tests.test_model_exposure_journal research_v3.tests.test_cuda_stream_exposure_admission -q',
 'requirement':'T03 excludes all nine own historical targets from labels/replay/teacher',
 'scope':'driver requires nine sealed roots and nine valid source hashes; actual own input reader verified all nine; does not prove production bank content',
 'historical_widths':[state.n for state in states],
 'historical_input_sha256':{Path(path).name:sha for path,sha in sources.items()},
 'open':['native bank reconstruction','actual full train label/replay/teacher audit','historical forward/gradient disclosure'],
 'source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}}
name='T03_HISTORICAL_ADMISSION_GATE_2026-10-01.json'
with (root/name).open('x',encoding='utf-8') as output:json.dump(receipt,output,indent=2)
ledger=json.loads((root/'NORMATIVE_REQUIREMENT_STATUS_V31_2026-10-01.json').read_text(encoding='utf-8'))
ledger['historical_quarantine_admission_update']=receipt
ledger_name='NORMATIVE_REQUIREMENT_STATUS_V32_2026-10-01.json'
with (root/ledger_name).open('x',encoding='utf-8') as output:json.dump(ledger,output,ensure_ascii=False,indent=2)
files += [name,ledger_name,'package_historical_admission.py']
manifest={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}
archive=root/'T03_historical_admission_patch_20261001.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as output:
 for n in files:output.write(root/n,n)
 output.writestr('source_manifest.json',json.dumps({'files':manifest,'status':receipt['status']},indent=2))
with zipfile.ZipFile(archive) as check:
 assert check.testzip() is None
 assert all(hashlib.sha256(check.read(n)).hexdigest()==sha for n,sha in manifest.items())
print(hashlib.sha256(archive.read_bytes()).hexdigest())
