import hashlib,json,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
files=['research_v3/gpu/frozen_bank_v13.py','research_v3/tests/test_holdout_wal_snapshot.py']
receipt={'status':'reference_storage_checked_native_bank_open','tests_passed':6,
 'command':'python -m unittest research_v3.tests.test_holdout_wal_snapshot research_v3.tests.test_stream_status_v13 research_v3.tests.test_historical_portability -q',
 'negative_finding':{'old_reader':'immutable=1','committed_wal_rows':1,'old_visible_rows':0},
 'scope':'actual SQLite WAL fixture: read-only consistent committed snapshot, writes rejected, database/WAL hashes unchanged by reads',
 'open':['actual Molab sealed database read','native GPU bank reconstruction'],
 'source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}}
name='T03_HOLDOUT_WAL_READER_GATE_2026-10-01.json'
with (root/name).open('x',encoding='utf-8') as output:json.dump(receipt,output,indent=2)
ledger=json.loads((root/'NORMATIVE_REQUIREMENT_STATUS_V37_2026-10-01.json').read_text(encoding='utf-8'))
ledger['holdout_wal_reader_update']=receipt
ledger_name='NORMATIVE_REQUIREMENT_STATUS_V38_2026-10-01.json'
with (root/ledger_name).open('x',encoding='utf-8') as output:json.dump(ledger,output,ensure_ascii=False,indent=2)
files += [name,ledger_name,'package_holdout_wal_fix.py']
manifest={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}
archive=root/'T03_holdout_wal_reader_patch_20261001.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as output:
 for n in files:output.write(root/n,n)
 output.writestr('source_manifest.json',json.dumps({'files':manifest,'status':receipt['status']},indent=2))
with zipfile.ZipFile(archive) as check:
 assert check.testzip() is None
 assert all(hashlib.sha256(check.read(n)).hexdigest()==sha for n,sha in manifest.items())
print(hashlib.sha256(archive.read_bytes()).hexdigest())
