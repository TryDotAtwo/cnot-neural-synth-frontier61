import hashlib,json,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
name='T03_NATIVE_EXPOSURE_RESUME_PREPARED_2026-10-01.json'
receipt={'status':'prepared_not_accepted','scope':'tiny actual field + Adam + CUDA RNG + durable exposure ledger; full training mode remains open',
 'native_command':'CUBLAS_WORKSPACE_CONFIG=:4096:8 python -m unittest research_v3.tests.test_molab_model_exposure -v',
 'negative':{'accidental_local_cuda_run':{'tests':2,'errors':2,'known_error':'deterministic cuBLAS workspace configuration missing','other_error':'backward failed; full traceback not retained, diagnosis open'}},
 'local_guard_verification':{'tests':2,'skipped':2,'accepted_native_tests':0},
 'open':['Molab execution','first backward error diagnosis','complete selected Bellman mode resume','logical configured journal path recovery']}
with (root/name).open('x',encoding='utf-8') as output:json.dump(receipt,output,indent=2)
files=['research_v3/tests/test_molab_model_exposure.py',name,'package_native_exposure_resume.py']
manifest={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}
archive=root/'T03_native_exposure_resume_gate_patch_20261001.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as output:
 for n in files:output.write(root/n,n)
 output.writestr('source_manifest.json',json.dumps({'files':manifest,'status':'prepared_not_accepted'},indent=2))
with zipfile.ZipFile(archive) as check:
 assert check.testzip() is None
 assert all(hashlib.sha256(check.read(n)).hexdigest()==sha for n,sha in manifest.items())
print(hashlib.sha256(archive.read_bytes()).hexdigest())
