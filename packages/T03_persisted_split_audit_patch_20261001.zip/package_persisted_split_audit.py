import hashlib,json,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
files=['research_v3/data/model_exposure_journal_v1.py','research_v3/data/splits.py','research_v3/tests/test_model_exposure_journal.py']
receipt={'status':'reference_checked_native_open','tests_passed':7,
 'command':'python -m unittest research_v3.tests.test_model_exposure_journal -q',
 'scope':'snapshot contains split audit from actual persisted keys; forged counts rejected on read-only validation',
 'molab_ui_observation':{'notebook_id':'nb_8eGbJsWtQ1MTcdvGhr4FEU','cell':'TTjf','state':'Interrupted','last_log_position':501,'child_pid':5442,'child_state':'unknown','restarted':False},
 'open':['native process state verification','native snapshot/journal throughput','production split audit'],
 'source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}}
name='T03_PERSISTED_SPLIT_AUDIT_REFERENCE_GATE_2026-10-01.json'
with (root/name).open('x',encoding='utf-8') as output:json.dump(receipt,output,indent=2)
files += [name,'package_persisted_split_audit.py']
manifest={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}
archive=root/'T03_persisted_split_audit_patch_20261001.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as output:
 for n in files:output.write(root/n,n)
 output.writestr('source_manifest.json',json.dumps({'files':manifest,'status':receipt['status']},indent=2))
with zipfile.ZipFile(archive) as check:
 assert check.testzip() is None
 assert all(hashlib.sha256(check.read(n)).hexdigest()==sha for n,sha in manifest.items())
print(hashlib.sha256(archive.read_bytes()).hexdigest())
