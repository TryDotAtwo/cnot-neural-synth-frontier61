import unittest
from dataclasses import replace
from types import SimpleNamespace
from unittest.mock import Mock
import torch
from research_v3.gpu.neural_beam import neural_field_callbacks
from research_v3.train.neural_refresh_solver_v13 import NeuralRefreshSolver
from research_v3.contracts import AlphabetSpec, Gate
from research_v3.data.generators import record_from_word


class RefreshForwardAdmissionTests(unittest.TestCase):
    def test_immutable_contract_binds_complete_bank_content(self):
        bank = SimpleNamespace(sorted_rows=torch.zeros((2, 3, 1), dtype=torch.int64),
                               sorted_hashes=torch.zeros(2, dtype=torch.int64),
                               hash_weights=torch.ones((3, 1), dtype=torch.int64))
        solver = NeuralRefreshSolver(torch.nn.Linear(1, 1),
            search_config=dict(beam_width=1, shortlist=1, max_depth=1,
                               inference_batch=1, max_expanded=1),
            field_config=dict(mc_samples=1, mc_seed=1, max_pair_states=1, head='qhat'),
            source_sha256={}, holdout_banks={3: bank})
        before = solver.immutable_contract()
        self.assertEqual(len(before['holdout_state_sha256']), 64)
        for tensor in (bank.sorted_rows, bank.sorted_hashes, bank.hash_weights):
            tensor.reshape(-1)[-1] += 1
            after = solver.immutable_contract()
            self.assertNotEqual(before['holdout_state_sha256'], after['holdout_state_sha256'])
            before = after

    def test_refresh_without_frozen_bank_rejected_before_model_access(self):
        model = Mock()
        solver = NeuralRefreshSolver(model,
            search_config=dict(beam_width=1, shortlist=1, max_depth=1,
                               inference_batch=1, max_expanded=1),
            field_config=dict(mc_samples=1, mc_seed=1, max_pair_states=1, head='qhat'),
            source_sha256={})
        record = record_from_word(AlphabetSpec.all_to_all(3), (Gate(0, 1),),
                                  'train:admission', 1, source='ordinary_walk_v1')
        record = replace(record, split='train')
        with self.assertRaisesRegex(ValueError, 'frozen holdout bank'):
            solver(record, 0)
        self.assertEqual(model.mock_calls, [])

    def test_both_callbacks_reject_before_feature_or_model_forward(self):
        model = Mock()
        def reject(rows):
            raise ValueError('forbidden full matrix')
        callbacks = neural_field_callbacks(model, mc_samples=1, mc_seed=1,
                                           max_pair_states=1, admission=reject)
        for callback in callbacks:
            with self.assertRaisesRegex(ValueError, 'forbidden full matrix'):
                callback(torch.zeros((2, 3, 1), dtype=torch.int64))
        self.assertEqual(model.mock_calls, [])


if __name__ == '__main__':
    unittest.main()
