"""Publishable own T03 forward-admission candidate; CPU contract evidence only."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile

root = Path(__file__).resolve().parent
files = [
    'research_v3/gpu/neural_beam.py',
    'research_v3/objectives/bellman.py',
    'research_v3/train/component_contract_v13.py',
    'research_v3/train/checkpoint.py',
    'research_v3/train/schedule.py',
    'research_v3/tests/test_bellman_macro_admission.py',
    'research_v3/tests/test_T06_gradients.py',
    'research_v3/tests/test_T12_objective.py',
    'research_v3/train/neural_refresh_solver_v13.py',
    'research_v3/tests/test_refresh_forward_admission.py',
    'research_v3/tests/test_neural_refresh_solver_v13.py',
    'research_v3/tests/test_cuda_joint_resume_v13.py',
]
command = [sys.executable, '-B', '-m', 'unittest',
           'research_v3.tests.test_refresh_forward_admission',
           'research_v3.tests.test_neural_refresh_solver_v13.NeuralRefreshContractTests',
           'research_v3.tests.test_bellman_macro_admission',
           'research_v3.tests.test_T06_gradients', 'research_v3.tests.test_T12_objective', '-v']
result = subprocess.run(command, cwd=root, capture_output=True, text=True)
receipt = dict(schema='T03_refresh_forward_admission_candidate_v3',
               command=command, returncode=result.returncode,
               stdout=result.stdout, stderr=result.stderr,
               source_sha256={name: hashlib.sha256((root/name).read_bytes()).hexdigest()
                              for name in files},
               scope='CPU full-batch primitive/macro preflight, callback admission, exact bank-byte contract and checkpoint restore refusal; no CUDA or production acceptance',
               prior_candidate_v2='Preserved negative result: added top-level contract key violated strict component schema; V3 stores digest within config and tests actual checkpoint restore',
               open=['actual sealed-loader bank provenance and restore transaction',
                     'actual CUDA nonempty bank rejection and exposure audit',
                     'paid macros connected to production objective and exposure sets'],
               diagnostic_cuda_tests='explicit empty bank fixtures only; no unseen-panel claim')
name = 'T03_REFRESH_FORWARD_ADMISSION_V3_2026-10-01.json'
(root/name).write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding='utf-8')
if result.returncode:
    raise SystemExit(result.returncode)
archive = root/'T03_refresh_admission_candidate_v3.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as output:
    for member in files + [name, 'package_refresh_admission_v3.py']:
        output.write(root/member, member)
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
print(json.dumps(dict(path=str(archive), sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
                      tests=24, returncode=result.returncode)))
