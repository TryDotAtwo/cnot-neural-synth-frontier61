import hashlib,json,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
files=['research_v3/data/splits.py','research_v3/tests/test_T03_data.py']
receipt={'status':'reference_checked_native_panel_open','tests_passed':9,
 'command':'python -B -m unittest research_v3.tests.test_T03_data.DataTests.test_split_report_distinguishes_transductive_and_pins_full_sets research_v3.tests.test_T03_data.DataTests.test_neighbor_exposure_excludes_parent research_v3.tests.test_T12_objective -q',
 'requirement':'T03 split report publishes label-held-out, transductive, strict unseen and hashes',
 'scope':'exact full-key set hashes; finite supplied augmentation bank; no orbit canonicalization claim',
 'open':['full mandated T03 gate','native sealed panels','actual production exposure report'],
 'source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}}
name='T03_SPLIT_AUDIT_V2_REFERENCE_GATE_2026-10-01.json'
with (root/name).open('x',encoding='utf-8') as output:json.dump(receipt,output,indent=2)
ledger=json.loads((root/'NORMATIVE_REQUIREMENT_STATUS_V30_2026-10-01.json').read_text(encoding='utf-8'))
ledger['split_audit_v2_update']=receipt
ledger_name='NORMATIVE_REQUIREMENT_STATUS_V31_2026-10-01.json'
with (root/ledger_name).open('x',encoding='utf-8') as output:json.dump(ledger,output,ensure_ascii=False,indent=2)
files += [name,ledger_name,'package_split_audit_v2.py']
manifest={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}
archive=root/'T03_split_audit_v2_patch_20261001.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as output:
 for n in files:output.write(root/n,n)
 output.writestr('source_manifest.json',json.dumps({'files':manifest,'status':receipt['status']},indent=2))
with zipfile.ZipFile(archive) as check:
 assert check.testzip() is None
 assert all(hashlib.sha256(check.read(n)).hexdigest()==sha for n,sha in manifest.items())
print(hashlib.sha256(archive.read_bytes()).hexdigest())
