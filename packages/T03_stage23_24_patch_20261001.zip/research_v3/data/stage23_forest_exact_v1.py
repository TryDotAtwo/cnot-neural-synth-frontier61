"""Own full-matrix forest recognizer; stage23B sections1-2 unit alphabet.

Only the forest family receives a global exact-distance label. This does not
claim a full GL(n,2) field, weighted synthesis or the later branch families.
"""
from dataclasses import dataclass, replace
import random
from .records import SampleRecord
from ..contracts import AlphabetSpec, MatrixState, Gate, WordCertificate
from ..gf2 import inverse
from ..words import verify_word

SOURCE_NOTES_SHA256 = '224c1348f8696d71ea33525e9f9b287ceb298ae347a8a5888610406bbd311e07'


@dataclass(frozen=True)
class ForestResult:
    status: str
    state: MatrixState
    scope_id: str
    distance: int | None
    word: WordCertificate | None
    hypotheses: dict
    witness: dict
    reason: str | None = None


def recognize(state, alphabet):
    if state.n != alphabet.n or state.alphabet_id != alphabet.id:
        raise ValueError('state/alphabet mismatch')
    def unsupported(reason):
        return ForestResult('unsupported', state, alphabet.id, None, None, {}, {}, reason)
    if state.n < 2 or alphabet != AlphabetSpec.all_to_all(state.n):
        return unsupported('requires n>=2 and complete unit-cost all-to-all CNOT')
    inv = inverse(state.packed_rows)
    parents = []
    for i, row in enumerate(inv):
        edge = row ^ (1 << i)
        if edge and (edge & (edge - 1) or edge & (1 << i)):
            return unsupported('I+M inverse has a non-parent row')
        parents.append(edge.bit_length() - 1 if edge else None)
    reconstructed, depths = [], []
    for i in range(state.n):
        row, current, seen = 0, i, set()
        while current is not None:
            if current in seen:
                return unsupported('parent links contain a cycle')
            seen.add(current)
            row ^= 1 << current
            current = parents[current]
        reconstructed.append(row)
        depths.append(len(seen) - 1)
    if tuple(reconstructed) != state.packed_rows:
        return unsupported('ancestor reconstruction differs from full input')
    order = tuple(sorted((i for i,p in enumerate(parents) if p is not None),
                         key=lambda i: (depths[i], i)))
    # The theorem constructs I->M parent-first; reverse the whole word for M->I.
    gates = tuple(Gate(parents[i], i) for i in reversed(order))
    lower_bound = sum(row != 1 << i for i,row in enumerate(state.packed_rows))
    assert lower_bound == len(gates)
    word = WordCertificate(state, MatrixState.identity(alphabet), gates, len(gates),
                           'stage23_forest_exact_v1', f'stage23:{state.n}:{state.packed_rows}')
    verify_word(word, alphabet)
    return ForestResult('exact', state, alphabet.id, len(gates), word,
                        {'full_unit_all_to_all':True, 'parent_forest':True,
                         'full_matrix_reconstructed':True, 'source_notes_sha256':SOURCE_NOTES_SHA256},
                        {'parents':tuple(parents), 'construction_order':order,
                         'changed_row_lower_bound':lower_bound})


def verify_result(result, alphabet):
    expected = recognize(result.state, alphabet)
    if result != expected:
        raise ValueError('stage23 result failed full re-recognition')
    return result.status == 'exact'


def generate(seed, n, *, split):
    if type(seed) is not int or type(n) is not int or n < 2 or split not in ('train','dev','test'):
        raise ValueError('invalid forest-family input')
    rng = random.Random(seed)
    order = list(range(n))
    rng.shuffle(order)
    parents = [None] * n
    for k, wire in enumerate(order):
        if k and rng.randrange(4):
            parents[wire] = rng.choice(order[:k])
    rows = []
    for wire in range(n):
        row, current = 0, wire
        while current is not None:
            row ^= 1 << current
            current = parents[current]
        rows.append(row)
    alphabet = AlphabetSpec.all_to_all(n)
    result = recognize(MatrixState(n, tuple(rows), alphabet.id), alphabet)
    if not verify_result(result, alphabet):
        raise AssertionError('generated forest failed recognition')
    return result


def ingest_exact(replay, result, *, seed, split):
    if type(seed) is not int or split not in ('train','dev','test'):
        raise ValueError('invalid forest lineage')
    if not verify_result(result, replay.alphabet):
        raise ValueError('unsupported forest exact result')
    if result.state.key in replay.forbidden_keys:
        raise ValueError('forbidden holdout label')
    old = replay.records.get(result.state.key)
    if old is not None and old.exact_distance is not None and old.exact_distance != result.distance:
        raise ValueError('conflicting exact distance')
    record = SampleRecord(result.state, (result.word,),
                          f'stage23:{split}:{seed}:{result.state.n}', seed,
                          'stage23_forest_exact_v1', split)
    replay.merge((record,))
    current = replay.records[result.state.key]
    replay.records[result.state.key] = replace(current, exact_distance=result.distance,
        exact_evidence='stage23_forest_theorem_sha256:' + SOURCE_NOTES_SHA256)
    return replay.records[result.state.key]
