"""Own recognizer of stage24 sections1-2 moving-root forest, fixed wires.

Produces a full reduction saturating the changed-row lower bound. No claim
about the finite-temperature field or all geodesic branch statistics.
"""
from .stage23_forest_exact_v1 import ForestResult
from ..contracts import AlphabetSpec, MatrixState, Gate, WordCertificate
from ..words import verify_word
from dataclasses import replace
import random
from .records import SampleRecord

SOURCE_NOTES_SHA256 = '2cdf10324be442405af7cc45ccaa1a5d825f75897b750f526d2d21840586aea1'


def recognize(state, alphabet):
    if state.n != alphabet.n or state.alphabet_id != alphabet.id:
        raise ValueError('state/alphabet mismatch')
    def unsupported(reason):
        return ForestResult('unsupported',state,alphabet.id,None,None,{}, {},reason)
    if state.n < 2 or alphabet != AlphabetSpec.all_to_all(state.n):
        return unsupported('requires full unit all-to-all CNOT')
    rows = state.packed_rows
    lookup = {row:i for i,row in enumerate(rows)}
    for a in range(state.n):
        if rows[a].bit_count() != 1:
            continue
        b = rows[a].bit_length()-1
        if a == b or rows[b] != (1<<a) ^ (1<<b):
            continue
        active = {i for i,row in enumerate(rows) if row != 1<<i} - {a,b}
        parents = {}
        valid = True
        for v in active:
            diff = rows[v] ^ (1<<v)
            if diff == 1<<b:
                parents[v] = b
            else:
                parent = lookup.get(diff)
                if parent not in active or parent == v:
                    valid = False
                    break
                parents[v] = parent
        if not valid:
            continue
        depths = {}
        for v in active:
            ancestor_bits, current, seen = 1<<v, parents[v], {v}
            while current != b:
                if current in seen or current not in active:
                    valid = False
                    break
                seen.add(current)
                ancestor_bits ^= 1<<current
                current = parents[current]
            if not valid or ancestor_bits ^ (1<<b) != rows[v]:
                valid = False
                break
            depths[v] = len(seen)
        if not valid:
            continue
        order = tuple(sorted(active,key=lambda v:(depths[v],v)))
        construction = (Gate(a,b),Gate(b,a)) + tuple(
            Gate(a if parents[v]==b else parents[v],v) for v in order)
        lower = sum(row != 1<<i for i,row in enumerate(rows))
        if len(construction) != lower:
            raise AssertionError('moving-root lower bound mismatch')
        word = WordCertificate(state,MatrixState.identity(alphabet),
            tuple(reversed(construction)),lower,'stage24_moving_root_exact_v1',
            f'stage24:{state.n}:{state.packed_rows}')
        verify_word(word,alphabet)
        return ForestResult('exact',state,alphabet.id,lower,word,
            {'full_unit_all_to_all':True,'full_matrix_reconstructed':True,
             'source_notes_sha256':SOURCE_NOTES_SHA256},
            {'core':(a,b),'parents':tuple(sorted(parents.items())),
             'construction_order':order,'changed_row_lower_bound':lower})
    return unsupported('matrix outside moving-root forest family')


def verify_result(result, alphabet):
    if recognize(result.state,alphabet) != result:
        raise ValueError('stage24 result failed re-recognition')
    return result.status == 'exact'


def generate(seed,n,*,split):
    if type(seed) is not int or type(n) is not int or n<2 or split not in ('train','dev','test'):
        raise ValueError('invalid moving-root family input')
    rng=random.Random(seed)
    order=list(range(n));rng.shuffle(order)
    a,b=order[:2]
    rows=[1<<i for i in range(n)]
    rows[a]=1<<b
    rows[b]=(1<<a)^(1<<b)
    active=[]
    for v in order[2:]:
        if rng.randrange(4)==0:
            continue
        parent=rng.choice([b]+active)
        rows[v]=(1<<v)^((1<<b) if parent==b else rows[parent])
        active.append(v)
    alphabet=AlphabetSpec.all_to_all(n)
    result=recognize(MatrixState(n,tuple(rows),alphabet.id),alphabet)
    if not verify_result(result,alphabet):
        raise AssertionError('generated moving-root forest failed recognition')
    return result


def ingest_exact(replay,result,*,seed,split):
    if type(seed) is not int or split not in ('train','dev','test'):
        raise ValueError('invalid moving-root lineage')
    if not verify_result(result,replay.alphabet):
        raise ValueError('unsupported moving-root exact result')
    if result.state.key in replay.forbidden_keys:
        raise ValueError('forbidden holdout label')
    old=replay.records.get(result.state.key)
    if old is not None and old.exact_distance is not None and old.exact_distance!=result.distance:
        raise ValueError('conflicting exact distance')
    record=SampleRecord(result.state,(result.word,),f'stage24:{split}:{seed}:{result.state.n}',
                        seed,'stage24_moving_root_exact_v1',split)
    replay.merge((record,))
    current=replay.records[result.state.key]
    replay.records[result.state.key]=replace(current,exact_distance=result.distance,
        exact_evidence='stage24_moving_root_theorem_sha256:'+SOURCE_NOTES_SHA256)
    return replay.records[result.state.key]
