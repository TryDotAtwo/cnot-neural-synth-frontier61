import unittest
from research_v3.contracts import AlphabetSpec, MatrixState, Gate
from research_v3.data.exact_small import build_exact_small
from research_v3.data.stage23_forest_exact_v1 import recognize, generate, verify_result, ingest_exact
from research_v3.data.replay import Replay
from dataclasses import replace
from dataclasses import asdict
import json
from research_v3.data.stream_reader_v13 import decode_record
from research_v3.words import verify_word


class ForestAdmissionTests(unittest.TestCase):
    def test_all_gl3_accepted_words_have_global_distance(self):
        alphabet = AlphabetSpec.all_to_all(3)
        catalog = build_exact_small(3, alphabet)
        accepted = 0
        for state, distance in catalog.distances.items():
            result = recognize(state, alphabet)
            if result.status == 'exact':
                verify_word(result.word, alphabet)
                self.assertEqual(result.distance, distance)
                self.assertEqual(result.word.physical_cost, distance)
                accepted += 1
            else:
                self.assertEqual(result.status, 'unsupported')
                self.assertIsNone(result.distance)
        self.assertEqual(accepted, 16)

    def test_non_topological_physical_labels(self):
        alphabet = AlphabetSpec.all_to_all(4)
        # Root 3 -> 1 -> 0 -> 2, deliberately not in label order.
        state = MatrixState(4, (11, 10, 15, 8), alphabet.id)
        result = recognize(state, alphabet)
        self.assertEqual(result.status, 'exact')
        self.assertEqual(result.distance, 3)
        verify_word(result.word, alphabet)

    def test_other_alphabets_never_get_exact_labels(self):
        for alphabet in (AlphabetSpec(2, (Gate(0, 1),), (1,), 'restricted'),
                         AlphabetSpec(2, (Gate(0, 1), Gate(1, 0)), (2, 2), 'weighted')):
            result = recognize(MatrixState.identity(alphabet), alphabet)
            self.assertEqual(result.status, 'unsupported')
            self.assertIsNone(result.distance)

    def test_generated_labels_and_replay_are_reverified(self):
        for n in (2, 3, 8):
            alphabet = AlphabetSpec.all_to_all(n)
            result = generate(1700 + n, n, split='dev')
            self.assertTrue(verify_result(result, alphabet))
            replay = Replay(alphabet)
            record = ingest_exact(replay, result, seed=1700+n, split='dev')
            self.assertEqual(record.exact_distance, record.upper_bound)
            self.assertEqual(record.split, 'dev')
            with self.assertRaises(ValueError):
                verify_result(replace(result, distance=result.distance+1), alphabet)
            blocked = Replay(alphabet, forbidden_keys={result.state.key})
            with self.assertRaises(ValueError):
                ingest_exact(blocked, result, seed=1700+n, split='train')
            self.assertFalse(blocked.records)

    def test_reader_roundtrip_and_tampered_certificate_rejection(self):
        result = generate(1723, 8, split='dev')
        record = ingest_exact(Replay(AlphabetSpec.all_to_all(8)), result, seed=1723, split='dev')
        self.assertEqual(decode_record(json.dumps(asdict(record))), record)
        for change in ({'exact_distance':record.exact_distance+1},
                       {'exact_evidence':'stage23_forest_theorem_sha256:bogus'},
                       {'source':'unverified_forest'}):
            with self.subTest(change=change), self.assertRaises(ValueError):
                decode_record(json.dumps(asdict(replace(record, **change))))
        damaged = replace(record.verified_words[0], gates=(), physical_cost=0)
        with self.assertRaises(ValueError):
            decode_record(json.dumps(asdict(replace(record, verified_words=(damaged,)))))


if __name__ == '__main__':
    unittest.main()
