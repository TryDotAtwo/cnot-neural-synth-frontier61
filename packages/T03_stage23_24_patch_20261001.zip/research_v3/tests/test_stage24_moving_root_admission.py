import unittest
from research_v3.contracts import AlphabetSpec, MatrixState, Gate
from research_v3.data.exact_small import build_exact_small
from research_v3.data.stage24_moving_root_exact_v1 import recognize, generate, ingest_exact
from research_v3.data.replay import Replay
from research_v3.data.stream_reader_v13 import decode_record
from dataclasses import asdict, replace
import json
from research_v3.words import verify_word


class MovingRootAdmissionTests(unittest.TestCase):
    def test_recognized_gl3_distances_match_complete_catalog(self):
        a = AlphabetSpec.all_to_all(3)
        catalog = build_exact_small(3, a)
        accepted = 0
        for state, distance in catalog.distances.items():
            result = recognize(state, a)
            if result.status == 'exact':
                verify_word(result.word, a)
                self.assertEqual(result.distance, distance)
                accepted += 1
            else:
                self.assertEqual(result.status, 'unsupported')
                self.assertIsNone(result.distance)
        self.assertGreaterEqual(accepted, 6)

    def test_full_non_topological_forest_and_inactive_wire(self):
        a = AlphabetSpec.all_to_all(6)
        # Core a=4,b=1, forest root3->0->2; inactive5.
        state = MatrixState(6, (11,18,15,10,2,32), a.id)
        result = recognize(state,a)
        self.assertEqual(result.status,'exact')
        self.assertEqual(result.distance,5)
        verify_word(result.word,a)

    def test_restricted_and_weighted_are_unsupported(self):
        for a in (AlphabetSpec(2,(Gate(0,1),),(1,),'restricted'),
                  AlphabetSpec(2,(Gate(0,1),Gate(1,0)),(2,2),'weighted')):
            self.assertEqual(recognize(MatrixState.identity(a),a).status,'unsupported')

    def test_generated_exact_records_and_reader_tamper_rejection(self):
        for n in (2,3,8):
            a=AlphabetSpec.all_to_all(n)
            result=generate(1724,n,split='dev')
            record=ingest_exact(Replay(a),result,seed=1724,split='dev')
            self.assertEqual(decode_record(json.dumps(asdict(record))),record)
            for change in ({'exact_distance':record.exact_distance+1},
                           {'exact_evidence':'bogus'},{'source':'unverified'}):
                with self.subTest(n=n,change=change), self.assertRaises(ValueError):
                    decode_record(json.dumps(asdict(replace(record,**change))))
            blocked=Replay(a,forbidden_keys={record.state.key})
            with self.assertRaises(ValueError):
                ingest_exact(blocked,result,seed=1724,split='train')
            self.assertFalse(blocked.records)
