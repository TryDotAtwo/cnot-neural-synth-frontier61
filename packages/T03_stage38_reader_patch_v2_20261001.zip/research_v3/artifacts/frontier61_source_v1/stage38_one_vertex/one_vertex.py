"""Exact contraction of the one-excess CNOT vertex between full endpoints.

The computation sums unknown intermediate currents and temporal order factors,
not intermediate GL matrices or CNOT words.  The contraction is polynomial for
bounded temporal elimination width; NO uniform width bound is claimed.
All arithmetic in certificates is integer. NumPy is used for object arrays.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from math import comb, factorial
from time import perf_counter
from typing import Sequence
import numpy as np

Rows = tuple[int, ...]
Gate = tuple[int, int]
History = tuple[tuple[int, ...], ...]
Constraint = tuple[int, int]

class ContractionBudgetExceeded(RuntimeError):
    """A positive/zero answer is NOT returned if exact contraction was skipped."""

@dataclass(frozen=True)
class Factor:
    # Sum of products of strict comparisons t_a < t_b.
    terms: tuple[tuple[Constraint, ...], ...]
    @property
    def scope(self):
        return tuple(sorted({i for term in self.terms for pair in term for i in pair}))

@dataclass
class CountResult:
    count: int
    events: int
    max_bag: int = 0
    components: int = 0
    lattice_values: list = field(default_factory=list)
    reason: str = ''

@dataclass
class VertexResult:
    count: int
    changed: int
    templates: int
    positive_templates: list
    max_bag: int
    gates: list[Gate] = field(default_factory=list)
    seconds: float = 0.
    transport_free: bool = False


def check_rows(rows: Sequence[int]) -> Rows:
    a=tuple(rows); n=len(a)
    if not n or any(type(x) is not int or not 0<x<(1<<n) for x in a):
        raise ValueError('expected nonzero n-bit integer rows')
    piv={}
    for row in a:
        x=row
        while x:
            j=x.bit_length()-1
            if j in piv: x^=piv[j]
            else: piv[j]=x;break
    if len(piv)!=n:raise ValueError('singular endpoint')
    return a


def apply(a: Sequence[int], gates: Sequence[Gate]) -> Rows:
    out=list(a);n=len(out)
    for c,t in gates:
        if not(0<=c<n and 0<=t<n and c!=t):raise ValueError('invalid CNOT')
        out[t]^=out[c]
    return tuple(out)


def history_factors(histories: History):
    n=len(histories)
    check_rows(tuple(h[0] for h in histories));check_rows(tuple(h[-1] for h in histories))
    if any(any(type(v) is not int or not 0<v<(1<<n) for v in h) for h in histories):
        raise ValueError('invalid intermediate row value')
    if any(any(x==y for x,y in zip(h,h[1:])) for h in histories):
        raise ValueError('an event may not leave its target unchanged')
    event=[]; labels={}
    for i,h in enumerate(histories):
        for r in range(len(h)-1):
            labels[i,r]=len(event);event.append((i,r))
    factors=[]
    for i,h in enumerate(histories):
        for r in range(len(h)-2):
            factors.append(Factor((((labels[i,r],labels[i,r+1]),),)))
    for e,(i,r) in enumerate(event):
        delta=histories[i][r]^histories[i][r+1]
        terms=[]
        for j,h in enumerate(histories):
            if j==i:continue
            for a,v in enumerate(h):
                if v!=delta:continue
                term=[]
                if a:term.append((labels[j,a-1],e))
                if a<len(h)-1:term.append((e,labels[j,a]))
                terms.append(tuple(sorted(term)))
        factors.append(Factor(tuple(terms)))
    # Duplicate deterministic indicators multiply to themselves.
    seen=set();filtered=[]
    for f in factors:
        if len(f.terms)==1:
            if f in seen:continue
            seen.add(f)
        filtered.append(f)
    return event,filtered


def _mandatory_cycle(k, factors):
    edges=set()
    for f in factors:
        if f.terms:
            mandatory=set(f.terms[0])
            for term in f.terms[1:]:mandatory.intersection_update(term)
            edges.update(mandatory)
    out=[set() for _ in range(k)];indeg=[0]*k
    for a,b in edges:
        if b not in out[a]:out[a].add(b);indeg[b]+=1
    stack=[i for i in range(k) if not indeg[i]];num=0
    while stack:
        v=stack.pop();num+=1
        for w in out[v]:
            indeg[w]-=1
            if not indeg[w]:stack.append(w)
    return num<k


def _components(k,factors):
    adj=[set() for _ in range(k)]
    for f in factors:
        s=f.scope
        for a in s:adj[a].update(set(s)-{a})
    comps=[];seen=set()
    for a in range(k):
        if a in seen:continue
        todo=[a];seen.add(a);comp=[]
        while todo:
            v=todo.pop();comp.append(v)
            for w in adj[v]:
                if w not in seen:seen.add(w);todo.append(w)
        comps.append(tuple(sorted(comp)))
    return comps


def elimination_order(vertices,factors,protected=frozenset()):
    adj={v:set() for v in vertices}
    for f in factors:
        for v in f.scope:adj[v].update(set(f.scope)-{v})
    # Certify that after retaining the repeated-row times the remaining
    # graph is a pseudoforest. Eliminate its degree <=2 vertices first.
    protected=set(protected)&set(vertices)
    remaining=set(vertices)-protected
    seen=set();pseudoforest=True
    for start in remaining:
        if start in seen:continue
        todo=[start];seen.add(start);nv=0;degree_sum=0
        while todo:
            v=todo.pop();nv+=1
            nn=adj[v]&remaining;degree_sum+=len(nn)
            for w in nn:
                if w not in seen:seen.add(w);todo.append(w)
        if degree_sum//2>nv:pseudoforest=False
    use_protected=bool(protected) and pseudoforest
    order=[];max_bag=0
    while adj:
        def key(v):
            neigh=adj[v]
            fill=sum(b not in adj[a] for a in neigh for b in neigh if a<b)
            return fill,len(neigh),v
        pool=set(adj)-protected if use_protected else set()
        if pool:
            v=min(pool,key=lambda a:(len(adj[a]-protected),key(a)))
            if len(adj[v]-protected)>2:raise AssertionError('pseudoforest elimination failed')
        else:v=min(adj,key=key)
        nn=adj[v].copy();max_bag=max(max_bag,len(nn)+1)
        order.append(v)
        for a in nn:
            adj[a].update(nn-{a});adj[a].discard(v)
        del adj[v]
    return tuple(order),max_bag


def _table(f: Factor,q: int,max_entries: int):
    s=f.scope
    if q**len(s)>max_entries:
        raise ContractionBudgetExceeded(f'factor table requires {q**len(s)} entries')
    if not s:return s,np.array(len(f.terms),dtype=object)
    pos={v:i for i,v in enumerate(s)}
    # Boolean factors are small, exact counts are arbitrary precision integers.
    arr=np.zeros((q,)*len(s),dtype=object)
    coords={v:np.arange(q).reshape(tuple(q if j==pos[v] else 1 for j in range(len(s)))) for v in s}
    for term in f.terms:
        value=True
        for a,b in term:value=np.logical_and(value,coords[a]<coords[b])
        arr+=value
    return s,arr


def _lattice_sum(q,vertices,factors,order,max_entries):
    tables=[_table(f,q,max_entries) for f in factors]
    for v in order:
        selected=[(s,a) for s,a in tables if v in s]
        tables=[(s,a) for s,a in tables if v not in s]
        if not selected:
            tables.append(((),np.array(q,dtype=object)));continue
        joint=tuple(sorted({j for s,a in selected for j in s}))
        if q**len(joint)>max_entries:
            raise ContractionBudgetExceeded(f'elimination bag requires {q**len(joint)} entries')
        prod=np.ones((q,)*len(joint),dtype=object)
        for s,a in selected:
            shape=tuple(q if j in s else 1 for j in joint)
            prod*=a.reshape(shape)
        axis=joint.index(v)
        reduced=prod.sum(axis=axis)
        tables.append((tuple(j for j in joint if j!=v),reduced))
    ans=1
    for s,a in tables:
        if s:raise AssertionError('uncontracted variable')
        ans*=int(a)
    return ans


def count_histories(histories: Sequence[Sequence[int]], *, max_entries: int=2_000_000,
                    keep_lattice: bool=False, protected_rows: frozenset[int]=frozenset()) -> CountResult:
    """Count ALL CNOT words following the given per-row value histories.

    The temporal graph is derived from possible controls, not supplied as a
    chosen CNOT dependency graph. All control choices and all orders are summed.
    No endpoint-state enumeration is performed. Worst-case cost depends on the
    measured elimination-bag size. Large contractions explicitly raise an error.
    """
    h=tuple(tuple(v for v in row) for row in histories)
    if not h or any(not row for row in h):raise ValueError('empty row history')
    events,factors=history_factors(h);k=len(events)
    if any(not f.terms for f in factors):return CountResult(0,k,reason='missing control')
    if _mandatory_cycle(k,factors):return CountResult(0,k,reason='mandatory temporal cycle')
    const=1;active=[]
    for f in factors:
        if not f.scope:const*=len(f.terms)
        else:active.append(f)
    if not k:return CountResult(const,0,reason='identity')
    comps=_components(k,active);counts=[];bags=[];lattice=[]
    retained_rows=set(protected_rows)|{i for i,row in enumerate(h) if len(row)>2}
    protected_events={e for e,(i,r) in enumerate(events) if i in retained_rows}
    for cc in comps:
        fc=[f for f in active if set(f.scope).issubset(cc)]
        order,bag=elimination_order(cc,fc,protected_events);bags.append(bag)
        m=len(cc)
        if m**bag>max_entries:
            raise ContractionBudgetExceeded(f'{m} events, bag {bag}: {m**bag} entries')
        values=[0]+[_lattice_sum(q,cc,fc,order,max_entries) for q in range(1,m+1)]
        num=sum((-1)**(m-q)*comb(m,q)*values[q] for q in range(m+1))
        if num<0:raise AssertionError('negative exact leading coefficient')
        counts.append(num)
        if keep_lattice:lattice.append({'events':list(cc),'values':values,'count':num,'order':list(order),'bag':bag})
        if not num:return CountResult(0,k,max(bags),len(comps),lattice,'zero temporal volume')
    # Integral factors across components; restore all interleavings.
    answer=const*factorial(k)
    denom=1
    for cc,num in zip(comps,counts):answer*=num;denom*=factorial(len(cc))
    if answer%denom:raise AssertionError('noninteger amplitude')
    return CountResult(answer//denom,k,max(bags),len(comps),lattice,'exact')


def recover_histories(histories: Sequence[Sequence[int]], *, max_entries=2_000_000):
    """Polynomially many count-oracle calls; no backtracking over CNOT words."""
    h=tuple(tuple(row) for row in histories)
    if count_histories(h,max_entries=max_entries).count==0:raise ValueError('zero amplitude')
    gates=[];protected=frozenset(i for i,row in enumerate(h) if len(row)>2)
    while any(len(row)>1 for row in h):
        current=tuple(row[0] for row in h);lookup={v:i for i,v in enumerate(current)}
        for i,row in enumerate(h):
            if len(row)==1:continue
            c=lookup.get(row[0]^row[1])
            if c is None or c==i:continue
            updated=list(h);updated[i]=row[1:];updated=tuple(updated)
            if count_histories(updated,max_entries=max_entries,protected_rows=protected).count:
                gates.append((c,i));h=updated;break
        else:raise AssertionError('positive amplitude without continuation')
    return gates


def one_excess(a: Sequence[int],b: Sequence[int], *, witness: bool=False,
               max_entries: int=2_000_000) -> VertexResult:
    """Return a_(r+1)(B,A) = [P0 H1 P0]_(B,A), height measured to B.

    r counts unequal rows. For r+1 gates exactly one changed row is updated
    twice and all other changed rows once. Its intermediate value belongs to
    the polynomial candidate set a_i + (initial/final control values).
    """
    start=perf_counter();a=check_rows(a);b=check_rows(b)
    if len(a)!=len(b):raise ValueError('dimensions differ')
    changed=[i for i in range(len(a)) if a[i]!=b[i]]
    total=0;templates=0;positives=[];maxbag=0;chosen=None
    for t in changed:
        endpoints={v for j in range(len(a)) if j!=t for v in (a[j],b[j])}
        candidate=sorted({a[t]^v for v in endpoints}-{0,a[t],b[t]})
        for p in candidate:
            if p^b[t] not in endpoints:continue
            histories=tuple((a[i],p,b[i]) if i==t else
                            ((a[i],b[i]) if a[i]!=b[i] else (a[i],)) for i in range(len(a)))
            templates+=1
            result=count_histories(histories,max_entries=max_entries)
            maxbag=max(maxbag,result.max_bag);total+=result.count
            if result.count:
                positives.append({'target':t,'intermediate':p,'count':result.count,
                                  'max_bag':result.max_bag})
                if chosen is None:chosen=histories
    gates=recover_histories(chosen,max_entries=max_entries) if witness and chosen is not None else []
    if gates and (len(gates)!=len(changed)+1 or apply(a,gates)!=b):
        raise AssertionError('invalid recovered word')
    transport_free=all(a[i]!=b[j] for i in range(len(a)) for j in range(len(a)) if i!=j)
    if transport_free and maxbag>5:raise AssertionError('proved width bound violated')
    return VertexResult(total,len(changed),templates,positives,maxbag,gates,perf_counter()-start,transport_free)
