"""Guarded, complete-neighbour-admitted reads of the 1000-epoch v13 stream."""
import json
from .stream_reader import decode_record as _decode_record, _decode_row
from .stage18_bipartite_exact_v1 import recognize as recognize_graph, verify_result as verify_graph, SOURCE_NOTES_SHA256
from .stage35_pair_exact_v1 import recognize as recognize_pair, verify_result as verify_pair, SOURCE_SHA256
from ..contracts import AlphabetSpec
from .stage37_zero_excess_exact_v1 import recognize as recognize_zero, verify_result as verify_zero, SOURCE_NOTES_SHA256 as ZERO_SHA
from .symmetry_records import augment_record, deterministic_transform
from .stage23_forest_exact_v1 import recognize as recognize_forest, verify_result as verify_forest, SOURCE_NOTES_SHA256 as FOREST_SHA
from .stage24_moving_root_exact_v1 import recognize as recognize_moving_root, verify_result as verify_moving_root, SOURCE_NOTES_SHA256 as MOVING_ROOT_SHA
from .stage25_swap_forest_exact_v1 import recognize as recognize_swap_forest, verify_result as verify_swap_forest, SOURCE_NOTES_SHA256 as SWAP_FOREST_SHA
from .stage36_saturated_frame_exact_v1 import recognize as recognize_saturated_frame, verify_result as verify_saturated_frame, SOURCE_NOTES_SHA256 as SATURATED_FRAME_SHA
from .stage38_one_excess_exact_v1 import recognize as recognize_one_excess, verify_result as verify_one_excess, SOURCE_NOTES_SHA256 as ONE_EXCESS_SHA

def validate_exact(record):
    if record.exact_distance is None:
        if record.exact_evidence is not None:
            raise ValueError('exact evidence without distance')
        return record
    alphabet = AlphabetSpec.all_to_all(record.state.n)
    if record.source == 'stage18_bipartite_exact_v1':
        if record.exact_evidence != 'acuaviva_2608.03825v1_notes_sha256:' + SOURCE_NOTES_SHA256:
            raise ValueError('wrong stage18 proof source')
        result = recognize_graph(record.state, alphabet)
        valid = verify_graph(result, alphabet)
    elif record.source == 'stage23_forest_exact_v1':
        if record.exact_evidence != 'stage23_forest_theorem_sha256:' + FOREST_SHA:
            raise ValueError('wrong stage23 proof source')
        result = recognize_forest(record.state, alphabet)
        valid = verify_forest(result, alphabet)
    elif record.source == 'stage24_moving_root_exact_v1':
        if record.exact_evidence != 'stage24_moving_root_theorem_sha256:' + MOVING_ROOT_SHA:
            raise ValueError('wrong stage24 proof source')
        result = recognize_moving_root(record.state, alphabet)
        valid = verify_moving_root(result, alphabet)
    elif record.source == 'stage25_swap_forest_exact_v1':
        if record.exact_evidence != 'stage25_swap_forest_theorem_sha256:' + SWAP_FOREST_SHA:
            raise ValueError('wrong stage25 proof source')
        result = recognize_swap_forest(record.state, alphabet)
        valid = verify_swap_forest(result, alphabet)
    elif record.source == 'stage35_pair_exact_v1':
        if record.exact_evidence != 'stage35_pair_theorem_sha256:' + SOURCE_SHA256:
            raise ValueError('wrong stage35 proof source')
        result = recognize_pair(record.state, alphabet)
        valid = verify_pair(result, alphabet)
    elif record.source == 'stage36_saturated_frame_exact_v1':
        if record.exact_evidence != 'stage36_saturated_frame_theorem_sha256:' + SATURATED_FRAME_SHA:
            raise ValueError('wrong stage36 proof source')
        result = recognize_saturated_frame(record.state, alphabet)
        valid = verify_saturated_frame(result, alphabet)
    elif record.source == 'stage37_zero_excess_exact_v1':
        if record.exact_evidence != 'stage37_zero_excess_theorem_sha256:' + ZERO_SHA:
            raise ValueError('wrong stage37 proof source')
        result = recognize_zero(record.state, alphabet)
        valid = verify_zero(result, alphabet)
    elif record.source == 'stage38_one_excess_exact_v1':
        if record.exact_evidence != 'stage38_one_excess_theorem_sha256:' + ONE_EXCESS_SHA:
            raise ValueError('wrong stage38 proof source')
        result = recognize_one_excess(record.state, alphabet)
        valid = result.status == 'exact' and verify_one_excess(result, alphabet)
    else:
        raise ValueError('unsupported exact producer in v13 reader')
    if not valid or result.status != 'exact' or result.distance != record.exact_distance:
        raise ValueError('exact claim does not match full matrix')
    if not any(word.physical_cost == result.distance for word in record.verified_words):
        raise ValueError('stored exact word has wrong physical cost')
    return record

def decode_record(raw):
    record = _decode_record(raw)
    if not record.verified_words:
        raise ValueError('root has no verified complete certificate')
    return validate_exact(record)


def _manifest(connection, epoch):
    from .stream_solver_dataset_v13 import SCHEMA, data_source_hashes, source_hashes
    saved = connection.execute("SELECT value FROM metadata WHERE key='manifest'").fetchone()
    if saved is None:
        raise ValueError('dataset manifest missing')
    manifest = json.loads(saved[0])
    if manifest['schema'] != SCHEMA or manifest['dataset_source_sha256'] != data_source_hashes():
        raise ValueError('reader/generator schema or source drift')
    if manifest['compiler_source_sha256'] != source_hashes():
        raise ValueError('own compiler source drift')
    if type(epoch) is not int or not 0 <= epoch < manifest['epochs']:
        raise ValueError('invalid stream epoch')
    if connection.execute("SELECT 1 FROM metadata WHERE key='holdout_seal'").fetchone() is None:
        raise ValueError('holdout is not sealed')
    return manifest


def _records(connection, row, suffixes_per_root, *, epoch, position, augment_suffix=False):
    from .stream_solver_dataset_v13 import admit_complete_neighbors
    if type(suffixes_per_root) is not int or suffixes_per_root < 0:
        raise ValueError('invalid suffix count')
    # The legacy decoder checks content digest, endpoints and stored offsets;
    # validate the exact root too, including when no suffixes were requested.
    records = tuple(_decode_row(connection, row, suffixes_per_root))
    records = tuple(validate_exact(record) for record in records)
    if not records[0].verified_words:
        raise ValueError('root has no complete certificate')
    if augment_suffix and len(records) > 1:
        transform = deterministic_transform(records[0].state.n, epoch, position)
        records = (records[0],) + tuple(augment_record(record, transform) for record in records[1:])
    # Check the actual augmented batch, before yielding even its first record.
    admit_complete_neighbors(connection, records)
    return records


def read_position(connection, epoch, position, *, suffixes_per_root=1, augment_suffix=False):
    manifest = _manifest(connection, epoch)
    if type(position) is not int or not 0 <= position < manifest['new_unique_roots_per_epoch']:
        raise ValueError('invalid stream position')
    row = connection.execute('''SELECT matrix_hash,matrix_json,record_json,audit_json,
        suffix_offsets_json,root_digest FROM roots
        WHERE split='train' AND epoch=? AND position=?''', (epoch, position)).fetchone()
    if row is None:
        raise KeyError((epoch, position))
    return _records(connection, row, suffixes_per_root, epoch=epoch, position=position,
                    augment_suffix=augment_suffix), row[-1]

def read_epoch(connection, epoch, *, suffixes_per_root=1):
    _manifest(connection, epoch)
    cursor = connection.execute('''SELECT position,matrix_hash,matrix_json,record_json,
        audit_json,suffix_offsets_json,root_digest FROM roots
        WHERE split='train' AND epoch=? ORDER BY position''', (epoch,))
    for position, *row in cursor:
        yield from _records(connection, row, suffixes_per_root, epoch=epoch, position=position)
