"""Regression: actual guarded root audits must survive CLI progress emission."""
import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import Mock, patch
from research_v3.data import stream_solver_dataset_v13 as stream


class GuardedProgressTests(unittest.TestCase):
    def test_all_guarded_families_survive_actual_cli_callback(self):
        for index in (14, 70, 126):
            record, audit = stream.make_root('dev', 0, index, 0, 3700)
            with self.subTest(source=record.source), tempfile.TemporaryDirectory() as directory:
                connection = Mock()
                def generate(_connection, **kwargs):
                    kwargs['on_root'](index, record, audit, {})
                    return {'new_roots': 1}
                output = io.StringIO()
                args = ['generate', '--db', str(Path(directory)/'roots.sqlite'),
                        '--split', 'dev', '--epoch', '0', '--count', '1',
                        '--expected-dev-roots', '1792', '--expected-test-roots', '1792']
                with patch('sys.argv', args), patch.object(stream, 'open_store',
                        return_value=(connection, {'fixture':'guarded_cli'})), \
                        patch.object(stream, 'build_epoch', side_effect=generate), \
                        contextlib.redirect_stdout(output):
                    stream.main()
                row = json.loads(output.getvalue().splitlines()[0])
                self.assertEqual(row['selected'], record.verified_words[0].producer)
                self.assertEqual(row['best'], record.upper_bound)
                connection.close.assert_called_once()


if __name__ == '__main__':
    unittest.main()
