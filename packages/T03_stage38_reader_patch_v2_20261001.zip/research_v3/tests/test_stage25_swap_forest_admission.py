import unittest
from research_v3.contracts import AlphabetSpec,MatrixState,Gate
from research_v3.data.exact_small import build_exact_small
from research_v3.data.stage25_swap_forest_exact_v1 import recognize,generate,ingest_exact
from research_v3.data.replay import Replay
from research_v3.data.stream_reader_v13 import decode_record
from dataclasses import asdict,replace
import json
from research_v3.words import verify_word


class SwapForestAdmissionTests(unittest.TestCase):
    def test_gl3_global_distances(self):
        alphabet=AlphabetSpec.all_to_all(3)
        catalog=build_exact_small(3,alphabet)
        accepted=0
        for state,distance in catalog.distances.items():
            result=recognize(state,alphabet)
            if result.status=='exact':
                verify_word(result.word,alphabet)
                self.assertEqual(result.distance,distance)
                self.assertEqual(result.distance,result.witness['changed_rows']+1)
                accepted+=1
            else:
                self.assertEqual(result.status,'unsupported')
                self.assertIsNone(result.distance)
        self.assertEqual(accepted,9)

    def test_two_colors_non_topological_full_matrix(self):
        alphabet=AlphabetSpec.all_to_all(7)
        # core a4,b1, root3 of color4 ->0; root2 of color1; inactive5/6.
        state=MatrixState(7,(25,16,6,24,2,32,64),alphabet.id)
        result=recognize(state,alphabet)
        self.assertEqual(result.status,'exact')
        self.assertEqual(result.distance,6)
        verify_word(result.word,alphabet)

    def test_alphabet_scope(self):
        for alphabet in (AlphabetSpec(2,(Gate(0,1),),(1,),'restricted'),
                         AlphabetSpec(2,(Gate(0,1),Gate(1,0)),(2,2),'weighted')):
            self.assertEqual(recognize(MatrixState.identity(alphabet),alphabet).status,'unsupported')

    def test_generator_replay_reader_and_tampering(self):
        for n in (2,3,8):
            alphabet=AlphabetSpec.all_to_all(n)
            result=generate(1725,n,split='dev')
            record=ingest_exact(Replay(alphabet),result,seed=1725,split='dev')
            self.assertEqual(decode_record(json.dumps(asdict(record))),record)
            for change in ({'exact_distance':record.exact_distance+1},
                           {'exact_evidence':'bogus'},{'source':'other'}):
                with self.subTest(n=n,change=change), self.assertRaises(ValueError):
                    decode_record(json.dumps(asdict(replace(record,**change))))
            bad=replace(record.verified_words[0],gates=(),physical_cost=0)
            with self.assertRaises(ValueError):
                decode_record(json.dumps(asdict(replace(record,verified_words=(bad,)))))
            blocked=Replay(alphabet,forbidden_keys={record.state.key})
            with self.assertRaises(ValueError):
                ingest_exact(blocked,result,seed=1725,split='train')
            self.assertFalse(blocked.records)
