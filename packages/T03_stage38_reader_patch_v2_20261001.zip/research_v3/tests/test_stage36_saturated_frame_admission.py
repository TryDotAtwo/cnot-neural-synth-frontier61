import unittest
from research_v3.contracts import AlphabetSpec,MatrixState,Gate
from research_v3.data.exact_small import build_exact_small
from research_v3.data.stage36_saturated_frame_exact_v1 import recognize,generate,ingest_exact
from research_v3.data.replay import Replay
from research_v3.data.stream_reader_v13 import decode_record
from dataclasses import asdict,replace
import json
from research_v3.words import verify_word
from research_v3.gf2 import permute


class SaturatedFrameAdmissionTests(unittest.TestCase):
    def test_all_gl3_exact_results_match_global_bfs(self):
        alphabet=AlphabetSpec.all_to_all(3)
        catalog=build_exact_small(3,alphabet)
        accepted=0
        for state,distance in catalog.distances.items():
            result=recognize(state,alphabet)
            if result.status=='exact':
                verify_word(result.word,alphabet)
                self.assertEqual(result.distance,distance)
                self.assertEqual(result.witness['global_lower_bound'],distance)
                accepted+=1
            else:self.assertEqual(result.status,'unsupported')
        self.assertGreater(accepted,0)

    def test_full_ten_wire_all_seven_currents(self):
        alphabet=AlphabetSpec.all_to_all(10)
        state=MatrixState(10,(686,821,967,8,16,32,64,128,256,512),alphabet.id)
        result=recognize(state,alphabet)
        self.assertEqual(result.status,'exact')
        self.assertEqual(result.distance,11)
        self.assertEqual(result.witness['nonzero_external_columns'],7)
        verify_word(result.word,alphabet)
        renamed=MatrixState(10,permute(state.packed_rows,(8,2,5,9,0,4,1,7,6,3)),alphabet.id)
        renamed_result=recognize(renamed,alphabet)
        self.assertEqual(renamed_result.status,'exact')
        self.assertEqual(renamed_result.distance,11)
        verify_word(renamed_result.word,alphabet)

    def test_identity_core_and_nonunit_not_global_exact(self):
        alphabet=AlphabetSpec.all_to_all(4)
        state=MatrixState(4,(9,10,12,8),alphabet.id)
        self.assertEqual(recognize(state,alphabet).status,'unsupported')
        weighted=AlphabetSpec(3,AlphabetSpec.all_to_all(3).allowed,(2,)*6,'weighted')
        self.assertEqual(recognize(MatrixState.identity(weighted),weighted).status,'unsupported')

    def test_generated_full_records_and_reader_tamper_rejection(self):
        for n in (3,4,8):
            alphabet=AlphabetSpec.all_to_all(n)
            result=generate(1736,n,split='dev')
            record=ingest_exact(Replay(alphabet),result,seed=1736,split='dev')
            self.assertEqual(decode_record(json.dumps(asdict(record))),record)
            for change in ({'exact_distance':record.exact_distance+1},
                           {'exact_evidence':'bogus'},{'source':'other'}):
                with self.subTest(n=n,change=change), self.assertRaises(ValueError):
                    decode_record(json.dumps(asdict(replace(record,**change))))
            blocked=Replay(alphabet,forbidden_keys={record.state.key})
            with self.assertRaises(ValueError):
                ingest_exact(blocked,result,seed=1736,split='train')
            self.assertFalse(blocked.records)
