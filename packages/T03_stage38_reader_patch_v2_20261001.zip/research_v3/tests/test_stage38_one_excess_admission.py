import unittest
from research_v3.contracts import AlphabetSpec,MatrixState
from research_v3.data.exact_small import build_exact_small
from research_v3.data.stage38_one_excess_exact_v1 import recognize,generate,ingest_exact
from research_v3.data.replay import Replay
from research_v3.data.stream_reader_v13 import decode_record
from dataclasses import asdict,replace
import json
from pathlib import Path
from unittest.mock import patch
from research_v3.words import verify_word


class OneExcessAdmissionTests(unittest.TestCase):
    def test_complete_gl3_distances_and_exclusion_scope(self):
        alphabet=AlphabetSpec.all_to_all(3)
        catalog=build_exact_small(3,alphabet)
        accepted=0
        for state,distance in catalog.distances.items():
            result=recognize(state,alphabet)
            if result.status=='exact':
                verify_word(result.word,alphabet)
                self.assertEqual(result.distance,distance)
                self.assertEqual(result.distance,result.witness['changed_rows']+1)
                self.assertGreater(result.witness['one_excess_count'],0)
                accepted+=1
            elif result.status=='certified_no_solution_within_scope':
                self.assertGreater(distance,result.witness['excluded_length'])
            else:self.assertEqual(result.status,'unsupported')
        self.assertGreater(accepted,0)

    def test_resource_limit_is_not_negative_amplitude(self):
        alphabet=AlphabetSpec.all_to_all(2)
        state=MatrixState(2,(2,1),alphabet.id)
        result=recognize(state,alphabet,max_entries=1)
        self.assertEqual(result.status,'resource_limit')
        self.assertIsNone(result.distance)
        self.assertIsNone(result.word)
        self.assertNotIn('one_excess_count',result.witness)

    def test_zero_excess_not_relabeled_as_one_excess(self):
        alphabet=AlphabetSpec.all_to_all(3)
        self.assertEqual(recognize(MatrixState.identity(alphabet),alphabet).status,'unsupported')

    def test_primary_source_drift_rejected_even_after_cache_population(self):
        alphabet=AlphabetSpec.all_to_all(2)
        state=MatrixState(2,(2,1),alphabet.id)
        self.assertEqual(recognize(state,alphabet).status,'exact')
        original_read=Path.read_bytes
        for filename in ('one_vertex.py','38_first_interaction_vertex_ru.md'):
            def drift(path):
                return b'changed primary source' if path.name==filename else original_read(path)
            with self.subTest(filename=filename), patch.object(Path,'read_bytes',new=drift):
                with self.assertRaisesRegex(ValueError,'source drift'):
                    recognize(state,alphabet)

    def test_matrix_only_generation_replay_and_reader(self):
        for n in (2,3):
            alphabet=AlphabetSpec.all_to_all(n)
            result=generate(1738,n,split='dev')
            self.assertEqual(result.status,'exact')
            record=ingest_exact(Replay(alphabet),result,seed=1738,split='dev')
            self.assertEqual(decode_record(json.dumps(asdict(record))),record)
            for change in ({'exact_distance':record.exact_distance+1},
                           {'exact_evidence':'bogus'},{'source':'other'}):
                with self.subTest(n=n,change=change), self.assertRaises(ValueError):
                    decode_record(json.dumps(asdict(replace(record,**change))))
            damaged=replace(record.verified_words[0],gates=(),physical_cost=0)
            with self.assertRaises(ValueError):
                decode_record(json.dumps(asdict(replace(record,verified_words=(damaged,)))))
            blocked=Replay(alphabet,forbidden_keys={record.state.key})
            with self.assertRaises(ValueError):
                ingest_exact(blocked,result,seed=1738,split='train')
            self.assertFalse(blocked.records)
