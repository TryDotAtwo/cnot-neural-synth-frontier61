"""Guarded own Frontier stage38 primary contraction, complete matrix target I.

Exact r+1 labels require stage37's independent exclusion of r AND a positive
integer one-excess amplitude with a fully verified word. A contraction budget
failure is a resource limit, never a zero amplitude or an infeasibility claim.
"""
import hashlib
import importlib.util
from pathlib import Path
import sys
from .stage23_forest_exact_v1 import ForestResult
from .stage37_zero_excess_exact_v1 import recognize as zero_excess
from ..contracts import AlphabetSpec,MatrixState,Gate,WordCertificate
from ..words import verify_word

SOURCE_NOTES_SHA256='0815dc96c12052e04d26a04295b26f883c8936fb62d5b4c484b7d3841ee8292d'
SOURCE_IMPLEMENTATION_SHA256='90f4aac082958111293665010a34332f28d5145e957ca2ae49551d199c4cd82e'
PRIMARY_RELATIVE_PATH='artifacts/frontier61_source_v1/stage38_one_vertex/one_vertex.py'


def primary():
    path=Path(__file__).resolve().parents[1]/PRIMARY_RELATIVE_PATH
    if hashlib.sha256(path.read_bytes()).hexdigest()!=SOURCE_IMPLEMENTATION_SHA256:
        raise ValueError('stage38 own primary implementation source drift')
    name='_own_frontier38_'+SOURCE_IMPLEMENTATION_SHA256
    if name not in sys.modules:
        spec=importlib.util.spec_from_file_location(name,path)
        module=importlib.util.module_from_spec(spec)
        sys.modules[name]=module
        try:spec.loader.exec_module(module)
        except BaseException:
            del sys.modules[name]
            raise
    return sys.modules[name]


def recognize(state,alphabet,*,max_entries=2_000_000):
    if state.n!=alphabet.n or state.alphabet_id!=alphabet.id:
        raise ValueError('state/alphabet mismatch')
    if type(max_entries) is not int or max_entries<1:
        raise ValueError('explicit positive integer contraction-entry budget required')
    def unsupported(reason):
        return ForestResult('unsupported',state,alphabet.id,None,None,{}, {},reason)
    if alphabet!=AlphabetSpec.all_to_all(state.n):
        return unsupported('requires full unit all-to-all CNOT')
    zero=zero_excess(state,alphabet)
    if zero.status=='exact':
        return unsupported('zero-excess labels belong to stage37, not one-excess family')
    if zero.status!='certified_no_solution_within_scope':
        return unsupported('zero-excess exclusion not established')
    changed=sum(row!=1<<i for i,row in enumerate(state.packed_rows))
    module=primary()
    hypotheses={'full_unit_all_to_all':True,'source_notes_sha256':SOURCE_NOTES_SHA256,
                'primary_implementation_sha256':SOURCE_IMPLEMENTATION_SHA256,
                'contraction_max_entries':max_entries,'zero_excess_excluded':True}
    try:
        vertex=module.one_excess(state.packed_rows,tuple(1<<i for i in range(state.n)),
                                witness=True,max_entries=max_entries)
    except module.ContractionBudgetExceeded:
        return ForestResult('resource_limit',state,alphabet.id,None,None,hypotheses,
                            {'changed_rows':changed},'exact contraction entry budget exceeded')
    witness={'changed_rows':changed,'one_excess_count':vertex.count,
             'templates':vertex.templates,'max_bag':vertex.max_bag,
             'transport_free':vertex.transport_free,'zero_excess_witness':zero.witness}
    if vertex.count==0:
        witness['excluded_length']=changed+1
        return ForestResult('certified_no_solution_within_scope',state,alphabet.id,
                            None,None,hypotheses,witness,'r and r+1 excluded; larger distance unknown')
    gates=tuple(Gate(c,t) for c,t in vertex.gates)
    distance=changed+1
    if len(gates)!=distance:
        raise AssertionError('one-excess witness length mismatch')
    word=WordCertificate(state,MatrixState.identity(alphabet),gates,distance,
        'stage38_one_excess_exact_v1',f'stage38:{state.n}:{state.packed_rows}')
    verify_word(word,alphabet)
    return ForestResult('exact',state,alphabet.id,distance,word,hypotheses,witness)


def verify_result(result,alphabet):
    budget=result.hypotheses.get('contraction_max_entries',2_000_000)
    if recognize(result.state,alphabet,max_entries=budget)!=result:
        raise ValueError('stage38 result failed exact re-contraction')
    return result.status=='exact'
