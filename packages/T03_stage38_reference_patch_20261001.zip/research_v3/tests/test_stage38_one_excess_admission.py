import unittest
from research_v3.contracts import AlphabetSpec,MatrixState
from research_v3.data.exact_small import build_exact_small
from research_v3.data.stage38_one_excess_exact_v1 import recognize
from research_v3.words import verify_word


class OneExcessAdmissionTests(unittest.TestCase):
    def test_complete_gl3_distances_and_exclusion_scope(self):
        alphabet=AlphabetSpec.all_to_all(3)
        catalog=build_exact_small(3,alphabet)
        accepted=0
        for state,distance in catalog.distances.items():
            result=recognize(state,alphabet)
            if result.status=='exact':
                verify_word(result.word,alphabet)
                self.assertEqual(result.distance,distance)
                self.assertEqual(result.distance,result.witness['changed_rows']+1)
                self.assertGreater(result.witness['one_excess_count'],0)
                accepted+=1
            elif result.status=='certified_no_solution_within_scope':
                self.assertGreater(distance,result.witness['excluded_length'])
            else:self.assertEqual(result.status,'unsupported')
        self.assertGreater(accepted,0)

    def test_resource_limit_is_not_negative_amplitude(self):
        alphabet=AlphabetSpec.all_to_all(2)
        state=MatrixState(2,(2,1),alphabet.id)
        result=recognize(state,alphabet,max_entries=1)
        self.assertEqual(result.status,'resource_limit')
        self.assertIsNone(result.distance)
        self.assertIsNone(result.word)
        self.assertNotIn('one_excess_count',result.witness)

    def test_zero_excess_not_relabeled_as_one_excess(self):
        alphabet=AlphabetSpec.all_to_all(3)
        self.assertEqual(recognize(MatrixState.identity(alphabet),alphabet).status,'unsupported')
