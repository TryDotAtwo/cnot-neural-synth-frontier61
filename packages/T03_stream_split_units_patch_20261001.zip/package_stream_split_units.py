import hashlib,json,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
files=['research_v3/data/stream_solver_dataset_v13.py','research_v3/tests/test_stream_split_units.py']
receipt={'status':'reference_checked_native_panel_open','tests_passed':5,
 'command':'python -m unittest research_v3.tests.test_stream_split_units research_v3.tests.test_guarded_stream_progress research_v3.tests.test_walk_mixture_schedule -q',
 'negative_finding':'seal checked source/seed but not shared lineage_id across different source/seed units',
 'scope':'disjoint seed domain bounds and cross-split seed/lineage collision rejection; no actual full panel audit',
 'open':['fresh native panel seal','complete train/replay lineage audit'],
 'source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}}
name='T03_STREAM_SPLIT_UNITS_GATE_2026-10-01.json'
with (root/name).open('x',encoding='utf-8') as output:json.dump(receipt,output,indent=2)
ledger=json.loads((root/'NORMATIVE_REQUIREMENT_STATUS_V36_2026-10-01.json').read_text(encoding='utf-8'))
ledger['stream_split_units_update']=receipt
ledger_name='NORMATIVE_REQUIREMENT_STATUS_V37_2026-10-01.json'
with (root/ledger_name).open('x',encoding='utf-8') as output:json.dump(ledger,output,ensure_ascii=False,indent=2)
files += [name,ledger_name,'package_stream_split_units.py']
manifest={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}
archive=root/'T03_stream_split_units_patch_20261001.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as output:
 for n in files:output.write(root/n,n)
 output.writestr('source_manifest.json',json.dumps({'files':manifest,'status':receipt['status']},indent=2))
with zipfile.ZipFile(archive) as check:
 assert check.testzip() is None
 assert all(hashlib.sha256(check.read(n)).hexdigest()==sha for n,sha in manifest.items())
print(hashlib.sha256(archive.read_bytes()).hexdigest())
