from dataclasses import replace
import unittest
from research_v3.contracts import AlphabetSpec,Gate
from research_v3.data.generators import record_from_word
from research_v3.data.stream_solver_dataset_v13 import audit_split_units,epoch_seed,SPLIT_SEED_OFFSET

class StreamSplitUnitTests(unittest.TestCase):
    def test_seed_domains_are_disjoint_and_identity_mapping_is_injective(self):
        ranges=[]
        for split in SPLIT_SEED_OFFSET:
            first=epoch_seed(split,0,0,0,42)
            last=epoch_seed(split,999,9999,99,42)
            self.assertEqual(last-first,999999999)
            ranges.append((first,last))
        for (_,last),(first,_) in zip(sorted(ranges),sorted(ranges)[1:]):
            self.assertLess(last,first)
        seen={epoch_seed('train',e,i,a,42) for e in (0,1,999)
              for i in (0,1,9998,9999) for a in (0,1,98,99)}
        self.assertEqual(len(seen),3*4*4)

    def test_both_lineage_id_and_source_seed_collisions_are_rejected(self):
        a=AlphabetSpec.all_to_all(2)
        dev=replace(record_from_word(a,(),'lineage-a',1),split='dev')
        test=replace(record_from_word(a,(Gate(0,1),),'lineage-b',2),split='test')
        self.assertEqual(audit_split_units((dev,test))['lineage_units'],2)
        for collision in (replace(test,lineage_id=dev.lineage_id),replace(test,seed=dev.seed)):
            with self.assertRaisesRegex(ValueError,'crosses splits'):
                audit_split_units((dev,collision))
        # Multiple suffix presentations from the same unit keep the same split.
        self.assertEqual(audit_split_units((dev,dev))['lineage_units'],1)

if __name__=='__main__':unittest.main()
