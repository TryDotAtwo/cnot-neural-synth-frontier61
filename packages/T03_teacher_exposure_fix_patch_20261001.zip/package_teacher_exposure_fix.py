import hashlib,json,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
files=['research_v3/train/cuda_stream_v13.py','research_v3/tests/test_replay_refresh_v13.py']
receipt={'status':'reference_checked_native_open','tests_passed':12,
 'command':'python -m unittest research_v3.tests.test_replay_refresh_v13 research_v3.tests.test_model_exposure_journal research_v3.tests.test_cuda_stream_exposure_admission -q',
 'negative_findings':['previous refresh metadata comparison omitted seed','previous teacher refresh call was outside actual stem exposure hooks'],
 'changes':['all nonword SampleRecord fields must remain equal','teacher refresh enclosed in actual stem journal hooks'],
 'scope':'metadata mutation rejection and existing actual CPU field journal tests; CUDA teacher route code wiring inspected',
 'open':['actual native teacher plus joint loss run','native complete exposure audit'],
 'source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}}
name='T03_TEACHER_EXPOSURE_FIX_GATE_2026-10-01.json'
with (root/name).open('x',encoding='utf-8') as output:json.dump(receipt,output,indent=2)
ledger=json.loads((root/'NORMATIVE_REQUIREMENT_STATUS_V32_2026-10-01.json').read_text(encoding='utf-8'))
ledger['teacher_exposure_fix_update']=receipt
ledger_name='NORMATIVE_REQUIREMENT_STATUS_V33_2026-10-01.json'
with (root/ledger_name).open('x',encoding='utf-8') as output:json.dump(ledger,output,ensure_ascii=False,indent=2)
files += [name,ledger_name,'package_teacher_exposure_fix.py']
manifest={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}
archive=root/'T03_teacher_exposure_fix_patch_20261001.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as output:
 for n in files:output.write(root/n,n)
 output.writestr('source_manifest.json',json.dumps({'files':manifest,'status':receipt['status']},indent=2))
with zipfile.ZipFile(archive) as check:
 assert check.testzip() is None
 assert all(hashlib.sha256(check.read(n)).hexdigest()==sha for n,sha in manifest.items())
print(hashlib.sha256(archive.read_bytes()).hexdigest())
