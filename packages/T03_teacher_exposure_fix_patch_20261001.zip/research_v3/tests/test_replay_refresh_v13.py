from dataclasses import replace
import unittest
from research_v3.contracts import AlphabetSpec, Gate, WordCertificate, MatrixState
from research_v3.data.generators import record_from_word
from research_v3.train.replay_refresh_v13 import CertifiedReplayRefresh


class OwnSolver:
    def __init__(self): self.calls = 0
    def __call__(self, record, update):
        self.calls += 1
        return WordCertificate(record.state,
                               MatrixState.identity(AlphabetSpec.all_to_all(3)),
                               (Gate(0, 1),), 1, 'own_neural_refresh_v13', record.lineage_id)
    def state_dict(self): return {'calls': self.calls}
    def load_state_dict(self, state): self.calls = state['calls']


class ReplayRefreshTests(unittest.TestCase):
    def test_stream_refresh_preserves_seed_and_all_nonword_metadata(self):
        from research_v3.train.cuda_stream_v13 import validate_refresh_records
        record=self.fixture()
        validate_refresh_records((record,),(record,))
        result=CertifiedReplayRefresh(OwnSolver(),every_updates=2,source_sha256={})((record,),2)
        validate_refresh_records((record,),result)
        for changed in (replace(record,seed=record.seed+1),replace(record,split='dev'),
                        replace(record,lineage_id='other'),replace(record,source='other'),
                        replace(record,verified_words=())):
            with self.assertRaisesRegex(ValueError,'provenance'):
                validate_refresh_records((record,),(changed,))

    def fixture(self):
        return replace(record_from_word(AlphabetSpec.all_to_all(3),
                                        (Gate(0, 1), Gate(1, 2), Gate(1, 2)),
                                        'train:own', 7), split='train')
    def test_verified_improvement_and_solver_state_survive_resume(self):
        record = self.fixture()
        refresh = CertifiedReplayRefresh(OwnSolver(), every_updates=2, source_sha256={})
        result = refresh((record,), 2)[0]
        self.assertEqual((record.upper_bound, result.upper_bound), (3, 1))
        self.assertEqual(refresh.events[-1]['update'], 2)
        self.assertEqual(result.state, record.state)
        restored = CertifiedReplayRefresh(OwnSolver(), every_updates=2, source_sha256={})
        restored.load_state_dict(refresh.state_dict())
        self.assertEqual(restored((record,), 3)[0].upper_bound, 1)
        self.assertEqual(restored.solver.calls, 1)
    def test_holdout_and_foreign_producer_are_rejected(self):
        record = self.fixture()
        refresh = CertifiedReplayRefresh(OwnSolver(), every_updates=2, source_sha256={})
        with self.assertRaises(ValueError): refresh((replace(record, split='dev'),), 2)
        class Foreign(OwnSolver):
            def __call__(self, record, update):
                return replace(super().__call__(record, update), producer='foreign')
        refresh = CertifiedReplayRefresh(Foreign(), every_updates=2, source_sha256={})
        with self.assertRaises(ValueError): refresh((record,), 2)


if __name__ == '__main__': unittest.main()
