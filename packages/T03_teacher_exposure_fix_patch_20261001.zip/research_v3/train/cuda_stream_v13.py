"""CUDA stream driver; launch requires sealed panels and stateful integrations.

Data production, replay refresh and full dev evaluation are explicit owners.
This driver never falls back to CPU generation or a shortened dev panel.
"""
from dataclasses import asdict,replace
import hashlib
import json
import os
import uuid
from pathlib import Path
from time import perf_counter

import torch

from ..data.stream_reader_v13 import read_position, _manifest
from ..gpu.record_batch_v13 import own_records_to_cuda
from ..gpu.joint_records_v13 import complete_joint_basis_records
from ..gpu.mixed_joint_records_v13 import RecordGroup, complete_mixed_joint_records
from .checkpoint import canonical, save_checkpoint, load_checkpoint, atomic_json, digest
from .runner import guarded_step
from .schedule import Progress, selection_key_from_json
from .stream_runner_v13 import StreamCursor, exclusive_run_lock, verify_cursor, reconcile_journal
from .dev_transaction_v13 import finish_dev
from .verify_cuda_dev_v13 import verify_cuda_dev_report
from .frozen_dev_panel_v13 import FrozenDevPanel
from .component_contract_v13 import component_contract


def checkpoint_events(roots_seen, attempted, target, checkpoint_every_roots):
    """Protocol 7.4 dev cadence is independent of periodic stream snapshots."""
    if any(type(v) is not int or v < 1 for v in
           (roots_seen, attempted, target, checkpoint_every_roots)):
        raise ValueError('positive integer schedule counters required')
    dev_due = attempted % 640 == 0 or roots_seen == target
    snapshot_due = dev_due or roots_seen % checkpoint_every_roots == 0
    return snapshot_due, dev_due


def publish_dev(root, path, report):
    key = selection_key_from_json(report['selection_key'])
    atomic_json(root/(path.stem+'.dev.json'), report)
    previous = root/'best_dev.json'
    if not previous.exists() or key <= selection_key_from_json(json.loads(previous.read_text())['selection_key']):
        atomic_json(previous, report)
        atomic_json(root/'best.json', json.loads(path.with_suffix('.json').read_text()))


def require_historical_quarantine(seal,bank_audit):
    if seal.get('historical_roots')!=9 or bank_audit.get('historical_roots')!=9:
        raise ValueError('all nine own historical roots must be quarantined')
    sources=seal.get('historical_source_sha256')
    if not isinstance(sources,dict) or len(sources)!=9 or any(
            not isinstance(value,str) or len(value)!=64 or any(c not in '0123456789abcdef' for c in value)
            for value in sources.values()):
        raise ValueError('nine pinned historical input sources required')


def validate_refresh_records(original,records):
    if len(records)!=len(original) or any(
            replace(new,verified_words=old.verified_words)!=old or
            not new.verified_words or new.upper_bound>old.upper_bound
            for old,new in zip(original,records)):
        raise ValueError('replay refresh changed roots, provenance, labels or worsened words')


def require_integrations(connection, config, banks, bank_audit, producer, replay, evaluate):
    manifest = _manifest(connection, 0)
    if (manifest['seed_base'] != config.seed_base or
            manifest['epochs'] != config.epochs or
            manifest['new_unique_roots_per_epoch'] != config.unique_roots_per_epoch):
        raise ValueError('stream schedule and sealed dataset differ')
    expected = manifest['expected_dev_roots']
    if (expected != 1792 or manifest['expected_test_roots'] != 1792 or
            bank_audit['dev_roots'] != expected or bank_audit['test_roots'] != 1792):
        raise ValueError('full confirmatory dev/test panels required')
    widths = {8, 10, 13, 25, 26, 34, 45, 50, 58, 72, 90, 108, 122, 144}
    if not widths.issubset(banks):
        raise ValueError('sealed GPU bank missing a width')
    seal = connection.execute("SELECT value FROM metadata WHERE key='holdout_seal'").fetchone()[0]
    if bank_audit.get('holdout_seal_sha256') != hashlib.sha256(seal.encode('utf-8')).hexdigest():
        raise ValueError('GPU banks belong to a different holdout seal')
    require_historical_quarantine(json.loads(seal),bank_audit)
    populations = {(split, n): count for split, n, count in connection.execute(
        "SELECT split,json_extract(record_json,'$.state.n'),COUNT(*) FROM roots "
        "WHERE split IN ('dev','test') GROUP BY split,json_extract(record_json,'$.state.n')")}
    if populations != {(split, n): 128 for split in ('dev', 'test') for n in widths}:
        raise ValueError('128 independent roots per split and width required')
    for component in (producer, replay, evaluate):
        if not callable(component) or not all(callable(getattr(component, n, None))
                                             for n in ('state_dict', 'load_state_dict')):
            raise ValueError('stateful producer, replay refresh and dev evaluator required')
    return manifest


def train_cuda_stream(model, optimizer, connection, run_dir, config, *, banks,
                      bank_audit, producer, replay, evaluate, joint_config,
                      source_versions, generator, dev_panel, dev_cap_multiplier,
                      resume=None, exact_sampler=None, frozen_dev_panel=None, exposure_journal=None):
    from ..data.model_exposure_journal_v1 import ModelExposureJournal
    if type(exposure_journal) is not ModelExposureJournal:
        raise ValueError('actual full-key model exposure journal required')
    if exposure_journal.holdout_seal_sha256 != bank_audit.get('holdout_seal_sha256') or exposure_journal.holdout_seal_sha256 is None:
        raise ValueError('model exposure journal belongs to a different sealed holdout')
    manifest = require_integrations(connection, config, banks, bank_audit,
                                    producer, replay, evaluate)
    exposure_journal.verify_packed_banks(banks)
    if config.exact_every_roots:
        require_exact_sampler(config, exact_sampler, banks, bank_audit)
    elif exact_sampler is not None:
        raise ValueError('unused exact sampler is not part of a zero-interval run')
    integrations = {name: component_contract(component, source_versions)
                    for name, component in (('producer', producer), ('replay', replay),
                                            ('evaluator', evaluate))}
    if exact_sampler is not None:
        integrations['exact_sampler'] = component_contract(exact_sampler, source_versions)
    integrations['model_exposures'] = component_contract(exposure_journal, source_versions)
    if generator.device.type != 'cuda' or next(model.parameters()).device.type != 'cuda':
        raise ValueError('CUDA model and durable CUDA basis generator required')
    dev_panel = tuple(dev_panel)
    from ..data.stream_reader_v13 import decode_record
    stored_panel = tuple(decode_record(raw) for (raw,) in connection.execute(
        "SELECT record_json FROM roots WHERE split='dev' ORDER BY epoch,position"))
    if dev_panel != stored_panel:
        raise ValueError('dev reference panel differs from sealed dataset')
    if (type(frozen_dev_panel) is not FrozenDevPanel or
            frozen_dev_panel.records != stored_panel):
        raise ValueError('full sealed frozen dev decoder/reference contract required')
    frozen = frozen_dev_panel.manifest()
    if (frozen['cap_multiplier'] != dev_cap_multiplier or
            frozen['holdout_seal_sha256'] != bank_audit['holdout_seal_sha256'] or
            integrations['evaluator']['config'].get('frozen_panel_sha256') != frozen_dev_panel.sha256):
        raise ValueError('evaluator does not own the frozen sealed dev contract')
    def validate_report(report, sha, update):
        return verify_cuda_dev_report(report, frozen_dev_panel, checkpoint_sha=sha, update=update)
    contract = json.loads(canonical(dict(schema='cuda_stream_v13', training=asdict(config),
                                        dataset_manifest=manifest, sources=source_versions,
                                        integrations=integrations,
                                        joint=joint_config, bank_audit=bank_audit,
                                        model_config=model.config,
                                        optimizer=dict(type=type(optimizer).__qualname__,
                                                       defaults=optimizer.defaults),
                                        dev_cap_multiplier=dev_cap_multiplier,
                                        frozen_dev_contract=frozen,
                                        frozen_dev_panel_sha256=frozen_dev_panel.sha256,
                                        dev_every_updates=640,
                                        dev_panel_sha256=hashlib.sha256(canonical(
                                            [asdict(record) for record in dev_panel]).encode()).hexdigest())))
    root = Path(run_dir); root.mkdir(parents=True, exist_ok=True)
    cursor, progress = StreamCursor(config), Progress()
    def extra():
        snapshot_name='exposures-'+uuid.uuid4().hex+'.sqlite'
        snapshot=exposure_journal.snapshot(root/snapshot_name)
        return dict(basis_rng=generator.get_state(), producer=producer.state_dict(),
                    replay=replay.state_dict(), evaluator=evaluate.state_dict(),
                    model_exposures=snapshot['state'],
                    model_exposure_snapshot=dict(file=snapshot_name,receipt=snapshot),
                    exact_sampler=None if exact_sampler is None else exact_sampler.state_dict())
    with exclusive_run_lock(root):
        if resume is None:
            if (root/'last.json').exists() or (root/'updates.jsonl').exists():
                raise FileExistsError('existing run requires explicit resume')
            atomic_json(root/'experiment_manifest.json', contract)
            # Establish a restorable pre-update state before opening the journal.
            save_checkpoint(root, model, optimizer, cursor, progress, contract, extra=extra())
        else:
            last = json.loads((root/'last.json').read_text())
            if Path(resume).resolve() != (root/last['file']).resolve():
                raise ValueError('resume requires the committed last snapshot')
            state = load_checkpoint(resume, model, optimizer, cursor, progress, contract)
            binding=state['model_exposure_snapshot']
            name=binding['file']
            if type(name) is not str or Path(name).name!=name or not name.startswith('exposures-') or not name.endswith('.sqlite'):
                raise ValueError('invalid checkpoint exposure snapshot path')
            ModelExposureJournal.validate_snapshot(root/name,binding['receipt'])
            if binding['receipt']['state']!=state['model_exposures']:
                raise ValueError('checkpoint exposure snapshot state differs')
            generator.set_state(state['basis_rng'])
            exposure_journal.load_state_dict(state['model_exposures'])
            for name, component in (('producer', producer), ('replay', replay), ('evaluator', evaluate)):
                component.load_state_dict(state[name])
            if exact_sampler is not None:
                exact_sampler.load_state_dict(state['exact_sampler'])
            verify_cursor(connection, cursor)
            if (progress.attempted != cursor.roots_seen or
                    progress.accepted != cursor.roots_seen or progress.rejected):
                raise ValueError('checkpoint progress and root cursor differ')
            if cursor.roots_seen == 0 and not (root/'updates.jsonl').exists():
                (root/'updates.jsonl').touch(exist_ok=False)
            reconcile_journal(root, cursor)
            # Finish or restore evaluation before consuming another train root.
            if cursor.roots_seen and checkpoint_events(
                    cursor.roots_seen, progress.attempted,
                    config.epochs * config.unique_roots_per_epoch,
                    config.checkpoint_every_roots)[1]:
                report = finish_dev(model, resume, progress.attempted, evaluate, generator,
                                    validator=validate_report)
                publish_dev(root, Path(resume), report)
        target = config.epochs * config.unique_roots_per_epoch
        with (root/'updates.jsonl').open('a', encoding='utf-8') as log:
            while cursor.roots_seen < target:
                epoch, position = cursor.epoch, cursor.position
                started = perf_counter()
                # Producer owns its native provenance and complete root transaction.
                producer(connection, epoch, position)
                records, root_digest = read_position(
                    connection, epoch, position, suffixes_per_root=config.suffixes_per_root,
                    augment_suffix=config.augment_suffix)
                original = tuple(records)
                # Teacher inference is also model access and must be journaled.
                with exposure_journal.attach_stem(model.field.stem):
                    records = tuple(replay(original, cursor.roots_seen))
                validate_refresh_records(original,records)
                n = records[0].state.n
                with exposure_journal.attach_stem(model.field.stem):
                    optimizer.zero_grad(set_to_none=True)
                    anchor = None
                    if (config.exact_every_roots and
                            (cursor.roots_seen + 1) % config.exact_every_roots == 0):
                        anchor = exact_sampler.record(epoch, position)
                        small_n = anchor.state.n
                        loss, audit = complete_mixed_joint_records(model, (
                            RecordGroup(records, banks[n]),
                            RecordGroup((anchor,), banks[small_n], exact_sampler.contexts[small_n])),
                            generator=generator, **joint_config)
                    else:
                        batch = own_records_to_cuda(records)
                        loss, audit = complete_joint_basis_records(
                            model, batch, records, generator=generator, holdout=banks[n], **joint_config)
                    exposure_journal.observe_labels(tuple(records) + (() if anchor is None else (anchor,)))
                    if not guarded_step(model, optimizer, loss, progress):
                        raise RuntimeError('nonfinite CUDA stream step')
                torch.cuda.synchronize()
                presentations = len(records) + int(anchor is not None)
                cursor.advance(root_digest, presentations)
                log.write(canonical(dict(root_number=cursor.roots_seen, epoch=epoch,
                                         position=position, root_digest=root_digest,
                                         presentations=presentations, loss=float(loss.detach()),
                                         exact_anchor_sha256=None if anchor is None else hashlib.sha256(
                                             canonical(asdict(anchor)).encode()).hexdigest(),
                                         exact_root_examples=audit['exact_root_examples'],
                                         end_to_end_seconds=perf_counter()-started))+'\n')
                log.flush()
                snapshot_due, dev_due = checkpoint_events(
                    cursor.roots_seen, progress.attempted, target, config.checkpoint_every_roots)
                if snapshot_due:
                    os.fsync(log.fileno())
                    path = save_checkpoint(root, model, optimizer, cursor, progress, contract, extra=extra())
                if dev_due:
                    report = finish_dev(model, path, progress.attempted, evaluate, generator,
                                        validator=validate_report)
                    if (report['total'] != 1792 or report['selection_protocol'] != 'EXPERIMENT_PROTOCOL_RU.md 7.4'):
                        raise ValueError('incomplete or nonnormative dev evaluation')
                    key = selection_key_from_json(report['selection_key'])
                    if key[3:] != (progress.attempted, digest(path)):
                        raise ValueError('dev report checkpoint identity mismatch')
                    publish_dev(root, path, report)
        return dict(status='completed', cursor=cursor.state_dict(), progress=asdict(progress))


def require_exact_sampler(config, sampler, banks, bank_audit):
    """Candidate route admission; actual Molab stream acceptance remains separate."""
    from ..data.exact_anchor_sampler_v13 import ExactAnchorSampler
    if (type(sampler) is not ExactAnchorSampler or sampler.sizes != (3, 4) or
            config.unique_roots_per_epoch != 10000 or config.exact_every_roots != 100):
        raise ValueError('complete pinned GL3/GL4 sampler and reference 100-root schedule required')
    for n in sampler.sizes:
        receipt = bank_audit.get('widths', {}).get(n, bank_audit.get('widths', {}).get(str(n)))
        if n not in banks or receipt is None:
            raise ValueError('sealed exact-anchor width projection missing')
        bank = banks[n]
        if (bank.sorted_rows.shape[1:] != (n, 1) or
                bank.sorted_rows.shape[0] != receipt['stored_forbidden']):
            raise ValueError('exact-anchor bank and projection receipt differ')
        if receipt['roots'] == 0 and (
                receipt.get('projection') != 'absent_in_verified_sealed_root_dimensions' or
                receipt['stored_forbidden'] != 0):
            raise ValueError('empty exact-anchor projection lacks verified absence receipt')
