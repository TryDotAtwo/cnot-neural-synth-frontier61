"""Own full-matrix neural search adapter for certified train replay.

Candidate integration: explicit work budgets, no wall-clock cutoff or fallback.
The caller must pin this module and its dependencies in source_sha256.
"""
from dataclasses import asdict
import hashlib
import json
import time
import torch
from ..contracts import AlphabetSpec, Gate, MatrixState, WordCertificate
from ..words import verify_word
from ..gpu.record_batch_v13 import own_records_to_cuda
from ..gpu.neural_beam import beam_search, neural_field_callbacks


def model_state_sha256(model):
    """Digest parameters AND persistent buffers, including names/shapes/dtypes."""
    digest = hashlib.sha256()
    for name, value in sorted(model.state_dict().items()):
        if not isinstance(value, torch.Tensor):
            raise ValueError('unsupported non-tensor model state')
        digest.update(json.dumps([name, str(value.dtype), list(value.shape)],
                                 separators=(',', ':')).encode())
        raw = value.detach().cpu().contiguous().reshape(-1).view(torch.uint8)
        digest.update(raw.numpy().tobytes())
    return digest.hexdigest()


class NeuralRefreshSolver:
    def exposure_stems(self):
        field=self.model.field if hasattr(self.model,'field') else self.model
        return (field.stem,)

    def __init__(self, model, *, search_config, field_config, source_sha256,
                 holdout_banks=None):
        expected = {'beam_width', 'shortlist', 'max_depth', 'inference_batch', 'max_expanded'}
        if set(search_config) != expected or any(type(v) is not int or v < 1
                                                for v in search_config.values()):
            raise ValueError('all positive explicit neural search budgets required')
        if set(field_config) != {'mc_samples', 'mc_seed', 'max_pair_states', 'head'}:
            raise ValueError('complete explicit field configuration required')
        if field_config['head'] not in ('qhat', 'proposal'):
            raise ValueError('unknown neural action head')
        if any(type(field_config[k]) is not int or field_config[k] < 1
               for k in ('mc_samples', 'max_pair_states')) or type(field_config['mc_seed']) is not int:
            raise ValueError('explicit integer feature sampling configuration required')
        self.model = model
        self.search_config = dict(search_config)
        self.field_config = dict(field_config)
        self.sources = dict(source_sha256)
        self.last_search = None
        self.holdout_banks = holdout_banks

    def immutable_contract(self):
        bank_sha = None
        if self.holdout_banks is not None:
            digest = hashlib.sha256()
            for width, bank in sorted(self.holdout_banks.items()):
                for name in ('sorted_rows', 'sorted_hashes', 'hash_weights'):
                    value = getattr(bank, name)
                    digest.update(json.dumps([width, name, str(value.dtype), list(value.shape)],
                                             separators=(',', ':')).encode())
                    raw = value.detach().contiguous().reshape(-1).view(torch.uint8)
                    # Explicit bounded host transfer; no whole-bank CPU copy.
                    for start in range(0, raw.numel(), 8 * 1024 * 1024):
                        digest.update(raw[start:start + 8 * 1024 * 1024].cpu().numpy().tobytes())
            bank_sha = digest.hexdigest()
        return dict(schema='own_neural_refresh_solver_v13',
                    config=dict(search=self.search_config, field=self.field_config,
                                holdout_state_sha256=bank_sha),
                    source_sha256=self.sources)

    def __call__(self, record, update):
        if record.split != 'train' or type(update) is not int or update < 0:
            raise ValueError('train record and nonnegative update required')
        if self.holdout_banks is None or record.state.n not in self.holdout_banks:
            raise ValueError('explicit frozen holdout bank required for neural refresh')
        bank = self.holdout_banks[record.state.n]
        forward_audit = dict(checked_presentations=0, rejected_batches=0)
        def admit(rows):
            if bool(bank.matches(rows).any().item()):
                forward_audit['rejected_batches'] += 1
                raise ValueError('neural refresh forward intersects frozen holdout bank')
            forward_audit['checked_presentations'] += rows.shape[0]
        device = next(self.model.parameters()).device
        if device.type != 'cuda':
            raise ValueError('neural refresh requires the live CUDA model')
        started = time.perf_counter()
        weights_sha = model_state_sha256(self.model)
        # The packer accepts the literal CUDA route and allocates on the current
        # device. Bind it to the model device rather than relying on that default.
        with torch.cuda.device(device):
            batch = own_records_to_cuda((record,), device='cuda')
        modes = [(module, module.training) for module in self.model.modules()]
        try:
            self.model.eval()
            with torch.random.fork_rng(devices=[device.index if device.index is not None
                                                else torch.cuda.current_device()]):
                actions, states = neural_field_callbacks(self.model, **self.field_config,
                                                         admission=admit)
                result = beam_search(batch.walk.rows, actions, states, **self.search_config)
        finally:
            for module, mode in modes:
                module.training = mode
        if model_state_sha256(self.model) != weights_sha:
            raise ValueError('neural inference mutated model parameters or buffers')
        self.last_search = dict(update=update, lineage=record.lineage_id,
                                model_state_sha256=weights_sha,
                                search_config=dict(self.search_config),
                                field_config=dict(self.field_config),
                                forward_admission=dict(forward_audit),
                                result=asdict(result),
                                adapter_seconds=time.perf_counter() - started)
        if result.word is None:
            return None
        if not result.verified:
            raise ValueError('search returned an uncertified word')
        alphabet = AlphabetSpec.all_to_all(record.state.n)
        word = WordCertificate(record.state, MatrixState.identity(alphabet),
                               tuple(Gate(c, t) for c, t in result.word),
                               len(result.word), 'own_neural_refresh_v13', record.lineage_id)
        verify_word(word, alphabet)
        return word

    def state_dict(self):
        return dict(schema='own_neural_refresh_solver_v13', last_search=self.last_search)

    def load_state_dict(self, state):
        if state['schema'] != 'own_neural_refresh_solver_v13':
            raise ValueError('neural refresh solver checkpoint schema mismatch')
        self.last_search = state['last_search']
