import hashlib,json,zipfile
from pathlib import Path
root=Path(__file__).resolve().parent
files=['research_v3/data/stream_solver_dataset_v13.py','research_v3/tests/test_walk_mixture_schedule.py']
receipt={'status':'reference_schedule_checked_native_data_open','tests_passed':7,
 'command':'python -m unittest research_v3.tests.test_walk_mixture_schedule research_v3.tests.test_guarded_family_dispatch research_v3.tests.test_guarded_stream_progress -q',
 'negative_finding':'seed_base + split_offset + epoch*1000000 + index*100 has constant parity at attempt zero; old walk mixture selected one source except retry artifacts',
 'scope':'all 1792 schedule positions; every width has 16 ordinary and 16 Poisson roots inside unchanged quarter walk share; not generated native data',
 'provenance':'new explicit manifest walk_kind_schedule; no existing database source-manifest migration',
 'open':['fresh native full panels','source SHA regeneration and native production dataset acceptance'],
 'source_sha256':{n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}}
name='T03_WALK_MIXTURE_SCHEDULE_GATE_2026-10-01.json'
with (root/name).open('x',encoding='utf-8') as output:json.dump(receipt,output,indent=2)
ledger=json.loads((root/'NORMATIVE_REQUIREMENT_STATUS_V35_2026-10-01.json').read_text(encoding='utf-8'))
ledger['walk_mixture_schedule_update']=receipt
ledger_name='NORMATIVE_REQUIREMENT_STATUS_V36_2026-10-01.json'
with (root/ledger_name).open('x',encoding='utf-8') as output:json.dump(ledger,output,ensure_ascii=False,indent=2)
files += [name,ledger_name,'package_walk_mixture_fix.py']
manifest={n:hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files}
archive=root/'T03_walk_mixture_schedule_patch_20261001.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as output:
 for n in files:output.write(root/n,n)
 output.writestr('source_manifest.json',json.dumps({'files':manifest,'status':receipt['status']},indent=2))
with zipfile.ZipFile(archive) as check:
 assert check.testzip() is None
 assert all(hashlib.sha256(check.read(n)).hexdigest()==sha for n,sha in manifest.items())
print(hashlib.sha256(archive.read_bytes()).hexdigest())
