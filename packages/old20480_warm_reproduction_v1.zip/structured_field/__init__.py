"""Structural full-matrix value field for CNOT synthesis."""

