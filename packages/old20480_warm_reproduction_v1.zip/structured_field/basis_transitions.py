"""Paid shared-basis macros built only by our stage-17 synthesizer."""

from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .gf2 import apply_word, identity, pack


@dataclass(frozen=True)
class Macro:
    word: tuple[tuple[int, int], ...]
    preparation: tuple[tuple[int, int], ...]
    core: tuple[tuple[int, int], ...]
    source: str

    @property
    def cost(self):
        return len(self.word)

    def apply(self, rows):
        return apply_word(rows, self.word)


def build_macros(n, *, count=8, seed=1700, wide=False):
    if n < 8:
        return []
    code_dir = str(Path(__file__).resolve().parents[1] / "code")
    if code_dir not in sys.path:
        sys.path.insert(0, code_dir)
    from shared_synth import compile_shear
    rng = np.random.default_rng(seed)
    out = []
    for _ in range(count*12):
        width = min(n//2, 8) if wide else 4
        wires = rng.choice(n, size=2*width, replace=False).tolist()
        base = rng.integers(0, 2, size=(width, max(1, width//2)), dtype=np.uint8)
        b = np.tile(base, (1, 2))[:, :width]
        if b.shape[1] < width:
            b = np.hstack((b, base[:, :1]))
        b ^= (rng.random(b.shape) < 0.08).astype(np.uint8)
        rec = compile_shear(b, wires[:width], wires[width:], width=4, exact_local=True,
                            restarts=0, maxiter=0, sweeps=2)
        prep = tuple(tuple(g) for g in rec["preparation"])
        if not prep:
            continue
        word = tuple(tuple(g) for g in rec["gates"])
        core = word[len(prep):len(word)-len(prep)]
        target = np.eye(n, dtype=np.uint8)
        target[np.ix_(wires[width:], wires[:width])] ^= b
        if apply_word(identity(n), word) != pack(target):
            raise AssertionError("stage17 macro changed target")
        if len(word) != 2*len(prep)+len(core):
            raise AssertionError("unpaid basis preparation")
        out.append(Macro(word, prep, core, "own_stage17_compile_shear"))
        if len(out) == count:
            break
    return out
