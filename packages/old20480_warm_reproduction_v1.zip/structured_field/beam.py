"""One CNOT-only beam with interchangeable full-state scorers."""

from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import torch

from .gf2 import apply_gate, gates, identity, unpack
from .model import tensor_batch


def _scores(states, model, device, chunk):
    if model is None:
        return [sum((row ^ (1 << i)).bit_count() for i, row in enumerate(state))
                for state in states]
    output = []
    model.eval()
    with torch.no_grad():
        for start in range(0, len(states), chunk):
            m, valid = tensor_batch(states[start:start+chunk], device=device)
            output.extend(model(m, valid).cpu().tolist())
    return output


def search(source, *, model=None, width=16, max_depth=100,
           score_chunk=32, per_parent_cap=None, device=None):
    started = time.perf_counter()
    n = len(source)
    goal = identity(n)
    if source == goal:
        return {"reason": "solved", "count": 0, "gates": [], "verified": True,
                "depth": 0, "expanded": 0, "generated": 0,
                "scorer_evaluations": 0, "seconds": 0.0}
    if width < 1 or max_depth < 1 or score_chunk < 1:
        raise ValueError("invalid beam budget")
    if device is None and model is not None:
        device = next(model.parameters()).device
    frontier = [(source, ())]
    closed = set()
    generated = 0
    evaluations = 0
    all_gates = gates(n)
    for depth in range(1, max_depth+1):
        layer = {}
        closed.update(state for state, _ in frontier)
        for state, reduction in frontier:
            candidates = []
            for gate in all_gates:
                nxt = apply_gate(state, gate)
                generated += 1
                if nxt == goal:
                    word = list(reversed(reduction+(gate,)))
                    code_dir = str(Path(__file__).resolve().parents[1] / "code")
                    if code_dir not in sys.path:
                        sys.path.insert(0, code_dir)
                    from stage16_reference import circuit_matrix
                    if not np.array_equal(circuit_matrix(n, word), unpack(source)):
                        raise AssertionError("beam word failed full matrix verification")
                    return {"reason": "solved", "count": len(word), "gates": word,
                            "verified": True, "depth": depth, "expanded": len(closed),
                            "generated": generated, "scorer_evaluations": evaluations,
                            "seconds": time.perf_counter()-started}
                if nxt not in closed:
                    candidates.append((nxt, reduction+(gate,)))
            if per_parent_cap is not None:
                scores = _scores([x[0] for x in candidates], model, device, score_chunk)
                evaluations += len(scores)
                candidates = [item for _, item in sorted(zip(scores, candidates),
                              key=lambda x: x[0])[:per_parent_cap]]
            for nxt, path in candidates:
                layer.setdefault(nxt, path)
        if not layer:
            return {"reason": "frontier_exhausted", "count": None, "gates": None,
                    "verified": False, "depth": depth, "expanded": len(closed),
                    "generated": generated, "scorer_evaluations": evaluations,
                    "seconds": time.perf_counter()-started}
        states = list(layer)
        scores = _scores(states, model, device, score_chunk)
        evaluations += len(scores)
        ordered = sorted(zip(scores, states), key=lambda item: item[0])
        frontier = [(state, layer[state]) for _, state in ordered[:width]]
    return {"reason": "depth_limit", "count": None, "gates": None,
            "verified": False, "depth": max_depth, "expanded": len(closed),
            "generated": generated, "scorer_evaluations": evaluations,
            "seconds": time.perf_counter()-started}
