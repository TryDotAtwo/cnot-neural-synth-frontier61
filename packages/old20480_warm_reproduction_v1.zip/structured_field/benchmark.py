"""CNOT-only comparison: Hamming, structural field, structural field+basis."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch

from .beam import search
from .data import benchmark_matrix
from .model import StructuralField


def load_field(checkpoint_path):
    checkpoint = torch.load(checkpoint_path, map_location="cpu", weights_only=False)
    model = StructuralField(**checkpoint["config"]["model"])
    model.load_state_dict(checkpoint["model"])
    model.to("cuda" if torch.cuda.is_available() else "cpu").eval()
    return model, checkpoint


def benchmark(cases, base_checkpoint, basis_checkpoint, output,
              *, width=4, depth=100, chunk=32):
    base, base_meta = load_field(base_checkpoint)
    basis, basis_meta = load_field(basis_checkpoint)
    if base_meta["config"]["model"] != basis_meta["config"]["model"]:
        raise ValueError("model architectures differ")
    identical = all(torch.equal(base_meta["model"][key], basis_meta["model"][key])
                    for key in base_meta["model"])
    rows = []
    def save():
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps({"rows": rows,
                                     "base_checkpoint": str(base_checkpoint),
                                     "basis_checkpoint": str(basis_checkpoint),
                                     "identical_state_dicts": identical}, indent=2))
    for name in cases:
        matrix = benchmark_matrix(name)
        record = {"case": name, "n": len(matrix), "width": width,
                  "depth_limit": depth, "score_chunk": chunk,
                  "per_parent_cap": None}
        rows.append(record)
        for label, model in (("hamming", None), ("field_no_basis", base),
                             ("field_basis", basis)):
            if label == "field_basis" and identical:
                record[label] = dict(record["field_no_basis"],
                                     reused_identical_model="field_no_basis")
            else:
                record[label] = search(matrix, model=model, width=width,
                                       max_depth=depth, score_chunk=chunk)
            print(name, label, record[label]["reason"],
                  record[label]["count"], flush=True)
            save()
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base_checkpoint", type=Path)
    parser.add_argument("basis_checkpoint", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cases", nargs="+", default=["hgp_13_1"])
    parser.add_argument("--width", type=int, default=4)
    parser.add_argument("--depth", type=int, default=100)
    parser.add_argument("--chunk", type=int, default=128)
    args = parser.parse_args()
    benchmark(args.cases, args.base_checkpoint, args.basis_checkpoint, args.output,
              width=args.width, depth=args.depth, chunk=args.chunk)


if __name__ == "__main__":
    main()
