"""Verified synthetic replay and strict stage-17 benchmark provenance."""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .gf2 import (apply_word, digest, distance_lower_bound, gates,
                  identity, pack, unpack)


HERE = Path(__file__).resolve().parents[1]
STAGE17_INPUTS = HERE.parent / "source_snapshot" / "inputs"
ALLOWED_PROVENANCE = {"own_exact_BFS", "own_random_walk", "own_stage17_basis_macro",
                      "own_forest_exact"}


@dataclass(frozen=True)
class Record:
    rows: tuple[int, ...]
    lower: int
    upper: int
    certificate: tuple[tuple[int, int], ...]
    exact: int | None
    provenance: str
    trajectory: str
    reductions: tuple[tuple[tuple[int, int], ...], ...] = ()

    def verify(self):
        if self.provenance not in ALLOWED_PROVENANCE:
            raise ValueError("disallowed data provenance")
        if apply_word(identity(len(self.rows)), self.certificate) != self.rows:
            raise AssertionError("invalid upper-bound certificate")
        if self.upper != len(self.certificate) or not self.lower <= self.upper:
            raise AssertionError("invalid bounds")
        if self.exact is not None and not self.lower <= self.exact <= self.upper:
            raise AssertionError("exact label outside bounds")
        for word in self.reductions:
            if not word or tuple(reversed(word)) != self.certificate[-len(word):]:
                raise AssertionError("macro reduction is not a certified suffix")

    def manifest(self):
        return {"n": len(self.rows), "sha256": digest(self.rows),
                "lower": self.lower, "upper": self.upper, "exact": self.exact,
                "provenance": self.provenance, "trajectory": self.trajectory,
                "reduction_costs": [len(w) for w in self.reductions]}


def exact_records(n):
    if n > 4:
        raise ValueError("exact BFS replay limited to n<=4")
    code_dir = str(HERE / "code")
    if code_dir not in sys.path:
        sys.path.insert(0, code_dir)
    from global_gradient import graph, _decode
    from collections import deque
    states, _, gate_list, neighbors, goal = graph(n)
    distance = [-1]*len(states)
    word = [None]*len(states)
    distance[goal] = 0
    word[goal] = ()
    queue = deque([goal])
    while queue:
        node = queue.popleft()
        for k, adjacent in enumerate(neighbors[node]):
            adjacent = int(adjacent)
            if distance[adjacent] == -1:
                distance[adjacent] = distance[node]+1
                # A CNOT is an involution; this word is an encoder from I.
                word[adjacent] = word[node] + (gate_list[k],)
                queue.append(adjacent)
    records = []
    for i, state in enumerate(states):
        rows = pack(_decode(state, n))
        rec = Record(rows, distance_lower_bound(rows), distance[i],
                     tuple(word[i]), distance[i], "own_exact_BFS", f"GL{n}_{i}")
        rec.verify()
        records.append(rec)
    return records


def synthetic_records(n, count, *, seed=1700, macros=()):
    rng = np.random.default_rng(seed)
    all_gates = gates(n)
    records = []
    for sample in range(count):
        length = int(rng.integers(1, max(3, min(3*n, 50))))
        word = tuple(all_gates[int(rng.integers(len(all_gates)))] for _ in range(length))
        rows = apply_word(identity(n), word)
        rec = Record(rows, distance_lower_bound(rows), len(word), word, None,
                     "own_random_walk", f"seed{seed}_walk{sample}")
        rec.verify()
        records.append(rec)
        if macros:
            macro = macros[sample % len(macros)]
            expanded = word + tuple(reversed(macro.word))
            grown = apply_word(identity(n), expanded)
            rec2 = Record(grown, distance_lower_bound(grown), len(expanded),
                          expanded, None, "own_stage17_basis_macro",
                          f"seed{seed}_walk{sample}")
            rec2.verify()
            records.append(rec2)
    best = {}
    for record in records:
        if record.rows not in best or record.upper < best[record.rows].upper:
            best[record.rows] = record
    return list(best.values())


def benchmark_matrix(name):
    allowed = {p.stem for p in STAGE17_INPUTS.glob("*.json")}
    if name not in allowed:
        raise ValueError("benchmark must come from own stage17 input allowlist")
    path = STAGE17_INPUTS / (name + ".json")
    raw = json.loads(path.read_text())
    return pack(np.asarray(raw["matrix"], dtype=np.uint8))


def trajectory_records(n, count, *, seed, macros=()):
    """Goal-connected prefixes; only certified lower==upper gives exact labels.

    All input trajectories are synthetic. No held-out benchmark is loaded.
    Recorded macro suffixes connect to a shorter known certificate, not to a
    state asserted to have a shorter true distance.
    """
    rng = np.random.default_rng(seed)
    available = gates(n)
    records = {}
    for sample in range(count):
        family = sample % 3
        segments = []
        if family == 0:
            permutation = rng.permutation(n).tolist()
            word = tuple((permutation[int(rng.integers(t))], permutation[t])
                         for t in range(1, n) if rng.random() < 0.85)
            provenance = "own_forest_exact"
        elif family == 1 and macros:
            word = ()
            for _ in range(int(rng.integers(1, 4))):
                macro = macros[int(rng.integers(len(macros)))]
                word += macro.word
                segments.append((len(word), tuple(reversed(macro.word))))
            provenance = "own_stage17_basis_macro"
        else:
            word = tuple(available[int(rng.integers(len(available)))]
                         for _ in range(int(rng.integers(1, max(3, 2*n)))))
            provenance = "own_random_walk"
        endings = dict(segments)
        # Keep all short prefixes plus regular samples and every macro boundary.
        indices = set(range(min(5, len(word)) + 1))
        indices.update(range(0, len(word)+1, max(1, len(word)//8)))
        indices.update(endings)
        indices.add(len(word))
        for end in sorted(indices):
            certificate = word[:end]
            rows = apply_word(identity(n), certificate)
            lower = distance_lower_bound(rows)
            exact = end if lower == end else None
            rec = Record(rows, lower, end, certificate, exact, provenance,
                         f"{seed}:{n}:{sample}",
                         (endings[end],) if end in endings else ())
            rec.verify()
            old = records.get(rows)
            if old is None or rec.upper < old.upper or (
                    rec.upper == old.upper and rec.reductions and not old.reductions):
                records[rows] = rec
    return list(records.values())
