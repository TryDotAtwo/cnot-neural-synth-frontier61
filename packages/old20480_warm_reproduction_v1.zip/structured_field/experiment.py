"""Refreshed goal-connected replay, independent validation, paired ablations.

All data is generated locally. Only benchmark.py opens stage17 target matrices.
There are no wall-clock cutoffs. Checkpoints contain optimizer and RNG state.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import time
from pathlib import Path

import numpy as np
import torch

from .basis_transitions import build_macros
from .data import exact_records, trajectory_records
from .gf2 import digest, identity
from .model import StructuralField, tensor_batch
from .objectives import loss_for_records, values


def atomic_torch_save(payload, path):
    temporary = path.with_suffix(".partial")
    torch.save(payload, temporary)
    temporary.replace(path)


def validation(model, records, device):
    model.eval()
    with torch.no_grad():
        pred = values(model, [r.rows for r in records], device=device, chunk=16).cpu().numpy()
    exact = [i for i, r in enumerate(records) if r.exact is not None]
    mae = float(np.abs(pred[exact]-np.array([records[i].exact for i in exact])).mean())
    upper = float(np.maximum(pred-np.array([r.upper for r in records]), 0).mean())
    lower = float(np.maximum(np.array([r.lower for r in records])-pred, 0).mean())
    by_size = {}
    for n in sorted({len(r.rows) for r in records}):
        ids = [i for i, r in enumerate(records) if len(r.rows) == n]
        exact_ids = [i for i in ids if records[i].exact is not None]
        by_size[n] = {"count": len(ids), "exact_count": len(exact_ids),
                      "exact_mae": float(np.abs(pred[exact_ids]-np.array(
                          [records[i].exact for i in exact_ids])).mean()) if exact_ids else None,
                      "upper_violation": float(np.maximum(pred[ids]-np.array(
                          [records[i].upper for i in ids]), 0).mean()),
                      "lower_violation": float(np.maximum(np.array(
                          [records[i].lower for i in ids])-pred[ids], 0).mean())}
    balanced_score = float(np.mean([(v["exact_mae"] or 0)+v["upper_violation"]+
                                    v["lower_violation"] for v in by_size.values()]))
    return {"exact_mae": mae, "upper_violation": upper, "lower_violation": lower,
            "count": len(records), "exact_count": len(exact), "score": balanced_score,
            "by_size": by_size}


def run(config, directory, *, resume=False):
    directory = Path(directory)
    if directory.exists() and not resume:
        raise FileExistsError(directory)
    directory.mkdir(parents=True, exist_ok=True)
    source_files = list(Path(__file__).parent.glob("*.py"))
    source_hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in source_files}
    checkpoint = None
    if resume:
        checkpoint = torch.load(directory / "last.pt", map_location="cpu", weights_only=False)
        old = checkpoint["config"]
        if any(old.get(k) != v for k, v in config.items() if k != "steps"):
            raise ValueError("resume may only extend the number of steps")
        if checkpoint.get("source_hashes", source_hashes) != source_hashes:
            raise ValueError("source changed; use a new labelled run instead of silent resume")
    (directory / "config.json").write_text(json.dumps(config, indent=2))
    (directory / "source_hashes.json").write_text(json.dumps(source_hashes, indent=2))
    torch.set_num_threads(4)
    seed = config["seed"]
    torch.manual_seed(seed)
    rng = random.Random(seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = StructuralField(**config["model"]).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config["learning_rate"], weight_decay=1e-4)
    sizes = config["sizes"]
    val, exact_train = [], {}
    for n in (3, 4):
        exact = exact_records(n)
        order = np.random.default_rng(seed+n).permutation(len(exact))
        val.extend(exact[int(i)] for i in order[:min(32, len(exact)//4)])
        exact_train[n] = [exact[int(i)] for i in order[min(32, len(exact)//4):]][:2048]
    for n in sizes:
        if n >= 8:
            val_macros = build_macros(n, count=2, seed=seed+90000+n, wide=True)
            val.extend(trajectory_records(n, 6, seed=seed+90000+n, macros=val_macros))
    forbidden = {digest(r.rows) for r in val}
    (directory / "validation_manifest.json").write_text(json.dumps([r.manifest() for r in val], indent=2))
    start = checkpoint["step"] if checkpoint else 0
    best = checkpoint["best_validation"] if checkpoint else float("inf")
    if checkpoint:
        model.load_state_dict(checkpoint["model"])
        optimizer.load_state_dict(checkpoint["optimizer"])
        rng.setstate(checkpoint["sampler_rng"])
        torch.set_rng_state(checkpoint["torch_rng"])
        if device.type == "cuda" and checkpoint.get("cuda_rng") is not None:
            torch.cuda.set_rng_state_all(checkpoint["cuda_rng"])
    last_generation = None
    started = time.perf_counter()
    for step in range(start+1, config["steps"]+1):
        generation = (step-1)//config["refresh_every"]
        if generation != last_generation:
            pools = {n: [r for r in pool if digest(r.rows) not in forbidden]
                     for n, pool in exact_train.items()}
            for n in sizes:
                if n < 8:
                    continue
                replay_seed = seed + 1000*generation + n
                macros = build_macros(n, count=4, seed=replay_seed, wide=True)
                pool = trajectory_records(n, config["trajectories_per_size"],
                                          seed=replay_seed, macros=macros)
                pools[n] = [r for r in pool if digest(r.rows) not in forbidden]
            manifest = [r.manifest() for pool in pools.values() for r in pool]
            (directory / f"replay_{generation:04d}.json").write_text(json.dumps(manifest, indent=2))
            print(json.dumps({"replay_generation": generation, "states": len(manifest),
                              "sizes": {n: len(p) for n, p in pools.items()}}), flush=True)
            last_generation = generation
        n = sizes[(step-1) % len(sizes)]
        pool = pools[n]
        batch = rng.sample(pool, min(config["microbatch"] if n <= 13 else 1, len(pool)))
        model.train()
        optimizer.zero_grad(set_to_none=True)
        loss, metrics = loss_for_records(model, batch, device=device,
                                         symmetry_weight=config.get("symmetry_weight", 0.0),
                                         use_recorded_basis=config["use_basis"])
        if not torch.isfinite(loss):
            raise FloatingPointError("nonfinite objective")
        loss.backward()
        norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        if not torch.isfinite(norm):
            raise FloatingPointError("nonfinite gradient")
        optimizer.step()
        row = {"step": step, "n": n, "loss": float(loss.detach()),
               "grad_norm": float(norm), "seconds": time.perf_counter()-started, **metrics}
        with (directory / "train.jsonl").open("a") as file:
            file.write(json.dumps(row)+"\n")
        if step % config["log_every"] == 0:
            print(json.dumps(row), flush=True)
        if step % config["validate_every"] == 0 or step == config["steps"]:
            report = validation(model, val, device)
            improved = report["score"] < best
            best = min(best, report["score"])
            with (directory / "validation.jsonl").open("a") as file:
                file.write(json.dumps({"step": step, **report})+"\n")
            saved = {"model": model.state_dict(), "optimizer": optimizer.state_dict(),
                     "step": step, "config": config, "best_validation": best,
                     "sampler_rng": rng.getstate(), "torch_rng": torch.get_rng_state(),
                     "cuda_rng": torch.cuda.get_rng_state_all() if device.type == "cuda" else None,
                     "source_hashes": source_hashes,
                     "parameter_count": model.parameter_count}
            atomic_torch_save(saved, directory / "last.pt")
            if improved:
                atomic_torch_save(saved, directory / "best.pt")
            print(json.dumps({"validation": report, "step": step}), flush=True)
    return {"run": str(directory), "steps": config["steps"], "seconds": time.perf_counter()-started}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("config", type=Path)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    print(json.dumps(run(json.loads(args.config.read_text()), args.directory, resume=args.resume)))
