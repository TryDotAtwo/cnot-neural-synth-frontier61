"""Exact GF(2) matrix states and CNOT transitions."""

from __future__ import annotations

import hashlib
import numpy as np


def pack(matrix):
    m = np.asarray(matrix, dtype=np.uint8)
    if m.ndim != 2 or m.shape[0] != m.shape[1] or np.any(m > 1):
        raise ValueError("expected a square binary matrix")
    return tuple(sum(int(bit) << j for j, bit in enumerate(row)) for row in m)


def unpack(rows):
    n = len(rows)
    return np.asarray([[(row >> j) & 1 for j in range(n)] for row in rows],
                      dtype=np.uint8)


def identity(n):
    return tuple(1 << i for i in range(n))


def apply_gate(rows, gate):
    c, t = gate
    if c == t or not (0 <= c < len(rows) and 0 <= t < len(rows)):
        raise ValueError("invalid CNOT")
    out = list(rows)
    out[t] ^= out[c]
    return tuple(out)


def apply_word(rows, word):
    for gate in word:
        rows = apply_gate(rows, gate)
    return rows


def gates(n):
    return [(c, t) for c in range(n) for t in range(n) if c != t]


def rank(rows):
    n = len(rows)
    work = list(rows)
    r = 0
    for col in range(n):
        pivot = next((i for i in range(r, n) if (work[i] >> col) & 1), None)
        if pivot is None:
            continue
        work[r], work[pivot] = work[pivot], work[r]
        for i in range(r+1, n):
            if (work[i] >> col) & 1:
                work[i] ^= work[r]
        r += 1
    return r


def distance_lower_bound(rows):
    difference = tuple(row ^ (1 << i) for i, row in enumerate(rows))
    changed_columns = 0
    for row in difference:
        changed_columns |= row
    # Each elementary factor changes one row under left multiplication and
    # one column under right multiplication. Both bound the same word length.
    return max(rank(difference), sum(row != 0 for row in difference),
               changed_columns.bit_count())


def inverse(rows):
    n = len(rows)
    left = list(rows)
    right = list(identity(n))
    for col in range(n):
        pivot = next((i for i in range(col, n) if (left[i] >> col) & 1), None)
        if pivot is None:
            raise ValueError("singular matrix")
        left[col], left[pivot] = left[pivot], left[col]
        right[col], right[pivot] = right[pivot], right[col]
        for i in range(n):
            if i != col and ((left[i] >> col) & 1):
                left[i] ^= left[col]
                right[i] ^= right[col]
    return tuple(right)


def relabel(rows, permutation):
    n = len(rows)
    if sorted(permutation) != list(range(n)):
        raise ValueError("invalid permutation")
    out = [0]*n
    for old_i in range(n):
        new_i = permutation[old_i]
        for old_j in range(n):
            if (rows[old_i] >> old_j) & 1:
                out[new_i] |= 1 << permutation[old_j]
    return tuple(out)


def transpose(rows):
    return pack(unpack(rows).T)


def digest(rows):
    n = len(rows)
    width = (n+7)//8
    return hashlib.sha256(n.to_bytes(4, "big") + b"".join(
        row.to_bytes(width, "little") for row in rows)).hexdigest()
