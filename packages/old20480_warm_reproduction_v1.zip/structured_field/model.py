"""Permutation-equivariant value encoder for whole binary matrices."""

from __future__ import annotations

import math
import numpy as np
import torch
from torch import nn


class StructuralBlock(nn.Module):
    def __init__(self, d=128, pair_d=32, heads=4, ffn=256):
        super().__init__()
        assert d % heads == 0
        self.d, self.heads = d, heads
        self.pair_update = nn.Sequential(nn.Linear(2*pair_d+11+2*d, ffn), nn.GELU(),
                                         nn.Linear(ffn, pair_d))
        self.pair_norm = nn.LayerNorm(pair_d)
        self.qkv = nn.Linear(d, 3*d)
        self.pair_bias = nn.Linear(pair_d, heads)
        self.out = nn.Linear(d, d)
        self.pair_out = nn.Linear(pair_d, d)
        self.pair_in = nn.Linear(pair_d, d)
        self.node_norm = nn.LayerNorm(d)
        self.node_ffn = nn.Sequential(nn.Linear(d, ffn), nn.GELU(), nn.Linear(ffn, d))
        self.node_ffn_norm = nn.LayerNorm(d)

    def forward(self, h, z, exact, valid):
        b, n, _ = h.shape
        node_mask = valid.unsqueeze(-1)
        pair_mask = (valid[:, :, None] & valid[:, None, :]).unsqueeze(-1)
        hi = h[:, :, None, :].expand(-1, -1, n, -1)
        hj = h[:, None, :, :].expand(-1, n, -1, -1)
        update = self.pair_update(torch.cat((z, z.transpose(1, 2), exact, hi, hj), -1))
        z = self.pair_norm(z + update) * pair_mask
        q, k, v = self.qkv(h).chunk(3, dim=-1)
        dh = self.d // self.heads
        q = q.reshape(b, n, self.heads, dh).transpose(1, 2)
        k = k.reshape(b, n, self.heads, dh).transpose(1, 2)
        v = v.reshape(b, n, self.heads, dh).transpose(1, 2)
        logits = (q @ k.transpose(-1, -2))/math.sqrt(dh)
        logits = logits + self.pair_bias(z).permute(0, 3, 1, 2)
        logits = logits.masked_fill(~valid[:, None, None, :], -1e9)
        attention = logits.softmax(-1)
        message = (attention @ v).transpose(1, 2).reshape(b, n, self.d)
        degree = valid.sum(1).clamp_min(1)[:, None, None]
        pair_out = z.sum(2)/degree
        pair_in = z.sum(1)/degree
        h = self.node_norm(h + self.out(message) + self.pair_out(pair_out) +
                           self.pair_in(pair_in)) * node_mask
        h = self.node_ffn_norm(h + self.node_ffn(h)) * node_mask
        return h, z


class StructuralField(nn.Module):
    def __init__(self, d=128, pair_d=32, blocks=6, heads=4, ffn=256,
                 bound_residual=False):
        super().__init__()
        self.config = dict(d=d, pair_d=pair_d, blocks=blocks, heads=heads, ffn=ffn,
                           bound_residual=bound_residual)
        self.bound_residual = bound_residual
        self.exact_pair = nn.Sequential(nn.Linear(11, pair_d), nn.GELU(),
                                        nn.Linear(pair_d, pair_d))
        self.node_initial = nn.Linear(2*pair_d, d)
        self.blocks = nn.ModuleList([StructuralBlock(d, pair_d, heads, ffn)
                                     for _ in range(blocks)])
        self.value = nn.Sequential(nn.Linear(3*d+pair_d+3, ffn), nn.GELU(),
                                   nn.Linear(ffn, 1))
        if bound_residual:
            nn.init.constant_(self.value[-1].bias,
                              0.0 if bound_residual == "shifted_softplus" else -2.0)

    @property
    def parameter_count(self):
        return sum(p.numel() for p in self.parameters())

    def forward(self, matrix, valid=None):
        if matrix.ndim != 3 or matrix.shape[-1] != matrix.shape[-2]:
            raise ValueError("matrix must have shape [B,N,N]")
        b, n, _ = matrix.shape
        if valid is None:
            valid = torch.ones((b, n), device=matrix.device, dtype=torch.bool)
        valid = valid.bool()
        m = matrix.to(dtype=torch.float32)
        pair_mask = (valid[:, :, None] & valid[:, None, :])
        m = m * pair_mask
        size = valid.sum(1).float()
        denominator = size[:, None, None]
        eye = torch.eye(n, device=matrix.device).unsqueeze(0)
        row_w = m.sum(-1)/size[:, None]
        col_w = m.sum(-2)/size[:, None]
        row_overlap = (m @ m.transpose(1, 2))/denominator
        col_overlap = (m.transpose(1, 2) @ m)/denominator
        exact = torch.stack((m, m.transpose(1, 2), eye.expand(b, -1, -1),
                             row_w[:, :, None].expand(-1, -1, n),
                             row_w[:, None, :].expand(-1, n, -1),
                             col_w[:, :, None].expand(-1, -1, n),
                             col_w[:, None, :].expand(-1, n, -1),
                             row_overlap, col_overlap,
                             size[:, None, None].expand(-1, n, n)/128,
                             ((m-eye).abs()*pair_mask).sum((1, 2))[:, None, None].expand(-1, n, n)/
                             (size[:, None, None]**2)), -1)
        exact = exact * pair_mask.unsqueeze(-1)
        z = self.exact_pair(exact) * pair_mask.unsqueeze(-1)
        degree = size[:, None, None]
        h = self.node_initial(torch.cat((z.sum(2)/degree, z.sum(1)/degree), -1))
        h = h * valid.unsqueeze(-1)
        for block in self.blocks:
            h, z = block(h, z, exact, valid)
        mask = valid.unsqueeze(-1)
        h_mean = h.sum(1)/size[:, None]
        h_scaled_sum = h.sum(1)/size.sqrt()[:, None]
        h_max = h.masked_fill(~mask, -1e9).max(1).values
        z_mean = z.sum((1, 2))/(size[:, None]**2)
        globals_ = torch.stack((size/128, size.log1p(),
                                ((m-eye).abs()*pair_mask).sum((1, 2))/(size**2)), -1)
        raw = self.value(torch.cat((h_mean, h_scaled_sum, h_max, z_mean,
                                    globals_), -1)).squeeze(-1)
        is_goal = (((m-eye).abs()*pair_mask).sum((1, 2)) == 0)
        prediction = nn.functional.softplus(raw)
        if self.bound_residual:
            error = ((m-eye).abs() * pair_mask) > 0
            lower = torch.maximum(error.any(2).sum(1), error.any(1).sum(1)).float()
            if self.bound_residual == "shifted_softplus":
                # Avoid saturation of a positive residual as it approaches zero.
                # The lower bound remains a supervised inequality, not a clamp.
                prediction = nn.functional.softplus(raw + lower)
            else:
                prediction = prediction + lower
        return torch.where(is_goal, torch.zeros_like(raw), prediction)


def tensor_batch(states, *, device=None, pad_to=None):
    if not states:
        raise ValueError("empty batch")
    nmax = max(len(s) for s in states) if pad_to is None else pad_to
    if any(len(s) > nmax for s in states):
        raise ValueError("padding too small")
    matrix_cpu = np.zeros((len(states), nmax, nmax), dtype=np.bool_)
    valid_cpu = np.zeros((len(states), nmax), dtype=np.bool_)
    for k, rows in enumerate(states):
        n = len(rows)
        valid_cpu[k, :n] = True
        width = (n+7)//8
        packed = b"".join(int(row).to_bytes(width, "little") for row in rows)
        bits = np.unpackbits(np.frombuffer(packed, dtype=np.uint8).reshape(n, width),
                             axis=1, bitorder="little")[:, :n]
        matrix_cpu[k, :n, :n] = bits
    matrix = torch.from_numpy(matrix_cpu).to(device=device)
    valid = torch.from_numpy(valid_cpu).to(device=device)
    return matrix, valid
