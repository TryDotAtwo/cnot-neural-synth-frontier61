"""Full active-branch Bellman gradient with bounded memory."""

from __future__ import annotations

import torch
from torch.nn import functional as F

from .gf2 import apply_gate, apply_word, gates, identity, inverse, transpose
from .model import tensor_batch


def values(model, states, *, device=None, chunk=64):
    result = []
    for start in range(0, len(states), chunk):
        m, valid = tensor_batch(states[start:start+chunk], device=device)
        result.append(model(m, valid))
    return torch.cat(result) if result else torch.empty(0, device=device)


def select_branch(model, state, macros=(), *, device=None, chunk=256, extra_words=()):
    """Select exact min over every CNOT and supplied paid macros, no grad."""
    gate_list = gates(len(state))
    if not gate_list:
        raise ValueError("nonterminal needs moves")
    best_score = float("inf")
    best = None
    chunk = min(chunk, max(1, 256000//(len(state)**2)))
    with torch.no_grad():
        base, _ = tensor_batch([state], device=device)
        for start in range(0, len(gate_list), chunk):
            selected = gate_list[start:start+chunk]
            pairs = torch.tensor(selected, device=device, dtype=torch.long)
            adjacent = base.expand(len(selected), -1, -1).clone()
            ids = torch.arange(len(selected), device=device)
            adjacent[ids, pairs[:, 1]] ^= adjacent[ids, pairs[:, 0]]
            scores = model(adjacent).cpu().tolist()
            for gate, score in zip(selected, scores):
                if 1+score < best_score:
                    best_score = 1+score
                    best = (1, apply_gate(state, gate), "cnot", gate)
        choices = [(macro.cost, macro.apply(state), "basis", i)
                   for i, macro in enumerate(macros)]
        choices += [(len(word), apply_word(state, word), "basis", tuple(word))
                    for word in extra_words]
        for start in range(0, len(choices), chunk):
            batch = choices[start:start+chunk]
            scores = values(model, [entry[1] for entry in batch],
                            device=device, chunk=chunk).cpu().tolist()
            for choice, score in zip(batch, scores):
                total = choice[0] + score
                if total < best_score:  # stable CNOT-first tie rule
                    best_score, best = total, choice
    return best


def loss_for_records(model, records, macros=(), *, device=None,
                     bellman_weight=1.0, macro_weight=0.2,
                     symmetry_weight=0.1, basis_rank_weight=0.0,
                     use_recorded_basis=False):
    if basis_rank_weight:
        raise ValueError("uncertified path ranking is not a valid distance-field constraint")
    states = [record.rows for record in records]
    m, valid = tensor_batch(states, device=device)
    estimate = model(m, valid)
    active = [i for i, state in enumerate(states) if state != identity(len(state))]
    zero = estimate.sum()*0
    winners = []
    if active:
        selected = [select_branch(model, states[i], macros if len(states[i]) >= 8 else (),
                                  device=device, extra_words=(records[i].reductions
                                  if use_recorded_basis else ())) for i in active]
        next_m, next_valid = tensor_batch([item[1] for item in selected], device=device)
        selected_values = model(next_m, next_valid)
        costs = torch.tensor([item[0] for item in selected], device=device,
                             dtype=estimate.dtype)
        residual = estimate[active] - costs - selected_values
        bellman = F.smooth_l1_loss(residual, torch.zeros_like(residual))
        winners = [item[2] for item in selected]
    else:
        bellman = zero
    lower = torch.tensor([r.lower for r in records], device=device,
                         dtype=estimate.dtype)
    upper = torch.tensor([r.upper for r in records], device=device,
                         dtype=estimate.dtype)
    bounds = (F.relu(lower-estimate).square() +
              F.relu(estimate-upper).square()).mean()
    exact_ids = [i for i, r in enumerate(records) if r.exact is not None]
    if exact_ids:
        truth = torch.tensor([records[i].exact for i in exact_ids], device=device,
                             dtype=estimate.dtype)
        exact = F.smooth_l1_loss(estimate[exact_ids], truth)
    else:
        exact = zero
    recorded_pairs = [(i, w) for i, r in enumerate(records)
                      for w in r.reductions] if use_recorded_basis else []
    if recorded_pairs:
        after = values(model, [apply_word(states[i], w) for i, w in recorded_pairs],
                       device=device)
        prices = torch.tensor([len(w) for _, w in recorded_pairs],
                              device=device, dtype=estimate.dtype)
        violation = F.relu(estimate[[i for i, _ in recorded_pairs]]-prices-after)
        macro_loss = violation.square().mean()
        macro_active = float((violation.detach() > 0).float().mean())
    elif macros and any(len(s) >= 8 for s in states):
        eligible = [i for i, s in enumerate(states) if len(s) >= 8]
        macro = macros[0]
        next_states = [macro.apply(states[i]) for i in eligible]
        macro_values = values(model, next_states, device=device)
        violation = F.relu(estimate[eligible] - macro.cost - macro_values)
        macro_loss = violation.square().mean()
        macro_active = float((violation.detach() > 0).float().mean())
    else:
        macro_loss = zero
        macro_active = 0.0
    # Relabeling is already enforced architecturally. These two symmetries
    # carry additional, nontrivial learning signal for the scalar field.
    if symmetry_weight:
        permuted = [transpose(s) if i % 2 == 0 else inverse(s)
                    for i, s in enumerate(states)]
        sym_values = values(model, permuted, device=device)
        symmetry = (estimate-sym_values).square().mean()
    else:
        symmetry = zero
    total = (bellman_weight*bellman + 0.2*bounds + exact +
             macro_weight*macro_loss + symmetry_weight*symmetry)
    metrics = {"bellman": float(bellman.detach()),
               "bounds": float(bounds.detach()), "exact": float(exact.detach()),
               "macro": float(macro_loss.detach()), "symmetry": float(symmetry.detach()),
               "macro_winner_fraction": (winners.count("basis")/len(winners) if winners else 0.0),
               "macro_active_fraction": macro_active,
               "recorded_basis_constraints": len(recorded_pairs),
               "exact_records": len(exact_ids)}
    return total, metrics
