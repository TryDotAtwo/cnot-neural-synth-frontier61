import numpy as np
import torch

from .gf2 import (apply_word, gates, identity, inverse, pack, relabel,
                  transpose, unpack)
from .model import StructuralField, tensor_batch
from .data import exact_records, synthetic_records
from .objectives import loss_for_records, select_branch
from .beam import search
from .basis_transitions import build_macros
from .data import Record, trajectory_records
from .gf2 import distance_lower_bound
import pytest


def test_noncommuting_word_and_inverse():
    word = [(0, 1), (1, 2), (0, 2)]
    target = apply_word(identity(3), word)
    assert target != apply_word(identity(3), list(reversed(word)))
    assert apply_word(target, list(reversed(word))) == identity(3)
    assert apply_word(inverse(target), word) == identity(3)
    assert pack(unpack(target)) == target


def test_structural_field_symmetry_padding_and_terminal():
    torch.manual_seed(5)
    net = StructuralField(d=32, pair_d=16, blocks=2, heads=4, ffn=64).eval()
    rows = apply_word(identity(5), [(0, 1), (1, 2), (0, 4), (3, 1)])
    permutation = [2, 4, 0, 1, 3]
    a, va = tensor_batch([rows])
    b, vb = tensor_batch([relabel(rows, permutation)])
    p, vp = tensor_batch([rows], pad_to=8)
    with torch.no_grad():
        x = net(a, va).item()
        y = net(b, vb).item()
        padded = net(p, vp).item()
        goal_m, goal_v = tensor_batch([identity(5)])
        goal = net(goal_m, goal_v).item()
    assert x > 0
    assert np.isclose(x, y, atol=1e-5, rtol=1e-5)
    assert np.isclose(x, padded, atol=1e-5, rtol=1e-5)
    assert goal == 0


def test_paid_macros_and_certificates():
    macros = build_macros(8, count=2)
    assert len(macros) == 2
    assert all(m.cost == 2*len(m.preparation)+len(m.core) for m in macros)
    records = synthetic_records(8, 8, macros=macros)
    assert any(r.provenance == "own_stage17_basis_macro" for r in records)
    for record in records:
        record.verify()


def test_active_branch_gradient_matches_full_autograd():
    torch.manual_seed(7)
    net = StructuralField(d=16, pair_d=8, blocks=1, heads=4, ffn=32)
    state = exact_records(3)[50].rows
    chosen = select_branch(net, state)
    current, valid = tensor_batch([state])
    next_m, next_valid = tensor_batch([chosen[1]])
    reduced = (net(current, valid) - chosen[0] - net(next_m, next_valid)).square().sum()
    grad_reduced = torch.autograd.grad(reduced, tuple(net.parameters()), retain_graph=False)
    neighbors = [apply_word(state, [g]) for g in gates(3)]
    all_m, all_valid = tensor_batch(neighbors)
    full = (net(current, valid) - 1 - net(all_m, all_valid).min()).square().sum()
    grad_full = torch.autograd.grad(full, tuple(net.parameters()))
    assert all(torch.allclose(a, b, atol=2e-5, rtol=2e-5)
               for a, b in zip(grad_reduced, grad_full))


def test_objective_and_one_beam():
    torch.manual_seed(11)
    net = StructuralField(d=16, pair_d=8, blocks=1, heads=4, ffn=32)
    records = exact_records(3)
    loss, metrics = loss_for_records(net, [records[0], records[1]])
    loss.backward()
    assert torch.isfinite(loss)
    assert all(p.grad is None or torch.isfinite(p.grad).all() for p in net.parameters())
    target = apply_word(identity(3), [(0, 1)])
    for model in (None, net):
        result = search(target, model=model, width=1, max_depth=3)
        assert result["reason"] == "solved" and result["count"] == 1


def test_certified_path_can_move_away_from_goal_and_terminal_batch():
    # A longer encoder certificate does not imply a larger true distance.
    word = ((0, 1),)
    certificate = word + tuple(reversed(word))
    record = Record(identity(3), 0, 2, certificate, 0, "own_random_walk",
                    "cancellation", (word,))
    record.verify()
    assert apply_word(record.rows, word) != identity(3)
    net = StructuralField(d=16, pair_d=8, blocks=1, heads=4, ffn=32,
                          bound_residual=True)
    loss, metrics = loss_for_records(net, [record], use_recorded_basis=True)
    loss.backward()
    assert torch.isfinite(loss) and metrics["bellman"] == 0
    with pytest.raises(ValueError, match="uncertified"):
        loss_for_records(net, [record], basis_rank_weight=0.5)


def test_stronger_lower_bound_and_exact_forests():
    for record in exact_records(3):
        assert distance_lower_bound(record.rows) <= record.exact
    records = trajectory_records(13, 6, seed=72, macros=build_macros(13, count=2))
    for record in records:
        record.verify()
        if record.provenance == "own_forest_exact":
            assert record.exact == record.upper


def test_bound_residual_and_goal_cannot_be_hidden_by_scorer():
    net = StructuralField(d=16, pair_d=8, blocks=1, heads=4, ffn=32,
                          bound_residual=True)
    states = [r.rows for r in exact_records(3)[:12]]
    matrix, mask = tensor_batch(states)
    result = net(matrix, mask).detach().numpy()
    for state, value in zip(states, result):
        row_lb = sum(row != 1 << i for i, row in enumerate(state))
        assert value >= row_lb
    class BadGoalScore(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.dummy = torch.nn.Parameter(torch.zeros(()))
        def forward(self, matrix, valid):
            n = matrix.shape[-1]
            return (matrix == torch.eye(n, dtype=torch.bool)).all(2).all(1).float()*100
    target = apply_word(identity(3), [(0, 1)])
    assert search(target, model=BadGoalScore(), width=1, max_depth=1,
                  per_parent_cap=1)["count"] == 1


def test_macro_can_win_full_backup_and_gradient_reaches_current():
    class ConstantNonterminal(torch.nn.Module):
        def __init__(self):
            super().__init__()
            self.value = torch.nn.Parameter(torch.tensor(10.0))
        def forward(self, matrix, valid=None):
            n = matrix.shape[-1]
            goal = (matrix == torch.eye(n, dtype=torch.bool)).all(2).all(1)
            return torch.where(goal, torch.zeros_like(goal, dtype=torch.float32), self.value)
    net = ConstantNonterminal()
    encoder = ((0, 1), (1, 2))
    state = apply_word(identity(3), encoder)
    reduction = tuple(reversed(encoder))
    branch = select_branch(net, state, extra_words=(reduction,))
    assert branch[0] == 2 and branch[1] == identity(3) and branch[2] == "basis"
    record = Record(state, distance_lower_bound(state), 2, encoder, 2,
                    "own_random_walk", "macro-test", (reduction,))
    loss, metrics = loss_for_records(net, [record], use_recorded_basis=True)
    loss.backward()
    assert metrics["macro_winner_fraction"] == 1
    assert net.value.grad > 0


def test_shifted_value_head_keeps_gradient_near_lower_bound():
    net = StructuralField(d=16, pair_d=8, blocks=1, heads=4, ffn=32,
                          bound_residual="shifted_softplus")
    torch.nn.init.zeros_(net.value[-1].weight)
    torch.nn.init.zeros_(net.value[-1].bias)
    state = apply_word(identity(13), [(0, t) for t in range(1, 13)])
    matrix, valid = tensor_batch([state])
    result = net(matrix, valid)
    result.sum().backward()
    assert abs(result.item()-12) < 1e-4
    assert net.value[-1].bias.grad.item() > 0.99
