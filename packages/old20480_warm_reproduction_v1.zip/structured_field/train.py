"""Reproducible training of the structural full-matrix value field."""

from __future__ import annotations

import argparse
import hashlib
import json
import random
import time
from pathlib import Path

import numpy as np
import torch

from .basis_transitions import build_macros
from .data import STAGE17_INPUTS, exact_records, synthetic_records
from .model import StructuralField
from .objectives import loss_for_records


def _records(config):
    macros = build_macros(8, count=config["macro_count"], seed=config["seed"])
    records = []
    if config.get("include_small_exact", True):
        for n in (3, 4):
            exact = exact_records(n)
            # Fixed spread covers different exact distances.
            take = config["exact_per_size"]
            indices = np.linspace(0, len(exact)-1, min(take, len(exact)), dtype=int)
            records.extend(exact[int(i)] for i in indices)
    records.extend(synthetic_records(8, config["synthetic_count"],
                                     seed=config["seed"], macros=macros))
    if config.get("synthetic_n13_count", 0):
        macros13 = build_macros(13, count=config["macro_count"], seed=config["seed"]+1)
        records.extend(synthetic_records(13, config["synthetic_n13_count"],
                                         seed=config["seed"]+1, macros=macros13))
    return records, {8: macros, 13: (macros13 if config.get("synthetic_n13_count", 0) else [])}


def train(config, run_dir, *, resume=False):
    run_dir = Path(run_dir)
    if run_dir.exists() and not resume:
        raise FileExistsError(f"run directory already exists: {run_dir}")
    run_dir.mkdir(parents=True, exist_ok=True)
    (run_dir / "config.json").write_text(json.dumps(config, indent=2))
    torch.set_num_threads(4)
    random.seed(config["seed"])
    np.random.seed(config["seed"])
    torch.manual_seed(config["seed"])
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    records, macros = _records(config)
    (run_dir / "replay_manifest.json").write_text(json.dumps(
        [r.manifest() for r in records], indent=2))
    source_hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                     for p in sorted(STAGE17_INPUTS.glob("*.json"))}
    (run_dir / "source_hashes.json").write_text(json.dumps(source_hashes, indent=2))
    model = StructuralField(**config["model"]).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=config["learning_rate"],
                                  weight_decay=config["weight_decay"])
    start_step = 0
    if resume:
        checkpoint = torch.load(run_dir / "last.pt", map_location="cpu", weights_only=False)
        model.load_state_dict(checkpoint["model"])
        optimizer.load_state_dict(checkpoint["optimizer"])
        start_step = checkpoint["step"]
        random.setstate(checkpoint["python_rng"])
        np.random.set_state(checkpoint["numpy_rng"])
        torch.set_rng_state(checkpoint["torch_rng"])
    started = time.perf_counter()
    logs = []
    for step in range(start_step+1, config["steps"]+1):
        # Mixed sizes use shared model weights; each microbatch has one n.
        index = random.randrange(len(records))
        record = records[index]
        same_n = [r for r in records if len(r.rows) == len(record.rows)]
        batch = random.sample(same_n, min(config["microbatch"], len(same_n)))
        active_macros = macros.get(len(record.rows), []) if config["use_basis"] else []
        optimizer.zero_grad(set_to_none=True)
        loss, metrics = loss_for_records(model, batch, active_macros, device=device,
                                         basis_rank_weight=config.get("basis_rank_weight", 0.0))
        if not torch.isfinite(loss):
            raise FloatingPointError("nonfinite training loss")
        loss.backward()
        norm = torch.nn.utils.clip_grad_norm_(model.parameters(), config["gradient_clip"])
        if not torch.isfinite(norm):
            raise FloatingPointError("nonfinite gradient norm")
        optimizer.step()
        row = {"step": step, "n": len(record.rows), "loss": float(loss.detach()),
               "gradient_norm": float(norm), "seconds": time.perf_counter()-started,
               **metrics}
        logs.append(row)
        if step % config["log_every"] == 0 or step == config["steps"]:
            print(json.dumps(row), flush=True)
            with (run_dir / "train.jsonl").open("a") as handle:
                for item in logs:
                    handle.write(json.dumps(item)+"\n")
            logs.clear()
        if step % config["checkpoint_every"] == 0 or step == config["steps"]:
            checkpoint = {"model": model.state_dict(), "optimizer": optimizer.state_dict(),
                          "step": step, "config": config,
                          "python_rng": random.getstate(), "numpy_rng": np.random.get_state(),
                          "torch_rng": torch.get_rng_state(),
                          "source_hashes": source_hashes,
                          "parameter_count": model.parameter_count}
            torch.save(checkpoint, run_dir / "last.pt")
    return {"run_dir": str(run_dir), "steps": config["steps"],
            "parameter_count": model.parameter_count,
            "seconds": time.perf_counter()-started}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("config", type=Path)
    parser.add_argument("run_dir", type=Path)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    config = json.loads(args.config.read_text())
    print(json.dumps(train(config, args.run_dir, resume=args.resume)))


if __name__ == "__main__":
    main()
