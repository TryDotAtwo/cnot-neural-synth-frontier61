"""Exact root-plus-CNOT closure index without expanded full matrices.

An index stores fingerprints and reversible integer descriptors. Every hash
candidate is reconstructed and compared in full; collisions cannot admit a
false match. CPU is supported only for tiny reference tests. Native CUDA
acceptance and journal/loader integration are separate gates.
"""
from dataclasses import dataclass
import torch


@dataclass(frozen=True)
class CompactOneHopBank:
    roots: torch.Tensor
    sorted_hashes: torch.Tensor
    sorted_codes: torch.Tensor
    hash_weights: torch.Tensor

    @classmethod
    def from_roots(cls, roots, *, action_chunk, max_entries, hash_weights=None):
        if roots.dtype != torch.int64 or roots.ndim != 3 or roots.shape[0] < 1:
            raise ValueError('nonempty packed int64 roots required')
        count,n,words=roots.shape
        if n < 2 or words != (n+63)//64:
            raise ValueError('complete packed matrix shape required')
        if type(action_chunk) is not int or action_chunk < 1 or type(max_entries) is not int or max_entries < 1:
            raise ValueError('positive explicit index budgets required')
        actions=n*(n-1)
        entries=count*(actions+1)
        if entries > max_entries:
            raise MemoryError(f'complete one-hop index requires {entries} entries; cap {max_entries}')
        if hash_weights is None:
            generator=torch.Generator(device=roots.device).manual_seed(0x19D2765)
            hash_weights=torch.randint(1,2**63-1,(n,words),device=roots.device,
                                       dtype=torch.int64,generator=generator)
        if hash_weights.dtype != torch.int64 or hash_weights.shape != (n,words) or hash_weights.device != roots.device:
            raise ValueError('fingerprint weights shape/device mismatch')
        # Own the actual immutable inputs, rather than aliases supplied by callers.
        roots=roots.clone().contiguous(); hash_weights=hash_weights.clone().contiguous()
        hashes=torch.empty(entries,dtype=torch.int64,device=roots.device)
        codes=torch.arange(entries,dtype=torch.int64,device=roots.device)
        base=(roots*hash_weights[None]).flatten(1).sum(1)
        layout=hashes.reshape(count,actions+1)
        layout[:,0]=base
        for start in range(0,actions,action_chunk):
            action=torch.arange(start,min(actions,start+action_chunk),device=roots.device)
            control=action//(n-1)
            target=action%(n-1)
            target=target+(target>=control).to(torch.int64)
            changed=roots[:,target]^roots[:,control]
            delta=((changed-roots[:,target])*hash_weights[target][None]).sum(-1)
            layout[:,start+1:start+1+len(action)]=base[:,None]+delta
        order=torch.argsort(hashes,stable=True)
        return cls(roots,hashes[order],codes[order],hash_weights)

    def reconstruct(self, codes):
        actions=self.roots.shape[1]*(self.roots.shape[1]-1)
        if codes.dtype != torch.int64 or codes.device != self.roots.device:
            raise ValueError('index descriptor dtype/device mismatch')
        if bool(((codes<0)|(codes>=self.sorted_codes.numel())).any()):
            raise ValueError('index descriptor outside complete closure')
        flat=codes.reshape(-1)
        root=flat//(actions+1); local=flat%(actions+1)
        action=(local-1).clamp(min=0)
        control=action//(self.roots.shape[1]-1)
        target=action%(self.roots.shape[1]-1)
        target=target+(target>=control).to(torch.int64)
        matrices=self.roots[root].clone()
        batch=torch.arange(len(flat),device=flat.device)
        new=matrices[batch,target]^matrices[batch,control]
        matrices[batch,target]=torch.where((local>0)[:,None],new,matrices[batch,target])
        return matrices.reshape(*codes.shape,*self.roots.shape[1:])

    def matches(self, rows, *, candidate_chunk=256, query_chunk=256):
        if rows.dtype != torch.int64 or rows.device != self.roots.device or rows.ndim not in (3,4) or rows.shape[-2:] != self.roots.shape[1:]:
            raise ValueError('full packed query shape/device mismatch')
        if type(candidate_chunk) is not int or candidate_chunk < 1:
            raise ValueError('positive candidate chunk required')
        if type(query_chunk) is not int or query_chunk < 1:
            raise ValueError('positive query chunk required')
        leading=rows.shape[:-2]; query=rows.reshape(-1,*self.roots.shape[1:])
        if len(query)==0:
            return torch.zeros(leading,dtype=torch.bool,device=rows.device)
        if len(query)>query_chunk:
            return torch.cat([self.matches(query[start:start+query_chunk],
                candidate_chunk=candidate_chunk,query_chunk=query_chunk)
                for start in range(0,len(query),query_chunk)]).reshape(leading)
        hashes=(query*self.hash_weights[None]).flatten(1).sum(1)
        left=torch.searchsorted(self.sorted_hashes,hashes,right=False)
        right=torch.searchsorted(self.sorted_hashes,hashes,right=True)
        counts=right-left
        result=torch.zeros(len(query),dtype=torch.bool,device=rows.device)
        for offset in range(0,int(counts.max().item()),candidate_chunk):
            slots=torch.arange(offset,min(offset+candidate_chunk,int(counts.max().item())),device=rows.device)
            active=(slots[None]<counts[:,None])&~result[:,None]
            qi,slot=torch.where(active)
            if len(qi)==0:
                continue
            index=left[qi]+slots[slot]
            matrices=self.reconstruct(self.sorted_codes[index])
            exact=(matrices==query[qi]).flatten(1).all(1)
            result[qi[exact]]=True
        return result.reshape(leading)
