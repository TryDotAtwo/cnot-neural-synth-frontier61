"""GPU first-order paid basis-proposer loss for an ordered source template.

The paired conditional Monte Carlo estimator follows the own wide basis
objective. This slice binds one full matrix to its deterministic partial
elimination block; a production batched template sampler remains open.
"""

from dataclasses import dataclass

import torch

from ..basis.templates import BasisChoice, BasisTemplate
from .basis_proposer import (batched_basis_proposal,
                             sample_ordered_source_pairs)
from .field_slice import (complete_bellman_slice, gpu_field_inputs,
                          gpu_field_value, gpu_qhat_loss)
from .holdout import GpuExactHoldout, admit_complete_neighborhood
from .packed_walk import PackedWalkBatch
from .structural_e import selected_e_features
from .verified_supervision import (interval_from_verified_walk,
                                   interval_hinge_loss,
                                   verified_walk_teacher_loss)


@dataclass(frozen=True)
class GpuBasisMcAudit:
    sample_costs: torch.Tensor
    gradient: torch.Tensor
    bits: torch.Tensor
    evaluations: int
    physical_width: int


def paid_source_cost(block: torch.Tensor, bits: torch.Tensor,
                     pairs: torch.Tensor) -> torch.Tensor:
    pair_batch = pairs[None].expand(block.shape[0], -1, -1) if pairs.ndim == 2 else pairs
    if (block.device.type != 'cuda' or block.ndim != 3 or block.dtype != torch.bool or
            bits.device != block.device or pairs.device != block.device or
            bits.ndim != 2 or bits.dtype != torch.bool or
            pair_batch.ndim != 3 or pair_batch.shape[2] != 2 or
            pair_batch.dtype != torch.int64 or
            block.shape[0] != bits.shape[0] or
            pair_batch.shape[:2] != bits.shape or
            bool(((pair_batch < 0) | (pair_batch >= block.shape[2]) |
                  (pair_batch[:, :, :1] == pair_batch[:, :, 1:])).any().item())):
        raise ValueError('invalid CUDA paid source template')
    current = block.clone()
    batch_ids = torch.arange(block.shape[0], device=block.device)
    for step in range(pair_batch.shape[1]):
        control = pair_batch[:, step, 0]
        target = pair_batch[:, step, 1]
        source_column = current[batch_ids, :, target].clone()
        current[batch_ids, :, control] = current[batch_ids, :, control] ^ \
                                  (source_column & bits[:, step, None])
    return 2 * bits.sum(dim=1, dtype=torch.int64) + \
           current.sum(dim=(1, 2), dtype=torch.int64)


def differentiable_gpu_mc_cost(block: torch.Tensor, theta: torch.Tensor,
                               pairs: torch.Tensor, *, samples: int,
                               seed: int, max_evaluations: int,
                               max_bytes: int) -> tuple[torch.Tensor, GpuBasisMcAudit]:
    if (block.device.type != 'cuda' or block.ndim != 3 or block.shape[0] != 1 or
            theta.device != block.device or theta.ndim != 1 or
            theta.shape[0] != pairs.shape[0] or samples < 1 or seed < 0 or
            not bool(((theta >= 0) & (theta <= 1) & torch.isfinite(theta)).all().item())):
        raise ValueError('invalid CUDA basis MC input')
    evaluations = samples * (1 + 2 * len(theta))
    if evaluations > max_evaluations:
        raise RuntimeError('resource_limit: complete MC gradient exceeds evaluation budget')
    estimated_bytes = block.shape[1] * block.shape[2] * 64 + \
                      samples * (len(theta) + 1) * 8
    if estimated_bytes > max_bytes:
        raise MemoryError('resource_limit: MC workspace preflight')
    generator = torch.Generator(device=block.device)
    generator.manual_seed(seed)
    uniforms = torch.rand((samples, len(theta)), device=block.device,
                          generator=generator)
    bits = uniforms < theta.detach()[None]
    repeated = block.expand(samples, -1, -1)
    costs = paid_source_cost(repeated, bits, pairs)
    gradients = []
    for step in range(len(theta)):
        zero, one = bits.clone(), bits.clone()
        zero[:, step] = False
        one[:, step] = True
        gradients.append(paid_source_cost(repeated, one, pairs) -
                         paid_source_cost(repeated, zero, pairs))
    gradient = torch.stack(gradients, dim=1).to(theta.dtype).mean(dim=0)
    value = costs.to(theta.dtype).mean()
    loss = value + ((theta - theta.detach()) * gradient).sum()
    return loss, GpuBasisMcAudit(costs, gradient, bits, evaluations,
                                  block.shape[2])


def differentiable_gpu_batched_mc_cost(block: torch.Tensor,
                                       theta: torch.Tensor,
                                       pairs: torch.Tensor, *, samples: int,
                                       generator: torch.Generator,
                                       available: torch.Tensor,
                                       max_evaluations: int,
                                       max_bytes: int) -> tuple[torch.Tensor, GpuBasisMcAudit]:
    if (block.device.type != 'cuda' or block.ndim != 3 or
            theta.device != block.device or theta.ndim != 2 or
            pairs.device != block.device or pairs.shape != (*theta.shape, 2) or
            available.device != block.device or available.shape != (block.shape[0],) or
            available.dtype != torch.bool or theta.shape[0] != block.shape[0] or
            samples < 1 or generator.device.type != 'cuda' or
            not bool(((theta >= 0) & (theta <= 1) & torch.isfinite(theta)).all().item())):
        raise ValueError('invalid CUDA batched basis MC input')
    batch, choices = theta.shape
    evaluations = batch * samples * (1 + 2 * choices)
    if evaluations > max_evaluations:
        raise RuntimeError('resource_limit: complete batched MC gradient exceeds budget')
    estimated_bytes = batch * block.shape[1] * block.shape[2] * 64 + \
                      batch * samples * (choices + 1) * 8
    if estimated_bytes > max_bytes:
        raise MemoryError('resource_limit: batched MC workspace preflight')
    uniforms = torch.rand((batch, samples, choices), device=block.device,
                          generator=generator)
    bits = uniforms < theta.detach()[:, None, :]
    repeated_block = block[:, None].expand(-1, samples, -1, -1).reshape(
        batch * samples, block.shape[1], block.shape[2])
    repeated_pairs = pairs[:, None].expand(-1, samples, -1, -1).reshape(
        batch * samples, choices, 2)
    flat_bits = bits.reshape(batch * samples, choices)
    costs = paid_source_cost(repeated_block, flat_bits, repeated_pairs).reshape(batch, samples)
    differences = []
    for step in range(choices):
        zero, one = flat_bits.clone(), flat_bits.clone()
        zero[:, step] = False
        one[:, step] = True
        differences.append(paid_source_cost(repeated_block, one, repeated_pairs) -
                           paid_source_cost(repeated_block, zero, repeated_pairs))
    gradient = torch.stack(differences, dim=1).reshape(batch, samples, choices)
    gradient = gradient.to(theta.dtype).mean(dim=1)
    weights = available.to(theta.dtype)
    denominator = weights.sum().clamp_min(1)
    value = (costs.to(theta.dtype).mean(dim=1) * weights).sum() / denominator
    surrogate = (((theta - theta.detach()) * gradient).sum(dim=1) *
                 weights).sum() / denominator
    return value + surrogate, GpuBasisMcAudit(costs, gradient, bits,
                                               evaluations, block.shape[2])


def complete_joint_basis_slice(model, rows: torch.Tensor, *, pairs: tuple[tuple[int, int], ...],
                               action_chunk: int, samples: int, seed: int,
                               max_evaluations: int, max_bytes: int,
                               weight: float, qhat_weight: float = 0.1,
                               mc_samples: int = 8,
                               max_pair_states: int = 10000):
    """One-root complete Bellman and bound partial-basis proposer gradient."""
    if (rows.device.type != 'cuda' or rows.ndim != 3 or rows.shape[0] != 1 or
            weight <= 0 or qhat_weight < 0 or not pairs):
        raise ValueError('one-root CUDA joint basis slice contract')
    field_loss, field_audit = complete_bellman_slice(
        model.field, rows, action_chunk=action_chunk, mc_samples=mc_samples,
        mc_seed=seed, max_pair_states=max_pair_states)
    qhat_loss = gpu_qhat_loss(model.field, rows, field_audit['primitive_totals'],
                              mc_samples=mc_samples, mc_seed=seed,
                              max_pair_states=max_pair_states) if qhat_weight else field_loss * 0
    field_loss = field_loss + qhat_weight * qhat_loss
    partial = selected_e_features(rows)
    if not bool(partial.available[0].item()):
        return field_loss, {'field': field_audit, 'qhat_loss': qhat_loss.detach(),
                            'basis_status': 'unavailable'}
    n = rows.shape[1]
    width = n // 2
    template = BasisTemplate(n, tuple(range(width)), tuple(range(width, n)),
                             'source', tuple(BasisChoice('add', control, target)
                                             for control, target in pairs))
    batch, packet = gpu_field_inputs(rows, mc_samples=mc_samples, mc_seed=seed,
                                     column_heat='G01' in model.field.stem.specs,
                                     pair_heat='G06' in model.field.stem.specs,
                                     max_pair_states=max_pair_states)
    encoded = model.field.stem(batch, packet)
    theta = model.proposer(encoded, template)
    pair_tensor = torch.tensor(pairs, device=rows.device, dtype=torch.int64)
    basis_loss, basis_audit = differentiable_gpu_mc_cost(
        partial.block, theta, pair_tensor, samples=samples, seed=seed,
        max_evaluations=max_evaluations, max_bytes=max_bytes)
    return field_loss + weight * basis_loss, {
        'field': field_audit,
        'qhat_loss': qhat_loss.detach(),
        'basis_status': 'evaluated',
        'basis_loss': basis_loss.detach(),
        'basis_gradient': basis_audit.gradient,
        'basis_samples': basis_audit.bits,
        'basis_evaluations': basis_audit.evaluations,
        'theta': theta.detach(),
    }


def complete_joint_basis_batch(model, rows: torch.Tensor, *,
                               generator: torch.Generator,
                               choice_count: int, action_chunk: int,
                               samples: int, max_evaluations: int,
                               max_bytes: int, weight: float,
                               qhat_weight: float = 0.1,
                               training_walk: PackedWalkBatch | None = None,
                               supervision_weight: float = 1.0,
                               teacher_weight: float = 0.1,
                               holdout: GpuExactHoldout | None = None,
                               mc_samples: int = 8, mc_seed: int = 0,
                               max_pair_states: int = 10000,
                               phase_profile: bool = False):
    """GPU batch route for full Bellman and sampled paid source proposals.

    The external caller owns a durable CUDA RNG and a sealed holdout bank.
    A supplied generation word is fully replayed before interval supervision.
    Teacher, suffix admission, checkpointing and full search are separate.
    """
    if (rows.device.type != 'cuda' or rows.ndim != 3 or rows.shape[0] < 1 or
            weight <= 0 or qhat_weight < 0 or supervision_weight < 0 or
            teacher_weight < 0 or
            generator.device.type != 'cuda' or choice_count < 1):
        raise ValueError('CUDA joint basis batch contract')
    admission_count = 0
    if holdout is not None:
        admission_count = admit_complete_neighborhood(holdout, rows,
                                                       chunk_size=action_chunk)
    if training_walk is not None and not torch.equal(training_walk.rows, rows):
        raise ValueError('training word belongs to a different matrix batch')
    labels = interval_from_verified_walk(training_walk) if training_walk is not None else None
    field_loss, field_audit = complete_bellman_slice(
        model.field, rows, action_chunk=action_chunk, mc_samples=mc_samples,
        mc_seed=mc_seed, max_pair_states=max_pair_states,
        phase_profile=phase_profile)
    qhat_loss = gpu_qhat_loss(model.field, rows, field_audit['primitive_totals'],
                              mc_samples=mc_samples, mc_seed=mc_seed,
                              max_pair_states=max_pair_states) if qhat_weight else field_loss * 0
    interval_loss = (interval_hinge_loss(
        gpu_field_value(model.field, rows, mc_samples=mc_samples, mc_seed=mc_seed,
                        max_pair_states=max_pair_states), rows, labels)
                     if labels is not None and supervision_weight else field_loss * 0)
    teacher_loss = field_loss * 0
    if labels is not None and teacher_weight:
        teacher_batch, teacher_packet = gpu_field_inputs(
            rows, mc_samples=mc_samples if any(key in model.field.stem.specs
                                                for key in ('G07', 'G08', 'G09', 'G10')) else 0,
            mc_seed=mc_seed, column_heat='G01' in model.field.stem.specs,
            pair_heat='G06' in model.field.stem.specs,
            max_pair_states=max_pair_states)
        teacher_encoded = model.field.stem(teacher_batch, teacher_packet)
        teacher_value = model.field.value(teacher_encoded)
        proposal, _, _ = model.field.auxiliary(
            teacher_encoded.wire, teacher_encoded.pair, teacher_value,
            teacher_encoded.valid)
        teacher_loss = verified_walk_teacher_loss(proposal, training_walk, labels)
    field_loss = (field_loss + qhat_weight * qhat_loss +
                  supervision_weight * interval_loss + teacher_weight * teacher_loss)
    partial = selected_e_features(rows)
    active = torch.nonzero(partial.available).flatten()
    if active.numel() == 0 or rows.shape[1] // 2 < 2:
        return field_loss, {'field': field_audit,
                            'qhat_loss': qhat_loss.detach(),
                            'interval_loss': interval_loss.detach(),
                            'teacher_loss': teacher_loss.detach(),
                            'verified_interval': labels is not None,
                            'basis_status': 'unavailable',
                            'admitted_parent_and_neighbors': admission_count,
                            'basis_evaluations': 0}
    batch, packet = gpu_field_inputs(
        rows, mc_samples=mc_samples if any(key in model.field.stem.specs
                                            for key in ('G07', 'G08', 'G09', 'G10')) else 0,
        mc_seed=mc_seed, column_heat='G01' in model.field.stem.specs,
        pair_heat='G06' in model.field.stem.specs,
        max_pair_states=max_pair_states)
    encoded = model.field.stem(batch, packet)
    width = rows.shape[1] // 2
    pairs = sample_ordered_source_pairs(rows.shape[0], width, choice_count,
                                         generator=generator, device=rows.device)
    theta = batched_basis_proposal(model.proposer, encoded, pairs,
                                   source_width=width)
    selected = active
    basis_loss, basis_audit = differentiable_gpu_batched_mc_cost(
        partial.block[selected], theta[selected], pairs[selected],
        samples=samples, generator=generator,
        available=torch.ones(selected.numel(), device=rows.device,
                             dtype=torch.bool),
        max_evaluations=max_evaluations, max_bytes=max_bytes)
    return field_loss + weight * basis_loss, {
        'field': field_audit,
        'qhat_loss': qhat_loss.detach(),
        'interval_loss': interval_loss.detach(),
        'teacher_loss': teacher_loss.detach(),
        'verified_interval': labels is not None,
        'basis_status': 'evaluated',
        'admitted_parent_and_neighbors': admission_count,
        'basis_evaluations': basis_audit.evaluations,
        'basis_active_count': selected.numel(),
        'sampled_pairs': pairs.detach(),
        'theta': theta.detach(),
        'basis_gradient': basis_audit.gradient.detach(),
        'basis_loss': basis_loss.detach(),
    }
