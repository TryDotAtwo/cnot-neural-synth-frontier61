"""Transfer verified own training records into a GPU full-word batch.

The input is archival metadata; all matrix products and final certificates are
checked again on CUDA. A reduction M->I is reversed to the generation order
expected by ``PackedWalkBatch``.
"""

from dataclasses import dataclass

import torch

from ..contracts import AlphabetSpec, MatrixState
from ..data.records import SampleRecord
from .packed_walk import (PackedWalkBatch, apply_gates, identity_rows,
                          verify_inverse)


OWN_SOURCES = frozenset(('ordinary_walk_v1', 'poisson_walk_v1',
                         'own_stage17_basis_program'))
OWN_PRODUCERS = {
    'ordinary_walk_v1': frozenset(('ordinary_walk_v1',
                                   'own_stage17_full_matrix_synth')),
    'poisson_walk_v1': frozenset(('poisson_walk_v1',
                                  'own_stage17_full_matrix_synth')),
    'own_stage17_basis_program': frozenset(('direct_shear_incumbent',
                                             'own_compile_shear_exact_local')),
}
OWN_PRODUCERS.update({
    'own_composition_v1': frozenset(('own_composition_v1', 'own_stage17_full_matrix_synth')),
    'stage18_bipartite_exact_v1': frozenset(('stage18_bipartite_exact_v1',)),
    'stage35_pair_exact_v1': frozenset(('stage35_pair_exact_v1',)),
    'stage37_zero_excess_exact_v1': frozenset(('stage37:zero_excess',)),
})
OWN_SOURCES = frozenset(OWN_PRODUCERS)


def validate_own_records(records):
    """CPU acceptance shared by transfer and tests, before CUDA allocation.

    The packed CUDA path below still replays the complete word independently.
    Exact claims are re-recognized from the full matrix, never trusted by tag.
    """
    from ..data.stream_reader_v13 import validate_exact
    from ..words import verify_word
    if not records:
        raise ValueError('empty own record batch')
    n = records[0].state.n
    alphabet = AlphabetSpec.all_to_all(n)
    if not 2 <= n <= 256 or len({r.state.key for r in records}) != len(records):
        raise ValueError('unsupported width or duplicate root')
    selected_words = []
    for record in records:
        if (record.split != 'train' or record.source not in OWN_SOURCES or
                record.state.n != n or record.state.alphabet_id != alphabet.id or
                not record.verified_words):
            raise ValueError('untrusted or mixed-width own training record')
        validate_exact(record)
        for word in record.verified_words:
            # Suffixes and declared symmetries retain independently replayed UB
            # words; their exact labels were intentionally removed upstream.
            producer = word.producer
            while producer.endswith(('_suffix', '_symmetry')):
                producer = producer.rsplit('_', 1)[0]
            if producer not in OWN_PRODUCERS[record.source]:
                raise ValueError('untrusted own certificate producer')
            verify_word(word, alphabet)
            if word.start != record.state or word.end != MatrixState.identity(alphabet):
                raise ValueError('wrong full certificate endpoints')
        selected = min(record.verified_words, key=lambda word: word.physical_cost)
        if selected.physical_cost < 1:
            raise ValueError('identity root is not a training word')
        selected_words.append(selected)
    return tuple(selected_words)


@dataclass(frozen=True)
class GpuOwnRecordBatch:
    walk: PackedWalkBatch
    lineages: tuple[str, ...]
    sources: tuple[str, ...]
    selected_producers: tuple[str, ...]


def own_records_to_cuda(records: tuple[SampleRecord, ...] | list[SampleRecord],
                        *, device: str = 'cuda') -> GpuOwnRecordBatch:
    selected_words = validate_own_records(records)
    if not records or device != 'cuda' or not torch.cuda.is_available():
        raise ValueError('nonempty own records and CUDA device required')
    n = records[0].state.n
    if n < 2 or n > 256:
        raise ValueError('unsupported packed CUDA width')
    alphabet = AlphabetSpec.all_to_all(n)
    if len({record.state.key for record in records}) != len(records):
        raise ValueError('duplicate root matrix in CUDA batch')
    words, packed, lineages, sources, producers = [], [], [], [], []
    for record, selected in zip(records, selected_words):
        if (record.split != 'train' or record.source not in OWN_SOURCES or
                record.state.n != n or record.state.alphabet_id != alphabet.id or
                not record.verified_words):
            raise ValueError('untrusted or mixed-width own training record')
        if (selected.start != record.state or
                selected.end != MatrixState.identity(alphabet) or
                selected.physical_cost != len(selected.gates) or
                any(not (0 <= gate.control < n and 0 <= gate.target < n and
                         gate.control != gate.target)
                    for gate in selected.gates)):
            raise ValueError('invalid complete unit-cost own word metadata')
        if selected.physical_cost < 1:
            raise ValueError('identity root is not a training word')
        words.append(tuple(reversed(selected.gates)))
        packed.append(tuple(tuple(
            ((row >> (64 * slot)) & ((1 << 64) - 1)) -
            (1 << 64) * bool((row >> (64 * slot)) & (1 << 63))
            for slot in range((n + 63) // 64))
            for row in record.state.packed_rows))
        lineages.append(record.lineage_id)
        sources.append(record.source)
        producers.append(selected.producer)
    lengths = torch.tensor([len(word) for word in words], device=device,
                           dtype=torch.int64)
    max_length = max(len(word) for word in words)
    controls = torch.zeros((len(words), max_length), device=device,
                           dtype=torch.int64)
    targets = torch.zeros_like(controls)
    for index, word in enumerate(words):
        controls[index, :len(word)] = torch.tensor(
            [gate.control for gate in word], device=device, dtype=torch.int64)
        targets[index, :len(word)] = torch.tensor(
            [gate.target for gate in word], device=device, dtype=torch.int64)
    rows = torch.tensor(packed, device=device, dtype=torch.int64)
    walk = PackedWalkBatch(rows, controls, targets, lengths)
    generated = apply_gates(identity_rows(len(words), n), controls, targets,
                            lengths)
    if not torch.equal(generated, rows) or not bool(verify_inverse(walk).all().item()):
        raise ValueError('full CUDA replay rejected own record batch')
    return GpuOwnRecordBatch(walk, tuple(lineages), tuple(sources),
                             tuple(producers))
