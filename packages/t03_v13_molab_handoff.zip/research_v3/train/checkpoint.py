"""Own immutable tensor payloads, hash-checked manifests and atomic pointers."""
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import random
import uuid
import numpy as np
import torch


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def rng_state():
    n = np.random.get_state()
    return {'python': random.getstate(), 'numpy': [n[0], n[1].tolist(), n[2], n[3], n[4]],
            'torch': torch.get_rng_state(),
            'cuda': torch.cuda.get_rng_state_all() if torch.cuda.is_initialized() else []}


def restore_rng(state):
    random.setstate(state['python'])
    n = state['numpy']
    np.random.set_state((n[0], np.array(n[1], dtype=np.uint32), n[2], n[3], n[4]))
    torch.set_rng_state(state['torch'].cpu())
    if state['cuda']:
        if not torch.cuda.is_available() or len(state['cuda']) != torch.cuda.device_count():
            raise ValueError('CUDA RNG topology differs')
        torch.cuda.set_rng_state_all(state['cuda'])


def atomic_json(path, value):
    temporary = path.with_name(path.name + '.' + uuid.uuid4().hex + '.tmp')
    with temporary.open('x', encoding='utf-8') as stream:
        stream.write(canonical(value))
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def save_checkpoint(run_dir, model, optimizer, sampler, progress, config, extra=None, best=False):
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    path = run_dir / f'step-{progress.attempted:09d}.pt'
    manifest_path = path.with_suffix('.json')
    config = json.loads(canonical(config))
    payload = dict(version=1, config=config, model=model.state_dict(), optimizer=optimizer.state_dict(),
                   module_modes={name:module.training for name, module in model.named_modules()},
                   optimizer_type=type(optimizer).__module__ + '.' + type(optimizer).__qualname__,
                   sampler=sampler.state_dict(), progress=asdict(progress), rng=rng_state(), extra=extra or {})
    if manifest_path.exists():
        raise FileExistsError(manifest_path)
    # Exclusive creation: failed writes remain unreferenced, never overwrite a snapshot.
    with path.open('xb') as stream:
        torch.save(payload, stream)
        stream.flush()
        os.fsync(stream.fileno())
    manifest = dict(version=1, file=path.name, sha256=digest(path), config=config, progress=asdict(progress))
    with manifest_path.open('x', encoding='utf-8') as stream:
        stream.write(canonical(manifest))
        stream.flush()
        os.fsync(stream.fileno())
    atomic_json(run_dir / 'last.json', manifest)
    if best:
        atomic_json(run_dir / 'best.json', manifest)
    return path


def load_checkpoint(path, model, optimizer, sampler, progress, config):
    path = Path(path)
    manifest = json.loads(path.with_suffix('.json').read_text(encoding='utf-8'))
    if manifest['file'] != path.name or manifest['sha256'] != digest(path):
        raise ValueError('checkpoint hash mismatch')
    if canonical(manifest['config']) != canonical(config):
        raise ValueError('checkpoint configuration/schema mismatch')
    payload = torch.load(path, map_location='cpu', weights_only=True)
    if payload['version'] != 1 or canonical(payload['config']) != canonical(config):
        raise ValueError('payload schema mismatch')
    if payload['optimizer_type'] != type(optimizer).__module__ + '.' + type(optimizer).__qualname__:
        raise ValueError('optimizer type mismatch')
    model.load_state_dict(payload['model'], strict=True)
    for name, module in model.named_modules():
        module.training = payload['module_modes'][name]
    optimizer.load_state_dict(payload['optimizer'])
    sampler.load_state_dict(payload['sampler'])
    for key, value in payload['progress'].items():
        setattr(progress, key, value)
    restore_rng(payload['rng'])
    return payload['extra']
