"""Train-only certified teacher refresh with explicit discovery/update state."""
from dataclasses import asdict, replace
import json
import hashlib
from ..contracts import AlphabetSpec, MatrixState
from ..data.replay import Replay
from ..data.stream_reader_v13 import decode_record, validate_exact
from ..words import verify_word


class CertifiedReplayRefresh:
    def __init__(self, solver, *, every_updates, source_sha256, forbidden_keys=()):
        if type(every_updates) is not int or every_updates < 1:
            raise ValueError('positive explicit teacher refresh interval required')
        self.solver = solver
        self.every_updates = every_updates
        self.sources = dict(source_sha256)
        self.forbidden = tuple(forbidden_keys)
        self.replays = {}
        self.events = []

    def immutable_contract(self):
        from .component_contract_v13 import component_contract
        solver_contract = component_contract(self.solver, self.sources)
        return dict(schema='certified_train_replay_refresh_v13',
                    config=dict(every_updates=self.every_updates,
                                solver=solver_contract,
                                forbidden_sha256=hashlib.sha256(repr(sorted(
                                    self.forbidden)).encode()).hexdigest()),
                    source_sha256=self.sources)

    def __call__(self, records, update):
        output = []
        for record in records:
            if record.split != 'train' or record.state.key in self.forbidden:
                raise ValueError('teacher refresh refuses holdout/nontrain roots')
            validate_exact(record)
            alphabet = AlphabetSpec.all_to_all(record.state.n)
            cache = self.replays.setdefault(record.state.n, Replay(alphabet, self.forbidden))
            plain = replace(record, exact_distance=None, exact_evidence=None)
            cache.merge((plain,))
            old = record.upper_bound
            if update % self.every_updates == 0:
                word = self.solver(record, update)
                if word is not None:
                    if word.producer != 'own_neural_refresh_v13':
                        raise ValueError('unapproved own teacher producer')
                    verify_word(word, alphabet)
                    if word.start != record.state or word.end != MatrixState.identity(alphabet):
                        raise ValueError('teacher word has wrong complete endpoints')
                    if record.exact_distance is not None and word.physical_cost < record.exact_distance:
                        raise ValueError('teacher word contradicts certified exact distance')
                    if word.physical_cost < old:
                        cache.merge((replace(plain, verified_words=(word,)),))
            words = cache.records[record.state.key].verified_words
            result = replace(record, verified_words=words)
            self.events.append(dict(update=update, lineage=record.lineage_id,
                                    state_key=repr(record.state.key), before=old,
                                    after=result.upper_bound,
                                    improved=result.upper_bound < old))
            output.append(result)
        return tuple(output)

    def state_dict(self):
        return dict(schema='certified_train_replay_refresh_v13',
                    records=[asdict(record) for cache in self.replays.values()
                             for record in cache.records.values()],
                    events=list(self.events), solver=self.solver.state_dict())

    def load_state_dict(self, state):
        if state['schema'] != 'certified_train_replay_refresh_v13':
            raise ValueError('replay checkpoint schema mismatch')
        caches = {}
        for raw in state['records']:
            record = decode_record(json.dumps(raw))
            if record.split != 'train':
                raise ValueError('nontrain replay checkpoint')
            cache = caches.setdefault(record.state.n,
                                       Replay(AlphabetSpec.all_to_all(record.state.n), self.forbidden))
            cache.merge((record,))
        self.solver.load_state_dict(state['solver'])
        self.replays = caches
        self.events = list(state['events'])
