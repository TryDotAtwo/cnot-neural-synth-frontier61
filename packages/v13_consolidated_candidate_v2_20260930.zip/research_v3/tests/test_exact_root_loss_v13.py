import unittest
import torch
from research_v3.gpu.joint_records_v13 import exact_root_loss


class ExactRootLossTests(unittest.TestCase):
    def test_unknown_upper_bound_is_not_exact_supervision(self):
        values = torch.tensor([4., 99., 2.], requires_grad=True)
        loss = exact_root_loss(values, (3, None, 2))
        self.assertEqual(loss.item(), .25)
        loss.backward()
        self.assertEqual(values.grad.tolist(), [.5, 0., 0.])

    def test_no_exact_roots_preserves_graph_with_zero_gradient(self):
        values = torch.tensor([19., 3.], requires_grad=True)
        loss = exact_root_loss(values, (None, None))
        loss.backward()
        self.assertEqual(loss.item(), 0.)
        self.assertEqual(values.grad.tolist(), [0., 0.])

    def test_bad_labels_are_rejected(self):
        for label in (-1, True, 1.5):
            with self.assertRaises(ValueError):
                exact_root_loss(torch.tensor([1.]), (label,))


if __name__ == '__main__':
    unittest.main()
