# Evaluator and schedule readiness audit

Source: current `full_training_config.json`, `research_v3/train/cuda_stream_v13.py`,
and normative `EXPERIMENT_PROTOCOL_RU.md` section 7.4. This is an incomplete
requirements audit, not T24 acceptance.

| Requirement | Current implementation/evidence | Status and required next action |
|---|---|---|
| Fixed nonidentity dev roots, verified Uref and caps before training | Runner requires exact sealed dev records and 128 roots for every width | Actual 1792-root sealed panels and cap manifest are not supplied to a production evaluator |
| Identical decoder budgets across checkpoints | CUDA neural refresh adapter has explicit budgets | Training config has no production dev decoder budget; diagnostic test budgets must not become production defaults |
| Raw neural results only for selection | Independent `verify_dev_report` checks full raw words and rational selection key | Actual CUDA dev callback and durable outcome ledger remain absent |
| Full end-to-end dev compute | `finish_dev` measures evaluator execution and model-integrity checks | State persistence, receipt and selection publication costs remain outside reported compute; durable interrupted-attempt compute remains unproven |
| Dev evaluation every 640 updates (protocol 7.4) | Driver now separates dev-640 snapshots from periodic 10000-root snapshots; resume follows the same event rule | Boundary test passes locally. Actual full-panel evaluator execution at this cadence remains unverified |
| Additional exact examples at configured cadence | Candidate driver wires interval 100 to the pinned complete GL3/GL4 sampler, checkpoint state and mixed-width objective; missing sampler or projection receipts are rejected | Actual GL4 mixed CUDA run, native generation and complete stream/resume acceptance remain missing. Do not change the interval to zero |
| Model and optimizer/replay restoration | Full29 fixed-root CUDA 8=4+4 diagnostic passed in Molab | Actual producer/full-panel dev transactions are outside this diagnostic scope |
| Training volume | Accepted config retains 1000 epochs × 10000 new unique roots | No production training launched; diagnostic eight-step test does not change the volume |

Next implementation must bind actual dev budgets and frozen caps, provide the
durable full-panel callback, and reconcile the explicit sampler/evaluation
schedule. Earlier evaluator CLI routes the reference field/dataset and does not
constitute the new full29 native callback. No CPU/Hamming fallback is authorized
by this audit. Old checkpoint 20480 evaluation remains a separate open item.
