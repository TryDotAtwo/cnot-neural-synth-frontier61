# Evaluator and schedule readiness audit

Source: current `full_training_config.json`, `research_v3/train/cuda_stream_v13.py`,
and normative `EXPERIMENT_PROTOCOL_RU.md` section 7.4. This is an incomplete
requirements audit, not T24 acceptance.

| Requirement | Current implementation/evidence | Status and required next action |
|---|---|---|
| Fixed nonidentity dev roots, verified Uref and caps before training | `FrozenDevPanel` candidate requires 1792 unique roots, 128 per width; pins ordered verified references, Uref, caps, seal identity and decoder configuration | Per-reference identity and short-panel rejection pass on CPU. Actual sealed 1792-root contract and production evaluator binding remain absent |
| Identical decoder budgets across checkpoints | CUDA neural refresh adapter has explicit budgets | Training config has no production dev decoder budget; diagnostic test budgets must not become production defaults |
| Raw neural results only for selection | Production driver now requires `verify_cuda_dev_report`, frozen 1792 panel, matching decoder/caps and full raw words; `DevOutcomeJournal` candidate persists ordered cases and measured controlled attempts | Five CPU journal tests pass. Actual CUDA full-panel callback binding and execution remain absent |
| Full end-to-end dev compute | `finish_dev` now starts before checkpoint hashing/pending preparation and measures through evaluator execution, model/checkpoint integrity, validated state save/fsync/rename/hash | Final receipt/final validation and best publication remain outside reported compute; durable interrupted outer-attempt compute remains unproven |
| Dev evaluation every 640 updates (protocol 7.4) | Driver now separates dev-640 snapshots from periodic 10000-root snapshots; resume follows the same event rule | Boundary test passes locally. Actual full-panel evaluator execution at this cadence remains unverified |
| Additional exact examples at configured cadence | Candidate driver wires interval 100 to the pinned complete GL3/GL4 sampler, checkpoint state and mixed-width objective; missing sampler or projection receipts are rejected | Actual GL4 mixed CUDA run, native generation and complete stream/resume acceptance remain missing. Do not change the interval to zero |
| Model and optimizer/replay restoration | Full29 fixed-root CUDA 8=4+4 diagnostic passed in Molab | Actual producer/full-panel dev transactions are outside this diagnostic scope |
| Training volume | Accepted config retains 1000 epochs × 10000 new unique roots | No production training launched; diagnostic eight-step test does not change the volume |

Next implementation must bind actual dev budgets and frozen caps, provide the
durable full-panel callback, and reconcile the explicit sampler/evaluation
schedule. Earlier evaluator CLI routes the reference field/dataset and does not
constitute the new full29 native callback. No CPU/Hamming fallback is authorized
by this audit. Old checkpoint 20480 evaluation remains a separate open item.

Journal candidate v2 published in public GitHub commit
`8cebdf7d2c6a2029eddd5f41a2f8ff27cc8aab6e`, package
`v13_dev_outcome_journal_candidate_v2.zip`, SHA-256
`418e38bc413a2455721e8b9f5d73149f6c92a72be689d265659861dbf699c74d`.
CPU tests verify reopen/ordered completion, controlled retry costs, identity
drift, altered or deleted attempt history, and deleted completed outcomes.
An open attempt blocks retry and qualified compute reporting; it neither proves
a dead process nor provides crash duration. Full end-to-end panel time remains
open, including persistence and publication. Earlier v1 remains preserved.

Full-panel traversal candidate `train/durable_dev_cases_v13.py` is published in
commit `ab3258c3979b8d09ae226e39d72f550d1372f44b`; package SHA-256
`0eee2e2869843c1896bfcce89beb048f072bc50003137825a66e7690e3abf789`.
It requires the actual FrozenDevPanel, checkpoint-bound journal and CUDA model;
rechecks stored outcomes and searches pending full matrices using the frozen
raw decoder, then independently validates each word and persists its outcome.
OOM is an explicit failure; controlled interruptions retain measured attempt
cost; failed synchronization leaves unknown compute open. It emits cases only,
not a normative selection report. Seven CPU journal/outcome-rule tests pass;
the traversal itself has not been executed on CUDA. Outer exclusive ownership,
full model/RNG isolation, full end-to-end timing and evaluator contract/state
adapter remain required integrations, not inferred from these CPU tests.

Latest Molab observation: existing notebook visible with configured RTX Pro
6000/4 CPU/32 GiB; prior reader banner absent. Terminal option interaction did
not produce a terminal. No live process inventory was obtained and no GPU
work was launched. Coordination request sent to the existing Astra chat for
current owner/pairing/process evidence. Visible configuration is not process
readiness or test execution evidence.

Stateful evaluator candidate `train/durable_dev_evaluator_v13.py` now supplies
the immutable source/config contract and checkpoint state interface required by
`train_cuda_stream`. A clean call traverses the full FrozenDevPanel, persists
raw cases, derives exact rational selection with failure penalties, and invokes
the full independent report verifier. It refuses an existing journal and
unqualified recovery rather than silently resetting compute. No actual CUDA
call or 1792-root report exists yet. Seven journal/outcome-rule tests still
pass; these do not execute or qualify the new evaluator. Driver transaction
persistence/publication costs and durable outer interrupted-attempt timing
remain open and prevent claiming protocol acceptance.

Nonfinite neural action/child scores now raise `FloatingPointError`, distinct
from shape/configuration `ValueError`. The durable panel traversal records this
as `numerical_error` with no raw word, preserving frozen configuration/cap; the
existing independent outcome test confirms its failure penalty `(cap+1)/Uref`.
Seven CPU journal/outcome-rule tests pass. Actual nonfinite CUDA dispatch and
full-panel continuation still require Molab execution; compilation and these
tests alone do not prove that route.

T12 snapshot identity: `finish_dev` now recomputes checkpoint SHA after the
evaluator and model integrity check, before committing any successful dev
receipt. A checkpoint mutation fault test confirms rejection, no dev commit,
and restored RNG/model mode. Four CPU transaction tests pass; they cover
checkpoint/model integrity, RNG/mode isolation, restored evaluator state and
explicit refusal of unqualified recovery. They do not establish full-panel
CUDA execution or complete end-to-end compute accounting.

Timing extension candidate commit `ed487ee34e6fbe9f19804c3ae90eb3a5b36c2c42`
includes durable evaluator state save in measured compute and explicitly
reports `timing_scope`. A controlled-clock CPU test injects 20 units into the
actual `torch.save` call and confirms both total and selection-key timing
include them. Five CPU transaction tests pass. This is a phase-accounting
regression, not a measured hardware runtime. Final receipt/validation/best
publication and qualified interrupted outer-transaction time remain open.
Older reports remain unchanged; no normative full end-to-end acceptance is
claimed for this candidate.
