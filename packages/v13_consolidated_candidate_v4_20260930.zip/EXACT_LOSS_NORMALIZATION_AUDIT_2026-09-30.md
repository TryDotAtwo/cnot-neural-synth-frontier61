# Exact-supervision normalization correction

Requirement: preserve the per-record averaging used by `train/objective.py::FullGraphObjective.__call__` when adding exact small-catalog anchors to a mixed-width update.

Confirmed discrepancy: `gpu/joint_records_v13.py::exact_root_loss` averaged over labeled roots only. The reference adds a zero exact term for unlabeled roots and divides the sum by the total number of records. For B records containing E exact labels the previous implementation amplified the exact component by B/E.

Correction: sum Huber terms on independently verified labels and divide by B. No labels are inferred from word lengths. Records without exact labels have zero exact gradient.

Evidence: `python -m unittest research_v3.tests.test_exact_root_loss_v13 -v`: 4 CPU tests pass, 1.521 s. The sparse-label test compares both the scalar and its gradient with the literal per-record reference expression. This is not a Molab training or synthesis result.

Earlier candidates and published packages are retained. No earlier result is reclassified as a run of the corrected objective.

Open integration: mixed widths need separate full-neighborhood forwards with a shared per-record denominator for main terms and a separate denominator over eligible basis templates, followed by one optimizer step. The CUDA stream still rejects a nonzero exact-sampler schedule until admission, sealed small-width holdout banks, durable sampler provenance, and full joint normalization are connected and verified.
