# Exact-sampler integration boundary

The existing reference `data/exact_stream.py::ExactStreamSampler` builds complete
GL(3,2)/GL(4,2) catalogs. `Replay.ingest_exact` verifies full reduction words,
neighbor closure and a unit-Lipschitz distance potential. Its deterministic
selection uses `(epoch * 10000 + position)` and adds one nonidentity exact anchor
to the same update every configured 100 roots in the reference stream runner.

This is NOT the stage18/35/37 guarded-family stream: replacing it with another
guarded example would change the declared objective/schedule.

Concrete missing routes in the CUDA candidate:

1. `record_batch_v13` now accepts `exact_small_bfs_v1` only with an explicit
   frozen `VerifiedExactCatalog` context. Other source guards remain intact.
   Complete GL3 CPU proof and local full-model CUDA backward were checked;
   no Molab repetition or production admission is inferred from that result.
2. `stream_reader_v13.validate_exact` still only re-recognizes stage18/35/37
   claims. Complete-catalog anchors use a separate explicit context, and must
   remain separate from the sealed production root decoder.
3. Exact n=3/4 anchors cannot be concatenated into the n=8..144 packed batch:
   that transfer requires one width. Compute their objective separately within
   the same update and preserve the reference example/loss normalization.
   Candidate `mixed_joint_records_v13` calls the full per-width CUDA objectives
   and merges differentiable main/basis components with separate reference
   denominators. Sparse exact Huber normalization was corrected. CPU scalar,
   gradient and rejection gates pass; actual mixed CUDA execution is pending.
4. Full-parent/all-successor holdout admission must include the exact anchor;
   no omitted neighbor or inherited child exact label is permitted. Candidate
   preflight admits all groups before any forward. The sealed bank loader can
   now produce an explicit empty width projection after checking every sealed
   and historical root. CNOT and declared views preserve dimension; no new
   small-width holdout split is introduced. Actual loader/GPU checks remain open.
5. Pin catalog content, source and schedule in the run contract/checkpoint.
   Native catalog construction/transfer and model loss need actual Molab checks.

Prepared Molab acceptance gate:
`tests/test_mixed_joint_cuda_v13.py` now targets n8+n4 full-field and proposer gradients,
complete neighbor admission counts, summed MC evaluations and exactly one AdamW
step. It uses diagnostic empty banks, not a production sealed-loader receipt.
It has not run. Public candidate commit
`306c2d587a0dc748eb1f56c52451c0f05574daa8`, package SHA256
`99e3fdab67ffec645a14f33b8c75b32a91b11768e7aeb549ad6d1e1a18f7a981`.

Schedule finding: with default `sizes=(3,4)` and `exact_every_roots=100`, actual
anchor positions are 99,199,...,9999. Since `epoch*10000+position` is always odd,
the original sampler always selects GL4 at those updates. The catalog bank
contains GL3 too, but this is not evidence of GL3 exposure in that schedule.
No schedule or size order has been changed. The earlier n8+n3 diagnostic gate
did not cover the scheduled anchor width and is retained in its old public ZIP.
The corrected n8+n4 gate requires actual Molab execution and complete GL4 proof.

T12 remains partial: sampler/run-contract/checkpoint pinning, native generation,
sealed-loader receipts and an actual complete CUDA stream/resume/dev execution
are missing. The candidate gate does not satisfy those requirements.

The candidate CUDA driver now has explicit `exact_sampler` wiring: component
contract, checkpoint save/load, scheduled mixed objective, one optimizer step,
presentation count and anchor content hash in the update journal. It requires
the complete pinned GL3/GL4 sampler, 10000 roots per epoch, interval 100, and
checked width-projection receipts. Missing or GL3-only samplers still fail.
Five CPU source/schedule/rejection tests pass. This does not verify a complete
GL4 CUDA stream, full sealed-loader content integrity, or crash/resume with dev.
Production acceptance is still open. Do not set the interval to zero, substitute guarded
families, change widths, or count an extra optimizer step as the declared update.
The complete GL(4,2) catalog is a legitimate reference; it does not prove any
large-matrix optimum. No production integration is claimed by this audit.
