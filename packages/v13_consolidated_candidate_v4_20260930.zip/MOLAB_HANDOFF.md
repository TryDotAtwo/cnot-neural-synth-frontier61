# T03 v13 CPU acceptance candidate — 2026-09-30

This is a local integration candidate, not a trained model or a completed T03.
Owner: this delegated data/CPU task. No Molab pairing, GPU execution, paid
resource, external publication or credential change occurred here.

## Identity and authoritative volume

Original source root: `D:/Lean4/TheQuantumProject`, with no Git repository/branch.
Writable integration root: `C:/Users/Иван Литвак/Documents/ChatGPT/TheQuantumProject/integration/t03_2026_09_30`.
`D:/QuantumComp` is an unrelated pancake-sorting Flipformer project.

Inputs: preserved local `gpu_source_sync_2026_09_28.zip`, local own stage17 code,
and public HF data modules at revision
`249df55fa22f81e19bead54df3ca983385371b51`.
See `hf_source_manifest.json` and `source_manifest.json` for hashes.
The candidate is v13 to avoid colliding with the other task's existing Molab v11/v12.
Do not overwrite those modules or their SQLite artifacts.

The Sept27 priority file says 100 epochs/one million new roots. The authorized
source thread subsequently accepted the side-chat direction **at least 1000
epochs of 10,000 matrices**, and v6/v10 manifests encode 10,000,000 globally unique
roots. `evidence/accepted_training_volume.json` pins the dated accepted relay.
The original side-chat user utterance was not separately read; this is accepted
relay evidence, not a claimed direct user quotation. `full_training_config.json`
preserves 1000 × 10,000, all 14 widths and 99,716,058 parameters.

## Implemented and tested here

- `research_v3/data/stream_solver_dataset_v13.py`: new schema, stage18/35/37 guarded
  exact scheduling, explicit `solver_called=False` for exact certificates,
  atomic root commit and resume, seed/schema guard, complete primitive admission
  for root/suffix offsets, finite-symmetry and lineage checks before sealing.
- `research_v3/data/stream_reader_v13.py`: manifest epoch range through 999,
  source/schema validation, full word/content digest checks, matrix recognition
  of exact claims, position reader, re-admission of the complete actually
  augmented batch before the first record can be yielded.
- `research_v3/gpu/record_batch_v13.py`: CPU full-word and exact validation for
  walks, basis, composition and stage18/35/37; preserves the independent CUDA
  replay in the transfer implementation. CUDA transfer has NOT run here.
- Negative regressions reproduced before fixes: exact ingestion KeyError,
  unsupported stage37 exact, neighbour leakage before first yield, cross-split
  symmetry overlap. Tests then pass; see the final logs.

CPU command (run from this directory; no GPU use):

```text
python -B -m unittest research_v3.data.test_stream_v13 research_v3.tests.test_T01_state research_v3.tests.test_T03_data research_v3.tests.test_T05_model research_v3.tests.test_T06_gradients research_v3.tests.test_T12_chunking -v
```

`CUDA_VISIBLE_DEVICES` was empty for local model/data tests. Model construction
on CPU separately counted 99,716,058 parameters. These CPU tests prove reference
terminal V(I)=0, full primitive minimum and both-side selected-branch gradients;
they do not establish current CUDA numerical parity or million-root throughput.

One upstream test is nonportable:
`research_v3.data.test_fast_cost_v1` performs work at import and then opens the
hardcoded `/marimo/cnot_work/research_v3/data/fast_cost_v1.py`. Its original failure
log is preserved; it was not silently fixed or reported as passing.

## Remaining acceptance gates and full-run boundary

1. The other task reports `/marimo/cnot_work/research_v3/data/stream_solver_dataset_v12.py`,
   `own_dev_v12_protocol_panel_retry.sqlite` and
   `evidence/dev_v12_protocol_panel_audit_2026-09-28.json`. Re-read and hash them
   through the existing authorized session before reconciling v12 with v13.
   Reported 128 dev roots / 224 certificates / 32 exact / historical overlap 0
   are previous-run facts awaiting verification here. They are not the full
   confirmatory panel of 128 independent roots **per width** (1792 per split).
2. Normative pilot/confirmatory populations: 32/128 independent root lineages
   per width, each of the four families, dev/test sealed before training,
   historical nine inputs and finite symmetry views excluded. Exact source gates
   stage23–25/36/38 remain explicitly open; do not invent labels from stage names.
3. Before GPU forward, route the versioned reader and the versioned transfer,
   and reconcile `gpu/frozen_bank.py`: its current default imports v5 hashes and
   legacy decoding. It will reject v13 source hashes. No global import monkeypatch.
4. The current full GPU joint objective supplies interval/teacher/Qhat/basis
   terms, but exact-root scalar supervision and production replay refresh/dev
   checkpoint selection need an explicit verified integration. Check complete
   argmin/gradients, MC packet consistency and every parent/neighbour after refresh.
5. The old `train/stream_runner.py` and `cli/train_100m_stream.py` hardcode v5
   generator/reader and cap epochs at 100. They must not be launched with this
   1000-epoch config. GPU own-transfer CLI is a finite pilot, not a full streaming
   trainer. Preserve durable optimizer/RNG/root cursor/chain, source hashes,
   checkpoint restore and teacher refresh in the production runner.
6. Main all-GPU/native data-generation instruction remains unresolved by these
   CPU reference fixes. The CPU stage17 generator here is a correctness reference,
   not a claimed complete GPU port. Measure the native GPU path before a full run.

There is deliberately no command claiming the full training run is launchable:
the generator/reader defects are fixed, but the production runner and the above
gates are concrete technical blockers. Use one existing Molab foreground job
after its owner checks authoritative active processes. No local RTX3070 training.

The historical direct-V pilot **0/3 vs Hamming 3/3** remains a negative result.
No new full-program quality comparison was run. T15–T22 remain optional research,
not a barrier to the neural route.

## Rulings and review

- Work in the writable integration copy because D: is read-only under this
  task's permissions and neither source root is Git. Cost if mistaken: later
  integration requires a hash-reviewed transfer; originals stay intact.
- Use v13 because Molab already owns v11/v12. Cost: consumers need explicit routing.
- Keep 1000 epochs, based on the dated accepted relay and later HF manifests.
  Cost if the relay was inaccurate: full volume needs clarification before launch;
  it is not silently cut back to 100.
- Preserve upstream sources and results; no plugin manifest update or publication.
  Self-review only: project plan explicitly prohibits subagents.
