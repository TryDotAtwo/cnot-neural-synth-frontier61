# Full-neighbour bottleneck: measured scope and next profile

Source: authorized original thread, event at 2026-09-27 22:20:42.644 UTC,
line 53108; sanitized numeric record in `evidence/n144_profile_source_excerpts.json`.
This is an existing Molab observation, not a new execution.

| Quantity | Measured value |
|---|---:|
| Width | 144 |
| Primitive actions per root | 20,592 |
| Admitted parent and neighbours | 20,593 |
| Complete-neighbour phase | 735.304525 s |
| Complete step | 736.596150 s |
| Admission | 0.097657 s |
| CUDA peak allocation | 48,812,497,920 bytes |
| Selected action | 9462 |

The neighbour phase accounts for 99.82465% of this step, approximately
28.00 candidate evaluations/s. This phase includes transitions, feature
production, the model, reductions and synchronizations. It is NOT an isolated
transformer forward measurement. Hardware, warmup and repeat variation must be
recovered from the same run manifest before comparing another run. Removing
all other phases would give only about 1.00176× on these observed times.

## Exact next measurement, attached to the existing foreground job

Keep the saved input matrix/root digest, source/config/checkpoint hash, weights,
MC seed/shared-word bank, dtype, action order, full action set, and tie rule fixed.
Use a separate artifact directory, retain the baseline trace, and record actual
GPU/driver/CUDA/Torch/device-memory and runtime mode. The profiling owner must
first verify the existing process/job state; this task launched no GPU work.

Existing `complete_bellman_slice(..., phase_profile=True)` synchronizes root,
all-neighbour and selected-child phases. Extend the existing profiling job with
Torch profiler CPU+CUDA ranges for:

1. admission and full-word verification;
2. primitive generation/packing;
3. feature builders A, B/F, C/D/H, E, G01/G05/G06, shared-word G07–G10;
4. structural blocks: QKV/attention, pair update, FFN/norm;
5. family heads, fusion transformer and V;
6. full argmin and Qhat totals;
7. parent/selected child grad recompute, teacher/bounds/basis;
8. backward, optimizer, checkpoint/HF I/O separately.

Record wall and CUDA-event times, launch count, H2D/D2H bytes, allocator peaks,
candidate count, effective batch/microbatch and actual phase boundaries. Profiling
changes execution overhead, so report an unprofiled repeat with identical finite
budgets separately; do not promote profiler time to production throughput.

## Candidate accelerations, not measured speedups

| Candidate | Preserve | Gate before promotion |
|---|---|---|
| Increase action microbatch; batch same-width roots | All 20,592 actions per root | Actual memory and end-to-end profile; argmin/value/gradient parity across chunk sizes |
| Reuse deterministic width-dependent heat/MC banks | Same MC samples and packet semantics for parent and child | Identical packets and gradients; cache identity includes width/config/device/dtype/seed |
| Reuse parent/selected feature packets rather than rebuilding | Same theta, same batch-independent deterministic features | Packet equality and both-side gradient oracle; no detached child |
| Fuse kernels or compile fixed shapes/SDPA backend | Same full-matrix structural field | Numerical/ranking/argmin and gradient tests, then measured complete step |
| Exact incremental row-XOR feature update | Every feature still equals its complete recomputation | Independent parity of reachability, rank, inverse, basis masks, heat features; no unsupported shortcut |
| Reduce host synchronization; preallocate neighbour buffers | Stable action IDs, finite-value errors and all totals retained | Failure-path tests, complete count, peak memory and trace |

No shortlist, action-head-only ranking, trajectory arm, detached target, feature
removal, architecture reduction or smaller training volume is an equivalent
acceleration of this objective. BF16/FP16/TF32 or quantization changes numerical
semantics; keep it a separately validated arm and do not presume argmin equality.
