"""Bounded exact correction after deleting two nonadjacent CNOTs.

For each short window, remove any two positions and insert one physical CNOT
at any position. Only a strict reduction with the identical full matrix is
accepted. This is a concrete subset of stage-28 defect repair, not an
exhaustive global search.
"""

from __future__ import annotations

import time

from stage28_exact import matrix_from_gates


def improve(gates, n, *, window=8, max_active=9, time_limit=2.0):
    original = matrix_from_gates(n, gates)
    out = [tuple(g) for g in gates]
    start_time = time.perf_counter()
    attempts = 0
    replacements = 0
    timed_out = False
    position = 0
    while position < len(out):
        if time.perf_counter() - start_time >= time_limit:
            timed_out = True
            break
        stop = min(len(out), position + window)
        old = out[position:stop]
        if len(old) < 3:
            break
        wires = sorted({wire for c, t in old for wire in (c, t)})
        if len(wires) > max_active:
            position += max(1, window // 2)
            continue
        relabel = {wire: i for i, wire in enumerate(wires)}
        local = [(relabel[c], relabel[t]) for c, t in old]
        target = matrix_from_gates(len(wires), local)
        pairs = [(c, t) for c in range(len(wires)) for t in range(len(wires)) if c != t]
        found = False
        for first in range(len(local)):
            for second in range(first + 1, len(local)):
                if time.perf_counter() - start_time >= time_limit:
                    timed_out = True
                    break
                shortened = [g for i, g in enumerate(local) if i not in (first, second)]
                for insert_at in range(len(shortened) + 1):
                    for gate in pairs:
                        attempts += 1
                        replacement = shortened[:insert_at] + [gate] + shortened[insert_at:]
                        if matrix_from_gates(len(wires), replacement) != target:
                            continue
                        physical = [(wires[c], wires[t]) for c, t in replacement]
                        candidate = out[:position] + physical + out[stop:]
                        if matrix_from_gates(n, candidate) != original:
                            raise AssertionError("defect replacement changed full matrix")
                        out = candidate
                        replacements += 1
                        position = max(0, position - window // 2)
                        found = True
                        break
                    if found:
                        break
                if found:
                    break
            if found or timed_out:
                break
        if timed_out:
            break
        if not found:
            position += max(1, window // 2)
    if matrix_from_gates(n, out) != original:
        raise AssertionError("final matrix changed")
    return out, {"before": len(gates), "after": len(out), "replacements": replacements,
                 "attempts": attempts, "seconds": time.perf_counter() - start_time,
                 "time_limit_reached": timed_out, "verified_full_matrix": True}
