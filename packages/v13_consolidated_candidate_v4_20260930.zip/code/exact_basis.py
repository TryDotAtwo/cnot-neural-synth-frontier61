"""Exact paid-basis optimization for local blocks of width at most four."""

from __future__ import annotations

from collections import deque
from functools import lru_cache

import numpy as np


@lru_cache(maxsize=8)
def atlas(width: int, side: str):
    if not 1 <= width <= 4 or side not in ("source", "target"):
        raise ValueError("exact basis atlas supports width 1..4 and a valid side")
    nstates = 1 << width
    identity = tuple(range(nstates))
    maps = []
    for c in range(width):
        for t in range(width):
            if c == t:
                continue
            if side == "source":
                mapping = tuple(i ^ (((i >> t) & 1) << c) for i in range(nstates))
            else:
                mapping = tuple(i ^ (((i >> c) & 1) << t) for i in range(nstates))
            maps.append(((c, t), mapping))
    states = [identity]
    distance = [0]
    parent = [-1]
    parent_gate = [None]
    seen = {identity: 0}
    queue = deque([0])
    while queue:
        i = queue.popleft()
        state = states[i]
        for gate, mapping in maps:
            nxt = tuple(mapping[code] for code in state)
            if nxt in seen:
                continue
            j = len(states)
            seen[nxt] = j
            states.append(nxt)
            distance.append(distance[i] + 1)
            parent.append(i)
            parent_gate.append(gate)
            queue.append(j)
    populations = np.asarray([[code.bit_count() for code in state] for state in states], dtype=np.int16)
    return populations, np.asarray(distance, dtype=np.int16), parent, parent_gate


def optimize(vectors: np.ndarray, side: str):
    """Minimize 2*preparation CNOTs + transformed core weight exactly."""
    width = vectors.shape[1]
    populations, distance, parent, parent_gate = atlas(width, side)
    codes = np.zeros(len(vectors), dtype=np.int16)
    for bit in range(width):
        codes |= vectors[:, bit].astype(np.int16) << bit
    histogram = np.bincount(codes, minlength=1 << width).astype(np.int32)
    costs = populations.astype(np.int32) @ histogram + 2 * distance.astype(np.int32)
    best = int(np.argmin(costs))
    word = []
    while parent[best] != -1:
        word.append(parent_gate[best])
        best = parent[best]
    word.reverse()
    return word, int(costs.min())
