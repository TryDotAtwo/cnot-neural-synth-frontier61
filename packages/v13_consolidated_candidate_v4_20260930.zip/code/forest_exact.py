"""Stage-23 exact synthesis for ancestor-accumulation forest matrices."""

from __future__ import annotations

import numpy as np

from stage16_reference import binary_matrix, circuit_matrix, inverse


def exact_forest_program(matrix):
    """Return a globally shortest word for M=(I+K)^-1, or None.

    K has at most one off-diagonal 1 per row and its parent relation is a forest.
    Each nonroot row of M differs from its initial row, so every implementation
    must target it at least once. The constructed word targets it exactly once.
    """
    M = binary_matrix(matrix, square=True)
    n = len(M)
    K = inverse(M) ^ np.eye(n, dtype=np.uint8)
    if np.any(np.diag(K)) or np.any(K.sum(axis=1) > 1):
        return None
    parent = [int(np.flatnonzero(K[v])[0]) if np.any(K[v]) else None for v in range(n)]
    state = [0] * n
    gates = []

    def visit(v):
        if state[v] == 1:
            raise ValueError("cycle")
        if state[v] == 2:
            return
        state[v] = 1
        p = parent[v]
        if p is not None:
            visit(p)
            gates.append((p, v))
        state[v] = 2

    try:
        for v in range(n):
            visit(v)
    except ValueError:
        return None
    if not np.array_equal(circuit_matrix(n, gates), M):
        return None
    lower = int(np.count_nonzero(np.any(M ^ np.eye(n, dtype=np.uint8), axis=1)))
    if lower != len(gates):
        raise AssertionError("forest lower bound does not match construction")
    return {"gates": gates, "count": len(gates), "lower_bound": lower,
            "parent": parent, "certificate": "each changed row must be a CNOT target"}
