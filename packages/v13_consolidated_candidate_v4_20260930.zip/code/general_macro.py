"""General-matrix wrapper around paid shared-basis shear compilation.

Gaussian elimination supplies a valid word for any invertible binary matrix.
Dynamic programming groups contiguous row operations into disjoint source/target
shears, prices each with the stage-17 basis compiler, and accounts for basis
preparations carried across macro boundaries. No Hamming score is used.
"""

from __future__ import annotations

import hashlib
import time

import numpy as np

from stage16_reference import binary_matrix, circuit_matrix


def gaussian_word(matrix):
    M = binary_matrix(matrix, square=True)
    n = len(M)
    work = M.copy()
    reduction = []

    def add(c, t):
        work[t] ^= work[c]
        reduction.append((c, t))

    for col in range(n):
        pivot = next((r for r in range(col, n) if work[r, col]), None)
        if pivot is None:
            raise ValueError("matrix is singular")
        if pivot != col:
            add(pivot, col)
            add(col, pivot)
            add(pivot, col)
        for row in range(n):
            if row != col and work[row, col]:
                add(col, row)
    if not np.array_equal(work, np.eye(n, dtype=np.uint8)):
        raise AssertionError("Gaussian reduction failed")
    word = list(reversed(reduction))
    if not np.array_equal(circuit_matrix(n, word), M):
        raise AssertionError("Gaussian encoder word failed")
    return word


def _macro_candidates(word, n, compile_shear, *, width, restarts, maxiter,
                      sweeps, seed, exact_local, max_span=32):
    candidates = []
    by_end = [[] for _ in range(len(word) + 1)]

    def add(candidate):
        index = len(candidates)
        candidates.append(candidate)
        by_end[candidate["end"]].append(index)

    for i, gate in enumerate(word):
        add({"start": i, "end": i + 1, "gates": [gate],
             "preparation": [], "kind": "direct"})
        controls = set()
        targets = set()
        chosen = []
        for j in range(i, min(len(word), i + max_span)):
            c, t = word[j]
            if c in targets or t in controls:
                break
            controls.add(c)
            targets.add(t)
            chosen.append((c, t))
            length = j + 1 - i
            if length < 4 or len(controls) < 2 or len(targets) < 2:
                continue
            if length not in (8, 16, 32) and j + 1 < len(word):
                next_c, next_t = word[j + 1]
                if next_c not in targets and next_t not in controls and length < max_span:
                    continue
            src = sorted(controls)
            tgt = sorted(targets)
            s = {wire: idx for idx, wire in enumerate(src)}
            d = {wire: idx for idx, wire in enumerate(tgt)}
            block = np.zeros((len(tgt), len(src)), dtype=np.uint8)
            for a, b in chosen:
                block[d[b], s[a]] ^= 1
            digest = hashlib.sha256(block.tobytes() + str((i, j, src, tgt)).encode()).digest()
            local_seed = seed + int.from_bytes(digest[:4], "big")
            compiled = compile_shear(block, src, tgt, width=width, restarts=restarts,
                                     maxiter=maxiter, sweeps=sweeps, seed=local_seed,
                                     exact_local=exact_local)
            if compiled["count"] >= length:
                continue
            gates = [tuple(g) for g in compiled["gates"]]
            if not np.array_equal(circuit_matrix(n, gates), circuit_matrix(n, chosen)):
                raise AssertionError("macro changed its segment matrix")
            add({"start": i, "end": j + 1, "gates": gates,
                 "preparation": [tuple(g) for g in compiled["preparation"]],
                 "kind": "shared_basis", "source_count": length,
                 "core_count": compiled["core_count"]})
    return candidates, by_end


def _prefix_cancellation(a, b):
    count = 0
    for x, y in zip(a, b):
        if x != y:
            break
        count += 1
    return 2 * count


def _cancel_adjacent(word):
    out = []
    for gate in word:
        if out and out[-1] == gate:
            out.pop()
        else:
            out.append(gate)
    return out


def _commuting_macros(a, b):
    return all(t1 != c2 and t2 != c1
               for c1, t1 in a["gates"] for c2, t2 in b["gates"])


def _ordered_word(selected):
    return _cancel_adjacent([gate for candidate in selected for gate in candidate["gates"]])


def _improve_macro_order(selected, *, time_limit=None):
    """Swap commuting macros while strictly shortening the full word.

    With no time limit this still terminates: every accepted pass decreases the
    nonnegative integer gate count. A supplied limit is for legacy callers.
    """
    start = time.perf_counter()
    current = list(selected)
    current_word = _ordered_word(current)
    swaps = 0
    while time_limit is None or time.perf_counter() - start < time_limit:
        best = None
        best_word = current_word
        for i in range(len(current) - 1):
            if time_limit is not None and time.perf_counter() - start >= time_limit:
                break
            if not _commuting_macros(current[i], current[i + 1]):
                continue
            trial = current.copy()
            trial[i], trial[i + 1] = trial[i + 1], trial[i]
            candidate = _ordered_word(trial)
            if len(candidate) < len(best_word):
                best, best_word = trial, candidate
            if i + 2 < len(current) and _commuting_macros(current[i], current[i + 2]):
                # Move the first macro past two commuting neighbors at once.
                trial2 = current.copy()
                trial2[i:i + 3] = [current[i + 1], current[i + 2], current[i]]
                candidate2 = _ordered_word(trial2)
                if len(candidate2) < len(best_word):
                    best, best_word = trial2, candidate2
        if best is None:
            break
        current, current_word = best, best_word
        swaps += 1
    return current, current_word, swaps


def compile_general(matrix, compile_shear, *, width=4, restarts=1,
                    maxiter=40, sweeps=2, seed=1700, exact_local=True,
                    max_span=32):
    start_time = time.perf_counter()
    M = binary_matrix(matrix, square=True)
    n = len(M)
    word = gaussian_word(M)
    candidates, by_end = _macro_candidates(
        word, n, compile_shear, width=width, restarts=restarts,
        maxiter=maxiter, sweeps=sweeps, seed=seed, exact_local=exact_local,
        max_span=max_span)
    costs = [float("inf")] * len(candidates)
    previous = [None] * len(candidates)
    for index, candidate in enumerate(candidates):
        own = len(candidate["gates"])
        if candidate["start"] == 0:
            costs[index] = own
        for pred in by_end[candidate["start"]]:
            price = costs[pred] + own - _prefix_cancellation(
                candidates[pred]["preparation"], candidate["preparation"])
            if price < costs[index]:
                costs[index] = price
                previous[index] = pred
    end = min(by_end[len(word)], key=lambda index: costs[index]) if word else None
    selected = []
    while end is not None:
        selected.append(candidates[end])
        end = previous[end]
    selected.reverse()
    selected, compiled_word, order_swaps = _improve_macro_order(selected)
    carry_saved = sum(_prefix_cancellation(a["preparation"], b["preparation"])
                      for a, b in zip(selected, selected[1:]))
    if not np.array_equal(circuit_matrix(n, compiled_word), M):
        raise AssertionError("general macro program changed full matrix")
    return {"gates": compiled_word, "count": len(compiled_word),
            "gaussian_count": len(word),
            "macro_count": sum(c["kind"] == "shared_basis" for c in selected),
            "basis_carry_saved": carry_saved,
            "commuting_macro_reorders": order_swaps,
            "selected_macros": [{k: c[k] for k in ("start", "end", "kind")}
                                for c in selected],
            "tested_candidates": len(candidates),
            "seconds": time.perf_counter() - start_time,
            "status": "verified_general_matrix_upper_bound_not_optimal"}
