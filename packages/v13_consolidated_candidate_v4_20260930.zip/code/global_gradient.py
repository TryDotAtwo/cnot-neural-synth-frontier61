"""Whole-program synthesis by gradient descent on the full CNOT Cayley graph.

This is an exact-state proof of concept for n <= 4. It minimizes a strictly
convex quadratic action for the positive resolvent field, then follows the
field from the requested full matrix to identity. It never consumes an input
circuit. The state count is |GL(n,2)|, so it is not a scalable benchmark solver.
"""

from __future__ import annotations

import hashlib
import time
from functools import lru_cache

import numpy as np

from stage16_reference import binary_matrix, circuit_matrix


def _encode(matrix):
    M = binary_matrix(matrix, square=True)
    n = len(M)
    return sum(int(M[i, j]) << (i * n + j) for i in range(n) for j in range(n))


def _decode(state, n):
    return np.asarray([[(state >> (i * n + j)) & 1 for j in range(n)]
                       for i in range(n)], dtype=np.uint8)


def _rank(state, n):
    rows = [(state >> (i * n)) & ((1 << n) - 1) for i in range(n)]
    rank = 0
    for col in range(n):
        pivot = next((i for i in range(rank, n) if (rows[i] >> col) & 1), None)
        if pivot is None:
            continue
        rows[rank], rows[pivot] = rows[pivot], rows[rank]
        for i in range(rank + 1, n):
            if (rows[i] >> col) & 1:
                rows[i] ^= rows[rank]
        rank += 1
    return rank


def _step(state, n, c, t):
    control = (state >> (c * n)) & ((1 << n) - 1)
    return state ^ (control << (t * n))


@lru_cache(maxsize=4)
def graph(n):
    if not 1 <= n <= 4:
        raise ValueError("full-state gradient is limited to n <= 4")
    states = [s for s in range(1 << (n * n)) if _rank(s, n) == n]
    index = {state: i for i, state in enumerate(states)}
    gates = [(c, t) for c in range(n) for t in range(n) if c != t]
    neighbors = np.asarray([[index[_step(state, n, c, t)] for c, t in gates]
                            for state in states], dtype=np.int32)
    goal_state = _encode(np.eye(n, dtype=np.uint8))
    return states, index, gates, neighbors, index[goal_state]


def synthesize(matrix, *, q_scale=0.6, tolerance=1e-13, max_iterations=400):
    started = time.perf_counter()
    M = binary_matrix(matrix, square=True)
    n = len(M)
    states, index, gates, neighbors, goal = graph(n)
    source = index[_encode(M)]
    D = len(gates)
    if source == goal:
        return {"n": n, "count": 0, "gates": [], "states": len(states),
                "iterations": 0, "residual": 0.0, "seconds": time.perf_counter()-started,
                "status": "verified_whole_program_convex_field"}
    if not 0 < q_scale < 1:
        raise ValueError("q_scale must be in (0,1)")
    q = q_scale / D
    field = np.zeros(len(states), dtype=np.float64)
    field[goal] = 1.0
    non_goal = np.arange(len(states)) != goal
    residual = float("inf")
    for iteration in range(1, max_iterations + 1):
        # Gradient step of 1/2 h^T(I-qA)h - b^T h, with h(goal)=1.
        desired = q * field[neighbors].sum(axis=1)
        residual = float(np.max(np.abs(field[non_goal] - desired[non_goal])))
        field[non_goal] = desired[non_goal]
        if residual <= tolerance:
            break
    else:
        raise RuntimeError(f"convex field did not converge: residual={residual}")
    node = source
    reduction = []
    seen = set()
    while node != goal:
        if node in seen:
            raise RuntimeError("field policy cycled")
        seen.add(node)
        choices = neighbors[node]
        gate_index = int(np.argmax(field[choices]))
        nxt = int(choices[gate_index])
        if field[nxt] <= field[node]:
            raise RuntimeError("field policy has no increasing transition")
        reduction.append(gates[gate_index])
        node = nxt
    word = list(reversed(reduction))
    if not np.array_equal(circuit_matrix(n, word), M):
        raise AssertionError("whole-program field returned wrong matrix")
    return {"n": n, "count": len(word), "gates": word, "states": len(states),
            "iterations": iteration, "residual": residual,
            "q_scale": q_scale, "matrix_sha256": hashlib.sha256(M.tobytes()).hexdigest(),
            "seconds": time.perf_counter() - started,
            "status": "verified_whole_program_convex_field"}
