"""Train a neural distance heuristic and use it to synthesize a whole CNOT word.

The training oracle is exact BFS on GL(4,2); evaluation uses held-out matrices.
This is an experiment, not a scalable model for the EA/BB benchmark.
"""

from __future__ import annotations

import json
import time
from collections import deque
from pathlib import Path

import numpy as np
import torch
from torch import nn

from global_gradient import _decode, _encode, _step, graph
from stage16_reference import binary_matrix, circuit_matrix


class DistanceNet(nn.Module):
    def __init__(self, n=4, hidden=128):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(n * n, hidden), nn.ReLU(),
                                 nn.Linear(hidden, hidden), nn.ReLU(),
                                 nn.Linear(hidden, 1))

    def forward(self, x):
        return self.net(x).squeeze(-1)


def exact_distances(n=4):
    states, _, _, neighbors, goal = graph(n)
    distance = np.full(len(states), -1, dtype=np.int16)
    distance[goal] = 0
    queue = deque([goal])
    while queue:
        node = queue.popleft()
        for adjacent in neighbors[node]:
            adjacent = int(adjacent)
            if distance[adjacent] == -1:
                distance[adjacent] = distance[node] + 1
                queue.append(adjacent)
    assert np.all(distance >= 0)
    return states, distance


def features(states, n):
    shifts = np.arange(n * n, dtype=np.uint32)
    return ((np.asarray(states, dtype=np.uint32)[:, None] >> shifts) & 1).astype(np.float32)


def split(states, *, seed=1700, train_fraction=0.8):
    rng = np.random.default_rng(seed)
    order = rng.permutation(len(states))
    count = int(len(states) * train_fraction)
    return order[:count], order[count:]


def train(*, n=4, seed=1700, epochs=100, hidden=128, batch_size=512):
    torch.set_num_threads(min(torch.get_num_threads(), 4))
    torch.manual_seed(seed)
    started = time.perf_counter()
    states, distances = exact_distances(n)
    train_idx, test_idx = split(states, seed=seed)
    x = torch.from_numpy(features(states, n))
    y = torch.from_numpy(distances.astype(np.float32))
    net = DistanceNet(n, hidden)
    optimizer = torch.optim.AdamW(net.parameters(), lr=0.002)
    generator = torch.Generator().manual_seed(seed)
    for _ in range(epochs):
        shuffled = train_idx[torch.randperm(len(train_idx), generator=generator).numpy()]
        net.train()
        for batch in np.array_split(shuffled, max(1, (len(shuffled) + batch_size - 1) // batch_size)):
            loss = nn.functional.mse_loss(net(x[batch]), y[batch])
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
    net.eval()
    with torch.no_grad():
        predicted = net(x).numpy()
    metrics = {
        "n": n, "seed": seed, "epochs": epochs, "hidden": hidden,
        "train_states": len(train_idx), "heldout_states": len(test_idx),
        "heldout_mae": float(np.abs(predicted[test_idx] - distances[test_idx]).mean()),
        "heldout_rounded_accuracy": float((np.rint(predicted[test_idx]) == distances[test_idx]).mean()),
        "train_seconds": time.perf_counter() - started,
    }
    return net, states, distances, test_idx, metrics


def synthesize(matrix, net, *, beam_width=64, max_depth=20, heuristic="network"):
    M = binary_matrix(matrix, square=True)
    n = len(M)
    if n != 4:
        raise ValueError("this trained model accepts n=4 only")
    source = _encode(M)
    goal = _encode(np.eye(n, dtype=np.uint8))
    gates = [(c, t) for c in range(n) for t in range(n) if c != t]
    if source == goal:
        return {"count": 0, "gates": [], "verified": True}
    beam = [(source, ())]
    seen = {source}
    if heuristic == "network":
        net.eval()
    elif heuristic not in ("hamming", "none"):
        raise ValueError("unknown heuristic")
    for _ in range(max_depth):
        candidates = []
        for state, path in beam:
            for gate in gates:
                nxt = _step(state, n, *gate)
                if nxt == goal:
                    word = list(reversed(path + (gate,)))
                    assert np.array_equal(circuit_matrix(n, word), M)
                    return {"count": len(word), "gates": word, "verified": True}
                if nxt not in seen:
                    seen.add(nxt)
                    candidates.append((nxt, path + (gate,)))
        if not candidates:
            break
        if heuristic == "network":
            with torch.no_grad():
                scores = net(torch.from_numpy(features([s for s, _ in candidates], n))).numpy()
        elif heuristic == "hamming":
            scores = np.asarray([(s ^ goal).bit_count() for s, _ in candidates])
        else:
            scores = np.zeros(len(candidates))
        keep = np.argsort(scores, kind="stable")[:beam_width]
        beam = [candidates[int(i)] for i in keep]
    return {"count": None, "gates": None, "verified": False}


def experiment(output_dir: Path, *, seed=1700, epochs=100, eval_count=200):
    output_dir.mkdir(parents=True, exist_ok=True)
    net, states, distances, test_idx, metrics = train(seed=seed, epochs=epochs)
    sampled = test_idx[:eval_count]
    results = []
    started = time.perf_counter()
    for i in sampled:
        result = synthesize(_decode(states[int(i)], 4), net)
        results.append({"state": int(states[int(i)]), "optimal": int(distances[int(i)]),
                        "neural": result["count"], "verified": result["verified"]})
    metrics["evaluation_seconds"] = time.perf_counter() - started
    metrics["evaluation_count"] = len(results)
    metrics["solved"] = sum(r["verified"] for r in results)
    metrics["optimal_count"] = sum(r["neural"] == r["optimal"] for r in results)
    metrics["excess_cnot_sum"] = sum(r["neural"] - r["optimal"] for r in results if r["verified"])
    comparisons = {}
    for heuristic in ("network", "hamming", "none"):
        for beam_width in (1, 4, 64):
            runs = [synthesize(_decode(states[int(i)], 4), net,
                               beam_width=beam_width, heuristic=heuristic)
                    for i in sampled]
            comparisons[f"{heuristic}_beam{beam_width}"] = {
                "solved": sum(r["verified"] for r in runs),
                "optimal": int(sum(r["count"] == distances[int(i)]
                                   for r, i in zip(runs, sampled))),
                "excess_cnot_sum": int(sum(r["count"] - int(distances[int(i)])
                                           for r, i in zip(runs, sampled) if r["verified"])),
            }
    metrics["comparisons"] = comparisons
    torch.save({"state_dict": net.state_dict(), "n": 4, "hidden": 128,
                "seed": seed}, output_dir / "model.pt")
    payload = {"metrics": metrics, "results": results,
               "training_source": "exact_BFS_GL4_supervision",
               "matrix_encoding": "row-major 16 bits"}
    (output_dir / "evaluation.json").write_text(json.dumps(payload, indent=2))
    return metrics


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--eval-count", type=int, default=200)
    args = parser.parse_args()
    print(json.dumps(experiment(args.output_dir, epochs=args.epochs,
                                eval_count=args.eval_count), indent=2))
