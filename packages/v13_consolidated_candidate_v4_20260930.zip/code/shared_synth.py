"""Matrix-only CNOT synthesis by a shared physical basis and exact local actions.

No circuit is accepted as input. All returned words preserve the full matrix.
There is no claim of global optimality. Discrete choices select small variational
blocks, not vertices of the full CNOT graph. Every selected physical basis gate
is executed once before the core and once, reversed, after it.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import time
from pathlib import Path
from typing import Sequence
import numpy as np
from stage16_reference import (UnsupportedMatrix, binary_matrix, circuit_matrix,
                               infer_layers, inverse, universal_basis_template)


class SharedAction:
    """Exact expectation of 2*preparation_length + core Hamming weight.

    `vectors` is an array of rows, each containing a slice of a core row (source
    basis) or core column (target basis). The only exponential size is 2**width.
    Fraction-valued probabilities are supported for independent exact tests.
    """
    def __init__(self,vectors,ops,*,side='source'):
        a=binary_matrix(vectors)
        self.width=a.shape[1]
        if side not in ('source','target'):raise ValueError('Bad side')
        if not 0<=self.width<=16:raise ValueError('Unreasonable action width')
        self.side=side;self.ops=list(ops)
        ids=np.arange(1<<self.width,dtype=np.int64)
        codes=np.zeros(a.shape[0],dtype=np.int64)
        for i in range(self.width):codes|=a[:,i].astype(np.int64)<<i
        self.initial=np.bincount(codes,minlength=len(ids))
        self.pop=np.array([int(x).bit_count() for x in ids],dtype=np.int64)
        self.perms=[];self.prices=[]
        for kind,c,t in self.ops:
            if c==t or not (0<=c<self.width and 0<=t<self.width):raise ValueError('Bad local gate')
            if kind=='add':
                if side=='source':p=ids^(((ids>>t)&1)<<c)
                else:p=ids^(((ids>>c)&1)<<t)
                price=2
            elif kind=='swap':
                bit=((ids>>c)^(ids>>t))&1;p=ids^(bit<<c)^(bit<<t);price=6
            else:raise ValueError('Bad local operation')
            self.perms.append(p);self.prices.append(price)
        self.prices=np.array(self.prices,dtype=np.int64)

    def value_gradient(self,theta):
        theta=np.asarray(theta)
        if theta.shape!=(len(self.ops),):raise ValueError('Wrong parameter length')
        dtype=object if theta.dtype==object else np.float64
        forward=[self.initial.astype(dtype)]
        for z,p in zip(theta,self.perms):
            x=forward[-1];forward.append((1-z)*x+z*x[p])
        back=self.pop.astype(dtype)
        value=np.dot(forward[-1],back)+np.dot(self.prices,theta)
        gradient=np.empty(len(theta),dtype=dtype)
        for j in range(len(theta)-1,-1,-1):
            x=forward[j];p=self.perms[j]
            gradient[j]=self.prices[j]+np.dot(back,x[p]-x)
            z=theta[j];back=(1-z)*back+z*back[p]
        return value,gradient

    def round(self,theta):
        theta=np.asarray(theta);dtype=object if theta.dtype==object else np.float64
        back=[None]*(len(theta)+1);back[-1]=self.pop.astype(dtype)
        for j in range(len(theta)-1,-1,-1):
            b=back[j+1];z=theta[j];back[j]=(1-z)*b+z*b[self.perms[j]]
        x=self.initial.astype(dtype);bits=[]
        for j,p in enumerate(self.perms):
            delta=self.prices[j]+np.dot(back[j+1],x[p]-x)
            bit=int(delta<0);bits.append(bit)
            if bit:x=x[p]
        return bits


def _apply_vectors(vectors,ops,bits,side):
    a=vectors.copy();physical=[]
    for (kind,c,t),bit in zip(ops,bits):
        if not bit:continue
        if kind=='swap':
            a[:,[c,t]]=a[:,[t,c]]
            physical.extend([(c,t),(t,c),(c,t)])
        else:
            if side=='source':a[:,c]^=a[:,t]
            else:a[:,t]^=a[:,c]
            physical.append((c,t))
    return a,physical


def _polish_discrete(vectors,ops,bits,side,*,passes=2):
    """Decrease the exact physical CNOT cost after conditional rounding.

    This works on a local basis template, not on the full CNOT state graph.
    Each accepted toggle is evaluated using the actual preparation gates and
    core weight; consequently the result cannot be worse than the rounded word.
    """
    bits=list(bits)
    out,gates=_apply_vectors(vectors,ops,bits,side)
    cost=2*len(gates)+int(out.sum())
    for _ in range(passes):
        best_cost=cost;best_choice=None;best_out=None;best_gates=None
        for j in range(len(bits)):
            bits[j]^=1
            candidate_out,candidate_gates=_apply_vectors(vectors,ops,bits,side)
            candidate_cost=2*len(candidate_gates)+int(candidate_out.sum())
            bits[j]^=1
            if candidate_cost<best_cost:
                best_cost=candidate_cost;best_choice=j
                best_out=candidate_out;best_gates=candidate_gates
        if best_choice is None:break
        bits[best_choice]^=1
        out,gates,cost=best_out,best_gates,best_cost
    return bits,out,gates,cost


def _groups(vectors,width):
    """Data-selected groups; only O(d) blocks, never enumerate GL or words."""
    if len(vectors)<2:return []
    weights=vectors.sum(axis=1).astype(int)
    active=np.flatnonzero(weights>0).tolist()
    if len(active)<2:return []
    w=min(width,len(active));seen=set();groups=[]
    # Largest possible one-row saving orders candidates but never determines
    # the selected word; each group is evaluated by its full variational action.
    for i in sorted(active,key=lambda i:(-weights[i],i)):
        others=[j for j in active if j!=i]
        others.sort(key=lambda j:(int(np.count_nonzero(vectors[i]^vectors[j]))-max(weights[i],weights[j]),j))
        group=tuple(sorted([i]+others[:w-1]))
        if group not in seen:groups.append(group);seen.add(group)
    for start in range(0,len(active),max(1,w-1)):
        group=tuple(active[start:start+w])
        if len(group)>1 and group not in seen:groups.append(group);seen.add(group)
    return groups


def _optimize_local(vectors,side,*,restarts,maxiter,rng,exact_local=False):
    if exact_local and vectors.shape[1]<=4:
        from exact_basis import optimize
        word,cost=optimize(vectors,side)
        out,gates=_apply_vectors(vectors,[('add',c,t) for c,t in word],[1]*len(word),side)
        if 2*len(gates)+int(out.sum())!=cost:
            raise AssertionError('Exact basis atlas price mismatch')
        return out,gates,{'before':int(vectors.sum()),'after_with_basis_cost':cost,
                          'trials':[],'bits':None,'template':None,
                          'exact_local_basis':True}
    w=vectors.shape[1];ops=universal_basis_template(w)
    action=SharedAction(vectors,ops,side=side)
    original=int(vectors.sum());bestcost=original;bestbits=[0]*len(ops)
    bestvectors=vectors.copy();bestgates=[];logs=[]
    starts=[np.zeros(len(ops))]
    starts.extend(rng.beta(.4,.4,size=len(ops)) for _ in range(restarts))
    for restart,start in enumerate(starts):
        if maxiter>0 and len(ops):
            from scipy.optimize import minimize
            result=minimize(action.value_gradient,start,jac=True,method='L-BFGS-B',
                bounds=[(0.,1.)]*len(ops),options={'maxiter':maxiter,'ftol':1e-12,'gtol':1e-7,'maxls':30})
            theta=np.clip(result.x,0,1);status=str(result.message);nfev=int(result.nfev)
        else:theta=start;status='conditional_rounding_no_gradient';nfev=1
        continuous,_=action.value_gradient(theta)
        bits=action.round(theta)
        out,gates=_apply_vectors(vectors,ops,bits,side)
        cost=2*len(gates)+int(out.sum())
        if cost>float(continuous)+1e-6:raise ArithmeticError('Rounding exceeded exact-action numerical tolerance')
        rounded_cost=cost
        bits,out,gates,cost=_polish_discrete(vectors,ops,bits,side)
        logs.append({'restart':restart,'continuous_action':float(continuous),'rounded_count':cost,
                     'conditional_rounded_count':rounded_cost,
                     'evaluations':nfev,'message':status})
        if cost<bestcost:
            bestcost=cost;bestbits=bits;bestvectors=out;bestgates=gates
    return bestvectors,bestgates,{'before':original,'after_with_basis_cost':bestcost,'trials':logs,
                                 'bits':bestbits,'template':ops}


def compile_shear(matrix,source_wires,target_wires,*,width=4,restarts=1,maxiter=40,sweeps=2,seed=1700,exact_local=True):
    B=binary_matrix(matrix);src=list(map(int,source_wires));tgt=list(map(int,target_wires))
    if B.shape!=(len(tgt),len(src)):raise ValueError('Wrong block/wire dimensions')
    if len(set(src))!=len(src) or len(set(tgt))!=len(tgt) or set(src)&set(tgt):raise ValueError('Wires must be distinct')
    if any(i<0 for i in src+tgt):raise ValueError('Negative wire index')
    if not 2<=width<=8 or restarts<0 or maxiter<0 or sweeps<0:raise ValueError('Invalid resource limits')
    D=B.copy();S=np.eye(len(src),dtype=np.uint8);T=np.eye(len(tgt),dtype=np.uint8)
    preparation=[];accepted=[];evals=0;tested=0
    rng=np.random.default_rng(seed)
    for sweep in range(sweeps):
        before=2*len(preparation)+int(D.sum())
        for side in ('source','target'):
            vectors=D.T if side=='source' else D
            groups=_groups(vectors,width)
            for group in groups:
                idx=list(group)
                block=D[:,idx] if side=='source' else D[idx,:].T
                changed,ops,record=_optimize_local(block,side,restarts=restarts,maxiter=maxiter,rng=rng,
                                                    exact_local=exact_local)
                tested+=1;evals+=sum(r['evaluations'] for r in record['trials'])
                if not ops:continue
                oldcost=2*len(preparation)+int(D.sum())
                for c,t in ops:
                    c,t=idx[c],idx[t]
                    if side=='source':
                        D[:,c]^=D[:,t];S[t]^=S[c];preparation.append((src[c],src[t]))
                    else:
                        D[t]^=D[c];T[t]^=T[c];preparation.append((tgt[c],tgt[t]))
                actual=D[:,idx] if side=='source' else D[idx,:].T
                if not np.array_equal(changed,actual):raise AssertionError('Local lift mismatch')
                newcost=2*len(preparation)+int(D.sum())
                if newcost>=oldcost:raise AssertionError('Accepted move must decrease physical count')
                accepted.append({'sweep':sweep,'side':side,'indices':idx,'cost_before':oldcost,
                                 'cost_after':newcost,'local':record})
        after=2*len(preparation)+int(D.sum())
        if after==before:break
    if not np.array_equal((T@B@inverse(S))&1,D):raise AssertionError('Prepared-basis invariant failed')
    core=[(src[int(c)],tgt[int(t)]) for t,c in zip(*np.nonzero(D))]
    gates=preparation+core+list(reversed(preparation))
    if len(gates)>int(B.sum()):raise AssertionError('Direct candidate lost')
    return {'method':'shared_physical_basis','count':len(gates),'gates':gates,
            'source_wires':src,'target_wires':tgt,'original_block':B.tolist(),'core':D.tolist(),
            'source_basis':S.tolist(),'target_basis':T.tolist(),'preparation':preparation,
            'preparation_cost':len(preparation),'core_count':len(core),'direct_count':int(B.sum()),
            'accepted_moves':accepted,'tested_groups':tested,'action_evaluations':evals,
            'message_size_bound':1<<width}


def synthesize(matrix,*,width=4,restarts=1,maxiter=40,sweeps=2,seed=1700,layer_fusion=True,exact_postprocess=True,exact_local=True,defect_postprocess=True,global_gradient=False):
    start=time.perf_counter();M=binary_matrix(matrix,square=True);n=len(M)
    if n<1:raise ValueError('At least one wire required')
    if global_gradient:
        from global_gradient import synthesize as full_gradient
        result=full_gradient(M)
        result.update(input_fields=['matrix'],selected_order='full_state_convex_gradient',
                      matrix_differences=0)
        return result
    from forest_exact import exact_forest_program
    forest=exact_forest_program(M)
    if forest is not None:
        return {'status':'verified_globally_optimal_forest_family','n':n,
                'matrix_sha256':hashlib.sha256(M.tobytes()).hexdigest(),
                'input_fields':['matrix'],'count':forest['count'],
                'gates':forest['gates'],'lower_bound':forest['lower_bound'],
                'certificate':forest['certificate'],'forest_parent':forest['parent'],
                'selected_order':'stage23_exact_forest','groups':None,
                'choices':[],'blocks':[],'seconds':time.perf_counter()-start,
                'matrix_differences':0,'seed':seed,
                'config':{'width':width,'restarts':restarts,'maxiter':maxiter,
                          'sweeps':sweeps,'layer_fusion':layer_fusion,'exact_local':exact_local},
                'tested_groups':0,'action_evaluations':0}
    try:
        P,F,Q=infer_layers(M)
    except UnsupportedMatrix as unsupported:
        from general_macro import compile_general
        result=compile_general(M,compile_shear,width=width,restarts=restarts,
                               maxiter=maxiter,sweeps=sweeps,seed=seed,
                               exact_local=exact_local)
        final_gates=result['gates']
        postprocess_stats=None
        if exact_postprocess:
            from stage28_exact import improve
            final_gates,postprocess_stats=improve(final_gates,n)
        defect_stats=None
        if defect_postprocess:
            from defect_repair import improve as repair_defect
            final_gates,defect_stats=repair_defect(final_gates,n)
        if np.count_nonzero(circuit_matrix(n,final_gates)^M):
            raise AssertionError('General macro route changed full target matrix')
        return {'status':'verified_general_matrix_upper_bound_not_optimal',
                'n':n,'matrix_sha256':hashlib.sha256(M.tobytes()).hexdigest(),
                'input_fields':['matrix'],'count':len(final_gates),
                'gates':final_gates,'selected_order':'general_paid_macro_decomposition',
                'groups':None,'choices':[],'blocks':[],
                'general_macro':{k:v for k,v in result.items() if k!='gates'},
                'stage28_exact':postprocess_stats,
                'defect_repair':defect_stats,
                'stage17_contract_rejection':str(unsupported),
                'seconds':time.perf_counter()-start,
                'matrix_differences':0,'seed':seed,
                'config':{'width':width,'restarts':restarts,'maxiter':maxiter,
                          'sweeps':sweeps,'exact_postprocess':exact_postprocess,
                          'defect_postprocess':defect_postprocess,
                          'exact_local':exact_local},
                'tested_groups':0,'action_evaluations':0}
    A=M[np.ix_(F,P)];C=M[np.ix_(Q,F)];B=M[np.ix_(Q,P)];Z=B^((C@A)&1)
    cache={}
    def get(block,src,tgt):
        key=(tuple(src),tuple(tgt),block.shape,block.tobytes())
        if key not in cache:
            digest=hashlib.sha256(block.tobytes()+str((src,tgt,block.shape)).encode()).hexdigest()
            local_seed=(seed+int(digest[:12],16))%(2**63-1)
            cache[key]=compile_shear(block,src,tgt,width=width,restarts=restarts,maxiter=maxiter,
                                     sweeps=sweeps,seed=local_seed,exact_local=exact_local)
        return cache[key]
    a=get(A,P,F);c=get(C,F,Q);b=get(B,P,Q);z=get(Z,P,Q)
    paths=[('C_then_A_then_B',[c,a,b]),('A_then_C_then_BplusCA',[a,c,z])]
    if layer_fusion:
        paths += [('C_then_joint_AB',[c,get(np.vstack((A,B)),P,F+Q)]),
                  ('joint_A_BplusCA_then_C',[get(np.vstack((A,Z)),P,F+Q),c]),
                  ('A_then_joint_BplusCA_C',[a,get(np.hstack((Z,C)),P+F,Q)]),
                  ('joint_BC_then_A',[get(np.hstack((B,C)),P+F,Q),a])]
    choices=[]
    blocks=list(cache.values());block_ids={id(block):i for i,block in enumerate(blocks)}
    for name,recs in paths:
        gates=[tuple(g) for rec in recs for g in rec['gates']]
        differences=int(np.count_nonzero(circuit_matrix(n,gates)^M))
        if differences:raise AssertionError('Full target matrix changed')
        choices.append({'order':name,'count':len(gates),'gates':gates,
                        'component_counts':[r['count'] for r in recs],
                        'block_indices':[block_ids[id(r)] for r in recs],
                        'matrix_differences':differences})
    best=min(choices,key=lambda d:d['count'])
    final_gates=list(best['gates'])
    postprocess_stats=None
    if exact_postprocess:
        from stage28_exact import improve
        final_gates,postprocess_stats=improve(final_gates,n)
        if np.count_nonzero(circuit_matrix(n,final_gates)^M):
            raise AssertionError('Exact postprocessing changed full target matrix')
    defect_stats=None
    if defect_postprocess:
        from defect_repair import improve as repair_defect
        final_gates,defect_stats=repair_defect(final_gates,n)
        if np.count_nonzero(circuit_matrix(n,final_gates)^M):
            raise AssertionError('Defect repair changed full target matrix')
    return {'status':'verified_best_found_shared_macro_family_not_global_minimum','n':n,
            'matrix_sha256':hashlib.sha256(M.tobytes()).hexdigest(),'input_fields':['matrix'],
            'count':len(final_gates),'gates':final_gates,'selected_order':best['order'],
            'stage28_exact':postprocess_stats,
            'defect_repair':defect_stats,
            'groups':{'P':P,'F':F,'Q':Q},'choices':choices,'blocks':blocks,
            'seconds':time.perf_counter()-start,'matrix_differences':0,'seed':seed,
            'config':{'width':width,'restarts':restarts,'maxiter':maxiter,'sweeps':sweeps,
                      'layer_fusion':layer_fusion,'exact_postprocess':exact_postprocess,
                      'exact_local':exact_local,'defect_postprocess':defect_postprocess},
            'tested_groups':sum(r['tested_groups'] for r in blocks),
            'action_evaluations':sum(r['action_evaluations'] for r in blocks)}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('matrix_json',type=Path);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--width',type=int,default=4);parser.add_argument('--restarts',type=int,default=1)
    parser.add_argument('--maxiter',type=int,default=40);parser.add_argument('--sweeps',type=int,default=2)
    parser.add_argument('--seed',type=int,default=1700);parser.add_argument('--no-fusion',action='store_true')
    parser.add_argument('--gradient-local',action='store_true',
                        help='use gradient search also for local widths <= 4')
    parser.add_argument('--global-gradient',action='store_true',
                        help='whole-matrix convex field; available only for n <= 4')
    parser.add_argument('--no-exact-postprocess',action='store_true')
    parser.add_argument('--no-defect-postprocess',action='store_true')
    args=parser.parse_args();raw=json.loads(args.matrix_json.read_text())
    matrix=raw['matrix'] if isinstance(raw,dict) else raw
    result=synthesize(matrix,width=args.width,restarts=args.restarts,maxiter=args.maxiter,
                      sweeps=args.sweeps,seed=args.seed,layer_fusion=not args.no_fusion,
                      exact_local=not args.gradient_local,
                      global_gradient=args.global_gradient,
                      exact_postprocess=not args.no_exact_postprocess,
                      defect_postprocess=not args.no_defect_postprocess)
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,indent=2))
    print(json.dumps({k:result[k] for k in ('n','count','selected_order','matrix_differences','seconds')}))
if __name__=='__main__':main()
