"""Experimental matrix-only CNOT macro synthesis. No supplied circuit is read.

The continuous variables change a *factorization* B=(U R^-1)(R V).
They are not fractional physical gates. Every rounded factorization is compiled
into fully charged parity/gather/uncompute circuits on the original wires.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import time
from pathlib import Path
from typing import Sequence

import numpy as np

Gate = tuple[int, int]

class UnsupportedMatrix(ValueError):
    pass

def binary_matrix(data, *, square=False):
    a=np.asarray(data)
    if a.ndim!=2 or (square and a.shape[0]!=a.shape[1]):
        raise ValueError('Expected a two-dimensional binary matrix' + (' with square shape' if square else ''))
    if not np.all((a==0)|(a==1)):
        raise ValueError('Every matrix element must be 0 or 1')
    return np.asarray(a,dtype=np.uint8).copy()

def rref(a):
    a=binary_matrix(a); piv=[]; row=0
    for col in range(a.shape[1]):
        hit=np.flatnonzero(a[row:,col])
        if len(hit)==0: continue
        k=row+int(hit[0]); a[[row,k]]=a[[k,row]]
        for j in range(a.shape[0]):
            if j!=row and a[j,col]: a[j]^=a[row]
        piv.append(col); row+=1
        if row==a.shape[0]: break
    return a,piv

def inverse(a):
    a=binary_matrix(a,square=True); n=len(a)
    v=np.concatenate((a,np.eye(n,dtype=np.uint8)),axis=1)
    for i in range(n):
        hit=np.flatnonzero(v[i:,i])
        if not len(hit): raise ValueError('Singular matrix over F2')
        j=i+int(hit[0]); v[[i,j]]=v[[j,i]]
        for j in range(n):
            if j!=i and v[j,i]: v[j]^=v[i]
    return v[:,n:]

def rank_factor(b):
    b=binary_matrix(b); q,p=b.shape
    if q==0 or p==0: return np.zeros((q,0),np.uint8),np.zeros((0,p),np.uint8)
    _,piv=rref(b); r=len(piv)
    u=b[:,piv].copy()
    if r==0: return u,np.zeros((0,p),np.uint8)
    aug=np.concatenate((u,b),axis=1)
    for i in range(r):
        hits=np.flatnonzero(aug[i:,i])
        j=i+int(hits[0]); aug[[i,j]]=aug[[j,i]]
        for j in range(q):
            if j!=i and aug[j,i]: aug[j]^=aug[i]
    v=aug[:r,r:]
    if not np.array_equal((u@v)&1,b): raise AssertionError('Rank factorization failed')
    return u,v

def circuit_matrix(n: int, gates: Sequence[Gate]):
    a=np.eye(n,dtype=np.uint8)
    for c,t in gates:
        c,t=int(c),int(t)
        if c==t or not (0<=c<n and 0<=t<n): raise ValueError('Invalid CNOT')
        a[t]^=a[c]
    return a

def apply_basis(u,v,ops,bits):
    u=u.copy(); v=v.copy(); r=v.shape[0]
    R=np.eye(r,dtype=np.uint8)
    for (kind,c,t),bit in zip(ops,bits):
        if not bit: continue
        if kind=='add':
            v[t]^=v[c]; u[:,c]^=u[:,t]; R[t]^=R[c]
        elif kind=='swap':
            v[[c,t]]=v[[t,c]]; u[:,[c,t]]=u[:,[t,c]]; R[[c,t]]=R[[t,c]]
        else: raise ValueError('Unknown basis operator')
    return u,v,R

def universal_basis_template(r: int):
    # Reverse of a complete Gauss-Jordan reduction schedule. Every invertible
    # r x r matrix has a binary selection in this template. Swap choices are
    # whole latent permutations, not three independently toggled operations.
    ops=[]
    for pivot in range(r):
        ops.extend(('swap',pivot,j) for j in range(pivot+1,r))
        ops.extend(('add',pivot,j) for j in range(r) if j!=pivot)
    return list(reversed(ops))

def _hist_columns(a):
    r=a.shape[0]; nstates=1<<r
    codes=np.zeros(a.shape[1],dtype=np.int64)
    for i in range(r): codes|=a[i].astype(np.int64)<<i
    return np.bincount(codes,minlength=nstates)

class BasisAction:
    """Exact finite expectation of the compiled cost, up to arithmetic precision.

    The optional object dtype supports Fraction tests. The numerical optimizer
    uses float64. Cost includes every physical gather/distribute/uncompute gate.
    """
    def __init__(self,u,v,ops,orientation='source'):
        self.u=binary_matrix(u); self.v=binary_matrix(v); self.r=self.v.shape[0]
        if self.u.shape[1]!=self.r: raise ValueError('Factor dimensions disagree')
        if orientation not in ('source','target'): raise ValueError('Bad orientation')
        self.ops=list(ops); self.orientation=orientation
        self.pop=np.array([k.bit_count() for k in range(1<<self.r)],dtype=np.int64)
        weights=(2,1) if orientation=='source' else (1,2) # V,U
        self.initial=np.stack((weights[0]*_hist_columns(self.v),weights[1]*_hist_columns(self.u.T)))
        ids=np.arange(1<<self.r,dtype=np.int64); self.perms=[]
        for kind,c,t in self.ops:
            if c==t or not(0<=c<self.r and 0<=t<self.r): raise ValueError('Bad latent operation')
            if kind=='add':
                p=ids^(((ids>>c)&1)<<t)
                pt=ids^(((ids>>t)&1)<<c)
            elif kind=='swap':
                mask=((ids>>c)^(ids>>t))&1
                p=ids^(mask<<c)^(mask<<t); pt=p
            else: raise ValueError('Bad latent operation')
            self.perms.append((p,pt))

    @staticmethod
    def permute(x,p):
        return np.stack((x[0,p[0]],x[1,p[1]]))

    def value_gradient(self,theta):
        theta=np.asarray(theta)
        if theta.shape!=(len(self.ops),): raise ValueError('Wrong parameter length')
        dtype=object if theta.dtype==object else np.float64
        forward=[self.initial.astype(dtype)]
        for z,p in zip(theta,self.perms):
            x=forward[-1]; forward.append((1-z)*x+z*self.permute(x,p))
        back=np.stack((self.pop,self.pop)).astype(dtype)
        value=np.sum(forward[-1]*back)-2*self.r
        grad=np.empty(len(self.ops),dtype=dtype)
        for j in range(len(self.ops)-1,-1,-1):
            x=forward[j]; p=self.perms[j]; z=theta[j]
            grad[j]=np.sum(back*(self.permute(x,p)-x))
            back=(1-z)*back+z*self.permute(back,p)
        return value,grad

    def round(self,theta):
        theta=np.asarray(theta); dtype=object if theta.dtype==object else np.float64
        back=[None]*(len(self.ops)+1)
        back[-1]=np.stack((self.pop,self.pop)).astype(dtype)
        for j in range(len(self.ops)-1,-1,-1):
            z=theta[j]; y=back[j+1]
            back[j]=(1-z)*y+z*self.permute(y,self.perms[j])
        x=self.initial.astype(dtype); bits=[]
        for j,p in enumerate(self.perms):
            xp=self.permute(x,p)
            diff=np.sum(back[j+1]*(xp-x))
            bit=int(diff<0); bits.append(bit)
            if bit: x=xp
        return bits


def rank_one_gates(controls,targets,orientation):
    controls=[int(x) for x in controls]; targets=[int(x) for x in targets]
    if not controls or not targets: raise ValueError('Nonzero rank-one factors required')
    if set(controls)&set(targets): raise ValueError('Control/target sets must be disjoint')
    if orientation=='source':
        pivot=controls[0]; prep=[(c,pivot) for c in controls[1:]]
        return prep+[(pivot,t) for t in targets]+list(reversed(prep))
    if orientation=='target':
        pivot=targets[0]; prep=[(pivot,t) for t in targets[1:]]
        return prep+[(c,pivot) for c in controls]+list(reversed(prep))
    raise ValueError('Bad orientation')


def factor_gates(u,v,source_wires,target_wires,orientation):
    gates=[]; macros=[]
    for j in range(v.shape[0]):
        controls=[source_wires[c] for c in np.flatnonzero(v[j])]
        targets=[target_wires[t] for t in np.flatnonzero(u[:,j])]
        block=rank_one_gates(controls,targets,orientation)
        gates+=block
        macros.append({'controls':controls,'targets':targets,'orientation':orientation,'count':len(block)})
    return gates,macros


def compile_shear(b,source_wires,target_wires,*,restarts,maxiter,seed,max_rank):
    b=binary_matrix(b); u,v=rank_factor(b); r=v.shape[0]
    direct=[(source_wires[c],target_wires[t]) for t,c in zip(*np.nonzero(b))]
    identity=np.eye(r,dtype=np.uint8)
    record={'shape':list(b.shape),'rank':r,'direct_count':len(direct),'trials':[],
            'original_U':u.tolist(),'original_V':v.tolist(),'source_wires':source_wires,'target_wires':target_wires}
    best={'gates':direct,'count':len(direct),'method':'direct','macros':[],'basis_R':identity.tolist()}
    if r==0:
        record.update(best); record.update(base_factor_count=0,optimized_factor_count=0,latent_parameters=0)
        return record
    base=[]
    for orientation in ('source','target'):
        g,m=factor_gates(u,v,source_wires,target_wires,orientation)
        base.append(len(g))
        if len(g)<best['count']:
            best={'gates':g,'count':len(g),'method':'rank_factor_identity_'+orientation,'macros':m,'basis_R':identity.tolist()}
    record['base_factor_count']=min(base)
    record['baseline_count']=min(min(base),len(direct))
    if r>max_rank:
        record.update(best); record.update(optimized_factor_count=min(base),latent_parameters=0,
                     optimization_skipped=f'rank {r} exceeds configured limit {max_rank}')
        return record
    ops=universal_basis_template(r); K=len(ops)
    record.update(latent_parameters=K,message_states=1<<r,latent_template=ops)
    rng=np.random.default_rng(seed); optimized_factor=min(base)
    if K:
        from scipy.optimize import minimize
        for orientation in ('source','target'):
            act=BasisAction(u,v,ops,orientation)
            starts=[np.zeros(K)]
            starts += [rng.beta(.4,.4,size=K) for _ in range(restarts)]
            for restart,start in enumerate(starts):
                value0,_=act.value_gradient(start)
                if maxiter>0:
                    res=minimize(act.value_gradient,start,jac=True,method='L-BFGS-B',
                        bounds=[(0.,1.)]*K,options={'maxiter':maxiter,'ftol':1e-12,'gtol':1e-7,'maxls':30})
                    theta=np.clip(res.x,0,1); nfev=int(res.nfev); message=str(res.message)
                else:
                    theta=start; nfev=1; message='rounding-only control'
                continuous,_=act.value_gradient(theta)
                bits=act.round(theta)
                ur,vr,R=apply_basis(u,v,ops,bits)
                if not np.array_equal((ur@vr)&1,b): raise AssertionError('Changed target factorization')
                g,m=factor_gates(ur,vr,source_wires,target_wires,orientation)
                objective_count=int((2*int(vr.sum())+int(ur.sum())-2*r) if orientation=='source'
                                    else (int(vr.sum())+2*int(ur.sum())-2*r))
                if len(g)!=objective_count: raise AssertionError('Physical cost mismatch')
                if len(g)>float(continuous)+1e-6: raise ArithmeticError('Rounding increased objective beyond tolerance')
                optimized_factor=min(optimized_factor,len(g))
                record['trials'].append({'orientation':orientation,'restart':restart,
                    'initial_action':float(value0),'continuous_action':float(continuous),
                    'rounded_count':len(g),'evaluations':nfev,'optimizer_message':message,
                    'bits':bits,'basis_R':R.tolist()})
                if len(g)<best['count']:
                    best={'gates':g,'count':len(g),'method':'variational_basis_'+orientation,'macros':m,
                          'basis_R':R.tolist(),'selected_U':ur.tolist(),'selected_V':vr.tolist()}
    record.update(best); record['optimized_factor_count']=optimized_factor
    return record


def infer_layers(M):
    M=binary_matrix(M,square=True); n=len(M)
    if not np.all(np.diag(M)==1): raise UnsupportedMatrix('This prototype requires unit diagonal')
    off=M^np.eye(n,dtype=np.uint8)
    indeg=off.sum(axis=1).astype(int); level=np.zeros(n,dtype=int)
    queue=[i for i in range(n) if indeg[i]==0]; seen=0
    for u in queue:
        seen+=1
        for v in np.flatnonzero(off[:,u]):
            v=int(v); level[v]=max(level[v],level[u]+1); indeg[v]-=1
            if indeg[v]==0: queue.append(v)
    if seen!=n: raise UnsupportedMatrix('Support of M-I contains a directed cycle')
    if n and level.max()>2: raise UnsupportedMatrix('Support depth exceeds two; not supported in this prototype')
    groups=[[int(i) for i in np.flatnonzero(level==k)] for k in (0,1,2)]
    return groups


def synthesize(matrix,*,restarts=3,maxiter=80,seed=1600,max_rank=10):
    """Compile a supported matrix. This is best-found, not minimum certification."""
    if restarts<0 or maxiter<0 or not(1<=max_rank<=16): raise ValueError('Invalid resource limits')
    t0=time.perf_counter(); M=binary_matrix(matrix,square=True); n=len(M)
    if n<1: raise ValueError('At least one wire required')
    P,F,Q=infer_layers(M)
    A=M[np.ix_(F,P)]; C=M[np.ix_(Q,F)]; B=M[np.ix_(Q,P)]
    cache={}; ids=0
    def get(block,src,tgt):
        nonlocal ids
        key=(tuple(src),tuple(tgt),block.tobytes())
        if key not in cache:
            ids+=1
            cache[key]=compile_shear(block,src,tgt,restarts=restarts,maxiter=maxiter,
                                    seed=seed+1009*ids,max_rank=max_rank)
        return cache[key]
    arec=get(A,P,F); crec=get(C,F,Q)
    choices=[]
    for order,central in [('C_then_A',B),('A_then_C',B^((C@A)&1))]:
        brec=get(central,P,Q)
        seq=[crec,arec,brec] if order=='C_then_A' else [arec,crec,brec]
        gates=[tuple(g) for rec in seq for g in rec['gates']]
        if not np.array_equal(circuit_matrix(n,gates),M): raise AssertionError('Final full matrix mismatch')
        choices.append({'order':order,'count':len(gates),'gates':gates,
             'component_methods':[rec['method'] for rec in seq],
             'component_counts':[rec['count'] for rec in seq],
             'central_matrix':central.tolist(),
             'no_basis_optimization_count':sum(rec.get('baseline_count',rec['count']) for rec in seq)})
    chosen=min(choices,key=lambda x:x['count'])
    source_hash=hashlib.sha256(M.tobytes()).hexdigest()
    return {'n':n,'matrix_sha256':source_hash,'input_fields':['matrix'],
        'status':'verified_best_found_in_documented_macro_family_not_global_minimum',
        'count':chosen['count'],'gates':chosen['gates'],'selected_order':chosen['order'],
        'groups':{'P':P,'F':F,'Q':Q},'choices':choices,'blocks':list(cache.values()),
        'no_basis_optimization_count':min(x['no_basis_optimization_count'] for x in choices),
        'direct_block_count':int(A.sum()+C.sum()+B.sum()),
        'max_rank':max((x['rank'] for x in cache.values()),default=0),
        'seconds':time.perf_counter()-t0,'seed':seed,
        'config':{'restarts':restarts,'maxiter':maxiter,'max_rank':max_rank},
        'matrix_differences':int(np.count_nonzero(circuit_matrix(n,chosen['gates'])^M))}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('matrix_json',type=Path)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--restarts',type=int,default=3)
    parser.add_argument('--maxiter',type=int,default=80)
    parser.add_argument('--seed',type=int,default=1600)
    parser.add_argument('--max-rank',type=int,default=10)
    a=parser.parse_args()
    raw=json.loads(a.matrix_json.read_text())
    matrix=raw['matrix'] if isinstance(raw,dict) else raw
    result=synthesize(matrix,restarts=a.restarts,maxiter=a.maxiter,seed=a.seed,max_rank=a.max_rank)
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(result,indent=2))
    print(json.dumps({k:result[k] for k in ('n','count','no_basis_optimization_count','matrix_differences','seconds')}))

if __name__=='__main__': main()
