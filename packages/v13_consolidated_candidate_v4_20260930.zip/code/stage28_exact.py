"""Exact short-window CNOT resynthesis, independent of Hamming search.

Only accepts strict improvements and verifies the full binary matrix. The
search covers contiguous windows of up to four gates, with replacements of
up to three gates. It does not claim stage 28's noncontiguous completeness.
"""

from __future__ import annotations

import argparse
import json
from functools import lru_cache
from pathlib import Path

import hashlib

Gate = tuple[int, int]


def matrix_from_gates(n: int, gates: list[Gate]) -> list[int]:
    rows = [1 << i for i in range(n)]
    for c, t in gates:
        rows[t] ^= rows[c]
    return rows


def _commute(a: Gate, b: Gate) -> bool:
    return a[1] != b[0] and b[1] != a[0]


def cancel_commuting_pairs(gates: list[Gate]) -> list[Gate]:
    out = []
    for gate in gates:
        match = next((i for i in range(len(out) - 1, -1, -1) if out[i] == gate), None)
        if match is not None and all(_commute(gate, other) for other in out[match + 1:]):
            del out[match]
        else:
            out.append(gate)
    return out


def matrix_sha256(rows: list[int]) -> str:
    n = len(rows)
    width = (n + 7) // 8
    payload = n.to_bytes(4, "big") + b"".join(row.to_bytes(width, "little") for row in rows)
    return hashlib.sha256(payload).hexdigest()


def rank_difference(rows: tuple[int, ...]) -> int:
    work = [row ^ (1 << i) for i, row in enumerate(rows)]
    n = len(rows)
    rank = 0
    for col in range(n):
        pivot = next((i for i in range(rank, n) if (work[i] >> col) & 1), None)
        if pivot is None:
            continue
        work[rank], work[pivot] = work[pivot], work[rank]
        for i in range(rank + 1, n):
            if (work[i] >> col) & 1:
                work[i] ^= work[rank]
        rank += 1
    return rank


@lru_cache(maxsize=8)
def atlas(n: int) -> dict[tuple[int, ...], tuple[Gate, ...]]:
    """All distinct local matrices reachable in at most three CNOTs."""
    identity = tuple(1 << i for i in range(n))
    table = {identity: ()}
    frontier = [identity]
    pairs = [(c, t) for c in range(n) for t in range(n) if c != t]
    for _ in range(3):
        next_frontier = []
        for matrix in frontier:
            prefix = table[matrix]
            for c, t in pairs:
                changed = list(matrix)
                changed[t] ^= changed[c]
                key = tuple(changed)
                if key not in table:
                    table[key] = prefix + ((c, t),)
                    next_frontier.append(key)
        frontier = next_frontier
    return table


def improve(gates: list[Gate], n: int) -> tuple[list[Gate], dict]:
    original = matrix_from_gates(n, gates)
    out = cancel_commuting_pairs(gates)
    replacements = 0
    while True:
        found = False
        for length in (4, 3, 2):
            for start in range(len(out) - length + 1):
                old = out[start:start + length]
                wires = sorted({wire for gate in old for wire in gate})
                local = {wire: i for i, wire in enumerate(wires)}
                normalized = [(local[c], local[t]) for c, t in old]
                target = tuple(matrix_from_gates(len(wires), normalized))
                if rank_difference(target) >= length:
                    continue
                replacement = atlas(len(wires)).get(target)
                if replacement is None or len(replacement) >= length:
                    continue
                actual = [(wires[c], wires[t]) for c, t in replacement]
                candidate = cancel_commuting_pairs(out[:start] + actual + out[start + length:])
                if len(candidate) >= len(out):
                    continue
                if matrix_from_gates(n, candidate) != original:
                    raise AssertionError("full matrix changed")
                out = candidate
                replacements += 1
                found = True
                break
            if found:
                break
        if not found:
            break
    if matrix_from_gates(n, out) != original:
        raise AssertionError("final full matrix changed")
    return out, {"before": len(gates), "after": len(out), "replacements": replacements,
                 "target_sha256": matrix_sha256(original), "verified": True}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="solver result JSON (or EA record with a result field)")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    raw = json.loads(args.input.read_text(encoding="utf-8"))
    result = raw.get("result", raw)
    n = result["n"]
    optimized, stats = improve([tuple(g) for g in result["gates"]], n)
    output = {"n": n, "gates": [list(g) for g in optimized], "count": len(optimized),
              "source": str(args.input), "stage28_local": stats}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(stats))


if __name__ == "__main__":
    main()
