import unittest
import numpy as np
from shared_synth import synthesize
from stage16_reference import circuit_matrix
class Contract(unittest.TestCase):
    def test_matrix_only_shared_basis(self):
        M=np.eye(10,dtype=np.uint8); M[5:,:5]=1
        result=synthesize(M,seed=17,restarts=1,width=4,maxiter=30,sweeps=2)
        self.assertTrue(np.array_equal(circuit_matrix(10,result['gates']),M),'full binary matrix must match')
        self.assertLessEqual(result['count'],13,'shared parity must beat 25 direct transfers')
        self.assertEqual(result['count'],len(result['gates']))
if __name__=='__main__':unittest.main()
