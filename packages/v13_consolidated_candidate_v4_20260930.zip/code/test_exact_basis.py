import unittest

import numpy as np

from exact_basis import atlas, optimize
from shared_synth import _apply_vectors, compile_shear
from stage16_reference import circuit_matrix


class ExactBasisTests(unittest.TestCase):
    def test_atlas_has_all_gl4_bases(self):
        self.assertEqual(len(atlas(4, "source")[0]), 20160)
        self.assertEqual(len(atlas(4, "target")[0]), 20160)

    def test_exact_price_matches_physical_word_on_both_sides(self):
        block = np.array([[1, 1, 1, 0], [1, 0, 1, 1], [0, 1, 0, 1]], dtype=np.uint8)
        for side in ("source", "target"):
            vectors = block if side == "source" else block.T
            word, cost = optimize(vectors, side)
            out, gates = _apply_vectors(vectors, [("add", c, t) for c, t in word],
                                        [1] * len(word), side)
            self.assertEqual(cost, 2 * len(gates) + int(out.sum()))
            self.assertLessEqual(cost, int(vectors.sum()))

    def test_compiled_shear_preserves_complete_matrix(self):
        block = np.array([[1, 1, 1], [1, 0, 1], [0, 1, 1]], dtype=np.uint8)
        result = compile_shear(block, [0, 1, 2], [3, 4, 5], exact_local=True)
        expected = np.eye(6, dtype=np.uint8)
        expected[np.ix_([3, 4, 5], [0, 1, 2])] = block
        np.testing.assert_array_equal(circuit_matrix(6, result["gates"]), expected)

    def test_wide_block_uses_gradient_fallback(self):
        block = np.random.default_rng(4).integers(0, 2, size=(6, 6), dtype=np.uint8)
        result = compile_shear(block, list(range(6)), list(range(6, 12)),
                               width=6, restarts=0, maxiter=5, sweeps=1,
                               exact_local=True)
        expected = np.eye(12, dtype=np.uint8)
        expected[np.ix_(range(6, 12), range(6))] = block
        np.testing.assert_array_equal(circuit_matrix(12, result["gates"]), expected)
        self.assertGreater(result["action_evaluations"], 0)


if __name__ == "__main__":
    unittest.main()
