import unittest

import numpy as np

from general_macro import (_cancel_adjacent, _prefix_cancellation,
                           _improve_macro_order, compile_general, gaussian_word)
from defect_repair import improve as repair_defect
from shared_synth import compile_shear
from stage16_reference import circuit_matrix


class GeneralMacroTests(unittest.TestCase):
    def test_general_route_preserves_random_invertible_targets(self):
        rng = np.random.default_rng(431)
        for n in range(2, 8):
            gates = [(int(c), int(t)) for c, t in
                     (rng.choice(n, size=2, replace=False) for _ in range(2 * n + 3))]
            matrix = circuit_matrix(n, gates)
            result = compile_general(matrix, compile_shear, width=4,
                                     restarts=0, maxiter=0, sweeps=1,
                                     exact_local=True)
            np.testing.assert_array_equal(circuit_matrix(n, result["gates"]), matrix)
            self.assertLessEqual(result["count"], result["gaussian_count"])

    def test_basis_preparation_carries_across_adjacent_macros(self):
        prep = [(0, 1), (1, 2)]
        core_a = [(2, 3)]
        core_b = [(2, 4)]
        separate = prep + core_a + prep[::-1] + prep + core_b + prep[::-1]
        carried = _cancel_adjacent(separate)
        self.assertEqual(_prefix_cancellation(prep, prep), 4)
        self.assertEqual(len(separate) - len(carried), 4)
        np.testing.assert_array_equal(circuit_matrix(5, separate), circuit_matrix(5, carried))

    def test_noncontiguous_defect_repair_preserves_operator(self):
        gates = [(0, 1), (2, 3), (0, 1), (1, 2), (2, 3)]
        repaired, stats = repair_defect(gates, 4, time_limit=1.0)
        self.assertLess(len(repaired), len(gates))
        self.assertTrue(stats["verified_full_matrix"])
        np.testing.assert_array_equal(circuit_matrix(4, repaired), circuit_matrix(4, gates))

    def test_commuting_order_exposes_shared_basis(self):
        prep = [(0, 1), (1, 2)]
        a = {"gates": prep + [(2, 3)] + prep[::-1], "preparation": prep}
        unrelated = {"gates": [(5, 6)], "preparation": []}
        b = {"gates": prep + [(2, 4)] + prep[::-1], "preparation": prep}
        before = a["gates"] + unrelated["gates"] + b["gates"]
        order, after, swaps = _improve_macro_order([a, unrelated, b])
        self.assertLess(len(after), len(before))
        self.assertGreater(swaps, 0)
        np.testing.assert_array_equal(circuit_matrix(7, before), circuit_matrix(7, after))


if __name__ == "__main__":
    unittest.main()
