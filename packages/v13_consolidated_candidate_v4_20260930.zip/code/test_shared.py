"""Tests defined before implementation: exact expectations, gradients, lifting."""
import itertools, unittest
from fractions import Fraction as F
import numpy as np
import shared_synth as ns
import stage16_reference as old


def independent_matrix(n,gates):
    out=np.zeros((n,n),np.uint8)
    for j in range(n):
        x=[int(i==j) for i in range(n)]
        for c,t in gates:x[t]^=x[c]
        out[:,j]=x
    return out


def brute_action(vectors,ops,bits,side):
    v=np.array(vectors,np.uint8).copy();cost=0
    for (kind,c,t),bit in zip(ops,bits):
        if not bit:continue
        cost+=2*(1 if kind=='add' else 3)
        if kind=='swap':v[:,[c,t]]=v[:,[t,c]]
        elif side=='source':v[:,c]^=v[:,t]
        else:v[:,t]^=v[:,c]
    return cost+int(v.sum())

class SharedTests(unittest.TestCase):
    def test_exact_action_gradient_and_rounding(self):
        rng=np.random.default_rng(17001)
        for side in ['source','target']:
            for z in range(20):
                w=3;vectors=rng.integers(0,2,(5,w),dtype=np.uint8)
                ops=[('add',0,1),('swap',1,2),('add',2,0),('add',1,0)]
                probs=np.array([F(int(x),7) for x in rng.integers(0,8,4)],dtype=object)
                act=ns.SharedAction(vectors,ops,side=side)
                val,grad=act.value_gradient(probs)
                ev=F(0);gd=[F(0)]*len(ops)
                for bits in itertools.product([0,1],repeat=4):
                    cost=brute_action(vectors,ops,bits,side)
                    p=F(1)
                    for b,t in zip(bits,probs):p*=t if b else 1-t
                    ev+=p*cost
                    for j in range(4):
                        p=F(1 if bits[j] else -1)
                        for k in range(4):
                            if k!=j:p*=probs[k] if bits[k] else 1-probs[k]
                        gd[j]+=p*cost
                self.assertEqual(val,ev)
                self.assertEqual(list(grad),gd)
                bits=act.round(probs)
                self.assertLessEqual(brute_action(vectors,ops,bits,side),ev)

    def test_shared_shear_arbitrary_inputs(self):
        rng=np.random.default_rng(17002)
        for q,p in [(1,1),(3,4),(4,3),(5,5),(6,8)]:
            for rep in range(3):
                b=rng.integers(0,2,(q,p),dtype=np.uint8)
                src=list(range(p));tgt=list(range(p,p+q))
                result=ns.compile_shear(b,src,tgt,width=3,restarts=0,maxiter=15,sweeps=2,seed=rep)
                expected=np.eye(p+q,dtype=np.uint8);expected[p:,:p]=b
                self.assertTrue(np.array_equal(independent_matrix(p+q,result['gates']),expected))
                self.assertEqual(result['count'],2*len(result['preparation'])+int(np.array(result['core']).sum()))
                self.assertLessEqual(result['count'],int(b.sum()))

    def test_macro_orders_and_disjoint_wires(self):
        rng=np.random.default_rng(17003)
        for rep in range(5):
            n=9;P,Fw,Q=[0,3,5],[1,7],[2,4,6,8]
            m=np.eye(n,dtype=np.uint8)
            for src,tgt in [(P,Fw),(Fw,Q),(P,Q)]:
                m[np.ix_(tgt,src)]=rng.integers(0,2,(len(tgt),len(src)),dtype=np.uint8)
            r=ns.synthesize(m,width=3,restarts=0,maxiter=10,sweeps=1,seed=rep)
            for choice in r['choices']:
                self.assertTrue(np.array_equal(independent_matrix(n,choice['gates']),m))
        self.assertLessEqual(r['count'],min(c['count'] for c in r['choices']))

    def test_row_col_noncommutativity_and_order(self):
        b=np.array([[1,1,0],[1,0,1],[0,1,1]],np.uint8)
        ops=[('source',0,1),('target',1,2),('source',2,0)]
        D=b.copy();S=np.eye(3,dtype=np.uint8);T=S.copy();prep=[]
        for side,c,t in ops:
            if side=='source':S[t]^=S[c];D[:,c]^=D[:,t];prep.append((c,t))
            else:T[t]^=T[c];D[t]^=D[c];prep.append((3+c,3+t))
        core=[(int(c),int(3+t)) for t,c in zip(*np.nonzero(D))]
        expected=np.eye(6,dtype=np.uint8);expected[3:,:3]=b
        self.assertTrue(np.array_equal(independent_matrix(6,prep+core+prep[::-1]),expected))
        wrong=independent_matrix(6,prep+core)
        self.assertFalse(np.array_equal(wrong,expected),'uncomputation must not be dropped')
        self.assertTrue(np.array_equal((T@b@old.inverse(S))&1,D))

    def test_fusion_needs_ordered_CA_term(self):
        a=np.eye(3,dtype=np.uint8); a[1,0]=1; a[2,1]=1
        correct=independent_matrix(3,[(1,2),(0,1)])
        wrong=independent_matrix(3,[(0,1),(1,2)])
        self.assertTrue(np.array_equal(correct,a))
        self.assertFalse(np.array_equal(wrong,a))
        r=ns.synthesize(a,width=3,restarts=0,maxiter=0,sweeps=1)
        for choice in r['choices']:
            self.assertTrue(np.array_equal(independent_matrix(3,choice['gates']),a))

    def test_paid_swap_is_six_not_zero(self):
        v=np.array([[1,0],[0,1],[1,1]],dtype=np.uint8)
        action=ns.SharedAction(v,[('swap',0,1)],side='source')
        a0,_=action.value_gradient(np.array([F(0)],dtype=object))
        a1,_=action.value_gradient(np.array([F(1)],dtype=object))
        self.assertEqual(a1-a0,6)
        self.assertEqual(action.round(np.array([F(1,2)],dtype=object)),[0])

    def test_fractional_action_is_mean_of_correct_programs(self):
        B=np.array([[1,1,1],[0,1,1],[1,0,1]],dtype=np.uint8)
        expected=np.eye(6,dtype=np.uint8);expected[3:,:3]=B
        for bits in itertools.product([0,1],repeat=4):
            core=B.copy();prep=[]
            for bit,(side,c,t) in zip(bits,[('source',0,1),('target',1,2),('source',2,0),('target',0,1)]):
                if not bit:continue
                if side=='source':core[:,c]^=core[:,t];prep.append((c,t))
                else:core[t]^=core[c];prep.append((3+c,3+t))
            middle=[(int(c),int(3+t)) for t,c in zip(*np.nonzero(core))]
            self.assertTrue(np.array_equal(independent_matrix(6,prep+middle+prep[::-1]),expected))

    def test_unsupported_and_identity(self):
        swap=np.array([[0,1],[1,0]],dtype=np.uint8)
        swap_result=ns.synthesize(swap)
        self.assertTrue(np.array_equal(independent_matrix(2,swap_result['gates']),swap))
        for m in [[[1,1],[1,1]], [[1,0],[2,1]]]:
            with self.assertRaises(ValueError):ns.synthesize(m)
        result=ns.synthesize(np.eye(5,dtype=np.uint8),width=3,restarts=0)
        self.assertEqual(result['gates'],[])
        self.assertEqual(result['count'],0)
        with self.assertRaises(ValueError):
            ns.compile_shear(np.ones((2,2),dtype=np.uint8),[0,1],[1,2])

if __name__=='__main__':unittest.main(verbosity=2)
