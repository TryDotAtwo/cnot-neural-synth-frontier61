import unittest

import numpy as np

from forest_exact import exact_forest_program
from shared_synth import synthesize
from stage16_reference import circuit_matrix


class Stage23Integration(unittest.TestCase):
    def test_exact_forest_bypasses_stage17_depth_limit(self):
        gates = [(0, 1), (1, 2), (2, 3), (3, 4), (1, 5)]
        matrix = circuit_matrix(6, gates)
        result = synthesize(matrix, maxiter=0)
        self.assertEqual(result["status"], "verified_globally_optimal_forest_family")
        self.assertEqual(result["count"], 5)
        self.assertEqual(result["lower_bound"], 5)
        np.testing.assert_array_equal(circuit_matrix(6, result["gates"]), matrix)

    def test_cycle_or_multiple_parents_rejected(self):
        matrix = circuit_matrix(3, [(0, 1), (1, 0)])
        self.assertIsNone(exact_forest_program(matrix))


if __name__ == "__main__":
    unittest.main()
