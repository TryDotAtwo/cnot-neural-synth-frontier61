"""Own full-matrix synthesis reference, schema v3."""
