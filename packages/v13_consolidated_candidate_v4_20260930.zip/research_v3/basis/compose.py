"""Composition of full physical operators, with adjacent inverse cancellation."""
from ..contracts import MatrixState, WordCertificate
from ..words import apply, verify_word


def cancel_adjacent(word):
    stack = []
    for gate in word:
        if stack and stack[-1] == gate:
            stack.pop()
        else:
            stack.append(gate)
    return tuple(stack)


def compose_blocks(blocks, alphabet, start=None):
    origin = MatrixState.identity(alphabet) if start is None else start
    endpoint = origin
    full_word = []
    for block in blocks:
        certificate = block.certificate
        verify_word(certificate, alphabet)
        if certificate.start != MatrixState.identity(alphabet):
            raise ValueError('block must specify its full encoder operator')
        for gate in certificate.gates:
            endpoint = apply(endpoint, gate, alphabet)
        full_word.extend(certificate.gates)
    shortened = cancel_adjacent(full_word)
    cert = WordCertificate(origin, endpoint, shortened, sum(alphabet.cost(g) for g in shortened),
                           'paid_block_composition_v1', 'composition')
    verify_word(cert, alphabet)
    return cert
