"""Physical frame bookkeeping; restoration is always a real paid word."""
from dataclasses import dataclass
from ..contracts import WordCertificate
from ..words import apply, verify_word


@dataclass(frozen=True)
class FrameState:
    origin: object
    physical_matrix: object
    frame_words: tuple
    pending_restoration: tuple


def open_frame(start, preparation, core, alphabet):
    executed = tuple(preparation) + tuple(core)
    state = start
    for gate in executed:
        state = apply(state, gate, alphabet)
    return FrameState(start, state, executed, tuple(reversed(preparation)))


def materialize(frame, alphabet):
    current = frame.origin
    for gate in frame.frame_words:
        current = apply(current, gate, alphabet)
    if current != frame.physical_matrix:
        raise ValueError('frame physical endpoint mismatch')
    for gate in frame.pending_restoration:
        current = apply(current, gate, alphabet)
    word = frame.frame_words + frame.pending_restoration
    cert = WordCertificate(frame.origin, current, word, sum(alphabet.cost(g) for g in word),
                           'paid_frame_materialization_v1', 'frame')
    verify_word(cert, alphabet)
    return cert
