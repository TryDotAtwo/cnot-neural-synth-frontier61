"""Explicit first-order paid-cost training for the own basis proposal head."""
import torch
from torch import nn
from .proposal import BasisProposal,differentiable_J
from .wide import estimate_mc
from ..contracts import MatrixBatch
from .templates import binary_block


def differentiable_mc_cost(template,block,theta,*,samples,seed,max_evaluations,max_bytes):
    required=samples*(1+2*len(template.choices))
    if required>max_evaluations:
        raise RuntimeError('resource_limit: complete MC gradient exceeds evaluation budget')
    estimated=template.n*template.n*64+samples*(len(template.choices)+1)*8
    if estimated>max_bytes:
        raise MemoryError('resource_limit: MC workspace preflight')
    estimate=estimate_mc(template,block,theta.detach().cpu().numpy(),samples,seed)
    gradient=theta.new_tensor(estimate.gradient)
    # Unbiased first derivative at this theta. This does not define a valid Hessian.
    loss=theta.new_tensor(estimate.value)+((theta-theta.detach())*gradient).sum()
    return loss,{'physical_width':template.width,'samples':samples,'evaluations':estimate.evaluations,
                 'gradient_kind':'unbiased independent-Bernoulli conditional difference; first order only',
                 'gradient_se':None if estimate.gradient_se is None else estimate.gradient_se.tolist(),
                 'expected_paid_cost_estimate':estimate.value}


class BasisField(nn.Module):
    """New schema: preserves the value field and adds a trainable basis head."""
    def __init__(self,field,hidden=128):
        super().__init__()
        self.field=field
        parameter=next(field.parameters())
        self.proposer=BasisProposal(field.stem.d,hidden).to(device=parameter.device,dtype=parameter.dtype)
        self.config={'schema':'basis_fusion_field_v1','field':field.config,'basis_hidden':hidden}

    def forward(self,batch,packet):
        return self.field(batch,packet)

    def basis_loss(self,state,template,block,registry,policy,*,backend,samples=4,seed=0,
                   max_evaluations=1000,max_bytes=256*1024*1024,binding='full_shear'):
        if state.n!=template.n:
            raise ValueError('state/template width mismatch')
        checked=binary_block(template,block)
        if binding=='full_shear':
            expected=[1<<i for i in range(state.n)]
            for t,wire in enumerate(template.target_wires):
                for c,source in enumerate(template.source_wires):
                    expected[wire]^=int(checked[t,c])<<source
            if tuple(expected)!=state.packed_rows:
                raise ValueError('basis block is not bound to the full matrix')
        elif binding=='partial_elimination':
            from ..search.basis_macros import partial_shear
            parsed=partial_shear(state)
            if (parsed is None or parsed[0]!=template.source_wires or parsed[1]!=template.target_wires or
                    (parsed[2]!=checked).any()):
                raise ValueError('basis block is not bound to the partial elimination')
        else:
            raise ValueError('unsupported basis problem binding')
        device=next(self.parameters()).device
        encoded=self.field.encode(MatrixBatch.from_states((state,),device),registry.build((state,),policy))
        theta=self.proposer(encoded,template)
        if backend=='exact_messages':
            if max_evaluations<1:
                raise RuntimeError('resource_limit: exact contraction evaluation budget exhausted')
            loss=differentiable_J(template,block,theta,max_bytes=max_bytes)
            audit={'physical_width':template.width,'evaluations':1,'gradient_kind':'exact independent-Bernoulli contraction in floating arithmetic'}
        elif backend=='mc':
            loss,audit=differentiable_mc_cost(template,block,theta,samples=samples,seed=seed,
                                            max_evaluations=max_evaluations,max_bytes=max_bytes)
        else:
            raise NotImplementedError('basis learning backend not implemented')
        audit['theta']=theta.detach().cpu().tolist()
        audit['binding']=binding
        return loss,audit
