"""Stage17 one-sided independent-Bernoulli exact message contraction."""
from fractions import Fraction
import numpy as np
from .templates import binary_block


def messages(template, block, theta, max_bytes):
    b = binary_block(template, block)
    theta = np.asarray(theta)
    if theta.shape != (len(template.choices),) or any(not 0 <= value <= 1 for value in theta):
        raise ValueError('invalid probability vector')
    exact_rational = theta.dtype == object
    if exact_rational and any(not isinstance(value, (Fraction, int)) for value in theta):
        raise ValueError('object probabilities must be rational')
    if not exact_rational and not np.isfinite(theta).all():
        raise ValueError('nonfinite probability')
    width = template.width
    count = 1 << width
    # Rational numerators grow with K. This is a preallocation estimate; Python
    # object overhead is implementation dependent and reported separately later.
    item_bytes = 128 if exact_rational else 8
    estimate = count * (len(theta) + 6) * item_bytes
    if max_bytes is not None and estimate > max_bytes:
        raise MemoryError(f'exact message resource_limit: estimated {estimate} bytes > {max_bytes}')
    if width >= 63:
        raise MemoryError('exact message index space unsupported; use wide Monte Carlo backend')
    ids = np.arange(count, dtype=np.int64)
    vectors = b if template.side == 'source' else b.T
    codes = sum(vectors[:, j].astype(np.int64) << j for j in range(width))
    dtype = object if exact_rational else np.float64
    initial = np.bincount(codes, minlength=count).astype(dtype)
    pop = np.array([i.bit_count() for i in range(count)], dtype=dtype)
    permutations, prices = [], []
    for choice in template.choices:
        c, t = choice.control, choice.target
        if choice.kind == 'swap':
            bit = ((ids >> c) ^ (ids >> t)) & 1
            permutation = ids ^ (bit << c) ^ (bit << t)
        elif template.side == 'source':
            permutation = ids ^ (((ids >> t) & 1) << c)
        else:
            permutation = ids ^ (((ids >> c) & 1) << t)
        permutations.append(permutation)
        prices.append(2 * choice.cost)
    return theta, initial, pop, permutations, np.asarray(prices, dtype=dtype)


def evaluate_J(template, block, theta, max_bytes=256 * 1024 * 1024):
    theta, initial, pop, permutations, prices = messages(template, block, theta, max_bytes)
    forward = [initial]
    for probability, permutation in zip(theta, permutations):
        current = forward[-1]
        forward.append((1 - probability) * current + probability * current[permutation])
    backward = pop
    value = np.dot(forward[-1], pop) + np.dot(prices, theta)
    gradient = np.empty(len(theta), dtype=initial.dtype)
    for j in range(len(theta) - 1, -1, -1):
        permutation = permutations[j]
        gradient[j] = prices[j] + np.dot(backward, forward[j][permutation] - forward[j])
        backward = (1 - theta[j]) * backward + theta[j] * backward[permutation]
    return value, gradient
