"""Explicit-budget wide-block measurement, independent of historical targets."""
import argparse
from dataclasses import asdict
import json
from pathlib import Path
from time import perf_counter
import numpy as np
from .templates import BasisTemplate, BasisChoice
from .wide import WideBudget, optimize_wide


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    rows = []
    budget = WideBudget(updates=2, samples=4, evaluations=100, max_bytes=64 * 1024 * 1024)
    for width in (8, 16, 32):
        choices = tuple(BasisChoice('add', c, t) for c, t in ((0, 1), (width // 2, width // 2 + 1), (width - 2, width - 1)))
        template = BasisTemplate(2 * width, tuple(range(width)), tuple(range(width, 2 * width)), 'source', choices)
        block = np.ones((width, width), dtype=np.uint8)
        start = perf_counter()
        result = optimize_wide(block, template, (.5,) * len(choices), 'mc', budget, seed=1700)
        rows.append({'physical_width': width, 'n': 2 * width, 'choices': len(choices), 'budget': asdict(budget),
                     'status': result.status, 'seconds': perf_counter() - start, 'evaluations': result.evaluations,
                     'direct_cost': width * width, 'best_verified_cost': result.best.certificate.physical_cost,
                     'word': [(g.control, g.target) for g in result.best.certificate.gates], 'trace': result.trace})
    args.output.open('x', encoding='utf-8').write(json.dumps({'scope': 'synthetic repeated-parity blocks; 3 choices per width, no global-optimality claim', 'results': rows}, indent=2))
    print(json.dumps([{k: row[k] for k in ('physical_width', 'seconds', 'direct_cost', 'best_verified_cost', 'evaluations')} for row in rows]))


if __name__ == '__main__':
    main()
