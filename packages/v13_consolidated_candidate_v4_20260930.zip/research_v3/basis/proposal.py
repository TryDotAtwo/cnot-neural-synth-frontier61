import torch
from torch import nn
from .objective import messages


class BasisProposal(nn.Module):
    """Ordered physical template choices predicted from the full-state encoding."""
    def __init__(self, d, hidden=128):
        super().__init__()
        self.network = nn.Sequential(nn.Linear(4 * d + 4, hidden), nn.GELU(), nn.Linear(hidden, 1))

    def forward(self, encoded, template, batch_index=0):
        wire = encoded.wire[batch_index]
        if wire.shape[0] < template.n or not encoded.valid[batch_index, :template.n].all():
            raise ValueError('template references absent physical wires')
        source = wire[list(template.source_wires)].mean(0)
        target = wire[list(template.target_wires)].mean(0)
        inputs = []
        for j, choice in enumerate(template.choices):
            c, t = template.group_wires[choice.control], template.group_wires[choice.target]
            metadata = wire.new_tensor([choice.cost, int(template.side == 'target'),
                                        j / max(1, len(template.choices)), len(template.choices)])
            inputs.append(torch.cat((wire[c], wire[t], source, target, metadata)))
        if not inputs:
            return wire.new_empty((0,))
        return self.network(torch.stack(inputs)).squeeze(-1).sigmoid()


def differentiable_J(template, block, theta, max_bytes=256 * 1024 * 1024):
    _, initial, pop, permutations, prices = messages(template, block, theta.detach().cpu().numpy(), max_bytes)
    distribution = theta.new_tensor(initial)
    for probability, permutation in zip(theta, permutations):
        index = torch.tensor(permutation, dtype=torch.long, device=theta.device)
        distribution = (1 - probability) * distribution + probability * distribution[index]
    return distribution @ theta.new_tensor(pop) + theta @ theta.new_tensor(prices)
