from .objective import evaluate_J
from .templates import compile_basis
from fractions import Fraction


def conditional_round(template, block, theta, max_bytes=256 * 1024 * 1024):
    # Reference coordinate conditioning. Repeated contractions deliberately cost
    # O(K^2 2^w); no linear-time rounding claim is made for this implementation.
    point = list(theta)
    initial, _ = evaluate_J(template, block, point, max_bytes)
    for j in range(len(point)):
        zero, one = point.copy(), point.copy()
        zero[j], one[j] = 0, 1
        a, _ = evaluate_J(template, block, zero, max_bytes)
        b, _ = evaluate_J(template, block, one, max_bytes)
        point[j] = int(b < a)
    candidate = compile_basis(template, block, tuple(int(x) for x in point))
    tolerance = 0 if isinstance(initial, Fraction) else 1e-10 * max(1, abs(float(initial)))
    if candidate.certificate.physical_cost > initial + tolerance:
        raise ArithmeticError('rounded integer cost exceeds expectation')
    return candidate
