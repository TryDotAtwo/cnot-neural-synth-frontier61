from dataclasses import dataclass
import numpy as np
from ..contracts import AlphabetSpec, Gate, MatrixState, WordCertificate
from ..words import verify_word


@dataclass(frozen=True)
class BasisChoice:
    kind: str
    control: int
    target: int

    @property
    def cost(self):
        return 1 if self.kind == 'add' else 3


@dataclass(frozen=True)
class BasisTemplate:
    n: int
    source_wires: tuple
    target_wires: tuple
    side: str
    choices: tuple[BasisChoice, ...]
    frozen_frame: tuple = ()

    def __post_init__(self):
        wires = self.source_wires + self.target_wires
        if self.side not in ('source', 'target') or len(set(wires)) != len(wires):
            raise ValueError('invalid side or overlapping wires')
        if any(type(i) is not int or not 0 <= i < self.n for i in wires):
            raise ValueError('invalid physical wire')
        if not self.source_wires or not self.target_wires:
            raise ValueError('empty shear block')
        if self.frozen_frame:
            raise NotImplementedError('nonidentity frozen frames require the composition adapter')
        for choice in self.choices:
            if (choice.kind not in ('add', 'swap') or choice.control == choice.target or
                any(type(i) is not int or not 0 <= i < self.width for i in (choice.control, choice.target))):
                raise ValueError('invalid local choice')

    @property
    def group_wires(self):
        return self.source_wires if self.side == 'source' else self.target_wires

    @property
    def width(self):
        return len(self.group_wires)


@dataclass(frozen=True)
class BasisCandidate:
    certificate: WordCertificate
    preparation: tuple
    core: tuple
    bits: tuple
    transformed_block: tuple


def binary_block(template, block):
    b = np.asarray(block)
    if b.shape != (len(template.target_wires), len(template.source_wires)) or not np.isin(b, (0, 1)).all():
        raise ValueError('invalid binary shear block')
    return b.astype(np.uint8)


def compile_basis(template, block, bits):
    if len(bits) != len(template.choices) or any(bit not in (0, 1) for bit in bits):
        raise ValueError('invalid template assignment')
    original = binary_block(template, block)
    d = original.copy()
    preparation = []
    for choice, bit in zip(template.choices, bits):
        if not bit:
            continue
        c, t = choice.control, choice.target
        physical_c, physical_t = template.group_wires[c], template.group_wires[t]
        if choice.kind == 'swap':
            if template.side == 'source':
                d[:, [c, t]] = d[:, [t, c]]
            else:
                d[[c, t]] = d[[t, c]]
            preparation.extend((Gate(physical_c, physical_t), Gate(physical_t, physical_c), Gate(physical_c, physical_t)))
        else:
            if template.side == 'source':
                d[:, c] ^= d[:, t]
            else:
                d[t] ^= d[c]
            preparation.append(Gate(physical_c, physical_t))
    core = tuple(Gate(template.source_wires[c], template.target_wires[t]) for t, c in zip(*np.nonzero(d)))
    word = tuple(preparation) + core + tuple(reversed(preparation))
    rows = [1 << i for i in range(template.n)]
    for t, c in zip(*np.nonzero(original)):
        rows[template.target_wires[t]] ^= 1 << template.source_wires[c]
    alphabet = AlphabetSpec.all_to_all(template.n)
    certificate = WordCertificate(MatrixState.identity(alphabet), MatrixState(template.n, tuple(rows), alphabet.id),
                                  word, len(word), 'own_J17_template_v1', 'basis_template')
    verify_word(certificate, alphabet)
    return BasisCandidate(certificate, tuple(preparation), core, tuple(bits), tuple(tuple(int(x) for x in row) for row in d))
