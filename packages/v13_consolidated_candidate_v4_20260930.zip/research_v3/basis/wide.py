"""Wide independent-choice optimization with explicit sampling/resource budgets."""
from dataclasses import dataclass
import numpy as np
from .templates import compile_basis
from .objective import evaluate_J


@dataclass(frozen=True)
class WideBudget:
    updates: int
    samples: int
    evaluations: int
    max_bytes: int

    def __post_init__(self):
        if any(type(x) is not int or x < 0 for x in (self.updates, self.samples, self.evaluations, self.max_bytes)):
            raise ValueError('budgets must be nonnegative integers')
        if self.samples < 1:
            raise ValueError('positive sample count required')


@dataclass
class MCEstimate:
    value: float
    gradient: np.ndarray
    gradient_se: object
    value_se: float | None
    samples: int
    evaluations: int
    semantics: str = 'unbiased independent-Bernoulli coordinate paired differences of paid cost'


@dataclass
class WideResult:
    status: str
    physical_width: int
    best: object
    theta: tuple
    evaluations: int
    trace: list
    backend: str


def coordinate_gradient_sample(template, block, bits):
    gradient = []
    for j in range(len(template.choices)):
        zero, one = list(bits), list(bits)
        zero[j], one[j] = 0, 1
        lo = compile_basis(template, block, zero).certificate.physical_cost
        hi = compile_basis(template, block, one).certificate.physical_cost
        # Other preparation costs cancel, leaving 2*a_j + C1-C0.
        gradient.append(hi - lo)
    return np.asarray(gradient, dtype=np.float64)


def estimate_mc(template, block, theta, samples, seed):
    theta = np.asarray(theta, dtype=np.float64)
    if theta.shape != (len(template.choices),) or not np.isfinite(theta).all() or ((theta < 0) | (theta > 1)).any():
        raise ValueError('invalid Bernoulli probabilities')
    if type(samples) is not int or samples < 1:
        raise ValueError('positive sample count required')
    rng = np.random.default_rng(seed)
    costs, gradients = [], []
    for _ in range(samples):
        bits = tuple((rng.random(len(theta)) < theta).astype(int))
        costs.append(compile_basis(template, block, bits).certificate.physical_cost)
        gradients.append(coordinate_gradient_sample(template, block, bits))
    gradients = np.asarray(gradients)
    return MCEstimate(float(np.mean(costs)), gradients.mean(0),
                      gradients.std(0, ddof=1) / np.sqrt(samples) if samples > 1 else None,
                      float(np.std(costs, ddof=1) / np.sqrt(samples)) if samples > 1 else None,
                      samples, samples * (1 + 2 * len(theta)))


def estimate_shared_mc(template, block, theta, choice_groups, samples, seed):
    """Independent latent Bernoulli variables each toggle a whole choice group.

    Physical choices inside a group are correlated. Differentiation conditions
    the entire latent bit: dE[L]/dp_g = E[L(Z_g=1)-L(Z_g=0)]. No division by p
    and no invalid sum of independent physical-choice derivatives is used.
    """
    flattened = [i for group in choice_groups for i in group]
    if any(not group for group in choice_groups) or sorted(flattened) != list(range(len(template.choices))):
        raise ValueError('choice groups must partition all template choices')
    theta = np.asarray(theta, dtype=np.float64)
    if theta.shape != (len(choice_groups),) or not np.isfinite(theta).all() or ((theta < 0) | (theta > 1)).any():
        raise ValueError('invalid latent probabilities')
    if type(samples) is not int or samples < 1:
        raise ValueError('positive sample count required')
    def cost(latent):
        bits = [0] * len(template.choices)
        for bit, group in zip(latent, choice_groups):
            for i in group:
                bits[i] = int(bit)
        return compile_basis(template, block, bits).certificate.physical_cost
    rng = np.random.default_rng(seed)
    values, gradients = [], []
    for _ in range(samples):
        latent = rng.random(len(theta)) < theta
        values.append(cost(latent))
        gradient = []
        for g in range(len(theta)):
            zero, one = latent.copy(), latent.copy()
            zero[g], one[g] = False, True
            gradient.append(cost(one) - cost(zero))
        gradients.append(gradient)
    gradients = np.asarray(gradients, dtype=np.float64)
    return MCEstimate(float(np.mean(values)), gradients.mean(0),
                      gradients.std(0, ddof=1) / np.sqrt(samples) if samples > 1 else None,
                      float(np.std(values, ddof=1) / np.sqrt(samples)) if samples > 1 else None,
                      samples, samples * (1 + 2 * len(theta)),
                      'unbiased latent-group conditional gradient; shared physical choices')


def optimize_wide(block, template, initial_theta, backend, budget, seed=0, learning_rate=.05, choice_groups=None):
    theta = np.asarray(initial_theta, dtype=np.float64)
    shared = backend == 'shared_mc'
    if shared:
        if choice_groups is None or any(not group for group in choice_groups) or sorted(i for group in choice_groups for i in group) != list(range(len(template.choices))):
            raise ValueError('shared backend requires a partition of physical choices')
    elif choice_groups is not None:
        raise ValueError('choice groups require the shared_mc backend')
    dimension = len(choice_groups) if shared else len(template.choices)
    if theta.shape != (dimension,) or not np.isfinite(theta).all() or ((theta < 0) | (theta > 1)).any():
        raise ValueError('invalid initial probabilities')
    if not np.isfinite(learning_rate) or learning_rate <= 0:
        raise ValueError('invalid learning rate')
    if backend not in ('exact_messages', 'mc', 'shared_mc'):
        return WideResult('unsupported', template.width, None, tuple(theta), 0, [], backend)
    evaluations, trace, best = 0, [], None
    # A retained direct candidate is reported separately from the optimization trace.
    if budget.evaluations < 1:
        return WideResult('resource_limit', template.width, None, tuple(theta), 0, [], backend)
    # This MC implementation materializes one full word at a time, never 2^w states.
    estimate_bytes = template.n * template.n * 64 + budget.samples * (len(theta) + 1) * 8
    if backend in ('mc', 'shared_mc') and estimate_bytes > budget.max_bytes:
        return WideResult('resource_limit', template.width, None, tuple(theta), 0, [], backend)
    best = compile_basis(template, block, (0,) * len(template.choices))
    evaluations += 1
    for update in range(budget.updates):
        work = budget.samples * (1 + 2 * len(theta)) if backend in ('mc', 'shared_mc') else 1
        if evaluations + work + 1 > budget.evaluations:
            return WideResult('resource_limit', template.width, best, tuple(theta), evaluations, trace, backend)
        try:
            if backend in ('mc', 'shared_mc'):
                estimate = (estimate_shared_mc(template, block, theta, choice_groups, budget.samples, seed + update)
                            if shared else estimate_mc(template, block, theta, budget.samples, seed + update))
                value, gradient = estimate.value, estimate.gradient
                se = None if estimate.gradient_se is None else estimate.gradient_se.tolist()
            else:
                value, gradient = evaluate_J(template, block, theta, max_bytes=budget.max_bytes)
                se = [0.] * len(theta)
        except MemoryError:
            return WideResult('resource_limit', template.width, best, tuple(theta), evaluations, trace, backend)
        evaluations += work
        theta = np.clip(theta - learning_rate * np.asarray(gradient, dtype=np.float64), 0, 1)
        bits = tuple((theta >= .5).astype(int))
        if shared:
            expanded = [0] * len(template.choices)
            for bit, group in zip(bits, choice_groups):
                for i in group:
                    expanded[i] = int(bit)
            bits = tuple(expanded)
        candidate = compile_basis(template, block, bits)
        evaluations += 1
        if candidate.certificate.physical_cost < best.certificate.physical_cost:
            best = candidate
        trace.append({'update': update, 'value_estimate_before_step': float(value),
                      'gradient_se': se, 'theta_after_step': theta.tolist(),
                      'candidate_cost': candidate.certificate.physical_cost,
                      'best_verified_cost': best.certificate.physical_cost,
                      'samples': budget.samples if backend in ('mc', 'shared_mc') else 0,
                      'gradient_kind': 'unbiased_shared_latent_mc' if shared else 'unbiased_mc' if backend == 'mc' else 'exact_messages_float'})
    return WideResult('budget_complete', template.width, best, tuple(theta), evaluations, trace, backend)
