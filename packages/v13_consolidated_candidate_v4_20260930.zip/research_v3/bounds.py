"""Elementary full-matrix lower bounds, with explicit unrestricted-unit scope."""
from .contracts import BoundCertificate, BoundSet, MatrixState
from .gf2 import rank, transpose
from .words import apply, verify_word


def verify_bounds(state, bounds, alphabet):
    if state.n != alphabet.n or state.alphabet_id != alphabet.id:
        raise ValueError('state/alphabet mismatch')
    elementary = {c.witness_ref: c for c in cheap_bounds(state).lower}
    for certificate in bounds.lower:
        if certificate.witness_ref == 'directional_cut_rank_sum':
            try:
                expected = cut_bound(state, certificate.hypotheses['left'], certificate.hypotheses['right'])
            except KeyError:
                raise ValueError('missing cut witness') from None
        else:
            expected = elementary.get(certificate.witness_ref)
        if expected is None or certificate != expected:
            raise ValueError('unverified lower-bound certificate')
    for word in bounds.upper:
        verify_word(word, alphabet)
        if word.start != state or word.end != MatrixState.identity(alphabet):
            raise ValueError('upper bound not a reduction of target')
    if bounds.upper and min(w.physical_cost for w in bounds.upper) < bounds.lower_bound:
        raise ValueError('inconsistent lower/upper certificates')
    if bounds.exact is not None:
        exact = bounds.exact
        if (exact.kind != 'exact' or exact.scope_id != alphabet.id or not bounds.upper or
            exact.value != bounds.lower_bound or exact.value != min(w.physical_cost for w in bounds.upper) or
            exact.witness_ref != 'matching_verified_bounds' or exact.hypotheses.get('state_key') != state.key):
            raise ValueError('exact certificate requires matching independently verified bounds')


def _certificate(state, value, witness, hypotheses=None):
    return BoundCertificate('lower', int(value), f'all_to_all_unit_cnot:{state.n}',
                            {'state_key': state.key, **(hypotheses or {})}, witness, 'elementary_bounds_v1')


def cheap_bounds(state):
    defect = tuple(row ^ (1 << i) for i, row in enumerate(state.packed_rows))
    values = (('changed_rows', sum(row != 0 for row in defect)),
              ('changed_columns', sum(col != 0 for col in transpose(defect))),
              ('rank_defect', rank(defect)))
    return BoundSet(lower=tuple(_certificate(state, value, name) for name, value in values))


def cut_bound(state, left, right):
    left, right = tuple(left), tuple(right)
    if (any(type(i) is not int for i in left + right) or
        len(set(left + right)) != state.n or sorted(left + right) != list(range(state.n))):
        raise ValueError('cut must partition all physical wires')
    def subrank(rows, cols):
        return rank(tuple(sum(((state.packed_rows[i] >> j) & 1) << k for k, j in enumerate(cols)) for i in rows))
    value = subrank(left, right) + subrank(right, left)
    return _certificate(state, value, 'directional_cut_rank_sum', {'left': left, 'right': right})


def action_bound(state, gate, alphabet):
    # Positive integer gate costs are at least one. The unrestricted unit LB
    # remains valid for a restricted positive-integer-cost continuation.
    successor = apply(state, gate, alphabet)
    return alphabet.cost(gate) + cheap_bounds(successor).lower_bound
