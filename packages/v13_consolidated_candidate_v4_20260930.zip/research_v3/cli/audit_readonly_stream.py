"""Inspect a saved own-solver stream without changing SQLite journal state.

The default summary verifies stored root digests and full matrix identities.
``--replay`` additionally checks every saved CNOT word and finite declared
symmetry overlap with the own historical targets. No connection opens writable.
"""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sqlite3

from ..data.frozen import forbidden_views, historical_states
from ..data.own_synthesis import source_hashes
from ..data.stream_reader import decode_record
from ..data.stream_solver_dataset import canonical, data_source_hashes


def audit(path: Path, *, replay: bool = False) -> dict:
    path = Path(path).resolve()
    if not path.is_file():
        raise FileNotFoundError(path)
    connection = sqlite3.connect(path.as_uri() + '?immutable=1', uri=True)
    try:
        saved = connection.execute(
            "SELECT value FROM metadata WHERE key='manifest'").fetchone()
        if saved is None:
            raise ValueError('dataset manifest missing')
        manifest = json.loads(saved[0])
        entries = connection.execute('''
            SELECT matrix_hash,matrix_json,record_json,audit_json,
                   suffix_offsets_json,root_digest,split,n
            FROM roots ORDER BY split,epoch,position''').fetchall()
        counts = Counter()
        states = {'dev': [], 'test': []}
        certificates = 0
        for matrix_hash, identity, record_json, audit_json, offsets_json, digest, split, n in entries:
            expected = hashlib.sha256(canonical((identity, record_json,
                                                  audit_json, offsets_json)).encode()).hexdigest()
            if digest != expected or hashlib.sha256(identity.encode('ascii')).hexdigest() != matrix_hash:
                raise ValueError('saved root digest or identity hash mismatch')
            raw = json.loads(record_json)
            state = raw['state']
            if (raw['split'] != split or state['n'] != n or
                    canonical((n, state['alphabet_id'], state['packed_rows'])) != identity):
                raise ValueError('saved root identity mismatch')
            counts[(split, n)] += 1
            if replay:
                record = decode_record(record_json)
                certificates += len(record.verified_words)
                if split in states:
                    states[split].append(record.state)
        seal = connection.execute(
            "SELECT value FROM metadata WHERE key='holdout_seal'").fetchone()
    finally:
        connection.close()
    result = {
        'schema': 'own_solver_stream_readonly_audit_v1',
        'db_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
        'root_count': len(entries),
        'content_digests_and_matrix_identities_verified': len(entries),
        'counts': {f'{split}:{n}': count for (split, n), count in sorted(counts.items())},
        'compiler_source_matches_manifest': manifest['compiler_source_sha256'] == source_hashes(),
        'dataset_source_matches_manifest': manifest['dataset_source_sha256'] == data_source_hashes(),
        'holdout_seal_present': seal is not None,
        'full_word_replay': replay,
    }
    if replay:
        historical, _ = historical_states(path.parents[4])
        dev_views = forbidden_views(states['dev'])
        test_views = forbidden_views(states['test'])
        historical_views = forbidden_views(historical)
        result.update({
            'certificates_replayed': certificates,
            'dev_finite_symmetry_views': len(dev_views),
            'test_finite_symmetry_views': len(test_views),
            'historical_finite_symmetry_views': len(historical_views),
            'dev_test_finite_view_overlap': len(dev_views & test_views),
            'holdout_historical_finite_view_overlap':
                len((dev_views | test_views) & historical_views),
        })
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', type=Path, required=True)
    parser.add_argument('--replay', action='store_true')
    args = parser.parse_args()
    print(json.dumps(audit(args.db, replay=args.replay), sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
