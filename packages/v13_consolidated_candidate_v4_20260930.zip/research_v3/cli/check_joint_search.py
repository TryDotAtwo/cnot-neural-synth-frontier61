"""One bounded own-matrix integration check, with separate raw and assisted words."""
import argparse
from dataclasses import asdict
from pathlib import Path
import json
from ..contracts import AlphabetSpec,MatrixState
from ..data.frozen import load
from ..train.evaluate import load_field
from ..search.reference import SearchConfig,solve
from ..search.learned_basis import LearnedBasisMacros
from ..search.basis_macros import solve_with_paid_basis
from ..basis.wide import WideBudget
from ..words import verify_word


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--checkpoint',type=Path,required=True)
    parser.add_argument('--dataset',type=Path,required=True)
    parser.add_argument('--lineage',required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    panels,_,_=load(args.dataset)
    record=next(r for r in panels['dev'] if r.lineage_id==args.lineage)
    model,registry,policy,digest=load_field(args.checkpoint)
    alphabet=AlphabetSpec.all_to_all(record.state.n)
    config=SearchConfig(alphabet,policy,beam_width=8,max_cost=2*record.upper_bound,
                        max_expansions=64,macro_expansions=1,inference_batch_size=16,checkpoint_id=digest)
    raw=solve(record.state,model,registry,config)
    proposer=LearnedBasisMacros(model,registry,policy,digest,WideBudget(2,4,32,268435456),
                                max_calls=1,choices=2,seed=2703)
    assisted=solve_with_paid_basis(record.state,model,registry,config,proposer)
    for result in (raw,assisted):
        if result.best_verified_word is not None:
            verify_word(result.best_verified_word,alphabet)
            if result.best_verified_word.start!=record.state or result.best_verified_word.end!=MatrixState.identity(alphabet):
                raise AssertionError('wrong full-matrix endpoint')
    report={'scope':'development integration only; no claimed neural gain or optimality',
            'lineage':record.lineage_id,'reference_UB':record.upper_bound,'checkpoint_sha256':digest,
            'raw':asdict(raw),'assisted':asdict(assisted),'basis_audit':proposer.audit,
            'basis_calls':proposer.calls,'basis_evaluations':proposer.evaluations}
    with args.output.open('x',encoding='utf-8') as stream:json.dump(report,stream,indent=2)
    print(json.dumps({'raw':raw.status,'raw_cost':None if raw.raw_search_word is None else raw.raw_search_word.physical_cost,
                      'assisted':assisted.status,'assisted_cost':None if assisted.best_verified_word is None else assisted.best_verified_word.physical_cost,
                      'basis_calls':proposer.calls,'basis_evaluations':proposer.evaluations}))


if __name__=='__main__':main()
