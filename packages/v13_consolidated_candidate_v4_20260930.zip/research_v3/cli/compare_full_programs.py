"""Matched raw-neural/Hamming full-program search on own frozen matrices."""
import argparse
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
from time import perf_counter

import torch

from ..contracts import AlphabetSpec, MatrixState
from ..postprocess import WindowBudget, shorten
from ..basis.wide import WideBudget
from ..search.reference import SearchConfig, solve
from ..search.learned_basis import LearnedBasisMacros
from ..search.basis_macros import solve_with_paid_basis
from ..train.evaluate import load_field
from ..words import verify_word


def own_cases(path, names=()):
    manifest = json.loads(Path(path).read_text(encoding='utf-8'))
    references = None
    if 'baseline_sha256' in manifest:
        refs = {case['certificate_ref'] for case in manifest['cases']}
        if len(refs) != 1:
            raise ValueError('ambiguous own baseline source')
        baseline_path = Path(next(iter(refs)))
        baseline_raw = baseline_path.read_bytes()
        if hashlib.sha256(baseline_raw).hexdigest() != manifest['baseline_sha256']:
            raise ValueError('own baseline SHA drift')
        baseline = json.loads(baseline_raw)
        references = {item['case']: item for item in baseline['cases']}
    allowed = set(names)
    if len(allowed) != len(names):
        raise ValueError('duplicate requested case')
    case_names = [case['case'] for case in manifest['cases']]
    if len(set(case_names)) != len(case_names):
        raise ValueError('duplicate case in own manifest')
    if allowed and not allowed <= set(case_names):
        raise ValueError('requested case missing from own manifest')
    for case in manifest['cases']:
        if allowed and case['case'] not in allowed:
            continue
        n, alphabet_id, rows = case['canonical_key']
        alphabet = AlphabetSpec.all_to_all(n)
        if alphabet.id != alphabet_id or case['word_validity'] != 'verified':
            raise ValueError('own matrix/alphabet/word evidence mismatch')
        canonical = json.dumps([n, alphabet_id, rows], separators=(',', ':')).encode('ascii')
        if hashlib.sha256(canonical).hexdigest() != case['canonical_sha256']:
            raise ValueError('canonical own matrix SHA mismatch')
        state = MatrixState(n, tuple(rows), alphabet.id)
        if references is not None:
            baseline = references.get(case['case'])
            if (baseline is None or baseline['best']['source'] != case['certificate_source'] or
                    baseline['best']['count'] != case['upper_bound'] or
                    baseline['matrix_sha256'] != case['legacy_matrix_sha256']):
                raise ValueError('own reference case/source/length mismatch')
            gates = baseline['best']['gates']
            if len(gates) != case['upper_bound']:
                raise ValueError('own reference gate count mismatch')
            replay = [1 << i for i in range(n)]
            for gate in gates:
                if (len(gate) != 2 or any(type(i) is not int for i in gate) or
                        gate[0] == gate[1] or min(gate) < 0 or max(gate) >= n):
                    raise ValueError('invalid own reference gate')
                replay[gate[1]] ^= replay[gate[0]]
            if tuple(replay) != state.packed_rows:
                raise ValueError('own reference encoder endpoint mismatch')
        yield case, state, alphabet


def verified_summary(word, root, alphabet):
    if word is None:
        return None
    verify_word(word, alphabet)
    if word.start != root or word.end != MatrixState.identity(alphabet):
        raise ValueError('wrong full-matrix reduction endpoint')
    # Independent packed-row replay; do not rely only on the search engine's
    # certificate verifier, which uses its own state-transition implementation.
    rows = list(root.packed_rows)
    cost = 0
    for gate in word.gates:
        if gate.control == gate.target or not (0 <= gate.control < root.n and 0 <= gate.target < root.n):
            raise ValueError('invalid independent replay gate')
        cost += alphabet.cost(gate)
        rows[gate.target] = rows[gate.target] ^ rows[gate.control]
    if tuple(rows) != tuple(1 << i for i in range(root.n)) or cost != word.physical_cost:
        raise ValueError('independent packed-row replay or physical cost mismatch')
    return {'length': len(word.gates), 'physical_cost': word.physical_cost,
            'gates': [[gate.control, gate.target] for gate in word.gates],
            'producer': word.producer}


def compare_case(case, root, alphabet, model, registry, policy, checkpoint_sha, config, window_budget,
                 basis_config=None):
    results = {}
    for label, scoring in (('raw_neural', 'direct_v'), ('qhat_neural', 'absolute_qhat'),
                           ('hamming', 'hamming_control')):
        search_config = SearchConfig(alphabet, policy, scoring=scoring,
                                     beam_width=config['beam_width'],
                                     max_cost=config['max_cost_multiplier'] * case['upper_bound'],
                                     max_expansions=config['max_expansions'],
                                     inference_batch_size=config['inference_batch_size'],
                                     checkpoint_id=checkpoint_sha)
        started = perf_counter()
        result = solve(root, model, registry, search_config)
        word = result.raw_search_word
        results[label] = {'status': result.status, 'word': verified_summary(word, root, alphabet),
                          'search_seconds': perf_counter()-started, 'counts': result.counts,
                          'budget': {'beam_width': search_config.beam_width,
                                     'max_expansions': search_config.max_expansions,
                                     'max_cost': search_config.max_cost}}
    raw_word = results['raw_neural']['word']
    postprocess = None
    if raw_word is not None and window_budget is not None:
        # Rebuild a typed certificate from the search result's independently
        # verified gate list rather than trusting any serialized report.
        from ..contracts import WordCertificate, Gate
        gates = tuple(Gate(c, t) for c, t in raw_word['gates'])
        cert = WordCertificate(root, MatrixState.identity(alphabet), gates,
                               raw_word['physical_cost'], 'direct_v', 'comparison_raw')
        started = perf_counter()
        shortened = shorten(cert, alphabet, window_budget)
        postprocess = {'status': shortened.status,
                       'word': verified_summary(shortened.after, root, alphabet),
                       'seconds': perf_counter()-started,
                       'evaluations': shortened.evaluations,
                       'window_budget': asdict(window_budget)}
    compiler_assisted = None
    if basis_config is not None:
        proposer = LearnedBasisMacros(model, registry, policy, checkpoint_sha,
                                      WideBudget(basis_config['updates'], basis_config['samples'],
                                                 basis_config['evaluations'], basis_config['max_bytes']),
                                      max_calls=basis_config['max_calls'],
                                      choices=basis_config['choices'], seed=basis_config['seed'])
        assisted_config = SearchConfig(alphabet, policy, scoring='direct_v',
                                       beam_width=config['beam_width'],
                                       max_cost=config['max_cost_multiplier'] * case['upper_bound'],
                                       max_expansions=config['max_expansions'],
                                       macro_expansions=basis_config['max_calls'],
                                       inference_batch_size=config['inference_batch_size'],
                                       checkpoint_id=checkpoint_sha)
        started = perf_counter()
        assisted = solve_with_paid_basis(root, model, registry, assisted_config, proposer)
        compiler_assisted = {'status': assisted.status,
                             'word': verified_summary(assisted.best_verified_word, root, alphabet),
                             'search_seconds': perf_counter()-started,
                             'counts': assisted.counts,
                             'basis_calls': proposer.calls,
                             'basis_proposal_forwards': proposer.proposal_forwards,
                             'basis_evaluations': proposer.evaluations,
                             'basis_audit': proposer.audit,
                             'budget': {**results['raw_neural']['budget'], 'basis': basis_config}}
    candidates = [(name, item['word']) for name, item in results.items() if item['word'] is not None]
    if postprocess is not None:
        candidates.append(('postprocess', postprocess['word']))
    if compiler_assisted is not None and compiler_assisted['word'] is not None:
        candidates.append(('compiler_assisted', compiler_assisted['word']))
    best = min(candidates, key=lambda item: item[1]['physical_cost']) if candidates else None
    return {'case': case['case'], 'n': root.n, 'matrix_sha256': case['canonical_sha256'],
            'own_reference_upper_bound': case['upper_bound'],
            'raw_neural': results['raw_neural'], 'qhat_neural': results['qhat_neural'],
            'hamming': results['hamming'],
            'postprocess': postprocess, 'compiler_assisted': compiler_assisted,
            'portfolio': None if best is None else {'source': best[0], 'word': best[1]},
            'external_same_matrix_reference': None,
            'claim_scope': 'own fixed matrix; verified full words; no external delta or optimality claim'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--own-manifest', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--case', action='append', default=[])
    parser.add_argument('--device', choices=('cpu', 'cuda'), default='cuda')
    parser.add_argument('--threads', type=int, default=4)
    parser.add_argument('--beam-width', type=int, required=True)
    parser.add_argument('--max-expansions', type=int, required=True)
    parser.add_argument('--max-cost-multiplier', type=int, default=2)
    parser.add_argument('--inference-batch-size', type=int, default=16)
    parser.add_argument('--window-evaluations', type=int, default=0)
    parser.add_argument('--window-states', type=int, default=100000)
    parser.add_argument('--window-length', type=int, default=3)
    parser.add_argument('--window-passes', type=int, default=2)
    parser.add_argument('--basis-max-calls', type=int, default=1)
    parser.add_argument('--basis-updates', type=int, default=2)
    parser.add_argument('--basis-samples', type=int, default=4)
    parser.add_argument('--basis-evaluations', type=int, default=64)
    parser.add_argument('--basis-max-bytes', type=int, default=268435456)
    parser.add_argument('--basis-choices', type=int, default=2)
    parser.add_argument('--basis-seed', type=int, default=2703)
    args = parser.parse_args()
    if (args.threads < 1 or args.max_cost_multiplier < 1 or args.window_evaluations < 0 or
            args.basis_max_calls < 0):
        raise ValueError('invalid compute budget')
    if args.output.exists():
        raise FileExistsError(args.output)
    torch.set_num_threads(args.threads)
    model, registry, policy, checkpoint_sha = load_field(args.checkpoint, args.device)
    budget = (WindowBudget(args.window_passes, args.window_length, args.window_evaluations,
                           args.window_states, support_restricted=True)
              if args.window_evaluations else None)
    config = {'beam_width': args.beam_width, 'max_expansions': args.max_expansions,
              'max_cost_multiplier': args.max_cost_multiplier,
              'inference_batch_size': args.inference_batch_size}
    basis_config = ({'max_calls': args.basis_max_calls, 'updates': args.basis_updates,
                     'samples': args.basis_samples, 'evaluations': args.basis_evaluations,
                     'max_bytes': args.basis_max_bytes, 'choices': args.basis_choices,
                     'seed': args.basis_seed} if args.basis_max_calls else None)
    header = {'checkpoint_sha256': checkpoint_sha,
              'own_manifest_sha256': hashlib.sha256(args.own_manifest.read_bytes()).hexdigest(),
              'comparison_code_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'search_code_sha256': hashlib.sha256(Path(solve.__code__.co_filename).read_bytes()).hexdigest(),
              'device': args.device, 'pid': os.getpid(), 'config': config,
              'window_budget': None if budget is None else asdict(budget),
              'basis_budget': basis_config,
              'cases_requested': args.case or 'all'}
    with args.output.open('x', encoding='utf-8') as stream:
        stream.write(json.dumps({'header': header})+'\n')
        stream.flush(); os.fsync(stream.fileno())
        for case, root, alphabet in own_cases(args.own_manifest, args.case):
            result = compare_case(case, root, alphabet, model, registry, policy,
                                  checkpoint_sha, config, budget, basis_config)
            stream.write(json.dumps(result, separators=(',', ':'))+'\n')
            stream.flush(); os.fsync(stream.fileno())
            print(json.dumps({'case': result['case'],
                              'raw': None if result['raw_neural']['word'] is None else result['raw_neural']['word']['length'],
                              'qhat': None if result['qhat_neural']['word'] is None else result['qhat_neural']['word']['length'],
                              'hamming': None if result['hamming']['word'] is None else result['hamming']['word']['length'],
                              'compiler': None if result['compiler_assisted'] is None or result['compiler_assisted']['word'] is None else result['compiler_assisted']['word']['length'],
                              'portfolio': None if result['portfolio'] is None else result['portfolio']['word']['length']}), flush=True)


if __name__ == '__main__':
    main()
