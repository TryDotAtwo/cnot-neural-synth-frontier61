import argparse
import json
import os
import hashlib
from pathlib import Path
import torch
from time import perf_counter
from ..data.frozen import load
from ..train.evaluate import load_field, evaluate_panel


def runtime_source_hashes(root):
    """Stable executable-source inventory; archived overlays never affect dev timing."""
    root=Path(root)
    return {p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.rglob('*.py'))
            if p.relative_to(root).parts[0] not in ('artifacts','tests','__pycache__')}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint',type=Path,required=True)
    parser.add_argument('--dataset',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--config',type=Path,required=True)
    parser.add_argument('--scoring',choices=('direct_v','absolute_qhat','hamming_control'),required=True)
    args = parser.parse_args()
    config = json.loads(args.config.read_text(encoding='utf-8'))
    journal = args.output.with_suffix('.cases.jsonl')
    manifest_path = args.output.with_suffix('.manifest.json')
    if any(path.exists() for path in (args.output,journal,manifest_path)):
        raise FileExistsError('immutable evaluation output already exists')
    compute_start = perf_counter()
    torch.set_num_threads(config['threads'])
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    model, registry, policy, digest = load_field(args.checkpoint, config['device'])
    panels, _, _ = load(args.dataset)
    update = json.loads(args.checkpoint.with_suffix('.json').read_text(encoding='utf-8'))['progress']['attempted']
    root = Path(__file__).resolve().parents[1]
    manifest = {'config':config,'checkpoint_sha256':digest,'scoring':args.scoring,'pid':os.getpid(),
                'dataset_sha256':hashlib.sha256(args.dataset.read_bytes()).hexdigest(),
                'code_sha256':runtime_source_hashes(root)}
    with manifest_path.open('x',encoding='utf-8') as stream:
        json.dump(manifest,stream,indent=2)
    with journal.open('x',encoding='utf-8') as stream:
        def persist(case):
            stream.write(json.dumps(case,separators=(',',':'))+'\n')
            stream.flush(); os.fsync(stream.fileno())
            word = case['result']['raw_search_word']
            print(json.dumps({'lineage':case['lineage_id'],'n':case['state']['n'],
                              'status':case['result']['status'],'cost':None if word is None else word['physical_cost']}),flush=True)
        report = evaluate_panel(model, registry, policy, panels['dev'], checkpoint_id=digest, scoring=args.scoring,
                                on_case=persist, update=update, compute_start=compute_start,
                                **{k:config[k] for k in ('beam_width','max_expansions','max_cost_multiplier','chunk_size')})
    with args.output.open('x',encoding='utf-8') as stream:
        json.dump(report,stream,indent=2)
    print(json.dumps({'solved':report['solved'],'total':report['total'],'selection_key':report['selection_key']}))


if __name__ == '__main__':
    main()
