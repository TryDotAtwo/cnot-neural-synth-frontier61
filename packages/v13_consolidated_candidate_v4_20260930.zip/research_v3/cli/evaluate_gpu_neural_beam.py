"""Replay-verified raw neural full-program evaluation on sealed own roots.

The decoder is deliberately separate from any own compiler or external method.
Its Qhat shortlist is approximate unless it contains every primitive action.
This executable records fixed resource limits and every failure as a row.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path
import sqlite3
from time import perf_counter
from types import SimpleNamespace

import torch

from ..data.stream_reader import decode_record
from ..data.stream_solver_dataset import canonical
from ..contracts import AlphabetSpec, MatrixState
from ..gpu.frozen_bank import _pack_states
from ..gpu.neural_beam import (beam_search, matrix_hamming_callbacks,
                               neural_field_callbacks)
from .probe_gpu_fullwidth_joint import _model, _sha256_file


def _read_panel(db: Path, split: str, width: int | None):
    connection = sqlite3.connect(db.resolve().as_uri() + '?immutable=1', uri=True)
    try:
        seal_row = connection.execute(
            "SELECT value FROM metadata WHERE key='holdout_seal'").fetchone()
        if seal_row is None:
            raise ValueError('sealed own holdout required')
        seal = json.loads(seal_row[0])
        total = connection.execute(
            'SELECT COUNT(*) FROM roots WHERE split=?', (split,)).fetchone()[0]
        if total != seal[f'{split}_roots']:
            raise ValueError('sealed own panel count changed')
        columns = ('matrix_hash,matrix_json,epoch,position,record_json,'
                   'audit_json,suffix_offsets_json,root_digest')
        if width is None:
            rows = connection.execute(
                f'SELECT {columns} FROM roots WHERE split=? '
                'ORDER BY epoch,position', (split,)).fetchall()
        else:
            rows = connection.execute(
                f'SELECT {columns} FROM roots WHERE split=? AND n=? '
                'ORDER BY epoch,position', (split, width)).fetchall()
    finally:
        connection.close()
    selected = []
    for matrix_hash, identity, epoch, position, raw, audit, offsets, digest in rows:
        if (hashlib.sha256(identity.encode('ascii')).hexdigest() != matrix_hash or
                hashlib.sha256(canonical((identity, raw, audit, offsets))
                               .encode('utf-8')).hexdigest() != digest):
            raise ValueError('sealed panel root digest mismatch')
        record = decode_record(raw)
        if record.split != split or canonical(record.state.key) != identity:
            raise ValueError('sealed panel matrix identity mismatch')
        if not record.verified_words:
            raise ValueError('panel root has no verified reference word')
        if width is not None and record.state.n != width:
            raise ValueError('panel width metadata mismatch')
        selected.append((epoch, position, digest, record))
    return selected


def _read_historical(stage17_root: Path, width: int | None):
    root = stage17_root.resolve()
    baseline = json.loads((root / 'improved/research_v2/baselines.json')
                          .read_text(encoding='utf-8'))
    selected = []
    for position, case in enumerate(baseline['cases']):
        n = case['n']
        source = (root / case['input_source'].replace('\\', '/')).resolve()
        if not source.is_relative_to((root / 'source_snapshot/inputs').resolve()):
            raise ValueError('historical own input outside pinned snapshot')
        raw = source.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        if digest != case['input_file_sha256']:
            raise ValueError('historical own input source drift')
        alphabet = AlphabetSpec.all_to_all(n)
        state = MatrixState.from_dense(json.loads(raw)['matrix'], alphabet)
        gates = case['best']['gates']
        if len(gates) != case['best']['count']:
            raise ValueError('historical own reference count mismatch')
        rows = [1 << wire for wire in range(n)]
        for control, target in gates:
            if not (0 <= control < n and 0 <= target < n and control != target):
                raise ValueError('invalid historical own CNOT')
            rows[target] ^= rows[control]
        if tuple(rows) != state.packed_rows:
            raise ValueError('historical own reference endpoint mismatch')
        if width is None or n == width:
            record = SimpleNamespace(
                state=state, lineage_id=case['case'],
                verified_words=(SimpleNamespace(physical_cost=len(gates)),))
            selected.append((0, position, digest, record))
    return selected


def _load_model(checkpoint_path: Path, config_path: Path):
    config_bytes = config_path.read_bytes()
    config_sha = hashlib.sha256(config_bytes).hexdigest()
    config = json.loads(config_bytes)
    checkpoint = torch.load(checkpoint_path, map_location='cpu', weights_only=False)
    if (checkpoint.get('config_sha256') != config_sha or
            checkpoint.get('schema') not in {
                'gpu_admitted_own_train_checkpoint_v1',
                'gpu_own_transfer_training_checkpoint_v1',
                'gpu_own_trajectory_transfer_checkpoint_v1'}):
        raise ValueError('unsupported or config-drifted own checkpoint')
    model = _model(config).eval()
    model.load_state_dict(checkpoint['model'])
    return model, config, checkpoint


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', type=Path)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--split', choices=('dev', 'test', 'historical'),
                        default='dev')
    parser.add_argument('--stage17-root', type=Path)
    parser.add_argument('--scorer', choices=('neural_qhat_shortlist',
                                             'neural_proposal_shortlist',
                                             'neural_direct_v',
                                             'matrix_hamming'),
                        default='neural_qhat_shortlist')
    parser.add_argument('--width', type=int)
    parser.add_argument('--max-roots', type=int, default=0)
    parser.add_argument('--beam-width', type=int, required=True)
    parser.add_argument('--shortlist', type=int, required=True)
    parser.add_argument('--max-depth', type=int, required=True)
    parser.add_argument('--max-expanded', type=int, required=True)
    parser.add_argument('--inference-batch', type=int, default=16)
    args = parser.parse_args()
    if (args.max_roots < 0 or args.beam_width < 1 or args.shortlist < 1 or
            args.max_depth < 1 or args.max_expanded < 1 or
            args.inference_batch < 1):
        raise ValueError('positive decoder budgets required')
    if args.output.exists():
        raise FileExistsError(args.output)
    panel_started = perf_counter()
    if args.split == 'historical':
        if args.stage17_root is None:
            raise ValueError('historical panel requires pinned stage17 root')
        panel = _read_historical(args.stage17_root, args.width)
    else:
        if args.db is None:
            raise ValueError('sealed dev/test panel requires a database')
        panel = _read_panel(args.db, args.split, args.width)
    panel_load_seconds = perf_counter() - panel_started
    if args.max_roots:
        panel = panel[:args.max_roots]
    if not panel:
        raise ValueError('no sealed own roots selected')
    if args.scorer in ('matrix_hamming', 'neural_direct_v') and any(
            args.shortlist < record.state.n * (record.state.n - 1)
            for _epoch, _position, _digest, record in panel):
        raise ValueError('direct-V and Hamming require the complete action alphabet')
    loaded_at = perf_counter()
    if args.scorer != 'matrix_hamming':
        model, config, checkpoint = _load_model(args.checkpoint, args.config)
        actions, states = neural_field_callbacks(
            model, mc_samples=config['diffusion']['mc_samples'],
            mc_seed=config['feature_seed'],
            max_pair_states=config['diffusion']['max_pair_states'],
            head=('proposal' if args.scorer == 'neural_proposal_shortlist'
                  else 'qhat'))
        if args.scorer == 'neural_direct_v':
            actions = None
    else:
        config = json.loads(args.config.read_bytes())
        checkpoint = None
        actions, states = matrix_hamming_callbacks()
    setup_seconds = perf_counter() - loaded_at
    torch.set_num_threads(config['threads'])
    header = {
        'schema': 'gpu_own_full_program_panel_v1',
        'claim_scope': 'own full-program pilot if panel/budgets do not match frozen protocol',
        'split': args.split, 'width': args.width,
        'scorer': args.scorer,
        'max_roots': args.max_roots, 'selected_roots': len(panel),
        'checkpoint_sha256': _sha256_file(args.checkpoint),
        'checkpoint_schema': None if checkpoint is None else checkpoint['schema'],
        'completed_units': None if checkpoint is None else checkpoint.get('completed_units'),
        'panel_load_seconds': panel_load_seconds,
        'setup_seconds': setup_seconds,
        'db_sha256': None if args.split == 'historical' else _sha256_file(args.db),
        'historical_baseline_sha256': (
            _sha256_file(args.stage17_root /
                         'improved/research_v2/baselines.json')
            if args.split == 'historical' else None),
        'config_sha256': _sha256_file(args.config),
        'decoder_source_sha256': _sha256_file(
            Path(__file__).resolve().parents[1] / 'gpu/neural_beam.py'),
        'budgets': {'beam_width': args.beam_width,
                    'shortlist': args.shortlist,
                    'max_depth': args.max_depth,
                    'max_expanded': args.max_expanded,
                    'inference_batch': args.inference_batch}}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open('x', encoding='utf-8') as stream:
        def emit(item):
            stream.write(json.dumps(item, sort_keys=True) + '\n')
            stream.flush()
            os.fsync(stream.fileno())
        emit({'header': header})
        for epoch, position, digest, record in panel:
            reference = min(word.physical_cost for word in record.verified_words)
            if reference < 1:
                raise ValueError('nonidentity dev/test panel required')
            torch.cuda.synchronize()
            started = perf_counter()
            try:
                root = _pack_states([record.state], record.state.n)
                result = beam_search(
                    root, actions, states,
                    beam_width=args.beam_width, shortlist=args.shortlist,
                    max_depth=args.max_depth,
                    max_expanded=args.max_expanded,
                    inference_batch=args.inference_batch)
                torch.cuda.synchronize()
                item = {'status': result.status,
                        'word': result.word, 'verified': result.verified,
                        'length': None if result.word is None else len(result.word),
                        'expanded': result.expanded,
                        'generated': result.generated,
                        'value_evaluations': result.value_evaluations,
                        'search_seconds': result.seconds}
            except (RuntimeError, MemoryError, ValueError, AssertionError) as error:
                reason = str(error).lower()
                if isinstance(error, MemoryError) or 'out of memory' in reason:
                    status = 'oom'
                elif isinstance(error, AssertionError):
                    status = 'invalid_certificate'
                elif 'nonfinite' in reason or 'nan' in reason or 'inf' in reason:
                    status = 'numerical_error'
                else:
                    status = 'error'
                item = {'status': status, 'error_type': type(error).__name__,
                        'error': str(error), 'word': None, 'verified': False,
                        'length': None}
            item.update({'epoch': epoch, 'position': position,
                         'root_digest': digest, 'n': record.state.n,
                         'lineage_id': record.lineage_id,
                         'own_reference_upper_bound': reference,
                         'end_to_end_seconds': perf_counter() - started})
            emit(item)
        emit({'event': 'panel_complete', 'roots': len(panel),
              'end_to_end_seconds': perf_counter() - panel_started})


if __name__ == '__main__':
    main()
