"""Export a compact, auditable own dev/test GPU admission input bundle.

Only the 256 held-out roots, their existing seal metadata, checked original
stage-17 inputs, and own source files are copied. No train roots, forbidden
hash table, checkpoint, credentials, or external-method material are exported.
The receiver reconstructs the one-hop bank from the compact roots on GPU.
"""

import argparse
import hashlib
import json
from pathlib import Path
import sqlite3
from tempfile import TemporaryDirectory
import zipfile

from ..data.frozen import historical_states
from ..data.own_synthesis import OWN_MODULES, source_hashes
from ..data.stream_solver_dataset import DATA_SOURCE_FILES, canonical, data_source_hashes


def _sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while chunk := stream.read(4 << 20):
            digest.update(chunk)
    return digest.hexdigest()


def export(source: Path, stage17_root: Path, output: Path) -> dict:
    source, stage17_root, output = (Path(p).resolve()
                                    for p in (source, stage17_root, output))
    if not source.is_file() or not stage17_root.is_dir() or output.exists():
        raise ValueError('existing sealed source/root and new output required')
    historical, sources = historical_states(stage17_root)
    connection = sqlite3.connect(source.as_uri() + '?immutable=1', uri=True)
    try:
        manifest_row = connection.execute(
            "SELECT value FROM metadata WHERE key='manifest'").fetchone()
        seal_row = connection.execute(
            "SELECT value FROM metadata WHERE key='holdout_seal'").fetchone()
        if manifest_row is None or seal_row is None:
            raise ValueError('source has no complete sealed own holdout')
        manifest, seal = json.loads(manifest_row[0]), json.loads(seal_row[0])
        if (manifest['compiler_source_sha256'] != source_hashes() or
                manifest['dataset_source_sha256'] != data_source_hashes() or
                seal['historical_source_sha256'] != sources or
                seal['historical_roots'] != len(historical)):
            raise ValueError('own source or historical provenance drift')
        rows = connection.execute(
            "SELECT matrix_hash,matrix_json,split,epoch,position,attempt,family,n,"
            "seed,record_json,audit_json,suffix_offsets_json,root_digest "
            "FROM roots WHERE split IN ('dev','test') ORDER BY split,epoch,position").fetchall()
        counts = {split: sum(row[2] == split for row in rows)
                  for split in ('dev', 'test')}
        if counts != {'dev': seal['dev_roots'], 'test': seal['test_roots']}:
            raise ValueError('held-out root count drift')
        for row in rows:
            matrix_hash, identity, _, _, _, _, _, _, _, record_json, audit_json, offsets_json, digest = row
            if (hashlib.sha256(identity.encode('ascii')).hexdigest() != matrix_hash or
                    hashlib.sha256(canonical((identity, record_json, audit_json,
                                              offsets_json)).encode()).hexdigest() != digest):
                raise ValueError('held-out root content digest drift')
    finally:
        connection.close()
    with TemporaryDirectory() as temporary:
        compact = Path(temporary) / 'own_holdout_128_128.sqlite'
        target = sqlite3.connect(compact)
        try:
            target.executescript('''
                CREATE TABLE metadata(key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE roots(
                    matrix_hash TEXT NOT NULL, matrix_json TEXT NOT NULL,
                    split TEXT NOT NULL, epoch INTEGER NOT NULL,
                    position INTEGER NOT NULL, attempt INTEGER NOT NULL, family TEXT NOT NULL,
                    n INTEGER NOT NULL, seed INTEGER NOT NULL, record_json TEXT NOT NULL,
                    audit_json TEXT NOT NULL, suffix_offsets_json TEXT NOT NULL,
                    root_digest TEXT NOT NULL,
                    PRIMARY KEY(matrix_hash,matrix_json),
                    UNIQUE(split,epoch,position));
            ''')
            with target:
                target.execute("INSERT INTO metadata VALUES('manifest',?)", (manifest_row[0],))
                target.execute("INSERT INTO metadata VALUES('holdout_seal',?)", (seal_row[0],))
                target.executemany('INSERT INTO roots VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)', rows)
        finally:
            target.close()
        compact_hash = _sha(compact)
        root = stage17_root / 'improved/research_v3'
        files = {}
        for name in DATA_SOURCE_FILES:
            files[f'research_v3/{name}'] = root / name
        for name in ('data/records.py', 'data/stream_reader.py',
                     'data/solver_programs.py', 'data/splits.py',
                     'gpu/frozen_bank.py', 'gpu/holdout.py',
                     'gpu/record_batch.py', 'tests/test_gpu_frozen_bank.py'):
            files[f'research_v3/{name}'] = root / name
        files['01_shared_basis_stage17/improved/research_v2/baselines.json'] = \
            stage17_root / 'improved/research_v2/baselines.json'
        for name in OWN_MODULES:
            files[f'code/{name}.py'] = stage17_root / 'improved/code' / f'{name}.py'
        for path_text in sources:
            path = Path(path_text)
            files[f'01_shared_basis_stage17/source_snapshot/inputs/{path.name}'] = path
        files['research_v3/artifacts/datasets/own_holdout_128_128.sqlite'] = compact
        if any(not path.is_file() for path in files.values()):
            raise ValueError('missing own source in export')
        manifest_export = {'schema': 'own_gpu_holdout_compact_bundle_v1',
                           'dev_roots': counts['dev'], 'test_roots': counts['test'],
                           'historical_roots': len(historical),
                           'finite_symmetry_views': seal['finite_symmetry_views'],
                           'forbidden_or_onehop_hashes_in_source':
                               seal['forbidden_or_onehop_hashes'],
                           'compact_db_sha256': compact_hash,
                           'files': {name: _sha(path) for name, path in sorted(files.items())},
                           'scope': 'own holdout roots and own code; receiver recomputes GPU one-hop bank'}
        output.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(output, 'x', compression=zipfile.ZIP_DEFLATED) as archive:
            for name, path in sorted(files.items()):
                archive.write(path, name)
            archive.writestr('bundle_manifest.json', canonical(manifest_export))
    return {'zip': str(output), 'zip_sha256': _sha(output),
            'zip_bytes': output.stat().st_size,
            'compact_db_sha256': compact_hash,
            'dev_roots': counts['dev'], 'test_roots': counts['test'],
            'file_count': len(files) + 1}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--stage17-root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(export(args.source, args.stage17_root, args.out), sort_keys=True))


if __name__ == '__main__':
    main()
