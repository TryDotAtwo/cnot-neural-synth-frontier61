"""Read-only export of verified own train roots for Molab GPU admission.

The full sealed SQLite and its hash closure remain on D:. This transfer carries
only requested train records; the independent GPU holdout bank checks each
parent and every primitive successor again before the model sees them.
"""

import argparse
import hashlib
import json
from pathlib import Path
import sqlite3

from ..data.stream_reader import decode_record
from ..data.stream_solver_dataset import canonical, matrix_identity, root_key


def export(db: Path, out: Path, count: int) -> dict:
    if count < 1 or out.exists() or not db.is_file():
        raise ValueError('positive count, existing DB and new output path required')
    connection = sqlite3.connect(db.resolve().as_uri() + '?mode=ro', uri=True)
    try:
        metadata = dict(connection.execute(
            "SELECT key,value FROM metadata WHERE key IN ('manifest','holdout_seal')"))
        if set(metadata) != {'manifest', 'holdout_seal'}:
            raise ValueError('sealed source metadata is incomplete')
        rows = connection.execute('''SELECT matrix_hash,matrix_json,epoch,position,
                                           record_json,audit_json,suffix_offsets_json,
                                           root_digest
                                    FROM roots WHERE split='train'
                                    ORDER BY epoch,position LIMIT ?''', (count,)).fetchall()
        if len(rows) != count:
            raise ValueError(f'only {len(rows)} train roots available; requested {count}')
    finally:
        connection.close()
    records = []
    for index, (digest, identity, epoch, position, record_json, audit_json,
                offsets_json, root_digest) in enumerate(rows):
        if epoch != 0 or position != index:
            raise ValueError('first train epoch is not contiguous')
        record = decode_record(record_json)
        if record.split != 'train' or matrix_identity(record) != identity or \
                root_key(record) != digest:
            raise ValueError('train root identity mismatch')
        calculated = hashlib.sha256(canonical((identity, record_json, audit_json,
                                               offsets_json)).encode('utf-8')).hexdigest()
        if calculated != root_digest:
            raise ValueError('train root digest mismatch')
        records.append({'epoch': epoch, 'position': position, 'matrix_hash': digest,
                        'matrix_json': identity, 'record_json': record_json,
                        'audit_json': audit_json,
                        'suffix_offsets_json': offsets_json,
                        'root_digest': root_digest})
    payload = {'schema': 'own_verified_train_subset_transfer_v1',
               'manifest_sha256': hashlib.sha256(metadata['manifest'].encode()).hexdigest(),
               'holdout_seal_sha256': hashlib.sha256(metadata['holdout_seal'].encode()).hexdigest(),
               'first_epoch': 0, 'count': count, 'records': records}
    out.parent.mkdir(parents=True, exist_ok=True)
    temp = out.with_name(out.name + '.tmp')
    try:
        with temp.open('x', encoding='utf-8', newline='\n') as stream:
            stream.write(canonical(payload) + '\n')
            stream.flush()
        temp.replace(out)
    except BaseException:
        temp.unlink(missing_ok=True)
        raise
    return {'schema': payload['schema'], 'count': count,
            'manifest_sha256': payload['manifest_sha256'],
            'holdout_seal_sha256': payload['holdout_seal_sha256'],
            'transfer_sha256': hashlib.sha256(out.read_bytes()).hexdigest(),
            'bytes': out.stat().st_size}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--count', type=int, required=True)
    args = parser.parse_args()
    print(json.dumps(export(args.db, args.out, args.count), sort_keys=True))


if __name__ == '__main__':
    main()
