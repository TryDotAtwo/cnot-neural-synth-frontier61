"""Recover stage49–51 test dependencies omitted from the listed source subset.

Only these exact archive prefixes are admitted. The original ZIP is read only;
existing extracted files are checked byte-for-byte and never overwritten.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
from zipfile import ZipFile


ARCHIVE_SHA256 = "cc2f2494be66efea10718abd88834a8a65e4cf1c77c8fcecea51acac8139a33c"
PREFIXES = (
    "stage49_feedback_influence/results/",
    "stage49_feedback_influence/reference_stage48/",
    "stage50_shared_feedback/results/",
    "stage50_shared_feedback/reference_stage49/",
    "stage51_dynamic_source/results/",
    "stage51_dynamic_source/reference_stage50/",
)


def sha256_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def extract(archive, destination, manifest_path):
    archive, destination, manifest_path = map(Path, (archive, destination, manifest_path))
    if sha256_file(archive) != ARCHIVE_SHA256:
        raise ValueError("source archive SHA-256 mismatch")
    root = destination.resolve()
    entries = []
    with ZipFile(archive) as zip_file:
        selected = sorted((item for item in zip_file.infolist()
                           if not item.is_dir() and item.filename.startswith(PREFIXES)),
                          key=lambda item: item.filename)
        for item in selected:
            relative = PurePosixPath(item.filename)
            if relative.is_absolute() or ".." in relative.parts or "\\" in item.filename:
                raise ValueError("unsafe source archive path")
            target = root.joinpath(*relative.parts).resolve()
            if not target.is_relative_to(root):
                raise ValueError("source archive path escapes extraction root")
            content = zip_file.read(item)
            digest = hashlib.sha256(content).hexdigest()
            if target.exists():
                if target.read_bytes() != content:
                    raise ValueError(f"existing file differs: {item.filename}")
                state = "matched_existing"
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(content)
                state = "extracted"
            entries.append({"member": item.filename, "bytes": len(content),
                            "sha256": digest, "state": state})
    report = {"archive_sha256": ARCHIVE_SHA256,
              "source_manifest_scope": "supplementary ZIP members, absent from original 635-member listed subset",
              "count": len(entries), "bytes": sum(row["bytes"] for row in entries),
              "entries": entries}
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("archive")
    parser.add_argument("destination")
    parser.add_argument("manifest")
    args = parser.parse_args()
    result = extract(args.archive, args.destination, args.manifest)
    print(json.dumps({key: result[key] for key in ("archive_sha256", "count", "bytes")}))
