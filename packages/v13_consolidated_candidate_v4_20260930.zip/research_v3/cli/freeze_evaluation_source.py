"""Freeze a checkpoint-compatible evaluator without changing training sources."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil


OVERLAYS = (
    'cli/compare_full_programs.py',
    'cli/summarize_full_programs.py',
    'search/reference.py',
)


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def freeze(training_snapshot, destination, source_root):
    training_snapshot = Path(training_snapshot).resolve()
    destination = Path(destination).resolve()
    source_root = Path(source_root).resolve()
    if destination.exists():
        raise FileExistsError(destination)
    manifest_path = training_snapshot / 'source_manifest.json'
    source = training_snapshot / 'research_v3'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    inventory = manifest.get('source_files', manifest.get('files'))
    if inventory is None or Path(manifest['snapshot_root']).resolve() != source:
        raise ValueError('invalid training source manifest')
    for relative, expected in inventory.items():
        if sha256(source / relative) != expected:
            raise ValueError('training source drift: '+relative)
    if source_root == source or destination.is_relative_to(source):
        raise ValueError('source root and frozen source must be distinct')
    copied = destination / 'research_v3'
    shutil.copytree(source, copied, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    overlay_hashes = {}
    for relative in OVERLAYS:
        original = source_root / relative
        target = copied / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(original, target)
        overlay_hashes[relative] = sha256(target)
    # The evaluator must retain the exact inference/training sources, so the
    # checkpoint loader can enforce its saved code provenance without bypasses.
    for relative, expected in inventory.items():
        if relative not in OVERLAYS and sha256(copied / relative) != expected:
            raise ValueError('copied frozen source drift: '+relative)
    result = {'schema': 'evaluation_source_overlay_v1',
              'base_training_source_manifest_sha256': sha256(manifest_path),
              'base_training_source': str(training_snapshot),
              'snapshot_root': str(copied),
              'overlays': overlay_hashes,
              'files': {p.relative_to(copied).as_posix(): sha256(p)
                        for p in sorted(copied.rglob('*.py'))}}
    output = destination / 'evaluation_source_manifest.json'
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding='utf-8')
    return output


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--training-snapshot', type=Path, required=True)
    parser.add_argument('--destination', type=Path, required=True)
    args = parser.parse_args()
    source_root = Path(__file__).resolve().parents[1]
    output = freeze(args.training_snapshot, args.destination, source_root)
    print(json.dumps({'evaluation_source_manifest': str(output),
                      'sha256': sha256(output)}))


if __name__ == '__main__':
    main()
