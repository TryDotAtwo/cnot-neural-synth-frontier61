"""Create a named, hash-verified Python source overlay for one training arm."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--destination', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    destination = args.destination.resolve()
    if destination.exists():
        raise FileExistsError(destination)
    if not args.config.is_file():
        raise FileNotFoundError(args.config)
    config = json.loads(args.config.read_text(encoding='utf-8'))
    if not isinstance(config.get('features'), list):
        raise ValueError('training config has no feature list')
    sources = [p for p in sorted(root.rglob('*.py'))
               if p.relative_to(root).parts[0] not in ('artifacts', '__pycache__')]
    if not sources:
        raise ValueError('empty source inventory')
    snapshot = destination / 'research_v3'
    snapshot.mkdir(parents=True)
    inventory = {}
    for source in sources:
        relative = source.relative_to(root)
        target = snapshot / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
        digest = sha256(source)
        if sha256(target) != digest:
            raise IOError(f'snapshot copy drift: {relative}')
        inventory[relative.as_posix()] = digest
    frozen_config = snapshot / 'configs' / args.config.name
    frozen_config.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.config, frozen_config)
    config_hash = sha256(args.config)
    if sha256(frozen_config) != config_hash:
        raise IOError('config snapshot copy drift')
    manifest = {'source_root': str(root), 'snapshot_root': str(snapshot),
                'source_files': inventory, 'config': f'configs/{args.config.name}',
                'config_sha256': config_hash}
    (destination / 'source_manifest.json').write_text(json.dumps(manifest, indent=2, ensure_ascii=False),
                                                      encoding='utf-8')
    print(json.dumps({'destination': str(destination), 'source_count': len(inventory),
                      'config_sha256': config_hash,
                      'manifest_sha256': sha256(destination / 'source_manifest.json')}))


if __name__ == '__main__':
    main()
