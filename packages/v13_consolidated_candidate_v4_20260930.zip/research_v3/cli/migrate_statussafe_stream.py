"""Make a provenance-recorded copy after the status-only source change.

The old database is read through an immutable SQLite URI and is never opened
writable. The destination must not exist. Existing roots retain their original
source attribution in the migration metadata.
"""

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3

from ..data.own_synthesis import source_hashes
from ..data.stream_solver_dataset import canonical, data_source_hashes


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _original_status_source_hash(path):
    """Reconstruct only the exact pre-change CLI status branch in memory."""
    source = Path(path).read_text(encoding='utf-8')
    start = source.index('    if args.status:\n', source.index('def main():'))
    end = source.index('    connection, manifest = open_store(', start)
    source = source[:start] + source[end:]
    needle = '    try:\n        if args.seal_holdout:\n'
    original = '''    try:
        if args.status:
            rows = connection.execute('SELECT split,COUNT(*) FROM roots GROUP BY split').fetchall()
            seal = connection.execute("SELECT value FROM metadata WHERE key='holdout_seal'").fetchone()
            print(canonical({'manifest': manifest, 'root_counts': dict(rows),
                             'holdout_seal': None if seal is None else json.loads(seal[0])}))
            return
        if args.seal_holdout:
'''
    if source.count(needle) != 1:
        raise ValueError('status-only source diff could not be reconstructed')
    return hashlib.sha256(source.replace(needle, original).encode()).hexdigest()


def migrate(source: Path, destination: Path) -> dict:
    source, destination = Path(source).resolve(), Path(destination).resolve()
    if (not source.is_file() or destination.exists() or
            destination.parent != source.parent or
            any(Path(str(source) + suffix).exists() for suffix in ('-wal', '-shm'))):
        raise ValueError('immutable source, absent sibling destination and no WAL required')
    source_hash_before = sha(source)
    old = sqlite3.connect(source.as_uri() + '?immutable=1', uri=True)
    try:
        stored = old.execute("SELECT value FROM metadata WHERE key='manifest'").fetchone()
        if stored is None:
            raise ValueError('source manifest missing')
        old_manifest = json.loads(stored[0])
        counts = dict(old.execute('SELECT split,COUNT(*) FROM roots GROUP BY split'))
        if counts != {'dev': 128} or old.execute(
                "SELECT 1 FROM metadata WHERE key='holdout_seal'").fetchone():
            raise ValueError('source is not the expected unsealed dev128 snapshot')
    finally:
        old.close()
    current_compiler = source_hashes()
    current_data = data_source_hashes()
    old_data = old_manifest['dataset_source_sha256']
    if (old_manifest['compiler_source_sha256'] != current_compiler or
            set(old_data) != set(current_data) or
            [name for name in old_data if old_data[name] != current_data[name]] !=
            ['data/stream_solver_dataset.py']):
        raise ValueError('migration scope is not exactly the status CLI source')
    source_file = Path(__file__).resolve().parents[1] / 'data/stream_solver_dataset.py'
    if _original_status_source_hash(source_file) != old_data['data/stream_solver_dataset.py']:
        raise ValueError('original pinned source is not reproduced exactly')
    new_manifest = dict(old_manifest)
    new_manifest['dataset_source_sha256'] = current_data
    migration = {
        'schema': 'status_only_source_manifest_migration_v1',
        'original_db_sha256': source_hash_before,
        'original_manifest_sha256': hashlib.sha256(stored[0].encode()).hexdigest(),
        'old_status_module_sha256': old_data['data/stream_solver_dataset.py'],
        'new_status_module_sha256': current_data['data/stream_solver_dataset.py'],
        'existing_root_count_under_original_manifest': counts,
        'change_scope': 'CLI --status uses immutable read-only connection; generation logic unchanged',
        'new_roots_start_after_migration': True,
    }
    shutil.copy2(source, destination)
    if sha(source) != source_hash_before or sha(destination) != source_hash_before:
        raise ValueError('source or copied snapshot changed during transfer')
    target = sqlite3.connect(destination)
    try:
        target.execute('PRAGMA journal_mode=DELETE')
        with target:
            target.execute("UPDATE metadata SET value=? WHERE key='manifest'",
                           (canonical(new_manifest),))
            target.execute("INSERT INTO metadata(key,value) VALUES('source_migration',?)",
                           (canonical(migration),))
    finally:
        target.close()
    if sha(source) != source_hash_before:
        raise ValueError('original database changed during migration')
    return {'source_sha256': source_hash_before,
            'destination_sha256': sha(destination),
            'destination': str(destination),
            'migration': migration}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--destination', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(migrate(args.source, args.destination), sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
