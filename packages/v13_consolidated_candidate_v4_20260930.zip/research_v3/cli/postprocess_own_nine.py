"""Endpoint-preserving local-window ablation on nine own historical programs."""
import argparse
from dataclasses import asdict
from pathlib import Path
import hashlib
import json
from time import perf_counter
from ..contracts import AlphabetSpec,Gate,MatrixState,WordCertificate
from ..data.frozen import historical_states
from ..postprocess import WindowBudget,shorten
from ..words import verify_word


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--stage17-root',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--passes',type=int,required=True)
    parser.add_argument('--max-window',type=int,required=True)
    parser.add_argument('--evaluations',type=int,required=True)
    parser.add_argument('--max-states',type=int,required=True)
    args=parser.parse_args()
    source=args.stage17_root/'improved'/'research_v2'/'baselines.json'
    raw=source.read_bytes(); cases=json.loads(raw)['cases']
    states,_=historical_states(args.stage17_root)
    budget=WindowBudget(args.passes,args.max_window,args.evaluations,args.max_states,True)
    reports=[]
    for case,state in zip(cases,states):
        alphabet=AlphabetSpec.all_to_all(state.n)
        gates=tuple(Gate(*pair) for pair in case['best']['gates'])
        before=WordCertificate(MatrixState.identity(alphabet),state,gates,
                               case['best']['count'],'own_historical_baseline',case['case'])
        verify_word(before,alphabet)
        start=perf_counter();result=shorten(before,alphabet,budget)
        verify_word(result.after,alphabet)
        reports.append({'case':case['case'],'n':state.n,'before_cost':before.physical_cost,
                        'after_cost':result.after.physical_cost,'status':result.status,
                        'evaluations':result.evaluations,'seconds':perf_counter()-start,
                        'after_certificate':asdict(result.after),'window_records':result.window_records})
        print(json.dumps({k:reports[-1][k] for k in ('case','before_cost','after_cost','status','evaluations','seconds')}),flush=True)
    output={'scope':'own historical programs; support-restricted exact local window search; no global optimum claim',
            'source':str(source),'source_sha256':hashlib.sha256(raw).hexdigest(),
            'budget':asdict(budget),'cases':reports}
    with args.output.open('x',encoding='utf-8') as stream:json.dump(output,stream,indent=2)


if __name__=='__main__':main()
