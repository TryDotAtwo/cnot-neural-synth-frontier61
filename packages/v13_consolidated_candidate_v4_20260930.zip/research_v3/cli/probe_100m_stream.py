"""One verified full-neighbor update on the sealed own-solver stream."""
import argparse
import json
from pathlib import Path
from time import perf_counter

import torch

from ..basis.learning import BasisField
from ..contracts import AlphabetSpec
from ..data.stream_reader import admit_complete_neighbors, read_position
from ..data.stream_solver_dataset import open_store
from ..features.registry import FeaturePolicy, FeatureRegistry
from ..features.subspace_views import register_subspace_views
from ..features.basis_gradient import register_basis_gradient
from ..features.diffusion import register_diffusion
from ..model.field import FusionDistanceField
from ..train.objective import FullGraphObjective
from ..train.joint_basis import JointBasisObjective


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--db', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--position', type=int, default=0)
    parser.add_argument('--suffixes-per-root', type=int, default=0)
    parser.add_argument('--neighbor-chunk-size', type=int)
    args = parser.parse_args()
    config = json.loads(args.config.read_text(encoding='utf-8'))
    if args.output.exists():
        raise FileExistsError(args.output)
    torch.set_num_threads(config['threads'])
    connection, manifest = open_store(args.db, seed_base=3700,
                                      expected_dev_roots=1, expected_test_roots=1)
    try:
        records, _ = read_position(connection, 0, args.position,
                                   suffixes_per_root=args.suffixes_per_root)
        admit_complete_neighbors(connection, records)
    finally:
        connection.close()
    registry = FeatureRegistry()
    register_subspace_views(registry)
    register_basis_gradient(registry)
    register_diffusion(registry, **config['diffusion'])
    policy = FeaturePolicy(tuple(config['features']), seed=config['feature_seed'],
                           symmetry_contract=config['feature_symmetry'])
    model = BasisField(FusionDistanceField([registry.specs[k] for k in policy.enabled_ids],
                                                 **config['field']), config['basis_hidden']).cuda().train()
    parameters = sum(p.numel() for p in model.parameters())
    if parameters != config['expected_parameters']:
        raise ValueError('parameter drift')
    optimizer = torch.optim.Adam(model.parameters(), lr=config['learning_rate'])
    alphabet = AlphabetSpec.all_to_all(records[0].state.n)
    base = FullGraphObjective((alphabet,), registry, policy,
                              neighbor_chunk_size=args.neighbor_chunk_size or config['neighbor_chunk_size'])
    objective = JointBasisObjective(base, **config['joint'])
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()
    started = perf_counter()
    loss = objective(model, records)
    loss.backward()
    optimizer.step()
    result = {'schema': '100m_stream_single_update_probe_v1',
              'parameters': parameters, 'state_n': records[0].state.n,
              'position': args.position, 'presentations': len(records),
              'neighbor_chunk_size': base.neighbor_chunk_size,
              'complete_neighbor_candidates': base.last_diagnostics['primitive_candidates'],
              'loss': float(loss.detach()), 'seconds': perf_counter() - started,
              'cuda_peak_allocated_bytes': torch.cuda.max_memory_allocated(),
              'note': 'resource and gradient probe only; no trained model or benchmark claim'}
    args.output.write_text(json.dumps(result, sort_keys=True, indent=2), encoding='utf-8')
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
