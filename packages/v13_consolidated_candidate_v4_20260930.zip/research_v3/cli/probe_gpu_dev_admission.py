"""Read verified own dev records and test exact GPU one-hop admission.

This is a partial dev-only diagnostic. The main 128+128 holdout is not sealed.
"""

import argparse
import hashlib
import json
from pathlib import Path
import sqlite3

import torch

from ..data.stream_reader import decode_record
from ..data.stream_solver_dataset import canonical
from ..gpu.holdout import GpuExactHoldout, admit_complete_neighborhood
from ..gpu.packed_walk import generate_walk_batch, verify_inverse


def _to_cuda_rows(records, n):
    width = (n + 63) // 64
    rows = []
    for record in records:
        encoded = []
        for row in record.state.packed_rows:
            words = []
            for slot in range(width):
                value = (row >> (64 * slot)) & ((1 << 64) - 1)
                words.append(value - (1 << 64) if value >= (1 << 63) else value)
            encoded.append(words)
        rows.append(encoded)
    return torch.tensor(rows, device='cuda', dtype=torch.int64)


def load_verified_dev_rows(path: Path, n: int) -> torch.Tensor:
    if not path.exists():
        raise FileNotFoundError(path)
    connection = sqlite3.connect(path.resolve().as_uri() + '?immutable=1', uri=True)
    try:
        query = '''SELECT matrix_hash,matrix_json,record_json,audit_json,
                          suffix_offsets_json,root_digest FROM roots
                   WHERE split='dev' AND n=? ORDER BY position'''
        entries = connection.execute(query, (n,)).fetchall()
    finally:
        connection.close()
    if not entries:
        raise ValueError('no saved own dev roots at width')
    records = []
    for matrix_hash, matrix_json, record_json, audit_json, offsets_json, digest in entries:
        expected = hashlib.sha256(canonical((matrix_json, record_json, audit_json,
                                             offsets_json)).encode('utf-8')).hexdigest()
        if expected != digest:
            raise ValueError('saved dev root content digest mismatch')
        record = decode_record(record_json)
        identity = canonical(record.state.key)
        if record.split != 'dev' or record.state.n != n or \
                matrix_json != identity or \
                hashlib.sha256(identity.encode('ascii')).hexdigest() != matrix_hash:
            raise ValueError('saved dev matrix identity mismatch')
        records.append(record)
    return _to_cuda_rows(records, n)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', type=Path, required=True)
    parser.add_argument('--n', type=int, default=8)
    parser.add_argument('--candidate-steps', type=int, default=11)
    parser.add_argument('--candidate-seed', type=int, default=3137)
    parser.add_argument('--chunk', type=int, default=16)
    args = parser.parse_args()
    frozen = load_verified_dev_rows(args.db, args.n)
    count = frozen.shape[0]
    required = count * (1 + args.n * (args.n - 1))
    bank = GpuExactHoldout.from_frozen_roots(frozen,
                                             neighbor_chunk=args.chunk,
                                             max_entries=required)
    candidate = generate_walk_batch(args.n, 1, args.candidate_steps,
                                    args.candidate_seed)
    if not bool(verify_inverse(candidate).all().item()):
        raise AssertionError('candidate generation certificate failed')
    admitted = admit_complete_neighborhood(bank, candidate.rows,
                                           chunk_size=args.chunk)
    print(json.dumps({
        'schema': 'gpu_dev_only_exact_one_hop_admission_v1',
        'width': args.n,
        'verified_dev_roots': count,
        'forbidden_parent_and_neighbor_entries': required,
        'candidate_seed': args.candidate_seed,
        'candidate_steps': args.candidate_steps,
        'candidate_parent_and_neighbors_checked': admitted,
        'exact_full_matrix_comparison': True,
        'scope': 'dev-only prefix; test128 and final holdout seal missing',
    }, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
