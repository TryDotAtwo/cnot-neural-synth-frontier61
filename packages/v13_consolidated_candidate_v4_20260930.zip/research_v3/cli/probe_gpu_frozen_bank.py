"""Independently load and query the sealed own holdout on a target GPU."""

import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sqlite3
from time import perf_counter

import torch

from ..contracts import MatrixState
from ..gpu.frozen_bank import _pack_states, load_sealed_own_banks


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--db', type=Path, required=True)
    parser.add_argument('--stage17-root', type=Path, required=True)
    parser.add_argument('--neighbor-chunk', type=int, required=True)
    parser.add_argument('--max-entries-per-width', type=int, required=True)
    args = parser.parse_args()
    torch.cuda.reset_peak_memory_stats()
    started = perf_counter()
    banks, audit = load_sealed_own_banks(
        args.db, args.stage17_root,
        neighbor_chunk=args.neighbor_chunk,
        max_entries_per_width=args.max_entries_per_width)
    connection = sqlite3.connect(args.db.resolve().as_uri() + '?immutable=1', uri=True)
    try:
        by_width = defaultdict(list)
        for (raw,) in connection.execute(
                "SELECT matrix_json FROM roots WHERE split IN ('dev','test')"):
            n, alphabet_id, rows = json.loads(raw)
            by_width[n].append(MatrixState(n, tuple(rows), alphabet_id))
    finally:
        connection.close()
    checked = 0
    for n, states in by_width.items():
        if not bool(banks[n].matches(_pack_states(states, n)).all().item()):
            raise AssertionError('saved held-out root absent from GPU bank')
        checked += len(states)
    print(json.dumps({
        'schema': 'gpu_sealed_own_holdout_bank_probe_v1',
        'compact_db_sha256': hashlib.sha256(args.db.read_bytes()).hexdigest(),
        'heldout_roots_queried_exactly': checked,
        'audit': audit,
        'neighbor_chunk': args.neighbor_chunk,
        'max_entries_per_width': args.max_entries_per_width,
        'seconds': perf_counter() - started,
        'peak_cuda_allocated_bytes': torch.cuda.max_memory_allocated(),
        'scope': 'finite declared views plus all primitive one-hop neighbors; '
                 'no train roots, no neural learning or search'
    }, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
