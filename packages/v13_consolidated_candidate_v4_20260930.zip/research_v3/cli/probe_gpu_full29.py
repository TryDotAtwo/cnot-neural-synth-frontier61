"""One complete-neighbor GPU field update with the configured 29-feature 100M model.

Diagnostic only: the fixed-template option does not execute production joint
basis training; the optional dev-only admission is not the sealed 128+128
holdout. Qhat, teacher, checkpoint, and million-root contracts are absent.
"""

import argparse
import json
from pathlib import Path
from time import perf_counter

import torch

from ..basis.learning import BasisField
from ..features.basis_gradient import register_basis_gradient
from ..features.diffusion import register_diffusion
from ..features.registry import FeatureRegistry
from ..features.subspace_views import register_subspace_views
from ..gpu.field_slice import complete_bellman_slice
from ..gpu.joint_basis_slice import complete_joint_basis_slice
from ..gpu.holdout import GpuExactHoldout, admit_complete_neighborhood
from ..gpu.packed_walk import generate_walk_batch, verify_inverse
from ..model.field import FusionDistanceField
from .probe_gpu_dev_admission import load_verified_dev_rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--n', type=int, default=8)
    parser.add_argument('--steps', type=int, default=11)
    parser.add_argument('--seed', type=int, default=3137)
    parser.add_argument('--joint-basis', action='store_true')
    parser.add_argument('--dev-db', type=Path)
    args = parser.parse_args()
    config = json.loads(args.config.read_text(encoding='utf-8'))
    torch.set_num_threads(config['threads'])
    torch.manual_seed(config['seed'])
    torch.cuda.manual_seed_all(config['seed'])
    walk = generate_walk_batch(args.n, 1, args.steps, args.seed)
    if not bool(verify_inverse(walk).all().item()):
        raise AssertionError('generated root inverse certificate failed')
    admitted = 0
    verified_dev_roots = 0
    if args.dev_db is not None:
        dev_rows = load_verified_dev_rows(args.dev_db, args.n)
        verified_dev_roots = dev_rows.shape[0]
        bank_entries = verified_dev_roots * (1 + args.n * (args.n - 1))
        holdout = GpuExactHoldout.from_frozen_roots(
            dev_rows, neighbor_chunk=config['neighbor_chunk_size'],
            max_entries=bank_entries)
        admitted = admit_complete_neighborhood(
            holdout, walk.rows, chunk_size=config['neighbor_chunk_size'])
    registry = FeatureRegistry()
    register_subspace_views(registry)
    register_basis_gradient(registry)
    register_diffusion(registry, **config['diffusion'])
    feature_ids = tuple(config['features'])
    model = BasisField(FusionDistanceField([registry.specs[key] for key in feature_ids],
                                           **config['field']),
                       config['basis_hidden']).cuda().train()
    parameters = sum(parameter.numel() for parameter in model.parameters())
    if parameters != config['expected_parameters']:
        raise AssertionError('configured parameter count drift')
    optimizer = torch.optim.Adam(model.parameters(), lr=config['learning_rate'])
    torch.cuda.reset_peak_memory_stats()
    start = perf_counter()
    if args.joint_basis:
        loss, joint_audit = complete_joint_basis_slice(
            model, walk.rows, pairs=((0, 1), (1, 0)),
            action_chunk=config['neighbor_chunk_size'],
            samples=config['joint']['samples'], seed=config['joint']['seed'],
            max_evaluations=config['joint']['max_evaluations'],
            max_bytes=config['joint']['max_bytes'], weight=config['joint']['weight'],
            mc_samples=config['diffusion']['mc_samples'],
            max_pair_states=config['diffusion']['max_pair_states'])
        audit = joint_audit['field']
    else:
        loss, audit = complete_bellman_slice(model.field, walk.rows,
                                             action_chunk=config['neighbor_chunk_size'],
                                             mc_samples=config['diffusion']['mc_samples'],
                                             mc_seed=config['feature_seed'],
                                             mc_tau=config['diffusion']['mc_tau'],
                                             max_pair_states=config['diffusion']['max_pair_states'])
    loss.backward()
    field_gradients = {key: model.field.stem.projections[key].weight.grad
                       for key in feature_ids}
    if any(gradient is None for gradient in field_gradients.values()):
        raise AssertionError('configured feature gradient route missing')
    optimizer.step()
    torch.cuda.synchronize()
    print(json.dumps({
        'schema': ('gpu_full29_fixed_template_joint_one_step_diagnostic_v1'
                   if args.joint_basis else
                   'gpu_full29_field_one_step_diagnostic_v2_shared_word_chunk_invariant'),
        'root_n': args.n,
        'generated_walk_steps': args.steps,
        'root_seed': args.seed,
        'model_parameters': parameters,
        'configured_feature_count': len(feature_ids),
        'configured_features': feature_ids,
        'primitive_candidates_checked': audit['candidate_actions_per_root'],
        'root_value': float(audit['root_value'][0].item()),
        'bellman_target': float(audit['bellman_target'][0].item()),
        'loss': float(loss.detach().item()),
        'feature_projections_with_grad': sum(gradient is not None for gradient in field_gradients.values()),
        'feature_projections_with_nonzero_grad': sum(bool((gradient != 0).any().item())
                                                     for gradient in field_gradients.values()),
        'basis_proposer_grad': any(parameter.grad is not None
                                   for parameter in model.proposer.parameters()),
        'verified_dev_roots': verified_dev_roots,
        'gpu_dev_only_parent_and_neighbor_admission_count': admitted,
        'basis_status': joint_audit['basis_status'] if args.joint_basis else 'not_run',
        'basis_cost': float(joint_audit['basis_loss'].item())
                      if args.joint_basis and joint_audit['basis_status'] == 'evaluated' else None,
        'basis_gradient': joint_audit['basis_gradient'].tolist()
                          if args.joint_basis and joint_audit['basis_status'] == 'evaluated' else None,
        'basis_evaluations': joint_audit['basis_evaluations']
                             if args.joint_basis and joint_audit['basis_status'] == 'evaluated' else 0,
        'seconds': perf_counter() - start,
        'peak_cuda_allocated_bytes': torch.cuda.max_memory_allocated(),
        'scope': ('field Bellman plus fixed two-choice paid basis-proposer gradient; '
                  'no production template sampling, Qhat/teacher or sealed holdout admission'
                  if args.joint_basis else
                  'field Bellman only; no joint basis/Qhat/teacher or sealed holdout admission'),
    }, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
