"""Two-root CUDA full29 Bellman plus sampled paid-basis gradient diagnostic."""

import argparse
import json
from pathlib import Path
from time import perf_counter

import torch

from ..basis.learning import BasisField
from ..features.basis_gradient import register_basis_gradient
from ..features.diffusion import register_diffusion
from ..features.registry import FeatureRegistry
from ..features.subspace_views import register_subspace_views
from ..gpu.holdout import GpuExactHoldout
from ..gpu.joint_basis_slice import complete_joint_basis_batch
from ..gpu.packed_walk import generate_walk_batch, verify_inverse
from ..model.field import FusionDistanceField
from .probe_gpu_dev_admission import load_verified_dev_rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--dev-db', type=Path, required=True)
    parser.add_argument('--n', type=int, default=8)
    parser.add_argument('--batch', type=int, default=2)
    parser.add_argument('--steps', type=int, default=11)
    parser.add_argument('--seed', type=int, default=3263)
    args = parser.parse_args()
    config = json.loads(args.config.read_text(encoding='utf-8'))
    torch.set_num_threads(config['threads'])
    torch.manual_seed(config['seed'])
    torch.cuda.manual_seed_all(config['seed'])
    roots = generate_walk_batch(args.n, args.batch, args.steps, args.seed)
    if not bool(verify_inverse(roots).all().item()):
        raise AssertionError('generated root certificates failed')
    frozen = load_verified_dev_rows(args.dev_db, args.n)
    closure_entries = frozen.shape[0] * (1 + args.n * (args.n - 1))
    holdout = GpuExactHoldout.from_frozen_roots(
        frozen, neighbor_chunk=config['neighbor_chunk_size'],
        max_entries=closure_entries)
    registry = FeatureRegistry()
    register_subspace_views(registry)
    register_basis_gradient(registry)
    register_diffusion(registry, **config['diffusion'])
    feature_ids = tuple(config['features'])
    model = BasisField(FusionDistanceField([registry.specs[key] for key in feature_ids],
                                           **config['field']),
                       config['basis_hidden']).cuda().train()
    parameters = sum(parameter.numel() for parameter in model.parameters())
    if parameters != config['expected_parameters']:
        raise AssertionError('configured parameter count drift')
    optimizer = torch.optim.Adam(model.parameters(), lr=config['learning_rate'])
    generator = torch.Generator(device='cuda').manual_seed(config['joint']['seed'])
    torch.cuda.reset_peak_memory_stats()
    started = perf_counter()
    loss, audit = complete_joint_basis_batch(
        model, roots.rows, generator=generator,
        choice_count=config['joint']['choices'],
        action_chunk=config['neighbor_chunk_size'],
        samples=config['joint']['samples'],
        max_evaluations=config['joint']['max_evaluations'],
        max_bytes=config['joint']['max_bytes'],
        weight=config['joint']['weight'], holdout=holdout,
        mc_samples=config['diffusion']['mc_samples'],
        mc_seed=config['feature_seed'],
        max_pair_states=config['diffusion']['max_pair_states'])
    loss.backward()
    feature_gradients = [model.field.stem.projections[key].weight.grad
                         for key in feature_ids]
    if any(gradient is None for gradient in feature_gradients):
        raise AssertionError('missing configured feature gradient')
    proposer_grad = any(parameter.grad is not None and
                        bool((parameter.grad != 0).any().item())
                        for parameter in model.proposer.parameters())
    optimizer.step()
    torch.cuda.synchronize()
    print(json.dumps({
        'schema': 'gpu_full29_batched_joint_dev_only_diagnostic_v1',
        'width': args.n,
        'batch': args.batch,
        'root_seed': args.seed,
        'generated_walk_steps_per_root': args.steps,
        'verified_dev_roots_at_width': frozen.shape[0],
        'dev_closure_entries': closure_entries,
        'admitted_parent_and_neighbors': audit['admitted_parent_and_neighbors'],
        'primitive_candidates_per_root': audit['field']['candidate_actions_per_root'],
        'configured_features': len(feature_ids),
        'model_parameters': parameters,
        'nonzero_feature_projection_gradients': sum(bool((gradient != 0).any().item())
                                                    for gradient in feature_gradients),
        'basis_status': audit['basis_status'],
        'basis_active_count': audit.get('basis_active_count', 0),
        'basis_evaluations': audit['basis_evaluations'],
        'sampled_pairs': audit['sampled_pairs'].tolist()
                         if audit['basis_status'] == 'evaluated' else [],
        'basis_proposer_nonzero_gradient': proposer_grad,
        'loss': float(loss.detach().item()),
        'seconds': perf_counter() - started,
        'peak_cuda_allocated_bytes': torch.cuda.max_memory_allocated(),
        'scope': 'dev-only, full Bellman and batched stochastic paid source basis; '
                 'no sealed test128, Qhat/teacher, checkpoint or full neural program',
    }, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()
