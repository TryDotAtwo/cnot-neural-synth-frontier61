"""Durable full-neighborhood wide GPU joint-step resource profile.

This diagnostic generates an independent own walk on the target GPU. It has no
sealed holdout or search outcome and cannot stand in for protocol training.
There is no wall-clock stopper; action and resource budgets come from config.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path
from time import perf_counter

import torch

from ..basis.learning import BasisField
from ..features.basis_gradient import register_basis_gradient
from ..features.diffusion import register_diffusion
from ..features.registry import FeatureRegistry
from ..features.subspace_views import register_subspace_views
from ..gpu.joint_basis_slice import complete_joint_basis_batch
from ..gpu.packed_walk import generate_walk_batch, verify_inverse
from ..model.field import FusionDistanceField


def _emit(path: Path, record: dict):
    with path.open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(record, sort_keys=True) + '\n')
        stream.flush()
        os.fsync(stream.fileno())


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(4 << 20):
            digest.update(chunk)
    return digest.hexdigest()


def _same_tree(left, right) -> bool:
    if isinstance(left, torch.Tensor):
        return (isinstance(right, torch.Tensor) and left.shape == right.shape and
                left.dtype == right.dtype and
                torch.equal(left, right.to(left.device)))
    if isinstance(left, dict):
        return isinstance(right, dict) and left.keys() == right.keys() and all(
            _same_tree(left[key], right[key]) for key in left)
    if isinstance(left, (list, tuple)):
        return type(left) is type(right) and len(left) == len(right) and all(
            _same_tree(a, b) for a, b in zip(left, right))
    return left == right


def _model(config):
    registry = FeatureRegistry()
    register_subspace_views(registry)
    register_basis_gradient(registry)
    register_diffusion(registry, **config['diffusion'])
    specs = [registry.specs[key] for key in config['features']]
    model = BasisField(FusionDistanceField(specs, **config['field']),
                       config['basis_hidden']).cuda()
    if sum(value.numel() for value in model.parameters()) != config['expected_parameters']:
        raise AssertionError('configured 100M model parameter drift')
    return model


def _verify_saved(checkpoint_path: Path, config: dict, config_sha256: str) -> dict:
    saved = torch.load(checkpoint_path, map_location='cpu', weights_only=False)
    if (saved['schema'] != 'gpu_fullwidth_joint_diagnostic_checkpoint_v1' or
            saved['config_sha256'] != config_sha256):
        raise ValueError('checkpoint schema/config mismatch')
    replica = _model(config)
    replica.load_state_dict(saved['model'])
    replica_optimizer = torch.optim.Adam(replica.parameters(),
                                         lr=config['learning_rate'])
    replica_optimizer.load_state_dict(saved['optimizer'])
    if (not _same_tree(saved['model'], replica.state_dict()) or
            not _same_tree(saved['optimizer'], replica_optimizer.state_dict())):
        raise AssertionError('checkpoint model/optimizer restoration mismatch')
    generator = torch.Generator(device='cuda')
    generator.set_state(saved['basis_generator_rng'])
    if not torch.equal(generator.get_state(), saved['basis_generator_rng']):
        raise AssertionError('checkpoint basis RNG restoration mismatch')
    if not isinstance(saved['cpu_rng'], torch.Tensor) or \
            not isinstance(saved['cuda_rng'], list) or not saved['cuda_rng']:
        raise AssertionError('checkpoint global RNG state missing')
    return {'checkpoint_sha256': _sha256_file(checkpoint_path),
            'checkpoint_model_optimizer_rng_restored': True,
            'checkpoint_n': saved['n'], 'checkpoint_steps': saved['steps']}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--n', type=int, choices=(72, 144), required=True)
    parser.add_argument('--steps', type=int, required=True)
    parser.add_argument('--seed', type=int, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--neighbor-chunk', type=int)
    parser.add_argument('--phase-profile', action='store_true')
    parser.add_argument('--verify-existing', action='store_true')
    args = parser.parse_args()
    if args.steps < 1 or args.seed < 0:
        raise ValueError('positive own word length and nonnegative seed required')
    if args.neighbor_chunk is not None and args.neighbor_chunk < 1:
        raise ValueError('positive neighbor chunk required')
    config_bytes = args.config.read_bytes()
    config = json.loads(config_bytes)
    config_sha256 = hashlib.sha256(config_bytes).hexdigest()
    action_chunk = args.neighbor_chunk or config['neighbor_chunk_size']
    journal = args.out / 'events.jsonl'
    if args.verify_existing:
        checkpoint_path = args.out / 'step1.pt'
        if not checkpoint_path.is_file() or not journal.is_file():
            raise FileNotFoundError('existing checkpoint and journal required')
        torch.set_num_threads(config['threads'])
        report = _verify_saved(checkpoint_path, config, config_sha256)
        if report['checkpoint_n'] != args.n or report['checkpoint_steps'] != args.steps:
            raise ValueError('checkpoint width or word-length mismatch')
        _emit(journal, {'event': 'recovered_checkpoint_verification', **report})
        print(json.dumps(report, sort_keys=True), flush=True)
        return
    args.out.mkdir(parents=True, exist_ok=False)
    _emit(journal, {'event': 'start', 'schema': 'gpu_fullwidth_joint_resource_profile_v1',
                    'n': args.n, 'steps': args.steps, 'seed': args.seed,
                    'neighbor_chunk': action_chunk,
                    'config_sha256': config_sha256,
                    'scope': 'own synthetic full-word training diagnostic; no sealed holdout or search'})
    torch.set_num_threads(config['threads'])
    torch.manual_seed(config['seed'])
    torch.cuda.manual_seed_all(config['seed'])
    generator = torch.Generator(device='cuda')
    generator.manual_seed(config['joint']['seed'])
    walk = generate_walk_batch(args.n, 1, args.steps, args.seed)
    if not bool(verify_inverse(walk).all().item()):
        raise AssertionError('own GPU walk full-matrix certificate failed')
    model = _model(config).train()
    optimizer = torch.optim.Adam(model.parameters(), lr=config['learning_rate'])
    torch.cuda.reset_peak_memory_stats()
    started = perf_counter()
    try:
        torch.cuda.synchronize()
        forward_started = perf_counter()
        loss, audit = complete_joint_basis_batch(
            model, walk.rows, generator=generator,
            choice_count=config['joint']['choices'],
            action_chunk=action_chunk,
            samples=config['joint']['samples'],
            max_evaluations=config['joint']['max_evaluations'],
            max_bytes=config['joint']['max_bytes'],
            weight=config['joint']['weight'],
            qhat_weight=0.1, training_walk=walk,
            supervision_weight=1.0,
            teacher_weight=config['teacher_weight'],
            mc_samples=config['diffusion']['mc_samples'],
            mc_seed=config['feature_seed'],
            max_pair_states=config['diffusion']['max_pair_states'],
            phase_profile=args.phase_profile)
        torch.cuda.synchronize()
        forward_seconds = perf_counter() - forward_started
        backward_started = perf_counter()
        loss.backward()
        torch.cuda.synchronize()
        backward_seconds = perf_counter() - backward_started
        feature_grads = sum(model.field.stem.projections[key].weight.grad is not None
                            for key in config['features'])
        basis_grad = any(parameter.grad is not None
                         for parameter in model.proposer.parameters())
        gradient_norm = torch.sqrt(sum(parameter.grad.detach().square().sum()
                                       for parameter in model.parameters()
                                       if parameter.grad is not None))
        optimizer_started = perf_counter()
        optimizer.step()
        torch.cuda.synchronize()
        optimizer_seconds = perf_counter() - optimizer_started
        step_seconds = perf_counter() - started
        checkpoint = {'schema': 'gpu_fullwidth_joint_diagnostic_checkpoint_v1',
                      'config_sha256': config_sha256,
                      'n': args.n, 'seed': args.seed, 'steps': args.steps,
                      'model': model.state_dict(),
                      'optimizer': optimizer.state_dict(),
                      'cpu_rng': torch.get_rng_state(),
                      'cuda_rng': torch.cuda.get_rng_state_all(),
                      'basis_generator_rng': generator.get_state()}
        tmp = args.out / 'step1.tmp.pt'
        saved = args.out / 'step1.pt'
        torch.save(checkpoint, tmp)
        os.replace(tmp, saved)
        restored = _verify_saved(saved, config, config_sha256)
        if (not _same_tree(model.state_dict(), checkpoint['model']) or
                not _same_tree(optimizer.state_dict(), checkpoint['optimizer']) or
                not torch.equal(checkpoint['basis_generator_rng'], generator.get_state())):
            raise AssertionError('pre-save model/optimizer/RNG drift')
        _emit(journal, {'event': 'complete', 'n': args.n, 'steps': args.steps,
                        'candidate_actions_per_root': audit['field']['candidate_actions_per_root'],
                        'neighbor_chunk': action_chunk,
                        'phase_seconds': audit['field']['phase_seconds'],
                        'forward_seconds': forward_seconds,
                        'backward_seconds': backward_seconds,
                        'optimizer_seconds': optimizer_seconds,
                        'feature_projections_with_grad': feature_grads,
                        'selected_action_ids': audit['field']['selected_action_ids'].cpu().tolist(),
                        'root_values': audit['field']['root_value'].cpu().tolist(),
                        'bellman_targets': audit['field']['bellman_target'].cpu().tolist(),
                        'gradient_l2': float(gradient_norm.item()),
                        'basis_proposer_with_grad': basis_grad,
                        'basis_status': audit['basis_status'],
                        'loss': float(loss.detach().item()),
                        'step_seconds': step_seconds,
                        'total_seconds': perf_counter() - started,
                        'peak_cuda_allocated_bytes': torch.cuda.max_memory_allocated(),
                        'checkpoint_sha256': restored['checkpoint_sha256'],
                        'checkpoint_model_optimizer_rng_restored':
                            restored['checkpoint_model_optimizer_rng_restored']})
    except BaseException as error:
        _emit(journal, {'event': 'failure', 'n': args.n,
                        'error_type': type(error).__name__, 'error': str(error),
                        'elapsed_seconds': perf_counter() - started,
                        'peak_cuda_allocated_bytes': torch.cuda.max_memory_allocated()})
        raise


if __name__ == '__main__':
    main()
