"""One admitted 100M full29 joint update on transferred own train records.

This is an integration gate for the sealed holdout and data transfer. It is not
a trained synthesizer or a benchmark-quality measurement.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path
import sqlite3
from time import perf_counter

import torch

from ..data.stream_reader import decode_record
from ..data.stream_solver_dataset import canonical, matrix_identity, root_key
from ..gpu.frozen_bank import load_sealed_own_banks
from ..gpu.holdout import admit_complete_neighborhood
from ..gpu.joint_basis_slice import complete_joint_basis_batch
from ..gpu.record_batch import own_records_to_cuda
from .probe_gpu_fullwidth_joint import _model, _same_tree, _sha256_file


def _emit(path: Path, value: dict):
    with path.open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(value, sort_keys=True) + '\n')
        stream.flush()
        os.fsync(stream.fileno())


def _read_transfer(path: Path, db: Path, width: int):
    raw = path.read_bytes()
    payload = json.loads(raw)
    if payload.get('schema') != 'own_verified_train_subset_transfer_v1' or \
            payload.get('count') != len(payload.get('records', ())) or \
            payload.get('first_epoch') != 0:
        raise ValueError('invalid own train transfer envelope')
    connection = sqlite3.connect(db.resolve().as_uri() + '?immutable=1', uri=True)
    try:
        metadata = dict(connection.execute(
            "SELECT key,value FROM metadata WHERE key IN ('manifest','holdout_seal')"))
    finally:
        connection.close()
    if (set(metadata) != {'manifest', 'holdout_seal'} or
            hashlib.sha256(metadata['manifest'].encode()).hexdigest() !=
            payload['manifest_sha256'] or
            hashlib.sha256(metadata['holdout_seal'].encode()).hexdigest() !=
            payload['holdout_seal_sha256']):
        raise ValueError('transfer and sealed holdout metadata mismatch')
    selected = []
    selected_digests = []
    selected_positions = []
    for position, item in enumerate(payload['records']):
        if item['epoch'] != 0 or item['position'] != position:
            raise ValueError('noncontiguous own train positions')
        record = decode_record(item['record_json'])
        digest = hashlib.sha256(canonical((item['matrix_json'], item['record_json'],
                                           item['audit_json'], item['suffix_offsets_json']))
                                .encode('utf-8')).hexdigest()
        if (record.split != 'train' or matrix_identity(record) != item['matrix_json'] or
                root_key(record) != item['matrix_hash'] or digest != item['root_digest']):
            raise ValueError('own train root digest or identity mismatch')
        if record.state.n == width:
            selected.append(record)
            selected_digests.append(digest)
            selected_positions.append(position)
    if not selected:
        raise ValueError('no own train roots at selected width')
    return selected, selected_digests, selected_positions, hashlib.sha256(raw).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--train-json', type=Path, required=True)
    parser.add_argument('--db', type=Path, required=True)
    parser.add_argument('--stage17-root', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--width', type=int, default=8)
    parser.add_argument('--neighbor-chunk', type=int, default=32)
    parser.add_argument('--max-entries-per-width', type=int, default=5000000)
    args = parser.parse_args()
    if args.width < 2 or args.neighbor_chunk < 1:
        raise ValueError('positive training width and neighbor chunk required')
    args.out.mkdir(parents=True, exist_ok=False)
    journal = args.out / 'events.jsonl'
    started = perf_counter()
    _emit(journal, {'event': 'start', 'schema': 'gpu_admitted_own_train_joint_probe_v1',
                    'width': args.width, 'neighbor_chunk': args.neighbor_chunk,
                    'scope': 'one own-record joint step, no neural quality claim'})
    try:
        config_bytes = args.config.read_bytes()
        config = json.loads(config_bytes)
        torch.set_num_threads(config['threads'])
        torch.manual_seed(config['seed'])
        torch.cuda.manual_seed_all(config['seed'])
        records, digests, positions, transfer_sha = _read_transfer(
            args.train_json, args.db, args.width)
        bank_started = perf_counter()
        banks, bank_audit = load_sealed_own_banks(
            args.db, args.stage17_root, neighbor_chunk=args.neighbor_chunk,
            max_entries_per_width=args.max_entries_per_width)
        bank_seconds = perf_counter() - bank_started
        if args.width not in banks:
            raise ValueError('selected width absent from sealed holdout')
        gpu_batch = own_records_to_cuda(records)
        admission_started = perf_counter()
        admitted = admit_complete_neighborhood(
            banks[args.width], gpu_batch.walk.rows,
            chunk_size=args.neighbor_chunk)
        admission_seconds = perf_counter() - admission_started
        model = _model(config).train()
        optimizer = torch.optim.Adam(model.parameters(), lr=config['learning_rate'])
        generator = torch.Generator(device='cuda')
        generator.manual_seed(config['joint']['seed'])
        torch.cuda.reset_peak_memory_stats()
        torch.cuda.synchronize()
        forward_started = perf_counter()
        loss, audit = complete_joint_basis_batch(
            model, gpu_batch.walk.rows, generator=generator,
            choice_count=config['joint']['choices'],
            action_chunk=args.neighbor_chunk,
            samples=config['joint']['samples'],
            max_evaluations=config['joint']['max_evaluations'],
            max_bytes=config['joint']['max_bytes'],
            weight=config['joint']['weight'], qhat_weight=0.1,
            training_walk=gpu_batch.walk,
            supervision_weight=1.0, teacher_weight=config['teacher_weight'],
            holdout=banks[args.width], mc_samples=config['diffusion']['mc_samples'],
            mc_seed=config['feature_seed'],
            max_pair_states=config['diffusion']['max_pair_states'],
            phase_profile=True)
        torch.cuda.synchronize()
        forward_seconds = perf_counter() - forward_started
        loss.backward()
        torch.cuda.synchronize()
        optimizer.step()
        torch.cuda.synchronize()
        if not bool(torch.isfinite(loss).item()):
            raise ValueError('nonfinite admitted own train loss')
        checkpoint = {
            'schema': 'gpu_admitted_own_train_checkpoint_v1',
            'config_sha256': hashlib.sha256(config_bytes).hexdigest(),
            'transfer_sha256': transfer_sha, 'selected_root_digests': digests,
            'width': args.width, 'data_cursor': {'epoch': 0, 'positions': positions},
            'model': model.state_dict(), 'optimizer': optimizer.state_dict(),
            'cpu_rng': torch.get_rng_state(), 'cuda_rng': torch.cuda.get_rng_state_all(),
            'basis_generator_rng': generator.get_state()}
        temp = args.out / 'step1.tmp.pt'
        saved = args.out / 'step1.pt'
        torch.save(checkpoint, temp)
        os.replace(temp, saved)
        restored = torch.load(saved, map_location='cpu', weights_only=False)
        if (not _same_tree(checkpoint['model'], restored['model']) or
                not _same_tree(checkpoint['optimizer'], restored['optimizer']) or
                not _same_tree(checkpoint['basis_generator_rng'], restored['basis_generator_rng'])):
            raise AssertionError('own admitted train checkpoint changed on disk')
        _emit(journal, {'event': 'complete', 'width': args.width,
                        'selected_train_roots': len(records),
                        'train_transfer_sha256': transfer_sha,
                        'selected_root_digests': digests,
                        'heldout_roots_queried_exactly': bank_audit['dev_roots'] +
                                                         bank_audit['test_roots'],
                        'bank_seconds': bank_seconds,
                        'admission_seconds': admission_seconds,
                        'admitted_parent_and_neighbors': admitted,
                        'joint_admission_count': audit['admitted_parent_and_neighbors'],
                        'candidate_actions_per_root': audit['field']['candidate_actions_per_root'],
                        'forward_seconds': forward_seconds,
                        'full_neighbor_seconds': audit['field']['phase_seconds']['complete_neighbor_forward'],
                        'loss': float(loss.detach().item()),
                        'qhat_loss': float(audit['qhat_loss'].item()),
                        'interval_loss': float(audit['interval_loss'].item()),
                        'teacher_loss': float(audit['teacher_loss'].item()),
                        'basis_status': audit['basis_status'],
                        'peak_cuda_allocated_bytes': torch.cuda.max_memory_allocated(),
                        'checkpoint_sha256': _sha256_file(saved),
                        'checkpoint_model_optimizer_rng_restored': True,
                        'total_seconds': perf_counter() - started})
    except BaseException as error:
        _emit(journal, {'event': 'failure', 'error_type': type(error).__name__,
                        'error': str(error), 'elapsed_seconds': perf_counter() - started})
        raise


if __name__ == '__main__':
    main()
