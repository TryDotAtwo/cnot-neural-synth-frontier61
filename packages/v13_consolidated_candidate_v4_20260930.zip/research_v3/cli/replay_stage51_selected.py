"""Read-only replay of the stage51 selected-mode independent checker.

Does not replace the source's 544-mode producer or overwrite saved results.
"""
import argparse
import importlib.util
import json
from pathlib import Path
from time import perf_counter


def replay(source_root):
    root = Path(source_root)
    spec = importlib.util.spec_from_file_location("frontier51_independent", root / "verify_independent.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    start = perf_counter()
    frames, index, permutations = module.build()
    if len(frames) != 20160:
        raise AssertionError("stage51 four-row frame count differs")
    chosen = ((312, 24, ((0, 0), (1, 2), (3, 15), (7, 11), (15, 15))),
              (13, 128, ((0, 0), (3, 15))))
    records = []
    for denominator, order, pairs in chosen:
        for eta in (1, 0):
            file = root / "results" / f"cheb_d{denominator}_k{order}_eta{eta}.tsv"
            _, values = module.records(file)
            for i, j in pairs:
                coordinates = module.check_mode(frames, index, permutations,
                                                i, j, denominator, order, eta, values[(i, j)])
                records.append({"denominator": denominator, "order": order,
                                "eta": eta, "i": i, "j": j,
                                "coordinates_checked": coordinates})
    return {"selected_modes": len(records), "coordinate_identities": sum(r["coordinates_checked"] for r in records),
            "four_row_frames": len(frames), "elapsed_seconds": perf_counter() - start,
            "scope": "read-only replay of original independent selected-mode checker; not all 544 source mode values",
            "records": records}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("source_root")
    parser.add_argument("--output")
    args = parser.parse_args()
    report = replay(args.source_root)
    if args.output:
        destination = Path(args.output)
        if destination.exists():
            raise FileExistsError(destination)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: report[key] for key in ("selected_modes", "coordinate_identities", "elapsed_seconds", "scope")}))
