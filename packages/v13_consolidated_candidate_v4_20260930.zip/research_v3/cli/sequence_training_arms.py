"""Wait for the live pilot, then run the two matched GPU arms sequentially.

No job is restarted or replaced automatically. Every transition is fsynced.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

import psutil


EXPECTED_DATASET_SHA = '55420c70580947298fbe295832dee6d4bacd8ada221fccd54594640ba2da53a5'
ARMS = (
    ('rich26', 'rich_structure_source_v6', 'joint_rich_structure_2700.json', 'joint_rich_structure_2700'),
    ('rich29', 'rich_basis_gradient_source_v3', 'joint_rich_basis_gradient_2700.json',
     'joint_rich_basis_gradient_2700'),
)


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def event(stream, kind, **details):
    row = {'time_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
           'event': kind, **details}
    stream.write(json.dumps(row, sort_keys=True)+'\n')
    stream.flush(); os.fsync(stream.fileno())
    print(json.dumps(row), flush=True)


def verify_snapshot(path, config_name):
    manifest_path = path / 'source_manifest.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    source = path / 'research_v3'
    if Path(manifest['snapshot_root']).resolve() != source.resolve():
        raise ValueError('snapshot root mismatch')
    for relative, expected in manifest['source_files'].items():
        if sha256(source / relative) != expected:
            raise ValueError('snapshot source drift: '+relative)
    config = source / 'configs' / config_name
    if manifest['config'] != f'configs/{config_name}' or sha256(config) != manifest['config_sha256']:
        raise ValueError('snapshot config drift')
    return manifest, config


def check_pilot(run_dir):
    completion_path = run_dir / 'completion.json'
    if not completion_path.exists():
        return False
    completion = json.loads(completion_path.read_text(encoding='utf-8'))
    if completion.get('status') != 'completed' or completion['progress']['attempted'] != 640:
        raise ValueError('pilot completion does not certify 640 updates')
    last = json.loads((run_dir / 'last.json').read_text(encoding='utf-8'))
    if last['progress']['attempted'] != 640 or sha256(run_dir / last['file']) != last['sha256']:
        raise ValueError('pilot final checkpoint hash/progress mismatch')
    return True


def gpu_pids():
    query = subprocess.run(['nvidia-smi', '--query-compute-apps=pid', '--format=csv,noheader'],
                           capture_output=True, text=True, check=True)
    return {int(line.strip()) for line in query.stdout.splitlines() if line.strip().isdigit()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pilot-pid', type=int, required=True)
    parser.add_argument('--poll-seconds', type=int, default=30)
    parser.add_argument('--preflight-only', action='store_true')
    args = parser.parse_args()
    if args.poll_seconds < 5:
        raise ValueError('poll interval too short')
    root = Path(__file__).resolve().parents[1]
    artifacts = root / 'artifacts'
    runs = artifacts / 'runs'
    pilot_run = runs / 'joint_g_source_independent_pilot_2700'
    dataset = artifacts / 'evidence' / '2026-09-27-development-v2-matching.json'
    if sha256(dataset) != EXPECTED_DATASET_SHA:
        raise ValueError('dataset SHA drift')
    if shutil.disk_usage(root).free < 2_000_000_000:
        raise OSError('less than 2 GB free on training disk')
    pilot_manifest = json.loads((pilot_run / 'experiment_manifest.json').read_text(encoding='utf-8'))
    if pilot_manifest['pid'] != args.pilot_pid or pilot_manifest['versions']['dataset_sha256'] != EXPECTED_DATASET_SHA:
        raise ValueError('pilot PID/dataset provenance mismatch')
    snapshots = []
    for name, directory, config_name, run_name in ARMS:
        source_dir = artifacts / directory
        manifest, config_path = verify_snapshot(source_dir, config_name)
        run_dir = runs / run_name
        if run_dir.exists():
            raise FileExistsError('arm run directory already exists: '+str(run_dir))
        snapshots.append((name, source_dir, manifest, config_path, run_dir))
    if snapshots[0][2]['source_files'] != snapshots[1][2]['source_files']:
        raise ValueError('paired arm source hashes differ')
    pilot = psutil.Process(args.pilot_pid)
    pilot_created = pilot.create_time()
    if args.preflight_only:
        print(json.dumps({'preflight': 'passed', 'pilot_live': pilot.is_running(),
                          'pilot_created': pilot_created, 'dataset_sha256': EXPECTED_DATASET_SHA,
                          'paired_source_files': len(snapshots[0][2]['source_files']),
                          'gpu_pids': sorted(gpu_pids())}))
        return 0
    journal = runs / 'rich_arms_sequence_2700.jsonl'
    with journal.open('x', encoding='utf-8') as stream:
        event(stream, 'preflight_passed', pilot_pid=args.pilot_pid, pilot_created=pilot_created,
              dataset_sha256=EXPECTED_DATASET_SHA,
              snapshots=[{'arm': name, 'manifest_sha256': sha256(path / 'source_manifest.json')}
                         for name, path, _, _, _ in snapshots])
        while True:
            try:
                live = pilot.is_running() and pilot.create_time() == pilot_created
            except psutil.Error:
                live = False
            if not live:
                if not check_pilot(pilot_run):
                    event(stream, 'stopped', reason='pilot process exited without verified completion')
                    return 2
                event(stream, 'pilot_verified_complete')
                break
            time.sleep(args.poll_seconds)
        for name, source_dir, _, config_path, run_dir in snapshots:
            while True:
                occupied = gpu_pids()
                if not occupied:
                    break
                time.sleep(args.poll_seconds)
            if run_dir.exists():
                raise FileExistsError('arm run directory appeared while waiting: '+str(run_dir))
            run_dir.mkdir()
            command = [sys.executable, '-m', 'research_v3.cli.train_joint',
                       '--config', str(config_path), '--dataset', str(dataset),
                       '--run-dir', str(run_dir)]
            env = os.environ.copy()
            env['PYTHONPATH'] = str(source_dir)
            flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
            with (run_dir / 'stdout.log').open('x', encoding='utf-8') as out, \
                 (run_dir / 'stderr.log').open('x', encoding='utf-8') as err:
                child = subprocess.Popen(command, cwd=source_dir, env=env, stdout=out, stderr=err,
                                         creationflags=flags)
                event(stream, 'arm_started', arm=name, pid=child.pid, run_dir=str(run_dir))
                code = child.wait()
            completion_path = run_dir / 'completion.json'
            if code != 0 or not completion_path.exists():
                event(stream, 'stopped', arm=name, pid=child.pid, exit_code=code,
                      reason='arm failed or missing completion')
                return 3
            completion = json.loads(completion_path.read_text(encoding='utf-8'))
            last = json.loads((run_dir / 'last.json').read_text(encoding='utf-8'))
            if (completion.get('status') != 'completed' or completion['progress']['attempted'] != 640 or
                    last['progress']['attempted'] != 640 or sha256(run_dir / last['file']) != last['sha256']):
                event(stream, 'stopped', arm=name, reason='arm completion/checkpoint verification failed')
                return 4
            event(stream, 'arm_verified_complete', arm=name, checkpoint_sha256=last['sha256'])
        event(stream, 'sequence_complete')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
