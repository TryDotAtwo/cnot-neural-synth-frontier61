"""Recheck complete comparison words and render an honest own-matrix table."""
import argparse
import hashlib
import json
from pathlib import Path

from .compare_full_programs import own_cases


def replay_serial(root, alphabet, word):
    if word is None:
        return None
    gates = word['gates']
    if word['length'] != len(gates):
        raise ValueError('serialized length mismatch')
    rows = list(root.packed_rows)
    cost = 0
    for gate in gates:
        if (len(gate) != 2 or any(type(i) is not int for i in gate) or
                gate[0] == gate[1] or min(gate) < 0 or max(gate) >= root.n):
            raise ValueError('invalid serialized gate')
        c, t = gate
        rows[t] ^= rows[c]
        # own_cases constructs the all-to-all unit-cost alphabet.
        cost += 1
    if tuple(rows) != tuple(1 << i for i in range(root.n)) or cost != word['physical_cost']:
        raise ValueError('serialized full-matrix/cost replay mismatch')
    return cost


def summarize(journal, own_manifest):
    lines = Path(journal).read_text(encoding='utf-8').splitlines()
    if not lines:
        raise ValueError('empty comparison journal')
    header = json.loads(lines[0])['header']
    manifest_sha = hashlib.sha256(Path(own_manifest).read_bytes()).hexdigest()
    if header['own_manifest_sha256'] != manifest_sha:
        raise ValueError('own manifest SHA drift')
    cases = {case['case']: (case, root, alphabet)
             for case, root, alphabet in own_cases(own_manifest)}
    results = {}
    for line in lines[1:]:
        report = json.loads(line)
        name = report['case']
        if name in results or name not in cases:
            raise ValueError('duplicate or unknown comparison case')
        case, root, alphabet = cases[name]
        if report['matrix_sha256'] != case['canonical_sha256'] or report['n'] != root.n:
            raise ValueError('comparison matrix mismatch')
        if report['own_reference_upper_bound'] != case['upper_bound']:
            raise ValueError('own reference upper bound mismatch')
        neural = report['raw_neural']
        hamming = report['hamming']
        if neural['budget'] != hamming['budget']:
            raise ValueError('raw neural and Hamming search budgets differ')
        if report.get('qhat_neural') is not None and neural['budget'] != report['qhat_neural']['budget']:
            raise ValueError('raw neural and Qhat search budgets differ')
        if report.get('compiler_assisted') is not None:
            assisted_budget = report['compiler_assisted']['budget']
            for key, value in neural['budget'].items():
                if assisted_budget.get(key) != value:
                    raise ValueError('compiler-assisted primitive search budget differs')
        for arm in ('raw_neural', 'hamming'):
            replay_serial(root, alphabet, report[arm]['word'])
        if report.get('qhat_neural') is not None:
            replay_serial(root, alphabet, report['qhat_neural']['word'])
        if report['postprocess'] is not None:
            replay_serial(root, alphabet, report['postprocess']['word'])
        if report.get('compiler_assisted') is not None:
            replay_serial(root, alphabet, report['compiler_assisted']['word'])
        if report['portfolio'] is not None:
            replay_serial(root, alphabet, report['portfolio']['word'])
            source = report['portfolio']['source']
            source_word = (report['postprocess']['word'] if source == 'postprocess'
                           else report['compiler_assisted']['word'] if source == 'compiler_assisted'
                           else report[source]['word'] if source in ('raw_neural', 'qhat_neural', 'hamming') else None)
            if source_word != report['portfolio']['word']:
                raise ValueError('portfolio attribution mismatch')
        available = [report[arm]['word'] for arm in ('raw_neural', 'hamming')]
        if report.get('qhat_neural') is not None:
            available.append(report['qhat_neural']['word'])
        available.extend([None if report['postprocess'] is None else report['postprocess']['word'],
                          None if report.get('compiler_assisted') is None else report['compiler_assisted']['word']])
        available = [word for word in available if word is not None]
        expected_best = min((word['physical_cost'] for word in available), default=None)
        observed_best = None if report['portfolio'] is None else report['portfolio']['word']['physical_cost']
        if observed_best != expected_best:
            raise ValueError('portfolio omits or overstates the best available word')
        results[name] = report
    return header, cases, results


def markdown_table(header, cases, results):
    def length(item, status=None):
        if item is not None:
            return str(item['length'])
        return '—' if status is None else f'— ({status})'
    source_names = {'raw_neural': 'raw V', 'qhat_neural': 'neural Qhat',
                    'hamming': 'Hamming', 'postprocess': 'raw V + windows',
                    'compiler_assisted': 'neural + basis'}
    rows = ['# Complete CNOT program comparison on own fixed matrices', '',
            f"Checkpoint SHA256: `{header['checkpoint_sha256']}`. ",
            f"Own matrix manifest SHA256: `{header['own_manifest_sha256']}`. ",
            'Every listed word was replayed again from its full packed matrix. ',
            'Missing programs are shown as —. External deltas require an independently matched target matrix.', '',
            '| Case | n | Own UB | Raw V | Neural Qhat | NN + windows | NN + basis | Hamming | Portfolio | Winner | Δ vs own UB | External Δ |',
            '|---|---:|---:|---:|---:|---:|---:|---:|---:|---|---:|---:|']
    for name, (case, root, _) in cases.items():
        report = results.get(name)
        if report is None:
            rows.append(f"| {name} | {root.n} | {case['upper_bound']} | — | — | — | — | — | — | — | — | — |")
            continue
        raw = report['raw_neural']['word']
        qhat = None if report.get('qhat_neural') is None else report['qhat_neural']['word']
        post = None if report['postprocess'] is None else report['postprocess']['word']
        compiler = None if report.get('compiler_assisted') is None else report['compiler_assisted']['word']
        ham = report['hamming']['word']
        portfolio = None if report['portfolio'] is None else report['portfolio']['word']
        winner = '—' if report['portfolio'] is None else source_names[report['portfolio']['source']]
        delta = '—' if portfolio is None else str(portfolio['physical_cost'] - case['upper_bound'])
        rows.append(f"| {name} | {root.n} | {case['upper_bound']} | "
                    f"{length(raw, report['raw_neural']['status'])} | "
                    f"{length(qhat, None if report.get('qhat_neural') is None else report['qhat_neural']['status'])} | {length(post)} | "
                    f"{length(compiler, None if report.get('compiler_assisted') is None else report['compiler_assisted']['status'])} | "
                    f"{length(ham, report['hamming']['status'])} | {length(portfolio)} | {winner} | {delta} | — |")
    rows.extend(['', 'Portfolio is the shortest verified word among the measured arms; Winner names its source. ',
                 'Δ vs own UB is portfolio physical cost minus the verified own reference upper bound. ',
                 'This is a comparison on our fixed matrices; it is not an external-paper delta or an optimality claim.',
                 '', '## Per-case search time (seconds)', '',
                 '| Case | Raw V | Neural Qhat | Hamming | Windows | Basis assisted |',
                 '|---|---:|---:|---:|---:|---:|'])
    for name in cases:
        report = results.get(name)
        if report is None:
            rows.append(f'| {name} | — | — | — | — | — |')
            continue
        post = report['postprocess']
        compiler = report.get('compiler_assisted')
        rows.append(f"| {name} | {report['raw_neural']['search_seconds']:.3f} | "
                    f"{'—' if report.get('qhat_neural') is None else format(report['qhat_neural']['search_seconds'], '.3f')} | "
                    f"{report['hamming']['search_seconds']:.3f} | "
                    f"{'—' if post is None else format(post['seconds'], '.3f')} | "
                    f"{'—' if compiler is None else format(compiler['search_seconds'], '.3f')} |")
    rows.extend(['', '## Primitive neural compute', '',
                 '| Case | Arm | Value states | Value forwards | Action forwards | Feature packets |',
                 '|---|---|---:|---:|---:|---:|'])
    for name in cases:
        report = results.get(name)
        if report is None:
            continue
        for arm in ('raw_neural', 'qhat_neural', 'hamming'):
            if report.get(arm) is None:
                continue
            counts = report[arm]['counts']
            metric = lambda key: str(counts[key]) if key in counts else '—'
            rows.append(f"| {name} | {source_names[arm]} | {metric('value_evaluations')} | "
                        f"{metric('value_model_forwards')} | {metric('action_model_forwards')} | "
                        f"{metric('primitive_feature_packet_builds')} |")
    rows.extend(['', 'Primitive counters exclude separate paid-basis proposer and compiler calls, '
                 'which are recorded in the per-case JSON.'])
    return '\n'.join(rows)+'\n'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--journal', type=Path, required=True)
    parser.add_argument('--own-manifest', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    header, cases, results = summarize(args.journal, args.own_manifest)
    args.output.write_text(markdown_table(header, cases, results), encoding='utf-8')
    print(json.dumps({'verified_cases': len(results), 'known_cases': len(cases),
                      'output': str(args.output)}))


if __name__ == '__main__':
    main()
