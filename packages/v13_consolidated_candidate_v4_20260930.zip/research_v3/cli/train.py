import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import random
import sys
import numpy as np
import torch
from ..contracts import AlphabetSpec
from ..data.frozen import load
from ..features.registry import FeaturePolicy, FeatureRegistry
from ..model.field import FusionDistanceField
from ..train.objective import FullGraphObjective
from ..train.runner import TrainingConfig, train_reference


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--dataset', type=Path, required=True)
    parser.add_argument('--run-dir', type=Path, required=True)
    parser.add_argument('--resume', type=Path)
    args = parser.parse_args()
    config = json.loads(args.config.read_text(encoding='utf-8'))
    if config['device'] == 'cuda' and not torch.cuda.is_available():
        raise RuntimeError('requested CUDA unavailable; no silent CPU substitution')
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
    torch.set_num_threads(config['threads'])
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.use_deterministic_algorithms(True)
    random.seed(config['seed']); np.random.seed(config['seed']); torch.manual_seed(config['seed'])
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(config['seed'])
    panels, forbidden, dataset_manifest = load(args.dataset)
    registry = FeatureRegistry()
    policy = FeaturePolicy(tuple(config['features']))
    model = FusionDistanceField([registry.specs[k] for k in policy.enabled_ids], **config['model']).to(config['device'])
    model.train()
    optimizer = torch.optim.Adam(model.parameters(), lr=config['learning_rate'])
    alphabets = tuple(AlphabetSpec.all_to_all(n) for n in sorted({r.state.n for r in panels['train']}))
    objective = FullGraphObjective(alphabets, registry, policy, forbidden_keys=forbidden,
                                   neighbor_chunk_size=config['neighbor_chunk_size'])
    root = Path(__file__).resolve().parents[1]
    sources = {str(path.relative_to(root)):hashlib.sha256(path.read_bytes()).hexdigest()
               for path in sorted(root.rglob('*.py'))}
    versions = {'code':sources, 'dataset_sha256':hashlib.sha256(args.dataset.read_bytes()).hexdigest(),
                'launch_config':config, 'torch':str(torch.__version__), 'python':platform.python_version(),
                'numpy':np.__version__, 'cuda':torch.version.cuda}
    training = TrainingConfig(config['updates'], config['batch_size'], config['seed'],
                              config['checkpoint_every'], objective.config['id'], versions)
    args.run_dir.mkdir(parents=True, exist_ok=True)
    manifest = {'config':config, 'versions':versions, 'parameters':sum(p.numel() for p in model.parameters()),
                'device_name':torch.cuda.get_device_name() if config['device'] == 'cuda' else platform.processor(),
                'pid':os.getpid(), 'train_roots':len(panels['train']), 'dev_roots':len(panels['dev']),
                'claim_scope':'development training; no confirmatory result or benchmark improvement',
                'dataset_provenance':dataset_manifest['provenance']}
    if args.resume is None:
        with (args.run_dir/'experiment_manifest.json').open('x', encoding='utf-8') as stream:
            json.dump(manifest, stream, indent=2)
    print(json.dumps({'started':True, 'pid':os.getpid(), 'parameters':manifest['parameters'],
                      'updates':config['updates'], 'train_roots':len(panels['train'])}), flush=True)
    result = train_reference(model, optimizer, panels['train'], objective, training, args.run_dir, resume=args.resume)
    result['exposure_audit'] = objective.audit()
    result['cuda_peak_allocated_bytes'] = torch.cuda.max_memory_allocated() if config['device'] == 'cuda' else None
    with (args.run_dir/'completion.json').open('x', encoding='utf-8') as stream:
        json.dump(result, stream, indent=2)
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
