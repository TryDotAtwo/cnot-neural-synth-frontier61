"""Own-solver million-root schedule with full-graph gradients and durable cursor."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import random
from functools import partial

import numpy as np
import torch

from ..basis.learning import BasisField
from ..contracts import AlphabetSpec
from ..data.stream_reader import admit_operator
from ..data.exact_stream import ExactStreamSampler
from ..data.stream_solver_dataset import open_store, SIZES
from ..features.registry import FeaturePolicy, FeatureRegistry
from ..features.subspace_views import register_subspace_views
from ..features.basis_gradient import register_basis_gradient
from ..features.diffusion import register_diffusion
from ..model.field import FusionDistanceField
from ..train.objective import FullGraphObjective
from ..train.joint_basis import JointBasisObjective
from ..train.stream_runner import StreamTrainingConfig, train_stream


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--db', type=Path, required=True)
    parser.add_argument('--run-dir', type=Path, required=True)
    parser.add_argument('--resume', type=Path)
    parser.add_argument('--stop-after-roots', type=int)
    args = parser.parse_args()
    config = json.loads(args.config.read_text(encoding='utf-8'))
    if not args.db.is_file():
        raise FileNotFoundError(args.db)
    if config['device'] == 'cuda' and not torch.cuda.is_available():
        raise RuntimeError('requested CUDA unavailable')
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG', ':4096:8')
    torch.set_num_threads(config['threads'])
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.use_deterministic_algorithms(True)
    random.seed(config['seed'])
    np.random.seed(config['seed'])
    torch.manual_seed(config['seed'])
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(config['seed'])
    connection, manifest = open_store(args.db, seed_base=config['stream']['seed_base'],
                                      expected_dev_roots=config['expected_dev_roots'],
                                      expected_test_roots=config['expected_test_roots'])
    try:
        if connection.execute("SELECT 1 FROM metadata WHERE key='holdout_seal'").fetchone() is None:
            raise ValueError('dev/test and historical holdout must be sealed first')
        registry = FeatureRegistry()
        register_subspace_views(registry)
        register_basis_gradient(registry)
        register_diffusion(registry, **config['diffusion'])
        policy = FeaturePolicy(tuple(config['features']), seed=config['feature_seed'],
                               symmetry_contract=config['feature_symmetry'])
        field = FusionDistanceField([registry.specs[key] for key in policy.enabled_ids],
                                    **config['field'])
        model = BasisField(field, config['basis_hidden']).to(config['device']).train()
        parameters = sum(parameter.numel() for parameter in model.parameters())
        if parameters != config['expected_parameters']:
            raise ValueError(f'parameter drift: {parameters} != {config["expected_parameters"]}')
        optimizer = torch.optim.Adam(model.parameters(), lr=config['learning_rate'])
        admission = partial(admit_operator, connection)
        schedule = StreamTrainingConfig(**config['stream'])
        exact_sampler = ExactStreamSampler() if schedule.exact_every_roots else None
        exact_catalogs = {} if exact_sampler is None else exact_sampler.catalogs
        sizes = ((3, 4) if exact_sampler is not None else ()) + SIZES
        base = FullGraphObjective(tuple(AlphabetSpec.all_to_all(n) for n in sizes),
                                  registry, policy, exact_catalogs=exact_catalogs,
                                  neighbor_chunk_size=config['neighbor_chunk_size'],
                                  external_admission=admission, compact_exposures=True,
                                  teacher_weight=config.get('teacher_weight', 0.),
                                  teacher_temperature=config.get('teacher_temperature', 4.))
        objective = JointBasisObjective(base, **config['joint'],
                                        operator_admission=admission,
                                        compact_operator_audit=True)
        root = Path(__file__).resolve().parents[1]
        sources = {str(path.relative_to(root)): hashlib.sha256(path.read_bytes()).hexdigest()
                   for path in sorted(root.rglob('*.py'))
                   if path.relative_to(root).parts[0] != 'artifacts'}
        versions = {'code': sources, 'config_sha256': hashlib.sha256(args.config.read_bytes()).hexdigest(),
                    'dataset_manifest': manifest, 'torch': str(torch.__version__),
                    'python': platform.python_version(), 'numpy': np.__version__,
                    'cuda': torch.version.cuda, 'launch_config': config}
        print(json.dumps({'started': True, 'pid': os.getpid(), 'parameters': parameters,
                          'target_unique_roots': schedule.epochs * schedule.unique_roots_per_epoch,
                          'explicit_stop_after_roots': args.stop_after_roots}), flush=True)
        result = train_stream(model, optimizer, objective, connection, args.run_dir,
                              schedule, versions, resume=args.resume,
                              stop_after_roots=args.stop_after_roots, exact_sampler=exact_sampler)
        result['parameters'] = parameters
        result['cuda_peak_allocated_bytes'] = (torch.cuda.max_memory_allocated()
                                               if config['device'] == 'cuda' else None)
        name = ('completion.json' if result['status'] == 'completed' else
                f'diagnostic_stop_root{result["cursor"]["roots_seen"]}.json')
        with (args.run_dir / name).open('x', encoding='utf-8') as stream:
            json.dump(result, stream, indent=2)
        print(json.dumps(result), flush=True)
    finally:
        connection.close()


if __name__ == '__main__':
    main()
