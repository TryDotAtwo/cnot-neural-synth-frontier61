"""Resumeable complete-action joint training on a verified own transfer.

Starts after the independently checked three-root width-8 pilot, then trains
every remaining transferred root with exact GPU holdout admission before each
forward. Saves model, optimizer, global/basis RNG and processed positions after
every update. This bounded transfer is a sustained pilot, not million-root
completion or evidence of solver quality.
"""

import argparse
from collections import defaultdict
import hashlib
import json
import os
from pathlib import Path
from time import perf_counter

import torch

from ..data.stream_reader import decode_record
from ..gpu.frozen_bank import load_sealed_own_banks
from ..gpu.holdout import admit_complete_neighborhood
from ..gpu.joint_basis_slice import complete_joint_basis_batch
from ..gpu.record_batch import own_records_to_cuda
from .probe_gpu_fullwidth_joint import _model, _same_tree, _sha256_file
from .probe_gpu_own_train import _read_transfer


def _emit(path: Path, record: dict):
    with path.open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(record, sort_keys=True) + '\n')
        stream.flush()
        os.fsync(stream.fileno())


def _schedule(train_json: Path, db: Path):
    first, first_digests, first_positions, transfer_sha = _read_transfer(
        train_json, db, 8)
    payload = json.loads(train_json.read_bytes())
    groups = defaultdict(list)
    for item in payload['records']:
        record = decode_record(item['record_json'])
        groups[record.state.n].append((item['position'], record, item['root_digest']))
    if groups[8] != [(p, r, d) for p, r, d in zip(first_positions, first,
                                                   first_digests)]:
        raise ValueError('width-8 train pilot lineage mismatch')
    units = []
    for width in sorted(groups):
        if width == 8:
            continue
        if width >= 72:
            units.extend(((width, (item,)) for item in groups[width]))
        else:
            units.append((width, tuple(groups[width])))
    schedule = tuple((width, tuple(position for position, _, _ in unit))
                     for width, unit in units)
    schedule_sha = hashlib.sha256(json.dumps(schedule, separators=(',', ':')).encode()).hexdigest()
    return first_positions, first_digests, transfer_sha, units, schedule_sha


def _restore(checkpoint_path: Path, config: dict, config_sha: str,
             transfer_sha: str, schedule_sha: str, first_positions: list[int],
             first_digests: list[str]):
    checkpoint = torch.load(checkpoint_path, map_location='cpu', weights_only=False)
    if (checkpoint['config_sha256'] != config_sha or
            checkpoint['transfer_sha256'] != transfer_sha):
        raise ValueError('checkpoint source/config mismatch')
    if checkpoint['schema'] == 'gpu_admitted_own_train_checkpoint_v1':
        if checkpoint['width'] != 8 or checkpoint['data_cursor'] != \
                {'epoch': 0, 'positions': first_positions} or \
                checkpoint['selected_root_digests'] != first_digests:
            raise ValueError('pilot checkpoint is not the transferred width-8 update')
        unit_index = 0
        processed_positions = list(first_positions)
    elif checkpoint['schema'] == 'gpu_own_transfer_training_checkpoint_v1':
        if checkpoint['schedule_sha256'] != schedule_sha:
            raise ValueError('resume schedule drift')
        unit_index = checkpoint['completed_units']
        processed_positions = checkpoint['processed_positions']
    else:
        raise ValueError('unknown own train checkpoint schema')
    model = _model(config).train()
    model.load_state_dict(checkpoint['model'])
    optimizer = torch.optim.Adam(model.parameters(), lr=config['learning_rate'])
    optimizer.load_state_dict(checkpoint['optimizer'])
    generator = torch.Generator(device='cuda')
    generator.set_state(checkpoint['basis_generator_rng'])
    torch.set_rng_state(checkpoint['cpu_rng'])
    torch.cuda.set_rng_state_all(checkpoint['cuda_rng'])
    if (not _same_tree(checkpoint['model'], model.state_dict()) or
            not _same_tree(checkpoint['optimizer'], optimizer.state_dict())):
        raise AssertionError('own train checkpoint restoration failed')
    return model, optimizer, generator, unit_index, processed_positions


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--train-json', type=Path, required=True)
    parser.add_argument('--db', type=Path, required=True)
    parser.add_argument('--stage17-root', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--pilot-checkpoint', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--neighbor-chunk', type=int, default=32)
    parser.add_argument('--max-entries-per-width', type=int, default=5000000)
    args = parser.parse_args()
    if args.neighbor_chunk < 1:
        raise ValueError('positive complete-neighbor chunk required')
    args.out.mkdir(parents=True, exist_ok=True)
    journal = args.out / 'events.jsonl'
    run_started = perf_counter()
    try:
        config_bytes = args.config.read_bytes()
        config = json.loads(config_bytes)
        config_sha = hashlib.sha256(config_bytes).hexdigest()
        torch.set_num_threads(config['threads'])
        first_positions, first_digests, transfer_sha, units, schedule_sha = _schedule(
            args.train_json, args.db)
        existing = sorted(args.out.glob('step_??.pt'))
        if existing:
            checkpoint_path = existing[-1]
        else:
            checkpoint_path = args.pilot_checkpoint
        _emit(journal, {'event': 'start_or_resume',
                        'schema': 'gpu_own_transfer_training_v1',
                        'checkpoint_source': str(checkpoint_path),
                        'config_sha256': config_sha,
                        'transfer_sha256': transfer_sha,
                        'schedule_sha256': schedule_sha,
                        'remaining_unit_count': len(units),
                        'neighbor_chunk': args.neighbor_chunk})
        model, optimizer, generator, start_index, processed = _restore(
            checkpoint_path, config, config_sha, transfer_sha, schedule_sha,
            first_positions, first_digests)
        if start_index > len(units):
            raise ValueError('resume cursor past transfer schedule')
        expected_positions = list(first_positions) + [
            position for _width, unit in units[:start_index]
            for position, _record, _digest in unit]
        if processed != expected_positions:
            raise ValueError('resume processed-root cursor drift')
        bank_started = perf_counter()
        banks, bank_audit = load_sealed_own_banks(
            args.db, args.stage17_root, neighbor_chunk=args.neighbor_chunk,
            max_entries_per_width=args.max_entries_per_width)
        _emit(journal, {'event': 'bank_ready', 'seconds': perf_counter() - bank_started,
                        'dev_roots': bank_audit['dev_roots'],
                        'test_roots': bank_audit['test_roots'],
                        'finite_symmetry_views': bank_audit['finite_symmetry_views']})
        for index in range(start_index, len(units)):
            width, unit = units[index]
            positions = [position for position, _, _ in unit]
            records = [record for _, record, _ in unit]
            digests = [digest for _, _, digest in unit]
            rows = own_records_to_cuda(records).walk
            admission_started = perf_counter()
            admitted = admit_complete_neighborhood(
                banks[width], rows.rows, chunk_size=args.neighbor_chunk)
            admission_seconds = perf_counter() - admission_started
            optimizer.zero_grad(set_to_none=True)
            torch.cuda.reset_peak_memory_stats()
            torch.cuda.synchronize()
            step_started = perf_counter()
            loss, audit = complete_joint_basis_batch(
                model, rows.rows, generator=generator,
                choice_count=config['joint']['choices'],
                action_chunk=args.neighbor_chunk,
                samples=config['joint']['samples'],
                max_evaluations=config['joint']['max_evaluations'],
                max_bytes=config['joint']['max_bytes'],
                weight=config['joint']['weight'], qhat_weight=0.1,
                training_walk=rows, supervision_weight=1.0,
                teacher_weight=config['teacher_weight'],
                holdout=banks[width], mc_samples=config['diffusion']['mc_samples'],
                mc_seed=config['feature_seed'],
                max_pair_states=config['diffusion']['max_pair_states'],
                phase_profile=True)
            loss.backward()
            gradient_norm = torch.sqrt(sum(
                parameter.grad.detach().square().sum()
                for parameter in model.parameters() if parameter.grad is not None))
            if not bool(torch.isfinite(loss).item()) or \
                    not bool(torch.isfinite(gradient_norm).item()):
                raise ValueError('nonfinite own train loss or gradient')
            optimizer.step()
            torch.cuda.synchronize()
            step_seconds = perf_counter() - step_started
            processed += positions
            checkpoint = {
                'schema': 'gpu_own_transfer_training_checkpoint_v1',
                'config_sha256': config_sha,
                'transfer_sha256': transfer_sha,
                'schedule_sha256': schedule_sha,
                'completed_units': index + 1,
                'processed_positions': processed.copy(),
                'last_width': width,
                'last_root_digests': digests,
                'model': model.state_dict(),
                'optimizer': optimizer.state_dict(),
                'cpu_rng': torch.get_rng_state(),
                'cuda_rng': torch.cuda.get_rng_state_all(),
                'basis_generator_rng': generator.get_state()}
            temp = args.out / f'step_{index + 1:02d}.tmp.pt'
            saved = args.out / f'step_{index + 1:02d}.pt'
            torch.save(checkpoint, temp)
            os.replace(temp, saved)
            restored = torch.load(saved, map_location='cpu', weights_only=False)
            if (not _same_tree(checkpoint['model'], restored['model']) or
                    not _same_tree(checkpoint['optimizer'], restored['optimizer']) or
                    not _same_tree(checkpoint['basis_generator_rng'],
                                   restored['basis_generator_rng'])):
                raise AssertionError('own train step checkpoint restoration mismatch')
            _emit(journal, {'event': 'unit_complete', 'unit_index': index + 1,
                            'width': width, 'positions': positions,
                            'root_digests': digests,
                            'admitted_parent_and_neighbors': admitted,
                            'joint_admission_count': audit['admitted_parent_and_neighbors'],
                            'admission_seconds': admission_seconds,
                            'primitive_actions_per_root': audit['field']['candidate_actions_per_root'],
                            'selected_action_ids': audit['field']['selected_action_ids'].cpu().tolist(),
                            'loss': float(loss.detach().item()),
                            'gradient_l2': float(gradient_norm.item()),
                            'basis_status': audit['basis_status'],
                            'complete_neighbor_seconds': audit['field']['phase_seconds']['complete_neighbor_forward'],
                            'step_seconds': step_seconds,
                            'peak_cuda_allocated_bytes': torch.cuda.max_memory_allocated(),
                            'checkpoint_sha256': _sha256_file(saved)})
        _emit(journal, {'event': 'transfer_complete',
                        'completed_units': len(units),
                        'processed_positions': sorted(processed),
                        'total_seconds': perf_counter() - run_started,
                        'scope': '32 transferred own roots; no heldout quality inference'})
    except BaseException as error:
        _emit(journal, {'event': 'failure', 'error_type': type(error).__name__,
                        'error': str(error), 'elapsed_seconds': perf_counter() - run_started})
        raise


if __name__ == '__main__':
    main()
