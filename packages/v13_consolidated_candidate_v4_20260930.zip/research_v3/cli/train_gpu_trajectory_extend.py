"""Continue the own verified-edge arm from its 32-root checkpoint.

The larger transfer must contain the exact initial 32-root payload.  Every
record is replay-checked before training, and every sampled edge plus its
complete one-hop neighborhood is admitted against the sealed holdout bank.
This is a scalable pilot, not the normative full Bellman run.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path
from time import perf_counter

import torch

from ..data.stream_reader import decode_record
from ..data.stream_solver_dataset import canonical
from ..gpu.frozen_bank import load_sealed_own_banks
from ..gpu.record_batch import own_records_to_cuda
from ..gpu.trajectory_objective import verified_trajectory_joint_loss
from .probe_gpu_fullwidth_joint import _model, _same_tree, _sha256_file
from .probe_gpu_own_train import _read_transfer
from .train_gpu_own_transfer import _emit


SCHEMA = 'gpu_own_trajectory_extended_checkpoint_v1'


def _transfer_and_schedule(path: Path, db: Path, prefix_count: int):
    # _read_transfer checks the metadata, all record digests and every word.
    _read_transfer(path, db, 8)
    payload = json.loads(path.read_bytes())
    if not prefix_count < payload['count']:
        raise ValueError('extended transfer has no new roots')
    prefix = dict(payload)
    prefix['count'] = prefix_count
    prefix['records'] = payload['records'][:prefix_count]
    prefix_sha = hashlib.sha256((canonical(prefix) + '\n').encode()).hexdigest()
    units = []
    for item in payload['records'][prefix_count:]:
        record = decode_record(item['record_json'])
        units.append((record.state.n, item['position'], record, item['root_digest']))
    schedule = tuple((width, position) for width, position, _, _ in units)
    schedule_sha = hashlib.sha256(canonical(schedule).encode()).hexdigest()
    return payload, prefix_sha, hashlib.sha256(path.read_bytes()).hexdigest(), units, schedule_sha


def _restore(path, config, config_sha, prefix_sha, transfer_sha,
             schedule_sha, samples_per_root, prefix_count, units):
    saved = torch.load(path, map_location='cpu', weights_only=False)
    if saved['config_sha256'] != config_sha:
        raise ValueError('configuration drift')
    if saved['schema'] == 'gpu_own_trajectory_transfer_checkpoint_v1':
        if (saved['transfer_sha256'] != prefix_sha or
                saved['samples_per_root'] != samples_per_root or
                saved['completed_units'] != 19 or
                sorted(saved['processed_positions']) != list(range(prefix_count))):
            raise ValueError('32-root predecessor checkpoint mismatch')
        predecessor_sha = _sha256_file(path)
        done = 0
    elif saved['schema'] == SCHEMA:
        if (saved['transfer_sha256'] != transfer_sha or
                saved['schedule_sha256'] != schedule_sha or
                saved['samples_per_root'] != samples_per_root or
                saved['prefix_count'] != prefix_count):
            raise ValueError('extended checkpoint source or schedule drift')
        predecessor_sha = saved['predecessor_sha256']
        done = saved['completed_units']
        expected = list(range(prefix_count)) + [position for _, position, _, _ in units[:done]]
        if sorted(saved['processed_positions']) != sorted(expected):
            raise ValueError('extended checkpoint cursor drift')
    else:
        raise ValueError('unsupported checkpoint schema')
    if done > len(units):
        raise ValueError('checkpoint cursor past schedule')
    model = _model(config).train()
    model.load_state_dict(saved['model'])
    optimizer = torch.optim.Adam(model.parameters(), lr=config['learning_rate'])
    optimizer.load_state_dict(saved['optimizer'])
    generator = torch.Generator(device='cuda')
    generator.set_state(saved['basis_generator_rng'])
    torch.set_rng_state(saved['cpu_rng'])
    torch.cuda.set_rng_state_all(saved['cuda_rng'])
    if (not _same_tree(saved['model'], model.state_dict()) or
            not _same_tree(saved['optimizer'], optimizer.state_dict())):
        raise AssertionError('extended checkpoint restore mismatch')
    return model, optimizer, generator, done, predecessor_sha


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--train-json', type=Path, required=True)
    parser.add_argument('--db', type=Path, required=True)
    parser.add_argument('--stage17-root', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--predecessor', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--prefix-count', type=int, default=32)
    parser.add_argument('--samples-per-root', type=int, default=2)
    parser.add_argument('--save-every', type=int, default=16)
    parser.add_argument('--admission-chunk', type=int, default=32)
    parser.add_argument('--max-entries-per-width', type=int, default=5000000)
    args = parser.parse_args()
    if min(args.prefix_count, args.samples_per_root, args.save_every,
           args.admission_chunk) < 1:
        raise ValueError('positive training budgets required')
    args.out.mkdir(parents=True, exist_ok=True)
    journal = args.out / 'events.jsonl'
    started = perf_counter()
    try:
        config_bytes = args.config.read_bytes()
        config = json.loads(config_bytes)
        config_sha = hashlib.sha256(config_bytes).hexdigest()
        if config['joint']['samples'] % args.samples_per_root:
            raise ValueError('sample count must divide basis MC budget')
        basis_samples = config['joint']['samples'] // args.samples_per_root
        torch.set_num_threads(config['threads'])
        payload, prefix_sha, transfer_sha, units, schedule_sha = \
            _transfer_and_schedule(args.train_json, args.db, args.prefix_count)
        existing = sorted(args.out.glob('step_*.pt'))
        source = existing[-1] if existing else args.predecessor
        model, optimizer, generator, done, predecessor_sha = _restore(
            source, config, config_sha, prefix_sha, transfer_sha,
            schedule_sha, args.samples_per_root, args.prefix_count, units)
        _emit(journal, {'event': 'start_or_resume', 'schema': SCHEMA,
                        'source': str(source), 'config_sha256': config_sha,
                        'prefix_sha256': prefix_sha,
                        'predecessor_sha256': predecessor_sha,
                        'transfer_sha256': transfer_sha,
                        'schedule_sha256': schedule_sha,
                        'completed_units': done, 'remaining_units': len(units)-done,
                        'save_every': args.save_every})
        banks, bank_audit = load_sealed_own_banks(
            args.db, args.stage17_root,
            neighbor_chunk=args.admission_chunk,
            max_entries_per_width=args.max_entries_per_width)
        _emit(journal, {'event': 'bank_ready', 'dev_roots': bank_audit['dev_roots'],
                        'test_roots': bank_audit['test_roots'],
                        'finite_symmetry_views': bank_audit['finite_symmetry_views']})
        processed = list(range(args.prefix_count)) + [
            position for _, position, _, _ in units[:done]]
        for index in range(done, len(units)):
            width, position, record, digest = units[index]
            walk = own_records_to_cuda([record]).walk
            optimizer.zero_grad(set_to_none=True)
            torch.cuda.reset_peak_memory_stats()
            torch.cuda.synchronize()
            t0 = perf_counter()
            loss, audit = verified_trajectory_joint_loss(
                model, walk, generator=generator,
                samples_per_root=args.samples_per_root,
                holdout=banks[width], admission_chunk=args.admission_chunk,
                mc_samples=config['diffusion']['mc_samples'],
                mc_seed=config['feature_seed'],
                max_pair_states=config['diffusion']['max_pair_states'],
                teacher_weight=config['teacher_weight'],
                basis_weight=config['joint']['weight'],
                basis_choices=config['joint']['choices'],
                basis_samples=basis_samples,
                basis_max_evaluations=config['joint']['max_evaluations'],
                basis_max_bytes=config['joint']['max_bytes'])
            loss.backward()
            norm = torch.sqrt(sum(p.grad.detach().square().sum()
                                  for p in model.parameters() if p.grad is not None))
            if not bool(torch.isfinite(loss).item()) or not bool(torch.isfinite(norm).item()):
                raise ValueError('nonfinite trajectory loss or gradient')
            optimizer.step()
            torch.cuda.synchronize()
            processed.append(position)
            _emit(journal, {'event': 'unit_complete', 'unit_index': index+1,
                            'width': width, 'position': position, 'root_digest': digest,
                            'sampled_edges': audit['sampled_edges'],
                            'admitted_parent_and_neighbors': audit['admitted_parent_and_neighbors'],
                            'basis_status': audit['basis_status'],
                            'loss': float(loss.detach().item()),
                            'gradient_l2': float(norm.item()),
                            'step_seconds': perf_counter()-t0,
                            'peak_cuda_allocated_bytes': torch.cuda.max_memory_allocated()})
            if (index + 1) % args.save_every == 0 or index + 1 == len(units):
                checkpoint = {
                    'schema': SCHEMA, 'config_sha256': config_sha,
                    'prefix_count': args.prefix_count,
                    'predecessor_sha256': predecessor_sha,
                    'transfer_sha256': transfer_sha,
                    'schedule_sha256': schedule_sha,
                    'samples_per_root': args.samples_per_root,
                    'completed_units': index + 1,
                    'processed_positions': processed.copy(),
                    'last_width': width, 'last_root_digest': digest,
                    'model': model.state_dict(),
                    'optimizer': optimizer.state_dict(),
                    'cpu_rng': torch.get_rng_state(),
                    'cuda_rng': torch.cuda.get_rng_state_all(),
                    'basis_generator_rng': generator.get_state()}
                temp = args.out / f'step_{index+1:06d}.tmp.pt'
                saved = args.out / f'step_{index+1:06d}.pt'
                torch.save(checkpoint, temp)
                os.replace(temp, saved)
                restored = torch.load(saved, map_location='cpu', weights_only=False)
                if (not _same_tree(checkpoint['model'], restored['model']) or
                        not _same_tree(checkpoint['optimizer'], restored['optimizer']) or
                        not _same_tree(checkpoint['basis_generator_rng'],
                                       restored['basis_generator_rng'])):
                    raise AssertionError('extended checkpoint restoration mismatch')
                _emit(journal, {'event': 'checkpoint', 'completed_units': index+1,
                                'checkpoint_sha256': _sha256_file(saved)})
        _emit(journal, {'event': 'transfer_complete',
                        'completed_units': len(units),
                        'processed_positions': sorted(processed),
                        'total_seconds': perf_counter()-started,
                        'scope': 'optional verified-edge arm; not full Bellman or heldout quality'})
    except BaseException as error:
        _emit(journal, {'event': 'failure', 'error_type': type(error).__name__,
                        'error': str(error), 'elapsed_seconds': perf_counter()-started})
        raise


if __name__ == '__main__':
    main()
