"""Separate verified-edge pilot on the same 32 own roots as full Bellman.

This is an optional fast-training arm. It never claims to replace the required
complete-neighborhood Bellman updates or to establish full-program quality.
Each sampled parent and its entire one-hop neighborhood is checked against the
sealed dev/test/historical bank before model evaluation.
"""

import argparse
import hashlib
import json
import os
from pathlib import Path
from time import perf_counter

import torch

from ..gpu.frozen_bank import load_sealed_own_banks
from ..gpu.record_batch import own_records_to_cuda
from ..gpu.trajectory_objective import verified_trajectory_joint_loss
from .probe_gpu_fullwidth_joint import _model, _same_tree, _sha256_file
from .train_gpu_own_transfer import _emit, _schedule


SCHEMA = 'gpu_own_trajectory_transfer_checkpoint_v1'


def _restore(path, config, config_sha, transfer_sha, schedule_sha,
             first_positions, first_digests, samples_per_root):
    checkpoint = torch.load(path, map_location='cpu', weights_only=False)
    if (checkpoint['config_sha256'] != config_sha or
            checkpoint['transfer_sha256'] != transfer_sha):
        raise ValueError('trajectory checkpoint source/config mismatch')
    if checkpoint['schema'] == 'gpu_admitted_own_train_checkpoint_v1':
        if (checkpoint['width'] != 8 or
                checkpoint['data_cursor'] != {'epoch': 0,
                                               'positions': first_positions} or
                checkpoint['selected_root_digests'] != first_digests):
            raise ValueError('trajectory seed is not the transferred n8 pilot')
        unit_index = 0
        processed = list(first_positions)
    elif checkpoint['schema'] == SCHEMA:
        if (checkpoint['schedule_sha256'] != schedule_sha or
                checkpoint['samples_per_root'] != samples_per_root):
            raise ValueError('trajectory resume schedule or edge count drift')
        unit_index = checkpoint['completed_units']
        processed = checkpoint['processed_positions']
    else:
        raise ValueError('unknown trajectory checkpoint schema')
    model = _model(config).train()
    model.load_state_dict(checkpoint['model'])
    optimizer = torch.optim.Adam(model.parameters(), lr=config['learning_rate'])
    optimizer.load_state_dict(checkpoint['optimizer'])
    generator = torch.Generator(device='cuda')
    generator.set_state(checkpoint['basis_generator_rng'])
    torch.set_rng_state(checkpoint['cpu_rng'])
    torch.cuda.set_rng_state_all(checkpoint['cuda_rng'])
    if (not _same_tree(checkpoint['model'], model.state_dict()) or
            not _same_tree(checkpoint['optimizer'], optimizer.state_dict())):
        raise AssertionError('trajectory seed checkpoint restoration failed')
    return model, optimizer, generator, unit_index, processed


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--train-json', type=Path, required=True)
    parser.add_argument('--db', type=Path, required=True)
    parser.add_argument('--stage17-root', type=Path, required=True)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--pilot-checkpoint', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--samples-per-root', type=int, default=2)
    parser.add_argument('--admission-chunk', type=int, default=32)
    parser.add_argument('--max-entries-per-width', type=int, default=5000000)
    args = parser.parse_args()
    if args.samples_per_root < 1 or args.admission_chunk < 1:
        raise ValueError('positive trajectory sampling/admission budgets required')
    args.out.mkdir(parents=True, exist_ok=True)
    journal = args.out / 'events.jsonl'
    started = perf_counter()
    try:
        config_bytes = args.config.read_bytes()
        config = json.loads(config_bytes)
        config_sha = hashlib.sha256(config_bytes).hexdigest()
        if config['joint']['samples'] % args.samples_per_root:
            raise ValueError('trajectory prefixes must divide the fixed basis MC budget')
        basis_samples = config['joint']['samples'] // args.samples_per_root
        torch.set_num_threads(config['threads'])
        first_positions, first_digests, transfer_sha, units, schedule_sha = _schedule(
            args.train_json, args.db)
        existing = sorted(args.out.glob('step_??.pt'))
        checkpoint_path = existing[-1] if existing else args.pilot_checkpoint
        _emit(journal, {'event': 'start_or_resume', 'schema': SCHEMA,
                        'checkpoint_source': str(checkpoint_path),
                        'config_sha256': config_sha,
                        'transfer_sha256': transfer_sha,
                        'schedule_sha256': schedule_sha,
                        'samples_per_root': args.samples_per_root,
                        'basis_samples_per_edge': basis_samples,
                        'remaining_unit_count': len(units)})
        model, optimizer, generator, first_index, processed = _restore(
            checkpoint_path, config, config_sha, transfer_sha, schedule_sha,
            first_positions, first_digests, args.samples_per_root)
        if first_index > len(units):
            raise ValueError('trajectory resume cursor past schedule')
        expected = list(first_positions) + [
            position for _width, unit in units[:first_index]
            for position, _record, _digest in unit]
        if processed != expected:
            raise ValueError('trajectory processed positions drift')
        bank_started = perf_counter()
        banks, bank_audit = load_sealed_own_banks(
            args.db, args.stage17_root,
            neighbor_chunk=args.admission_chunk,
            max_entries_per_width=args.max_entries_per_width)
        _emit(journal, {'event': 'bank_ready',
                        'seconds': perf_counter() - bank_started,
                        'dev_roots': bank_audit['dev_roots'],
                        'test_roots': bank_audit['test_roots'],
                        'finite_symmetry_views': bank_audit['finite_symmetry_views']})
        for index in range(first_index, len(units)):
            width, unit = units[index]
            positions = [position for position, _, _ in unit]
            digests = [digest for _, _, digest in unit]
            walk = own_records_to_cuda([record for _, record, _ in unit]).walk
            optimizer.zero_grad(set_to_none=True)
            torch.cuda.reset_peak_memory_stats()
            torch.cuda.synchronize()
            step_started = perf_counter()
            loss, audit = verified_trajectory_joint_loss(
                model, walk, generator=generator,
                samples_per_root=args.samples_per_root,
                holdout=banks[width],
                admission_chunk=args.admission_chunk,
                mc_samples=config['diffusion']['mc_samples'],
                mc_seed=config['feature_seed'],
                max_pair_states=config['diffusion']['max_pair_states'],
                teacher_weight=config['teacher_weight'],
                basis_weight=config['joint']['weight'],
                basis_choices=config['joint']['choices'],
                basis_samples=basis_samples,
                basis_max_evaluations=config['joint']['max_evaluations'],
                basis_max_bytes=config['joint']['max_bytes'])
            loss.backward()
            norm = torch.sqrt(sum(parameter.grad.detach().square().sum()
                                  for parameter in model.parameters()
                                  if parameter.grad is not None))
            if not bool(torch.isfinite(loss).item()) or \
                    not bool(torch.isfinite(norm).item()):
                raise ValueError('nonfinite trajectory loss or gradient')
            optimizer.step()
            torch.cuda.synchronize()
            step_seconds = perf_counter() - step_started
            processed += positions
            checkpoint = {
                'schema': SCHEMA, 'config_sha256': config_sha,
                'transfer_sha256': transfer_sha,
                'schedule_sha256': schedule_sha,
                'samples_per_root': args.samples_per_root,
                'completed_units': index + 1,
                'processed_positions': processed.copy(),
                'last_width': width, 'last_root_digests': digests,
                'model': model.state_dict(),
                'optimizer': optimizer.state_dict(),
                'cpu_rng': torch.get_rng_state(),
                'cuda_rng': torch.cuda.get_rng_state_all(),
                'basis_generator_rng': generator.get_state()}
            temp = args.out / f'step_{index + 1:02d}.tmp.pt'
            saved = args.out / f'step_{index + 1:02d}.pt'
            torch.save(checkpoint, temp)
            os.replace(temp, saved)
            restored = torch.load(saved, map_location='cpu', weights_only=False)
            if (not _same_tree(checkpoint['model'], restored['model']) or
                    not _same_tree(checkpoint['optimizer'], restored['optimizer']) or
                    not _same_tree(checkpoint['basis_generator_rng'],
                                   restored['basis_generator_rng'])):
                raise AssertionError('trajectory checkpoint restoration mismatch')
            _emit(journal, {
                'event': 'unit_complete', 'unit_index': index + 1,
                'width': width, 'positions': positions,
                'root_digests': digests,
                'sampled_edges': audit['sampled_edges'],
                'admitted_parent_and_neighbors':
                    audit['admitted_parent_and_neighbors'],
                'basis_status': audit['basis_status'],
                'loss': float(loss.detach().item()),
                'gradient_l2': float(norm.item()),
                'step_seconds': step_seconds,
                'peak_cuda_allocated_bytes': torch.cuda.max_memory_allocated(),
                'checkpoint_sha256': _sha256_file(saved)})
        _emit(journal, {'event': 'transfer_complete',
                        'completed_units': len(units),
                        'processed_positions': sorted(processed),
                        'total_seconds': perf_counter() - started,
                        'scope': 'optional verified-edge arm; no full Bellman or heldout quality claim'})
    except BaseException as error:
        _emit(journal, {'event': 'failure',
                        'error_type': type(error).__name__,
                        'error': str(error),
                        'elapsed_seconds': perf_counter() - started})
        raise


if __name__ == '__main__':
    main()
