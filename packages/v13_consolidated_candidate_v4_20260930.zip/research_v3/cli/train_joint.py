"""Own joint Bellman+basis development runner. No implicit source-dependent labels."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import random
import numpy as np
import torch
from ..basis.learning import BasisField
from ..contracts import AlphabetSpec
from ..data.frozen import load
from ..features.registry import FeaturePolicy,FeatureRegistry
from ..features.diffusion import register_diffusion
from ..features.subspace_views import register_subspace_views
from ..features.basis_gradient import register_basis_gradient
from ..model.field import FusionDistanceField
from ..train.objective import FullGraphObjective
from ..train.joint_basis import JointBasisObjective
from ..train.runner import TrainingConfig,train_reference


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--config',type=Path,required=True)
    parser.add_argument('--dataset',type=Path,required=True)
    parser.add_argument('--run-dir',type=Path,required=True)
    parser.add_argument('--resume',type=Path)
    args=parser.parse_args()
    cfg=json.loads(args.config.read_text(encoding='utf-8'))
    if cfg['device']=='cuda' and not torch.cuda.is_available():
        raise RuntimeError('requested CUDA unavailable')
    os.environ.setdefault('CUBLAS_WORKSPACE_CONFIG',':4096:8')
    torch.set_num_threads(cfg['threads'])
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    torch.use_deterministic_algorithms(True)
    random.seed(cfg['seed']);np.random.seed(cfg['seed']);torch.manual_seed(cfg['seed'])
    if torch.cuda.is_available():torch.cuda.manual_seed_all(cfg['seed'])
    panels,forbidden,source=load(args.dataset)
    selected=tuple(r for r in panels['train'] if r.state.n in cfg['train_sizes'])
    if not selected:raise ValueError('empty selected training panel')
    registry=FeatureRegistry()
    if any(k.startswith(('C', 'D', 'H')) for k in cfg['features']):
        register_subspace_views(registry)
    if any(k.startswith('E') for k in cfg['features']):
        register_basis_gradient(registry)
    if any(k.startswith('G') for k in cfg['features']):
        diffusion=register_diffusion(registry,**cfg['diffusion'])
    else:diffusion=None
    policy=FeaturePolicy(tuple(cfg['features']),seed=cfg['feature_seed'],
                         symmetry_contract=cfg['feature_symmetry'])
    field=FusionDistanceField([registry.specs[k] for k in policy.enabled_ids],**cfg['field']).to(cfg['device'])
    model=BasisField(field,cfg['basis_hidden']).to(cfg['device']).train()
    parameters=sum(p.numel() for p in model.parameters())
    if 'expected_parameters' in cfg and parameters != cfg['expected_parameters']:
        raise ValueError(f"model parameter count drift: {parameters} != {cfg['expected_parameters']}")
    optimizer=torch.optim.Adam(model.parameters(),lr=cfg['learning_rate'])
    alphabets=tuple(AlphabetSpec.all_to_all(n) for n in sorted({r.state.n for r in selected}))
    base=FullGraphObjective(alphabets,registry,policy,forbidden_keys=forbidden,
                            neighbor_chunk_size=cfg['neighbor_chunk_size'])
    objective=JointBasisObjective(base,**cfg['joint'])
    root=Path(__file__).resolve().parents[1]
    sources={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
             for p in sorted(root.rglob('*.py')) if p.relative_to(root).parts[0]!='artifacts'}
    versions={'code':sources,'dataset_sha256':hashlib.sha256(args.dataset.read_bytes()).hexdigest(),
              'launch_config':cfg,'torch':str(torch.__version__),'python':platform.python_version(),
              'numpy':np.__version__,'cuda':torch.version.cuda,'diffusion':diffusion}
    training=TrainingConfig(cfg['updates'],cfg['batch_size'],cfg['seed'],cfg['checkpoint_every'],
                            objective.config['id'],versions)
    args.run_dir.mkdir(parents=True,exist_ok=True)
    manifest={'config':cfg,'versions':versions,'parameters':parameters,
              'train_roots':len(selected),'dev_roots':len(panels['dev']),'dataset_provenance':source['provenance'],
              'pid':os.getpid(),'claim_scope':cfg['claim_scope'],
              'source_gate':'independent matching-bound family only; recovered Frontier stage61 source is not used by this arm'}
    if args.resume is None:
        with (args.run_dir/'experiment_manifest.json').open('x',encoding='utf-8') as stream:json.dump(manifest,stream,indent=2)
    print(json.dumps({'started':True,'pid':os.getpid(),'parameters':manifest['parameters'],
                      'updates':cfg['updates'],'train_roots':len(selected)}),flush=True)
    result=train_reference(model,optimizer,selected,objective,training,args.run_dir,resume=args.resume)
    result['exposure_audit']=objective.audit()
    result['cuda_peak_allocated_bytes']=torch.cuda.max_memory_allocated() if cfg['device']=='cuda' else None
    with (args.run_dir/'completion.json').open('x',encoding='utf-8') as stream:json.dump(result,stream,indent=2)
    print(json.dumps(result),flush=True)

if __name__=='__main__':main()
