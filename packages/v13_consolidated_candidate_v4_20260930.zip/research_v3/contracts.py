from dataclasses import dataclass
from .gf2 import rank


@dataclass(frozen=True, order=True)
class Gate:
    control: int
    target: int


@dataclass(frozen=True)
class AlphabetSpec:
    n: int
    allowed: tuple[Gate, ...]
    costs: tuple[int, ...]
    id: str

    def __post_init__(self):
        if type(self.n) is not int or self.n < 1 or not self.id:
            raise ValueError('invalid alphabet size/id')
        if not isinstance(self.allowed, tuple) or not isinstance(self.costs, tuple):
            raise ValueError('immutable tuples required')
        if len(self.allowed) != len(self.costs) or len(set(self.allowed)) != len(self.allowed):
            raise ValueError('invalid alphabet entries')
        for gate, cost in zip(self.allowed, self.costs):
            if (type(gate.control) is not int or type(gate.target) is not int or
                not 0 <= gate.control < self.n or not 0 <= gate.target < self.n or
                gate.control == gate.target or type(cost) is not int or cost <= 0):
                raise ValueError('invalid gate/cost')

    @classmethod
    def all_to_all(cls, n):
        gates = tuple(Gate(c, t) for c in range(n) for t in range(n) if c != t)
        return cls(n, gates, (1,) * len(gates), f'all_to_all_unit_cnot:{n}')

    def cost(self, gate):
        if not isinstance(gate, Gate) or type(gate.control) is not int or type(gate.target) is not int:
            raise ValueError('gate indices must be integers, not bool')
        try:
            return self.costs[self.allowed.index(gate)]
        except ValueError:
            raise ValueError('gate outside alphabet') from None


@dataclass(frozen=True)
class MatrixState:
    n: int
    packed_rows: tuple[int, ...]
    alphabet_id: str

    def __post_init__(self):
        if type(self.n) is not int or self.n < 1 or not self.alphabet_id:
            raise ValueError('invalid matrix size/id')
        if not isinstance(self.packed_rows, tuple) or len(self.packed_rows) != self.n:
            raise ValueError('invalid matrix shape')
        if any(type(row) is not int or not 0 <= row < (1 << self.n) for row in self.packed_rows):
            raise ValueError('invalid packed row/padding')
        if rank(self.packed_rows) != self.n:
            raise ValueError('singular matrix')

    @classmethod
    def identity(cls, alphabet):
        return cls(alphabet.n, tuple(1 << i for i in range(alphabet.n)), alphabet.id)

    @classmethod
    def from_dense(cls, matrix, alphabet):
        n = alphabet.n
        if len(matrix) != n or any(len(row) != n for row in matrix):
            raise ValueError('invalid matrix shape')
        if any(type(bit) not in (bool, int) or bit not in (0, 1) for row in matrix for bit in row):
            raise ValueError('matrix must be binary')
        return cls(n, tuple(sum(int(bit) << j for j, bit in enumerate(row)) for row in matrix), alphabet.id)

    @property
    def key(self):
        return self.n, self.alphabet_id, self.packed_rows


@dataclass(frozen=True)
class WordCertificate:
    start: MatrixState
    end: MatrixState
    gates: tuple[Gate, ...]
    physical_cost: int
    producer: str
    lineage_id: str


@dataclass(frozen=True)
class BoundCertificate:
    kind: str
    value: int
    scope_id: str
    hypotheses: dict
    witness_ref: str
    verifier_version: str


@dataclass(frozen=True)
class BoundSet:
    lower: tuple[BoundCertificate, ...] = ()
    upper: tuple[WordCertificate, ...] = ()
    exact: BoundCertificate | None = None

    @property
    def lower_bound(self):
        return max((bound.value for bound in self.lower), default=0)


@dataclass(frozen=True)
class MatrixBatch:
    states: tuple[MatrixState, ...]
    matrix: object
    valid: object

    def __post_init__(self):
        import torch
        if not self.states or self.matrix.dtype != torch.bool or self.valid.dtype != torch.bool:
            raise ValueError('nonempty boolean matrix batch required')
        n = max(state.n for state in self.states)
        if self.matrix.shape != (len(self.states), n, n) or self.valid.shape != (len(self.states), n):
            raise ValueError('batch shape mismatch')
        expected = torch.zeros_like(self.matrix)
        valid = torch.zeros_like(self.valid)
        for b, state in enumerate(self.states):
            valid[b, :state.n] = True
            for i, row in enumerate(state.packed_rows):
                expected[b, i, :state.n] = torch.tensor([(row >> j) & 1 for j in range(state.n)],
                                                      dtype=torch.bool, device=expected.device)
        if not torch.equal(expected, self.matrix) or not torch.equal(valid, self.valid):
            raise ValueError('batch contents/padding differ from canonical full states')

    @classmethod
    def from_states(cls, states, device='cpu'):
        import torch
        states = tuple(states)
        if not states:
            raise ValueError('empty state batch')
        nmax = max(s.n for s in states)
        matrix = torch.zeros((len(states), nmax, nmax), dtype=torch.bool, device=device)
        valid = torch.zeros((len(states), nmax), dtype=torch.bool, device=device)
        for b, state in enumerate(states):
            valid[b, :state.n] = True
            matrix[b, :state.n, :state.n] = torch.tensor(
                [[(row >> j) & 1 for j in range(state.n)] for row in state.packed_rows], dtype=torch.bool, device=device)
        return cls(states, matrix, valid)


@dataclass
class EncodedState:
    wire: object
    pair: object
    group: object
    global_tokens: object
    valid: object
    availability: object
    identity: object


@dataclass
class ModelOutput:
    value: object
    proposal: object = None
    qhat: object = None
