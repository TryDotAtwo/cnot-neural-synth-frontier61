"""Offline verified data; exact enumeration is never a runtime solver dependency."""
