import sys,sqlite3,json,hashlib
from pathlib import Path
sys.path.insert(0,'/marimo/cnot_work')
from research_v3.data.stream_reader import decode_record
from research_v3.contracts import AlphabetSpec,MatrixState
from research_v3.words import verify_word
from research_v3.data.stream_solver_dataset_v7 import data_source_hashes
root=Path('/marimo/cnot_work/research_v3/data')
p=root/'own14_v7_fastcost_smoke.sqlite'
c=sqlite3.connect(p.resolve().as_uri()+'?immutable=1',uri=True)
assert c.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
manifest=json.loads(c.execute("select value from metadata where key='manifest'").fetchone()[0])
assert manifest['schema']=='own_solver_stream_v7_fastcost_prelim'
assert manifest['dataset_source_sha256']==data_source_hashes()
assert manifest['dataset_source_sha256']['data/stream_solver_dataset_v7.py']==hashlib.sha256((root/'stream_solver_dataset_v7.py').read_bytes()).hexdigest()
assert manifest['dataset_source_sha256']['data/fast_cost_v1.py']==hashlib.sha256((root/'fast_cost_v1.py').read_bytes()).hexdigest()
counts={};certs=0;rows=[]
for split,raw in c.execute('select split,record_json from roots order by split'):
 r=decode_record(raw);a=AlphabetSpec.all_to_all(r.state.n);ident=MatrixState.identity(a)
 for cert in r.verified_words:
  verify_word(cert,a)
  assert {cert.start,cert.end}=={ident,r.state}
  certs+=1
 counts[split]=counts.get(split,0)+1
 rows.append({'split':split,'n':r.state.n,'certificates':len(r.verified_words),'matrix_sha256':hashlib.sha256(str(r.state.key).encode()).hexdigest()})
assert counts=={'dev':1,'test':1} and certs==4
report={'schema':manifest['schema'],'db_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256(json.dumps(manifest,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'counts':counts,'certificates_verified':certs,'rows':rows,'integrity_check':'ok','source_hashes_verified':True,'scope':'nonnormative smoke, not sealed holdout'}
c.close()
q=root/'own14_v7_fastcost_smoke_audit.json';q.write_text(json.dumps(report,sort_keys=True,indent=2))
print(json.dumps(report,sort_keys=True))