"""Reproducible development roots; this is not a confirmatory benchmark."""
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import random
import numpy as np
from ..contracts import AlphabetSpec, Gate
from ..basis.templates import BasisTemplate, BasisChoice, compile_basis
from .generators import generate, record_from_word
from .frozen import historical_states, freeze


PLAN = {'schema':'development_population_v1', 'sizes':[8,13,25,34], 'roots_per_family_size_split':8,
        'families':['ordinary_walk','disjoint_cnot','paid_shear','compound_paid_shear'],
        'splits':['train','dev'], 'test_status':'not_created_confirmatory_gate_pending',
        'seeds':{'train':100000,'dev':200000}, 'wall_clock_stopper':None,
        'basis_choices':3, 'basis_choice_bits':'seeded_independent_bernoulli_half_no_optimization',
        'labels':'verified_UB; disjoint family has matching elementary LB but no unverified exact tag',
        'word_lengths_are_not_distances':True}


def root(family, seed, n):
    rng = random.Random(seed)
    alphabet = AlphabetSpec.all_to_all(n)
    if family == 'ordinary_walk':
        return generate('ordinary_walk', seed, n, 1, n * (1 + seed % 3))[0]
    if family == 'disjoint_cnot':
        wires = rng.sample(range(n), n)
        count = rng.randint(1, n//2)
        word = tuple(Gate(wires[2*i], wires[2*i+1]) for i in range(count))
    else:
        word = ()
        for _ in range(2 if family == 'compound_paid_shear' else 1):
            wires = rng.sample(range(n), n)
            width = n // 2
            pairs = [tuple(rng.sample(range(width), 2)) for _ in range(3)]
            template = BasisTemplate(n, tuple(wires[:width]), tuple(wires[width:]), 'source',
                                     tuple(BasisChoice('add', c, t) for c,t in pairs))
            block = np.array([[int(rng.random() < .35) for _ in range(width)] for _ in range(n-width)], dtype=np.uint8)
            candidate = compile_basis(template, block, tuple(rng.randrange(2) for _ in pairs))
            word += candidate.certificate.gates
    return record_from_word(alphabet, word, f'{family}:{seed}:{n}', seed, family + '_own_v3')


def build(output):
    output = Path(output)
    plan_path = output.with_suffix('.plan.json')
    with plan_path.open('x', encoding='utf-8') as stream:
        json.dump(PLAN, stream, indent=2)
    panels = {'train':[], 'dev':[], 'test':[]}
    for split in PLAN['splits']:
        for n in PLAN['sizes']:
            for fi, family in enumerate(PLAN['families']):
                for i in range(PLAN['roots_per_family_size_split']):
                    seed = PLAN['seeds'][split] + n * 100 + fi * 10 + i
                    panels[split].append(replace(root(family, seed, n), split=split))
    stage17 = Path(__file__).resolve().parents[3]
    historical, sources = historical_states(stage17)
    code = {str(p.relative_to(stage17)):hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((stage17/'improved/research_v3').rglob('*.py'))}
    result = freeze(output, panels, historical,
                    {'plan':PLAN, 'plan_sha256':hashlib.sha256(plan_path.read_bytes()).hexdigest(),
                     'historical_input_sha256':sources, 'own_code_sha256':code})
    print(json.dumps(result), flush=True)


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    build(parser.parse_args().output)
