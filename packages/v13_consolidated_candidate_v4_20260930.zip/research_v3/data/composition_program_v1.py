"""Own composition targets from independently generated paid basis blocks and a walk.

Every component supplies a verified reduction. Reversing each reduction builds
an encoder from I; the final candidate is reverified against the full matrix.
No component length is marked exact.
"""
from dataclasses import replace
import hashlib
from time import perf_counter
from ..contracts import AlphabetSpec, MatrixState
from ..words import verify_word
from .generators import record_from_word
from .solver_programs import basis_program, walk_with_solver
from .own_synthesis import solve_matrix_with_own_synth


def composition_program(seed, n, *, split):
    if type(seed) is not int or type(n) is not int or n < 4 or split not in ('train', 'dev', 'test'):
        raise ValueError('invalid composition input')
    alphabet = AlphabetSpec.all_to_all(n)
    parts = (
        basis_program(seed * 3 + 1, n, split=split),
        basis_program(seed * 3 + 2, n, split=split),
        walk_with_solver('ordinary_walk', seed * 3 + 3, n, n, split=split),
    )
    encoders = []
    component_audit = []
    for record, audit in parts:
        chosen = min(record.verified_words, key=lambda cert: cert.physical_cost)
        verify_word(chosen, alphabet)
        if chosen.start != record.state or chosen.end != MatrixState.identity(alphabet):
            raise ValueError('invalid component certificate')
        encoders.extend(reversed(chosen.gates))
        component_audit.append({'source': record.source, 'seed': record.seed,
                                'cost': chosen.physical_cost,
                                'matrix_sha256': hashlib.sha256(str(record.state.key).encode()).hexdigest(),
                                'solver_status': audit.get('solver_status')})
    lineage = f'own_composition:{split}:{seed}:{n}'
    incumbent = replace(record_from_word(alphabet, tuple(encoders), lineage, seed,
                                         'own_composition_v1'), split=split)
    candidates = [incumbent.verified_words[0]]
    started = perf_counter()
    try:
        solved, solver_audit = solve_matrix_with_own_synth(incumbent.state, seed=seed)
        verify_word(solved, alphabet)
        if solved.start != incumbent.state or solved.end != MatrixState.identity(alphabet):
            raise ValueError('solver endpoint mismatch')
        candidates.append(solved)
        solver_status = 'verified'
    except Exception as error:
        solver_audit = {'status': 'failed_or_invalid', 'error_type': type(error).__name__,
                        'error': str(error)}
        solver_status = 'failed_or_invalid'
    solver_seconds = perf_counter() - started
    best = min(candidates, key=lambda cert: cert.physical_cost)
    audit = {'family': 'composition', 'seed': seed, 'n': n, 'split': split,
             'components': component_audit, 'solver_called': True,
             'solver_status': solver_status, 'solver_seconds': solver_seconds,
             'synthesizer': solver_audit,
             'candidate_lengths': {cert.producer: cert.physical_cost for cert in candidates},
             'selected_producer': best.producer, 'selected_length': best.physical_cost}
    return replace(incumbent, verified_words=tuple(candidates)), audit
