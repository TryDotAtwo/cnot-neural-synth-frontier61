"""Offline uniform-cost BFS. Incomplete catalogs never certify absence."""
from dataclasses import dataclass
from ..contracts import MatrixState, WordCertificate


@dataclass
class ExactCatalog:
    alphabet: object
    distances: dict
    parents: dict
    status: str

    def certificate(self, state):
        if state not in self.distances:
            raise KeyError('unknown distance; absence is not infeasibility')
        gates = []
        current = state.packed_rows
        while self.parents[current] is not None:
            previous, gate = self.parents[current]
            gates.append(gate)
            current = previous
        return WordCertificate(state, MatrixState.identity(self.alphabet), tuple(gates),
                               self.distances[state], 'exact_small_bfs_v1', 'exact:' + self.alphabet.id)


def build_exact_small(n, alphabet, max_states=None):
    if n != alphabet.n or any(cost != 1 for cost in alphabet.costs):
        raise ValueError('BFS requires matching n and unit costs')
    if max_states is not None and (type(max_states) is not int or max_states < 1):
        raise ValueError('max_states must be positive')
    identity = tuple(1 << i for i in range(n))
    queue, distances, parents = [identity], {identity: 0}, {identity: None}
    status = 'complete'
    for rows in queue:
        for gate in alphabet.allowed:
            successor = list(rows)
            successor[gate.target] ^= successor[gate.control]
            successor = tuple(successor)
            if successor in distances:
                continue
            if max_states is not None and len(distances) >= max_states:
                status = 'resource_limit'
                break
            distances[successor] = distances[rows] + 1
            parents[successor] = rows, gate
            queue.append(successor)
        if status != 'complete':
            break
    return ExactCatalog(alphabet, {MatrixState(n, rows, alphabet.id): d for rows, d in distances.items()}, parents, status)
