"""Small complete GL(n,2) catalogs as independently verified exact anchors."""
from dataclasses import replace

from ..contracts import AlphabetSpec, MatrixState
from .exact_small import build_exact_small
from .replay import Replay


class ExactStreamSampler:
    def __init__(self, sizes=(3, 4)):
        self.catalogs = {}
        self.states = {}
        self.verified_records = {}
        for n in sizes:
            alphabet = AlphabetSpec.all_to_all(n)
            catalog = build_exact_small(n, alphabet)
            if catalog.status != 'complete':
                raise ValueError('incomplete exact catalog cannot supply labels')
            replay = Replay(alphabet)
            replay.ingest_exact(catalog)
            self.catalogs[alphabet.id] = catalog
            self.verified_records.update(replay.records)
            self.states[n] = tuple(sorted((state for state in catalog.distances
                                           if state != MatrixState.identity(alphabet)),
                                          key=lambda state: state.packed_rows))
        self.sizes = tuple(sizes)

    def record(self, epoch, position):
        if epoch < 0 or position < 0:
            raise ValueError('invalid exact schedule position')
        index = epoch * 10_000 + position
        n = self.sizes[index % len(self.sizes)]
        states = self.states[n]
        state = states[(index // len(self.sizes)) % len(states)]
        verified = self.verified_records[state.key]
        return replace(verified, lineage_id=f'exact_stream:{epoch}:{position}:{n}',
                       seed=index, split='train')
