import argparse
import collections
import hashlib
import json
import sqlite3
import sys
import zipfile
from pathlib import Path
from dotenv import load_dotenv
from huggingface_hub import HfApi, hf_hub_download
sys.path.insert(0, '/marimo/cnot_work')
from research_v3.data.stream_reader import read_position

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--start', type=int, required=True)
    ap.add_argument('--end', type=int, required=True)
    args = ap.parse_args()
    if not 0 <= args.start <= args.end < 10000:
        raise ValueError('invalid interval')
    root = Path('/marimo/cnot_work/research_v3/artifacts/datasets')
    db = root / 'own14_v6.sqlite'
    base = root / 'own14_v6_sealed_dev128_test128.zip'
    out = root / f'own14_v6_train_epoch0_{args.start:04d}_{args.end:04d}.zip'
    con = sqlite3.connect('file:' + str(db) + '?mode=ro', uri=True)
    cols = [row[1] for row in con.execute('pragma table_info(roots)')]
    rows = con.execute('select * from roots where split=? and epoch=? and position between ? and ? order by position', ('train', 0, args.start, args.end)).fetchall()
    if [row[cols.index('position')] for row in rows] != list(range(args.start, args.end + 1)):
        raise ValueError('noncontiguous train interval')
    counts = collections.Counter()
    certificates = 0
    suffixes = 0
    for position, row in zip(range(args.start, args.end + 1), rows):
        records, digest = read_position(con, 0, position, suffixes_per_root=0)
        if len(records) != 1 or digest != row[cols.index('root_digest')]:
            raise ValueError('root replay or digest mismatch')
        record = records[0]
        counts[record.state.n] += 1
        certificates += len(record.verified_words)
        suffixes += len(json.loads(row[cols.index('suffix_offsets_json')]))
    seal = json.loads(con.execute("select value from metadata where key='holdout_seal'").fetchone()[0])
    manifest = json.loads(con.execute("select value from metadata where key='manifest'").fetchone()[0])
    con.close()
    raw = bytes([10]).join(json.dumps(row, ensure_ascii=False, separators=(',', ':')).encode('utf-8') for row in rows) + bytes([10])
    body = {'schema': 'own14_v6_train_delta_v1', 'split': 'train', 'epoch': 0,
            'positions': [args.start, args.end], 'row_count': len(rows),
            'root_certificate_count': certificates, 'accepted_suffix_count': suffixes,
            'width_counts': dict(sorted(counts.items())), 'columns': cols,
            'base_sealed_archive_sha256': sha(base),
            'generator_manifest_sha256': hashlib.sha256(json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
            'seal_sha256': hashlib.sha256(json.dumps(seal, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
            'rows_jsonl_sha256': hashlib.sha256(raw).hexdigest(),
            'reader_check': 'read_position(suffixes_per_root=0) for every root; full certificate replay; root identity and forbidden closure'}
    with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=1) as z:
        z.writestr('manifest.json', json.dumps(body, sort_keys=True, indent=2))
        z.writestr('rows.jsonl', raw)
    with zipfile.ZipFile(out) as z:
        if z.testzip() is not None or hashlib.sha256(z.read('rows.jsonl')).hexdigest() != body['rows_jsonl_sha256']:
            raise ValueError('bad delta archive')
    print('delta', str(out), out.stat().st_size, sha(out), 'certificates', certificates, 'suffixes', suffixes, flush=True)
    load_dotenv('/marimo/.env')
    repo = 'TryDotAtwo/cnot-neural-synth-frontier61'
    remote_path = f'datasets/own14_v6/train_epoch0_{args.start:04d}_{args.end:04d}.zip'
    uploaded = HfApi().upload_file(path_or_fileobj=str(out), path_in_repo=remote_path, repo_id=repo, repo_type='model', commit_message='Archive verified own14 v6 train delta')
    downloaded = Path(hf_hub_download(repo_id=repo, filename=remote_path, repo_type='model', force_download=True))
    print('uploaded', str(uploaded), 'remote_match', sha(downloaded) == sha(out), flush=True)

if __name__ == '__main__':
    main()
