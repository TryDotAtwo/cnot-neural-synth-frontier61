"""Versioned O(1) fast path for canonical CNOT alphabet order.

Install explicitly in new runs; archived v6 source remains unchanged.
"""
from research_v3.contracts import AlphabetSpec, Gate

ORIGINAL_COST = AlphabetSpec.cost


def fast_cost(self, gate):
    if not isinstance(gate, Gate) or type(gate.control) is not int or type(gate.target) is not int:
        raise ValueError('gate indices must be integers, not bool')
    c, t = gate.control, gate.target
    if 0 <= c < self.n and 0 <= t < self.n and c != t:
        index = c * (self.n - 1) + t - (t > c)
        if index < len(self.allowed) and self.allowed[index] == gate:
            return self.costs[index]
    try:
        return self.costs[self.allowed.index(gate)]
    except ValueError:
        raise ValueError('gate outside alphabet') from None


def install():
    AlphabetSpec.cost = fast_cost
