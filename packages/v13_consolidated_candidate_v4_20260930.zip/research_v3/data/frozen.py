"""Immutable own-data panels and explicit finite symmetry-overlap audits."""
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
from ..contracts import AlphabetSpec, MatrixState, Gate, WordCertificate
from ..words import verify_word
from .records import SampleRecord
from .splits import known_symmetry_keys, SplitPolicy
from .matching import verify_record


def historical_states(stage17_root):
    root = Path(stage17_root).resolve()
    baseline = root / 'improved/research_v2/baselines.json'
    cases = json.loads(baseline.read_text(encoding='utf-8'))['cases']
    states, sources = [], {}
    for case in cases:
        path = (root / case['input_source']).resolve()
        if not path.is_relative_to(root / 'source_snapshot/inputs'):
            raise ValueError('historical input outside own snapshot')
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        if digest != case['input_file_sha256']:
            raise ValueError('historical input source drift')
        state = MatrixState.from_dense(json.loads(raw)['matrix'], AlphabetSpec.all_to_all(case['n']))
        states.append(state)
        sources[str(path)] = digest
    return tuple(states), sources


def forbidden_views(states):
    keys = set()
    for state in states:
        alphabet = AlphabetSpec.all_to_all(state.n)
        keys.update(known_symmetry_keys((state,), alphabet, (tuple(reversed(range(state.n))),)))
    return keys


def freeze(path, panels, historical, provenance):
    """Reject overlapping dev/test roots; remove entire unsafe train parents."""
    if set(panels) != {'train', 'dev', 'test'} or not provenance:
        raise ValueError('explicit three panels and provenance required')
    views, lineages = {}, {}
    for split, records in panels.items():
        roots = set()
        for record in records:
            if record.split != split:
                raise ValueError('wrong split or exact catalog labels require separate catalog artifact')
            verify_record(record)
            if not record.verified_words:
                raise ValueError('missing certificate')
            alphabet = AlphabetSpec.all_to_all(record.state.n)
            for cert in record.verified_words:
                verify_word(cert, alphabet)
                if cert.start != record.state or cert.end != MatrixState.identity(alphabet):
                    raise ValueError('certificate is not a complete root reduction')
            unit = (record.source, record.seed)
            if unit in lineages and lineages[unit] != split:
                raise ValueError('root seed family split leakage')
            lineages[unit] = split
            if record.state.key in roots:
                raise ValueError('duplicate root within panel')
            roots.add(record.state.key)
        views[split] = forbidden_views([r.state for r in records])
    historical_keys = forbidden_views(historical)
    if views['dev'] & views['test'] or (views['dev'] | views['test']) & historical_keys:
        raise ValueError('holdout finite-symmetry overlap')
    forbidden = historical_keys | views['dev'] | views['test']
    split_policy = SplitPolicy(forbidden)
    accepted, rejected = [], []
    for record in panels['train']:
        safe, _ = split_policy.filter_full_backup((record,), AlphabetSpec.all_to_all(record.state.n))
        # Also screen declared root symmetries; not a full orbit proof.
        if safe and not forbidden_views((record.state,)) & forbidden:
            accepted.append(record)
        else:
            rejected.append(record.lineage_id)
    body = {'schema':'own_frozen_panels_v1', 'provenance':provenance,
            'symmetries':'identity,inverse,transpose,inverse_transpose and wire reversal; not full orbit',
            'forbidden_keys':sorted(forbidden), 'historical_keys':sorted(historical_keys),
            'rejected_train_lineages':rejected,
            'panels':{split:[asdict(r) for r in (accepted if split == 'train' else records)]
                      for split, records in panels.items()}}
    raw = json.dumps(body, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
    path = Path(path)
    with path.open('xb') as stream:
        stream.write(raw)
    digest = hashlib.sha256(raw).hexdigest()
    with path.with_suffix('.sha256').open('x', encoding='ascii') as stream:
        stream.write(digest + '\n')
    return {'sha256':digest, 'counts':{k:len(v) for k,v in body['panels'].items()},
            'rejected_train':len(rejected), 'forbidden':len(forbidden)}


def load(path):
    path = Path(path)
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != path.with_suffix('.sha256').read_text().strip():
        raise ValueError('frozen dataset hash mismatch')
    body = json.loads(raw)
    if body['schema'] != 'own_frozen_panels_v1':
        raise ValueError('dataset schema mismatch')
    def state(obj):
        return MatrixState(obj['n'], tuple(obj['packed_rows']), obj['alphabet_id'])
    panels = {}
    for split, rows in body['panels'].items():
        records = []
        for row in rows:
            words = tuple(WordCertificate(state(c['start']), state(c['end']),
                                         tuple(Gate(**g) for g in c['gates']), c['physical_cost'],
                                         c['producer'], c['lineage_id']) for c in row['verified_words'])
            record = SampleRecord(state(row['state']), words, row['lineage_id'], row['seed'], row['source'], split,
                                  row.get('exact_distance'),row.get('exact_evidence'))
            verify_record(record)
            for cert in words:
                verify_word(cert, AlphabetSpec.all_to_all(record.state.n))
                if cert.start != record.state or cert.end != MatrixState.identity(AlphabetSpec.all_to_all(record.state.n)):
                    raise ValueError('invalid root certificate')
            records.append(record)
        panels[split] = tuple(records)
    return panels, { (n,a,tuple(rows)) for n,a,rows in body['forbidden_keys']}, body
