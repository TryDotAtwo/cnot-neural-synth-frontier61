import random
import numpy as np
from ..contracts import AlphabetSpec, MatrixState, WordCertificate
from ..words import apply, verify_word, invert_word
from .records import SampleRecord


def record_from_word(alphabet, word, lineage_id, seed, source='own_walk_v1'):
    state = MatrixState.identity(alphabet)
    cost = 0
    for gate in word:
        state = apply(state, gate, alphabet)
        cost += alphabet.cost(gate)
    certificate = WordCertificate(state, MatrixState.identity(alphabet), invert_word(word), cost, source, lineage_id)
    verify_word(certificate, alphabet)
    return SampleRecord(state, (certificate,), lineage_id, seed, source)


def generate(family, seed, n, count, steps):
    if family not in ('ordinary_walk', 'poisson_walk'):
        raise NotImplementedError('family source gate not verified')
    if count < 0 or steps < 0:
        raise ValueError('negative generation budget')
    alphabet = AlphabetSpec.all_to_all(n)
    rng, poisson = random.Random(seed), np.random.default_rng(seed)
    records = []
    for i in range(count):
        length = steps if family == 'ordinary_walk' else int(poisson.poisson(steps))
        if not alphabet.allowed and length:
            raise ValueError('nonzero walk requested on empty alphabet')
        word = tuple(rng.choice(alphabet.allowed) for _ in range(length))
        records.append(record_from_word(alphabet, word, f'{family}:{seed}:{n}:{i}', seed, family + '_v1'))
    return records
