"""Exact distances only when a full CNOT word meets rank(M-I)."""
from dataclasses import replace
import hashlib
from ..bounds import cheap_bounds,verify_bounds
from ..contracts import AlphabetSpec,BoundCertificate,BoundSet,MatrixState

PREFIX='rank_defect_matching_word_v1:'


def _evidence(state,distance):
    return PREFIX+hashlib.sha256(repr((state.key,distance)).encode()).hexdigest()


def certify_record(record):
    alphabet=AlphabetSpec.all_to_all(record.state.n)
    if record.state.alphabet_id!=alphabet.id or not record.verified_words:
        raise ValueError('requires full all-to-all unit-cost word')
    rank_bound=next(c for c in cheap_bounds(record.state).lower if c.witness_ref=='rank_defect')
    distance=record.upper_bound
    if distance!=rank_bound.value:
        raise ValueError('verified upper bound does not meet rank lower bound')
    exact=BoundCertificate('exact',distance,alphabet.id,{'state_key':record.state.key},
                           'matching_verified_bounds','rank_defect_matching_v1')
    verify_bounds(record.state,BoundSet(lower=(rank_bound,),upper=record.verified_words,exact=exact),alphabet)
    return replace(record,exact_distance=distance,exact_evidence=_evidence(record.state,distance))


def verify_record(record):
    if record.exact_distance is None and record.exact_evidence is None:
        return False
    if record.exact_distance is None or record.exact_evidence!=_evidence(record.state,record.exact_distance):
        raise ValueError('invalid matching-bound exact evidence')
    certified=certify_record(replace(record,exact_distance=None,exact_evidence=None))
    if record.exact_distance!=certified.exact_distance:
        raise ValueError('exact distance differs from matched verified bounds')
    return True
