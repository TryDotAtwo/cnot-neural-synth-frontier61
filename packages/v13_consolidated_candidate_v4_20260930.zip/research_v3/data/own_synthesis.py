"""Versioned adapter to our stage-17 full-matrix/basis synthesizer."""
import hashlib
import importlib
from pathlib import Path
import sys

import numpy as np

from ..contracts import AlphabetSpec, Gate, MatrixState, WordCertificate
from ..words import verify_word
from .generators import record_from_word


OWN_MODULES = ('shared_synth', 'stage16_reference', 'exact_basis', 'general_macro',
               'forest_exact', 'stage28_exact', 'defect_repair')


def source_hashes():
    directory = Path(__file__).resolve().parents[2] / 'code'
    return {name: hashlib.sha256((directory / (name + '.py')).read_bytes()).hexdigest()
            for name in OWN_MODULES}


def _own_compiler():
    directory = Path(__file__).resolve().parents[2] / 'code'
    for name in OWN_MODULES:
        module = sys.modules.get(name)
        if module is not None and Path(module.__file__).resolve().parent != directory:
            raise ValueError('conflicting own compiler import origin: ' + name)
    previous = sys.path.copy()
    try:
        sys.path.insert(0, str(directory))
        return directory, importlib.import_module('shared_synth')
    finally:
        sys.path[:] = previous


def solve_matrix_with_own_synth(state, *, seed, width=4, restarts=0, maxiter=0,
                               sweeps=1):
    """Return a checked complete reduction and a compiler audit.

    The compiled word is a verified upper bound. It is never an exact-distance
    label without a separate lower-bound certificate.
    """
    alphabet = AlphabetSpec.all_to_all(state.n)
    if state.alphabet_id != alphabet.id:
        raise ValueError('solver requires the own all-to-all CNOT alphabet')
    dense = np.array([[(row >> j) & 1 for j in range(state.n)]
                      for row in state.packed_rows], dtype=np.uint8)
    directory, compiler = _own_compiler()
    previous = sys.path.copy()
    try:
        sys.path.insert(0, str(directory))
        result = compiler.synthesize(
            dense, width=width, restarts=restarts, maxiter=maxiter, sweeps=sweeps,
            seed=seed, exact_postprocess=False, defect_postprocess=False,
            exact_local=True)
    finally:
        sys.path[:] = previous
    gates = tuple(Gate(int(c), int(t)) for c, t in result['gates'])
    encoded = record_from_word(alphabet, gates, f'own_synth:{seed}:{state.n}', seed,
                               'own_stage17_full_matrix_synth')
    if encoded.state != state or result['count'] != len(gates):
        raise ValueError('own synthesizer matrix/count mismatch')
    certificate = WordCertificate(state, MatrixState.identity(alphabet),
                                  encoded.verified_words[0].gates, len(gates),
                                  'own_stage17_full_matrix_synth', f'own_synth:{seed}:{state.n}')
    verify_word(certificate, alphabet)
    return certificate, {'status': result['status'], 'selected_order': result['selected_order'],
                         'count': len(gates), 'seconds': result['seconds'],
                         'compiler_source_sha256': source_hashes(),
                         'config': result['config']}
