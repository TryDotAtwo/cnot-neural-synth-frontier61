"""Adapter to our preserved compiler. No benchmark words are accepted as input."""
from pathlib import Path
import importlib
import sys
import numpy as np
from ..contracts import AlphabetSpec, Gate, MatrixState
from ..evidence import sha256
from .generators import record_from_word


def compile_example(alphabet, block, source_wires, target_wires, seed=1700, sweeps=2):
    if alphabet != AlphabetSpec.all_to_all(alphabet.n):
        raise ValueError('legacy basis adapter requires all-to-all unit alphabet')
    wires = tuple(source_wires) + tuple(target_wires)
    if any(type(i) is not int or not 0 <= i < alphabet.n for i in wires) or len(set(wires)) != len(wires):
        raise ValueError('invalid source/target wires')
    b = np.asarray(block)
    if b.shape != (len(target_wires), len(source_wires)) or not np.isin(b, (0, 1)).all():
        raise ValueError('invalid binary block')
    own_code = Path(__file__).resolve().parents[2] / 'code'
    names = ('shared_synth', 'stage16_reference', 'exact_basis')
    for name in names:
        loaded = sys.modules.get(name)
        if loaded is not None and Path(loaded.__file__).resolve().parent != own_code:
            raise ValueError('conflicting compiler import origin')
    previous_path = sys.path.copy()
    try:
        sys.path.insert(0, str(own_code))
        compiler = importlib.import_module('shared_synth')
        result = compiler.compile_shear(b.astype(np.uint8), source_wires, target_wires,
                                        width=4, restarts=0, maxiter=0, sweeps=sweeps,
                                        seed=seed, exact_local=True)
    finally:
        sys.path[:] = previous_path
    word = tuple(Gate(int(c), int(t)) for c, t in result['gates'])
    prep = tuple(Gate(int(c), int(t)) for c, t in result['preparation'])
    if len(word) != 2 * len(prep) + result['core_count']:
        raise ValueError('unpaid basis cost')
    if prep and (word[:len(prep)] != prep or word[-len(prep):] != tuple(reversed(prep))):
        raise ValueError('preparation/restoration mismatch')
    lineage = f'own_paid_basis:{seed}:{alphabet.n}:{tuple(source_wires)}:{tuple(target_wires)}'
    record = record_from_word(alphabet, word, lineage, seed, 'own_compile_shear_exact_local')
    target = [1 << i for i in range(alphabet.n)]
    for t, target_wire in enumerate(target_wires):
        for c, source_wire in enumerate(source_wires):
            target[target_wire] ^= int(b[t, c]) << source_wire
    if record.state != MatrixState(alphabet.n, tuple(target), alphabet.id):
        raise ValueError('compiler changed full target operator')
    audit = {'preparation': len(prep), 'core': result['core_count'], 'restoration': len(prep),
             'direct_cost': int(b.sum()), 'paid_cost': len(word), 'local_width': 4,
             'physical_block_shape': list(b.shape), 'sweeps': sweeps,
             'source_sha256': {name: sha256(own_code / (name + '.py')) for name in names}}
    return record, audit
