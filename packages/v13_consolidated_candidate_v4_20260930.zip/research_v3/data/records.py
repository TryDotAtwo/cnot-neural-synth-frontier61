from dataclasses import dataclass
from ..contracts import MatrixState, WordCertificate


@dataclass(frozen=True)
class SampleRecord:
    state: MatrixState
    verified_words: tuple[WordCertificate, ...]
    lineage_id: str
    seed: int
    source: str
    split: str = 'unassigned'
    exact_distance: int | None = None
    exact_evidence: str | None = None

    @property
    def upper_bound(self):
        return min(word.physical_cost for word in self.verified_words)
