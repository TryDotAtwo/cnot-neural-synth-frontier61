from dataclasses import replace
from ..contracts import MatrixState
from ..words import verify_word, apply
from .records import SampleRecord
import hashlib


class Replay:
    def __init__(self, alphabet, forbidden_keys=()):
        self.alphabet = alphabet
        self.forbidden_keys = set(forbidden_keys)
        self.records = {}
        self.lineages = {}

    def ingest_exact(self, catalog):
        if catalog.status != 'complete' or catalog.alphabet != self.alphabet:
            raise ValueError('exact ingestion requires complete matching-alphabet catalog')
        identity = MatrixState.identity(self.alphabet)
        if catalog.distances.get(identity) != 0:
            raise ValueError('exact potential must vanish at identity')
        pending = []
        for state, distance in catalog.distances.items():
            if type(distance) is not int or distance < 0:
                raise ValueError('invalid exact distance')
            word = catalog.certificate(state)
            verify_word(word, self.alphabet)
            if word.start != state or word.end != identity or word.physical_cost != distance:
                raise ValueError('exact upper-bound witness mismatch')
            # Closed neighbor set and a 1-Lipschitz potential prove the lower bound.
            for gate in self.alphabet.allowed:
                neighbor = apply(state, gate, self.alphabet)
                if neighbor not in catalog.distances or abs(distance - catalog.distances[neighbor]) > self.alphabet.cost(gate):
                    raise ValueError('invalid global distance potential/closure')
            pending.append((state, word, distance))
        digest = hashlib.sha256(repr(sorted((s.key, d) for s, d in catalog.distances.items())).encode()).hexdigest()
        ordinary = [SampleRecord(s, (word,), 'exact:' + digest, 0, 'exact_small_bfs_v1') for s, word, _ in pending]
        result = self.merge(ordinary)
        for state, _, distance in pending:
            self.records[state.key] = replace(self.records[state.key], exact_distance=distance,
                                              exact_evidence='closed_lipschitz_and_full_words:' + digest)
        return result

    def merge(self, records):
        # Validate the whole proposed batch before changing the replay.
        records = tuple(records)
        for record in records:
            if record.state.alphabet_id != self.alphabet.id or record.state.n != self.alphabet.n:
                raise ValueError('record/alphabet mismatch')
            if record.state.key in self.forbidden_keys:
                raise ValueError('forbidden benchmark/holdout label')
            if not record.verified_words:
                raise ValueError('missing upper-bound certificate')
            if record.exact_distance is not None:
                raise ValueError('exact labels require separate independently verified catalog ingestion')
            for word in record.verified_words:
                verify_word(word, self.alphabet)
                if word.start != record.state or word.end != MatrixState.identity(self.alphabet):
                    raise ValueError('word not a reduction of record')
        for record in records:
            key = record.state.key
            self.lineages.setdefault(key, set()).add(record.lineage_id)
            old = self.records.get(key)
            if old is None:
                self.records[key] = record
            else:
                words = tuple(sorted(set(old.verified_words + record.verified_words), key=lambda w: (w.physical_cost, w.gates)))
                self.records[key] = replace(old, verified_words=words)
        return {'ingested': len(records), 'unique': len(self.records)}
