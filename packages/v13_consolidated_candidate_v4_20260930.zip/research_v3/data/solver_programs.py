"""Own-synthesizer training targets and checked solution trajectories."""
from dataclasses import replace
import random
from time import perf_counter

import numpy as np

from ..contracts import AlphabetSpec, Gate, MatrixState, WordCertificate
from ..words import apply, verify_word
from .generators import generate, record_from_word
from .paid_basis import compile_example
from .records import SampleRecord
from .own_synthesis import solve_matrix_with_own_synth


def walk_with_solver(family, seed, n, steps, *, split):
    """Solve an I-random-walk endpoint with our synthesizer, retaining walk UB.

    The inverse walk is only an incumbent. The synthesizer is always called.
    A worse, failed, or invalid synthesizer result cannot worsen the label.
    """
    if family not in ('ordinary_walk', 'poisson_walk'):
        raise ValueError('unsupported walk family')
    incumbent = replace(generate(family, seed, n, 1, steps)[0], split=split)
    candidates = [incumbent.verified_words[0]]
    audit = {'family': family, 'seed': seed, 'n': n, 'steps_parameter': steps,
             'split': split, 'walk_length': candidates[0].physical_cost,
             'solver_called': True}
    started = perf_counter()
    try:
        solved, solver_audit = solve_matrix_with_own_synth(incumbent.state, seed=seed)
        verify_word(solved, AlphabetSpec.all_to_all(n))
        candidates.append(solved)
        audit['synthesizer'] = solver_audit
        audit['solver_status'] = 'verified'
    except Exception as error:
        audit['synthesizer'] = {'status': 'failed_or_invalid',
                                'error_type': type(error).__name__,
                                'error': str(error)}
        audit['solver_status'] = 'failed_or_invalid'
    audit['solver_seconds'] = perf_counter() - started
    best = min(candidates, key=lambda word: word.physical_cost)
    audit.update({'candidate_lengths': {word.producer: word.physical_cost for word in candidates},
                  'selected_producer': best.producer,
                  'selected_length': best.physical_cost,
                  'synth_improved': len(candidates) == 2 and best is solved and
                                    best.physical_cost < candidates[0].physical_cost})
    return replace(incumbent, verified_words=tuple(candidates)), audit


def basis_program(seed, n, *, split):
    """Construct a random shear and compile it with our stage-17 basis solver."""
    if n < 4:
        raise ValueError('basis family needs at least four wires')
    rng = random.Random(seed)
    wires = rng.sample(range(n), n)
    width = n // 2
    sources, targets = tuple(wires[:width]), tuple(wires[width:])
    block = np.array([[int(rng.random() < .35) for _ in sources]
                      for _ in targets], dtype=np.uint8)
    if not block.any():
        block[0, 0] = 1
    direct = tuple(Gate(sources[j], targets[i])
                   for i in range(len(targets)) for j in range(len(sources)) if block[i, j])
    direct_record = record_from_word(AlphabetSpec.all_to_all(n), direct,
                                     f'own_basis:{seed}:{n}', seed, 'direct_shear_incumbent')
    candidates = [direct_record.verified_words[0]]
    started = perf_counter()
    try:
        compiled, compiler_audit = compile_example(
            AlphabetSpec.all_to_all(n), block, sources, targets, seed=seed,
            sweeps=2)
        if direct_record.state != compiled.state:
            raise ValueError('own basis compiler changed target')
        candidates.append(compiled.verified_words[0])
        solver_status = 'verified'
    except Exception as error:
        compiler_audit = {'status': 'failed_or_invalid',
                          'error_type': type(error).__name__, 'error': str(error)}
        solver_status = 'failed_or_invalid'
    solver_seconds = perf_counter() - started
    best = min(candidates, key=lambda word: word.physical_cost)
    audit = {'family': 'basis_shear', 'seed': seed, 'n': n, 'split': split,
             'solver_called': True, 'solver_status': solver_status,
             'solver_seconds': solver_seconds,
             'candidate_lengths': {word.producer: word.physical_cost for word in candidates},
             'selected_producer': best.producer, 'selected_length': best.physical_cost,
             'compiler': compiler_audit}
    return SampleRecord(direct_record.state, tuple(candidates), f'basis_shear:{seed}:{n}', seed,
                        'own_stage17_basis_program', split), audit


def solution_suffixes(record):
    """Make verified M_j→I certificates from one selected complete solution."""
    return tuple(solution_suffix_at(record, offset) for offset in solution_offsets(record))


def solution_offsets(record):
    """Store only offsets; materialize full suffix words on training read."""
    alphabet = AlphabetSpec.all_to_all(record.state.n)
    if record.split != 'train':
        raise ValueError('suffix training requires a train parent lineage')
    for candidate in record.verified_words:
        verify_word(candidate, alphabet)
        if candidate.start != record.state or candidate.end != MatrixState.identity(alphabet):
            raise ValueError('invalid parent solution')
    selected = min(record.verified_words, key=lambda word: word.physical_cost)
    state = record.state
    by_state = {}
    for offset, gate in enumerate(selected.gates):
        by_state[state.key] = offset  # Later occurrence has the shorter suffix.
        state = apply(state, gate, alphabet)
    if state != MatrixState.identity(alphabet):
        raise ValueError('selected solution did not terminate at identity')
    return tuple(sorted(by_state.values()))


def solution_suffix_at(record, offset):
    alphabet = AlphabetSpec.all_to_all(record.state.n)
    if record.split != 'train':
        raise ValueError('suffix training requires a train parent lineage')
    selected = min(record.verified_words, key=lambda word: word.physical_cost)
    if type(offset) is not int or not 0 <= offset < len(selected.gates):
        raise ValueError('invalid suffix offset')
    state = record.state
    for gate in selected.gates[:offset]:
        state = apply(state, gate, alphabet)
    remaining = selected.gates[offset:]
    lineage = f'{record.lineage_id}:suffix:{offset}'
    cert = WordCertificate(state, MatrixState.identity(alphabet), remaining,
                           sum(alphabet.cost(g) for g in remaining),
                           selected.producer + '_suffix', lineage)
    verify_word(cert, alphabet)
    return SampleRecord(state, (cert,), lineage,
                        record.seed, record.source, 'train')
