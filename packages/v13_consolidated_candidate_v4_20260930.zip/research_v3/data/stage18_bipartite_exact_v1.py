"""Guarded matrix-only exact adapter for bipartite Acuaviva graph matrices.

The global distance theorem is Acuaviva et al., arXiv:2608.03825v1.
Only fixed labelled wires and unit-cost all-to-all CNOT are admitted.
"""
from __future__ import annotations
from collections import deque
from dataclasses import dataclass, replace
from random import Random
from ..contracts import AlphabetSpec, Gate, MatrixState, WordCertificate
from ..words import verify_word
from .records import SampleRecord

SOURCE_URL = 'https://arxiv.org/html/2608.03825v1'
SOURCE_NOTES_SHA256 = '8eb04960e885d49df91ad013472e01d53f4916b56c87ac30c9b5a33bba008ac9'

@dataclass(frozen=True)
class GraphModel:
    n: int
    z: int
    q: tuple[int, ...]
    x: tuple[int, ...]
    edges: tuple[tuple[int, int], ...]
    y: tuple[int, ...]

@dataclass(frozen=True)
class GraphResult:
    status: str
    state: MatrixState
    scope_id: str
    distance: int | None
    word: WordCertificate | None
    hypotheses: dict
    witness: dict
    reason: str | None = None

def _unsupported(state, alphabet, reason):
    return GraphResult('unsupported', state, alphabet.id, None, None, {}, {}, reason)

def _model_from_rows(rows):
    n = len(rows)
    if any(((r >> i) & 1) != 1 for i, r in enumerate(rows)):
        raise ValueError('requires unit diagonal')
    off = tuple(r ^ (1 << i) for i, r in enumerate(rows))
    roots = tuple(i for i, b in enumerate(off) if b == 0)
    if len(roots) != 1:
        raise ValueError('requires unique unchanged z row')
    z = roots[0]
    q = tuple(i for i, b in enumerate(off) if b == (1 << z))
    if not q:
        raise ValueError('requires vertex pairs')
    x = []
    for qi in q:
        candidates = tuple(i for i, b in enumerate(off) if b == (1 << qi))
        if len(candidates) != 1:
            raise ValueError('each q requires one x row')
        x.append(candidates[0])
    if len({z, *q, *x}) != 1 + 2 * len(q):
        raise ValueError('overlapping vertex registers')
    inverse_x = {wire: vertex for vertex, wire in enumerate(x)}
    pairs = []
    for yi in range(n):
        if yi in {z, *q, *x}:
            continue
        b = off[yi]
        if b.bit_count() != 3 or not (b & (1 << z)):
            raise ValueError('edge row has wrong support')
        support = b ^ (1 << z)
        endpoints = tuple(sorted(inverse_x[i] for i in range(n) if support & (1 << i) and i in inverse_x))
        if len(endpoints) != 2 or support != ((1 << x[endpoints[0]]) | (1 << x[endpoints[1]])):
            raise ValueError('edge support not two x rows')
        pairs.append((endpoints, yi))
    pairs.sort()
    if len({e for e, _ in pairs}) != len(pairs):
        raise ValueError('parallel edge')
    if n != 1 + 2 * len(q) + len(pairs):
        raise ValueError('wrong graph matrix dimension')
    return GraphModel(n, z, q, tuple(x), tuple(e for e, _ in pairs), tuple(y for _, y in pairs))

def _target_rows(model):
    rows = [1 << i for i in range(model.n)]
    for qi, xi in zip(model.q, model.x):
        rows[qi] ^= 1 << model.z
        rows[xi] ^= 1 << qi
    for (a, b), yi in zip(model.edges, model.y):
        rows[yi] ^= (1 << model.z) | (1 << model.x[a]) | (1 << model.x[b])
    return tuple(rows)

def _bipartite_certificate(model):
    v = len(model.q)
    adj = [set() for _ in range(v)]
    for a, b in model.edges:
        adj[a].add(b); adj[b].add(a)
    color = [None] * v
    for root in range(v):
        if color[root] is not None:
            continue
        color[root] = 0
        queue = deque([root])
        while queue:
            a = queue.popleft()
            for b in sorted(adj[a]):
                if color[b] is None:
                    color[b] = 1 - color[a]; queue.append(b)
                elif color[b] == color[a]:
                    raise ValueError('graph is not bipartite')
    left = tuple(i for i in range(v) if color[i] == 0)
    match_right = {}
    def augment(a, seen):
        for b in sorted(adj[a]):
            if b in seen:
                continue
            seen.add(b)
            prior = match_right.get(b)
            if prior is None or augment(prior, seen):
                match_right[b] = a
                return True
        return False
    for a in left:
        augment(a, set())
    match_left = {a: b for b, a in match_right.items()}
    reached_left = {a for a in left if a not in match_left}
    reached_right = set()
    queue = deque(sorted(reached_left))
    while queue:
        a = queue.popleft()
        for b in sorted(adj[a]):
            if match_left.get(a) == b or b in reached_right:
                continue
            reached_right.add(b)
            other = match_right.get(b)
            if other is not None and other not in reached_left:
                reached_left.add(other); queue.append(other)
    cover = tuple(sorted((set(left) - reached_left) | reached_right))
    matching = tuple(sorted((a, b) for b, a in match_right.items()))
    if len(cover) != len(matching):
        raise AssertionError('cover and matching differ')
    if any(a not in cover and b not in cover for a, b in model.edges):
        raise AssertionError('cover misses edge')
    if len({wire for pair in matching for wire in pair}) != 2 * len(matching):
        raise AssertionError('matching repeats endpoint')
    if any((a, b) not in model.edges and (b, a) not in model.edges for a, b in matching):
        raise AssertionError('matching uses absent edge')
    return cover, matching, tuple(color)

def _encoder(model, cover):
    selected = set(cover)
    incident = [[] for _ in model.q]
    for idx, (a, b) in enumerate(model.edges):
        incident[a].append((idx, b)); incident[b].append((idx, a))
    done = set(); gates = []
    for a in cover:
        gates.extend((Gate(model.z, model.q[a]), Gate(model.z, model.x[a])))
        for idx, b in incident[a]:
            if idx not in done:
                gates.extend((Gate(model.x[a], model.y[idx]), Gate(model.x[b], model.y[idx])))
                done.add(idx)
    if len(done) != len(model.edges):
        raise AssertionError('cover did not process every edge')
    for a in cover:
        gates.append(Gate(model.q[a], model.x[a]))
    for a in range(len(model.q)):
        if a not in selected:
            gates.extend((Gate(model.q[a], model.x[a]), Gate(model.z, model.q[a])))
    return tuple(gates)

def recognize(state, alphabet):
    if state.n != alphabet.n or state.alphabet_id != alphabet.id:
        raise ValueError('state/alphabet mismatch')
    if alphabet != AlphabetSpec.all_to_all(state.n):
        return _unsupported(state, alphabet, 'requires full unit all-to-all CNOT alphabet')
    try:
        model = _model_from_rows(state.packed_rows)
        if _target_rows(model) != state.packed_rows:
            raise ValueError('graph rows do not reconstruct full matrix')
        cover, matching, color = _bipartite_certificate(model)
    except ValueError as exc:
        return _unsupported(state, alphabet, str(exc))
    encoder = _encoder(model, cover)
    distance = 2 * len(model.q) + 2 * len(model.edges) + len(matching)
    if len(encoder) != distance:
        raise AssertionError('graph word length disagrees with theorem')
    word = WordCertificate(state, MatrixState.identity(alphabet), tuple(reversed(encoder)),
                           distance, 'stage18_bipartite_exact_v1',
                           f'stage18:{state.n}:{state.packed_rows}')
    verify_word(word, alphabet)
    hypotheses = {'full_unit_all_to_all': True, 'graph_matrix': True,
                  'bipartite': True, 'source_url': SOURCE_URL,
                  'source_notes_sha256': SOURCE_NOTES_SHA256}
    witness = {'z': model.z, 'q': model.q, 'x': model.x, 'y': model.y,
               'edges': model.edges, 'colors': color, 'cover': cover,
               'matching': matching, 'formula': (2 * len(model.q), 2 * len(model.edges), len(matching))}
    return GraphResult('exact', state, alphabet.id, distance, word, hypotheses, witness)

def verify_result(result, alphabet):
    if result.status != 'exact' or result.distance is None or result.word is None:
        return False
    if result.scope_id != alphabet.id or result.state.alphabet_id != alphabet.id:
        return False
    fresh = recognize(result.state, alphabet)
    if fresh.status != 'exact' or fresh.distance != result.distance or fresh.witness != result.witness:
        return False
    if result.hypotheses != fresh.hypotheses or result.word.physical_cost != result.distance:
        return False
    verify_word(result.word, alphabet)
    return True

def generate(seed, n, *, split):
    if type(seed) is not int or type(n) is not int or n < 8 or not split:
        raise ValueError('invalid graph generator input')
    v = max(1, (n - 1) // 3)
    while True:
        e = n - 1 - 2 * v
        if e >= 0 and e <= (v // 2) * (v - v // 2):
            break
        v += 1
        if v > (n - 1) // 2:
            raise ValueError('no bipartite graph shape for width')
    rng = Random(seed)
    candidates = [(a, b) for a in range(v // 2) for b in range(v // 2, v)]
    edges = tuple(sorted(rng.sample(candidates, e)))
    model = GraphModel(n, 0, tuple(range(1, v + 1)), tuple(range(v + 1, 2*v + 1)),
                       edges, tuple(range(2*v + 1, n)))
    rows = _target_rows(model)
    perm = list(range(n)); rng.shuffle(perm)
    permuted = [0] * n
    for i, row in enumerate(rows):
        bits = 0
        for j in range(n):
            if row & (1 << j):
                bits |= 1 << perm[j]
        permuted[perm[i]] = bits
    alphabet = AlphabetSpec.all_to_all(n)
    result = recognize(MatrixState(n, tuple(permuted), alphabet.id), alphabet)
    if result.status != 'exact' or not verify_result(result, alphabet):
        raise AssertionError('generated graph matrix not exact')
    return result

def ingest_exact(replay, result, *, seed, split):
    if result.status != 'exact' or not verify_result(result, replay.alphabet):
        raise ValueError('unsupported or invalid graph exact result')
    if result.state.key in replay.forbidden_keys:
        raise ValueError('forbidden holdout state')
    old = replay.records.get(result.state.key)
    if old is not None and old.exact_distance is not None and old.exact_distance != result.distance:
        raise ValueError('conflicting exact distance')
    record = SampleRecord(result.state, (result.word,),
                          f'stage18:{split}:{seed}:{result.state.n}', seed,
                          'stage18_bipartite_exact_v1', split)
    replay.merge((record,))
    current = replay.records[result.state.key]
    replay.records[result.state.key] = replace(current, exact_distance=result.distance,
         exact_evidence='acuaviva_2608.03825v1_notes_sha256:' + SOURCE_NOTES_SHA256)
    return replay.records[result.state.key]
