"""Guarded stage-35 exact two-changed-row adapter for full CNOT matrices.

The global lower-bound theorem is from 35_pair_kernel_to_global_geodesic_ru.md,
SHA-256 1b8ef924af6c68af51dd67e0be98148ad7f8e8c272d379ad44943b7baf3fade5.
No claim is made for other alphabets, costs, or more changed rows.
"""
from dataclasses import dataclass, replace
import random
from ..contracts import AlphabetSpec, Gate, MatrixState, WordCertificate
from ..words import verify_word
from .records import SampleRecord

SOURCE_SHA256 = '1b8ef924af6c68af51dd67e0be98148ad7f8e8c272d379ad44943b7baf3fade5'
FRAMES = {(1,2): (), (1,3): ((0,1),), (3,2): ((1,0),),
          (2,3): ((0,1),(1,0)), (3,1): ((1,0),(0,1)),
          (2,1): ((0,1),(1,0),(0,1))}


@dataclass(frozen=True)
class PairResult:
    status: str
    state: MatrixState
    scope_id: str
    distance: int | None
    word: WordCertificate | None
    hypotheses: dict
    witness: dict
    reason: str | None = None


def _mul(b, v):
    return ((b[0] & v).bit_count() & 1) | (((b[1] & v).bit_count() & 1) << 1)


def _inverse(b):
    a, x, y, d = b[0] & 1, (b[0] >> 1) & 1, b[1] & 1, (b[1] >> 1) & 1
    if (a & d) ^ (x & y) != 1:
        raise ValueError('singular active block')
    return (d | (x << 1), y | (a << 1))


def _components(rows):
    n = len(rows)
    parent = list(range(n))
    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    for i, row in enumerate(rows):
        bits = row & ~(1 << i)
        while bits:
            bit = bits & -bits
            j = bit.bit_length() - 1
            bits ^= bit
            a, b = root(i), root(j)
            if a != b:
                parent[a] = b
    return len({root(i) for i in range(n)})


def _unsupported(state, alphabet, reason):
    return PairResult('unsupported', state, alphabet.id, None, None,
                      {'source_sha256': SOURCE_SHA256}, {}, reason)


def recognize(state, alphabet):
    if state.n != alphabet.n or state.alphabet_id != alphabet.id:
        raise ValueError('state/alphabet mismatch')
    if alphabet != AlphabetSpec.all_to_all(alphabet.n):
        return _unsupported(state, alphabet, 'requires full unit CNOT alphabet')
    n = state.n
    if n < 2:
        return _unsupported(state, alphabet, 'requires at least two wires')
    rows = state.packed_rows
    changed = tuple(i for i, row in enumerate(rows) if row != (1 << i))
    if len(changed) > 2:
        return _unsupported(state, alphabet, 'more than two changed rows')
    active = list(changed)
    for i in range(n):
        if len(active) == 2:
            break
        if i not in active:
            active.append(i)
    a, b = active
    B = tuple(((rows[i] >> a) & 1) | (((rows[i] >> b) & 1) << 1) for i in active)
    inverse = _inverse(B)
    external = tuple(i for i in range(n) if i not in active)
    C = {j: ((rows[a] >> j) & 1) | (((rows[b] >> j) & 1) << 1) for j in external}
    X = {j: _mul(inverse, v) for j, v in C.items()}
    m = sum(v != 0 for v in X.values())
    shared = tuple(j for j, v in X.items() if v == 3)
    r = len(shared)
    if B == (1, 2) and r <= 2:
        encoder = [Gate(j, active[i]) for j, v in C.items()
                   for i in range(2) if (v >> i) & 1]
        distance = m + r
        branch = 'no_frame_motion'
    else:
        frame = FRAMES[B] if B != (1, 2) else ((0, 1), (0, 1))
        encoder = [Gate(j, active[0 if v == 1 else 1])
                   for j, v in X.items() if v in (1, 2)]
        c, t = frame[0]
        encoder.append(Gate(active[c], active[t]))
        first = [1, 2]
        first[t] ^= first[c]
        first_inv = _inverse(tuple(first))
        receiver = next(i for i in range(2) if _mul(first_inv, 1 << i) == 3)
        encoder.extend(Gate(j, active[receiver]) for j in shared)
        encoder.extend(Gate(active[c], active[t]) for c, t in frame[1:])
        distance = m + len(frame)
        branch = 'nonempty_frame_motion'
    if len(encoder) != distance:
        raise AssertionError('formula and constructed word disagree')
    word = WordCertificate(state, MatrixState.identity(alphabet),
                           tuple(reversed(encoder)), distance,
                           'stage35_pair_exact_v1',
                           f'stage35:{state.n}:{state.packed_rows}')
    verify_word(word, alphabet)
    connectivity = n - _components(rows)
    zero_diagonal = sum(((rows[i] >> i) & 1) == 0 for i in range(n))
    if B != (1, 2):
        lower = connectivity + zero_diagonal
        kind = 'connectivity_plus_diagonal_zeros'
    elif r >= 2:
        lower = connectivity + 1
        kind = 'tree_obstruction_two_common_sources'
    else:
        lower = connectivity
        kind = 'connectivity'
    if lower != distance:
        raise AssertionError('global lower bound does not match word')
    hypotheses = {'state_key': state.key, 'changed_rows': changed,
                  'all_to_all_unit': True, 'source_sha256': SOURCE_SHA256,
                  'active_rows': tuple(active), 'B_rows': B,
                  'nonzero_external_columns': m, 'shared_external_columns': r}
    witness = {'branch': branch, 'kind': kind, 'connectivity': connectivity,
               'zero_diagonal': zero_diagonal,
               'shared_sources': shared[:2], 'lower': lower,
               'encoder_gates': tuple(encoder)}
    return PairResult('exact', state, alphabet.id, distance, word,
                      hypotheses, witness)


def verify_result(result, alphabet):
    expected = recognize(result.state, alphabet)
    if result != expected:
        raise ValueError('stage35 result failed re-recognition')
    return result.status == 'exact'


def generate(seed, n, *, split):
    if type(seed) is not int or type(n) is not int or n < 2 or split not in ('train', 'dev', 'test'):
        raise ValueError('invalid pair-family input')
    rng = random.Random(seed)
    active = rng.sample(range(n), 2)
    B = rng.choice(tuple(FRAMES))
    rows = [1 << i for i in range(n)]
    a, b = active
    for i, wire in enumerate(active):
        rows[wire] = (((B[i] & 1) << a) | (((B[i] >> 1) & 1) << b))
    for j in range(n):
        if j in active:
            continue
        c = _mul(B, rng.randrange(4))
        rows[a] |= (c & 1) << j
        rows[b] |= ((c >> 1) & 1) << j
    alphabet = AlphabetSpec.all_to_all(n)
    state = MatrixState(n, tuple(rows), alphabet.id)
    result = recognize(state, alphabet)
    if result.status != 'exact':
        raise AssertionError('generated state was not recognized')
    return result


def ingest_exact(replay, result, *, seed, split):
    if result.status != 'exact' or not verify_result(result, replay.alphabet):
        raise ValueError('unsupported or invalid pair exact result')
    if result.state.key in replay.forbidden_keys:
        raise ValueError('forbidden holdout label')
    old = replay.records.get(result.state.key)
    if old is not None and old.exact_distance is not None and old.exact_distance != result.distance:
        raise ValueError('conflicting exact distance')
    record = SampleRecord(result.state, (result.word,),
                          f'stage35:{split}:{seed}:{result.state.n}', seed,
                          'stage35_pair_exact_v1', split)
    replay.merge((record,))
    current = replay.records[result.state.key]
    replay.records[result.state.key] = replace(current, exact_distance=result.distance,
        exact_evidence='stage35_pair_theorem_sha256:' + SOURCE_SHA256)
    return replay.records[result.state.key]
