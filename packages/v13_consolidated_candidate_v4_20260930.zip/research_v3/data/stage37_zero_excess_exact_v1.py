"""Own stage-37 zero-excess recognizer for complete unit-cost CNOT matrices.

The changed-row lower bound is globally saturated exactly when each row's
required XOR equals another initial or final row. This module builds and
checks a full word; a negative result excludes only the saturated length.
"""
from __future__ import annotations
from collections import deque
from dataclasses import dataclass
from ..contracts import AlphabetSpec, Gate, MatrixState, WordCertificate
from ..words import verify_word

SOURCE_NOTES_SHA256 = '144cfd8d91663581fee9edb79718d5fb93969dcda50a42e8939965024834c6f9'

@dataclass(frozen=True)
class ZeroExcessResult:
    status: str
    state: MatrixState
    scope_id: str
    distance: int | None
    word: WordCertificate | None
    hypotheses: dict
    witness: dict
    reason: str | None = None


def recognize(state: MatrixState, alphabet: AlphabetSpec) -> ZeroExcessResult:
    if state.n != alphabet.n or state.alphabet_id != alphabet.id:
        raise ValueError('state/alphabet mismatch')
    if alphabet != AlphabetSpec.all_to_all(state.n):
        return ZeroExcessResult('unsupported', state, alphabet.id, None, None, {}, {},
                                'requires complete unit-cost all-to-all CNOT')
    a = tuple(state.packed_rows)
    b = tuple(1 << i for i in range(state.n))
    changed = tuple(i for i in range(state.n) if a[i] != b[i])
    active = set(changed)
    initial = {value: i for i, value in enumerate(a)}
    final = {value: i for i, value in enumerate(b)}
    parent: dict[int, int] = {}
    mode: dict[int, str] = {}
    edges: dict[int, set[int]] = {i: set() for i in changed}
    indegree = {i: 0 for i in changed}
    missing = []
    for i in changed:
        diff = a[i] ^ b[i]
        j = initial.get(diff)
        if j is not None and j != i:
            parent[i] = j
            mode[i] = 'initial'
            if j in active and j not in edges[i]:
                edges[i].add(j)
                indegree[j] += 1
            continue
        j = final.get(diff)
        if j is not None and j != i:
            parent[i] = j
            mode[i] = 'final'
            if j in active and i not in edges[j]:
                edges[j].add(i)
                indegree[i] += 1
            continue
        missing.append(i)
    hypotheses = {'full_unit_all_to_all': True, 'changed_row_lower_bound': len(changed),
                  'source_notes_sha256': SOURCE_NOTES_SHA256}
    if missing:
        return ZeroExcessResult('certified_no_solution_within_scope', state, alphabet.id,
                                None, None, hypotheses,
                                {'changed': changed, 'missing': tuple(missing),
                                 'excluded_length': len(changed)},
                                'zero-excess criterion fails; greater distance unknown')
    queue = deque(sorted(i for i in changed if indegree[i] == 0))
    order = []
    while queue:
        i = queue.popleft()
        order.append(i)
        for j in sorted(edges[i]):
            indegree[j] -= 1
            if indegree[j] == 0:
                queue.append(j)
    if len(order) != len(changed):
        raise AssertionError('stage-37 acyclicity theorem contradicted')
    gates = tuple(Gate(parent[i], i) for i in order)
    word = WordCertificate(state, MatrixState.identity(alphabet), gates, len(gates),
                           'stage37:zero_excess', f'stage37:{state.n}:{state.packed_rows}')
    verify_word(word, alphabet)
    if len(gates) != len(changed) or word.physical_cost != len(changed):
        raise AssertionError('lower bound saturation failed')
    return ZeroExcessResult('exact', state, alphabet.id, len(changed), word, hypotheses,
                            {'changed': changed, 'order': tuple(order),
                             'parents': tuple((i, parent[i], mode[i]) for i in order),
                             'lower_bound': len(changed)})


def verify_result(result: ZeroExcessResult, alphabet: AlphabetSpec) -> bool:
    if result.status != 'exact' or result.word is None or result.distance is None:
        return False
    if result.scope_id != alphabet.id or result.state.alphabet_id != alphabet.id:
        return False
    fresh = recognize(result.state, alphabet)
    if (fresh.status, fresh.distance, fresh.hypotheses, fresh.witness) != (
            result.status, result.distance, result.hypotheses, result.witness):
        return False
    if result.word.physical_cost != result.distance:
        return False
    verify_word(result.word, alphabet)
    return True
