"""Deterministic own exact examples for the stage-37 zero-excess scope."""
from __future__ import annotations

import random

from ..contracts import AlphabetSpec, MatrixState
from .stage37_zero_excess_exact_v1 import recognize, verify_result, ZeroExcessResult


def generate(seed: int, n: int, *, split: str = 'train') -> ZeroExcessResult:
    if n < 2:
        raise ValueError('n must be at least 2')
    if split not in ('train', 'dev', 'test'):
        raise ValueError('unknown split')
    salt = {'train': 0x36a17, 'dev': 0x9be02, 'test': 0xd0471}[split]
    rng = random.Random((seed << 24) ^ (n << 8) ^ salt)
    alphabet = AlphabetSpec.all_to_all(n)
    rows = [1 << i for i in range(n)]
    targets = list(range(n))
    rng.shuffle(targets)
    count = rng.randrange(max(1, n // 2), n + 1)
    for target in targets[:count]:
        control = rng.randrange(n - 1)
        if control >= target:
            control += 1
        rows[target] ^= rows[control]
    state = MatrixState(n, tuple(rows), alphabet.id)
    result = recognize(state, alphabet)
    if result.status != 'exact' or result.distance != count or not verify_result(result, alphabet):
        raise AssertionError('stage37 construction failed exact replay')
    return result
