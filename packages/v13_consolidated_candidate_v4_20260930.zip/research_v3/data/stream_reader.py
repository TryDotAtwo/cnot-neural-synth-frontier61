"""Verified, bounded reads from the sealed own-solver training stream."""
import hashlib
from itertools import islice
import json

from ..contracts import AlphabetSpec, Gate, MatrixState, WordCertificate
from ..words import apply, verify_word
from .records import SampleRecord
from .solver_programs import solution_suffix_at
from .symmetry_records import augment_record, deterministic_transform
from .stream_solver_dataset import canonical


def _state(raw):
    return MatrixState(raw['n'], tuple(raw['packed_rows']), raw['alphabet_id'])


def _certificate(raw):
    return WordCertificate(_state(raw['start']), _state(raw['end']),
                           tuple(Gate(**gate) for gate in raw['gates']),
                           raw['physical_cost'], raw['producer'], raw['lineage_id'])


def decode_record(raw):
    data = json.loads(raw)
    record = SampleRecord(_state(data['state']),
                          tuple(_certificate(word) for word in data['verified_words']),
                          data['lineage_id'], data['seed'], data['source'], data['split'],
                          data['exact_distance'], data['exact_evidence'])
    alphabet = AlphabetSpec.all_to_all(record.state.n)
    for word in record.verified_words:
        verify_word(word, alphabet)
        if word.start != record.state or word.end != MatrixState.identity(alphabet):
            raise ValueError('stored root certificate has wrong endpoints')
    return record


def read_epoch(connection, epoch, *, suffixes_per_root=1):
    """Yield verified records without loading an epoch's full words into memory."""
    if not 0 <= epoch < 100 or not 0 <= suffixes_per_root:
        raise ValueError('invalid epoch or suffix count')
    if connection.execute("SELECT 1 FROM metadata WHERE key='holdout_seal'").fetchone() is None:
        raise ValueError('holdout is not sealed')
    cursor = connection.execute('''SELECT matrix_hash,matrix_json,record_json,audit_json,
                                          suffix_offsets_json,root_digest
                                   FROM roots WHERE split='train' AND epoch=? ORDER BY position''', (epoch,))
    for row in cursor:
        yield from _decode_row(connection, row, suffixes_per_root)


def read_position(connection, epoch, position, *, suffixes_per_root=1, augment_suffix=False):
    if not 0 <= epoch < 100 or not 0 <= position < 10_000:
        raise ValueError('invalid stream position')
    if connection.execute("SELECT 1 FROM metadata WHERE key='holdout_seal'").fetchone() is None:
        raise ValueError('holdout is not sealed')
    row = connection.execute('''SELECT matrix_hash,matrix_json,record_json,audit_json,
                                     suffix_offsets_json,root_digest
                              FROM roots WHERE split='train' AND epoch=? AND position=?''',
                             (epoch, position)).fetchone()
    if row is None:
        raise KeyError((epoch, position))
    records = tuple(_decode_row(connection, row, suffixes_per_root))
    if augment_suffix and len(records) > 1:
        transform = deterministic_transform(records[0].state.n, epoch, position)
        records = (records[0],) + tuple(augment_record(record, transform)
                                      for record in records[1:])
    return records, row[-1]


def _decode_row(connection, row, suffixes_per_root):
    digest, identity, packed, audit_json, offsets_json, root_digest = row
    if not 0 <= suffixes_per_root:
        raise ValueError('invalid suffix count')
    if hashlib.sha256(canonical((identity, packed, audit_json, offsets_json))
                      .encode('utf-8')).hexdigest() != root_digest:
        raise ValueError('stored root content digest mismatch')
    record = decode_record(packed)
    if record.split != 'train' or canonical(record.state.key) != identity or \
            hashlib.sha256(identity.encode('ascii')).hexdigest() != digest:
        raise ValueError('stored root identity mismatch')
    if connection.execute('SELECT 1 FROM forbidden_hashes WHERE state_hash=?',
                          (digest,)).fetchone():
        raise ValueError('stored root intersects holdout closure')
    yield record
    offsets = json.loads(offsets_json)
    if len(offsets) != len(set(offsets)) or offsets != sorted(offsets):
        raise ValueError('invalid stored suffix offsets')
    for offset in islice((value for value in offsets if value > 0), suffixes_per_root):
        suffix = solution_suffix_at(record, offset)
        state_hash = hashlib.sha256(canonical(suffix.state.key).encode('ascii')).hexdigest()
        if connection.execute('SELECT 1 FROM forbidden_hashes WHERE state_hash=?',
                              (state_hash,)).fetchone():
            raise ValueError('stored suffix intersects holdout closure')
        yield suffix


def admit_complete_neighbors(connection, records):
    """Check every model-visible parent and one-CNOT successor before forward."""
    count = 0
    for record in records:
        alphabet = AlphabetSpec.all_to_all(record.state.n)
        for state in (record.state,) + tuple(apply(record.state, gate, alphabet)
                                               for gate in alphabet.allowed):
            digest = hashlib.sha256(canonical(state.key).encode('ascii')).hexdigest()
            if connection.execute('SELECT 1 FROM forbidden_hashes WHERE state_hash=?',
                                  (digest,)).fetchone():
                raise ValueError('training parent or complete neighbor intersects holdout')
            count += 1
    return count


def admit_operator(connection, state):
    digest = hashlib.sha256(canonical(state.key).encode('ascii')).hexdigest()
    if connection.execute('SELECT 1 FROM forbidden_hashes WHERE state_hash=?',
                          (digest,)).fetchone():
        raise ValueError('basis operator intersects holdout closure')
