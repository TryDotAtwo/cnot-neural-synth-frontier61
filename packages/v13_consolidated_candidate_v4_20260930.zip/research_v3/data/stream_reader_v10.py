"""Versioned guarded exact reader for stage18 and stage35 v10 records."""
from .stream_reader import decode_record as _decode_record, read_epoch as _read_epoch
from .stage18_bipartite_exact_v1 import recognize as recognize_graph, verify_result as verify_graph, SOURCE_NOTES_SHA256
from .stage35_pair_exact_v1 import recognize as recognize_pair, verify_result as verify_pair, SOURCE_SHA256
from ..contracts import AlphabetSpec

def validate_exact(record):
    if record.exact_distance is None:
        if record.exact_evidence is not None:
            raise ValueError('exact evidence without distance')
        return record
    alphabet = AlphabetSpec.all_to_all(record.state.n)
    if record.source == 'stage18_bipartite_exact_v1':
        if record.exact_evidence != 'acuaviva_2608.03825v1_notes_sha256:' + SOURCE_NOTES_SHA256:
            raise ValueError('wrong stage18 proof source')
        result = recognize_graph(record.state, alphabet)
        valid = verify_graph(result, alphabet)
    elif record.source == 'stage35_pair_exact_v1':
        if record.exact_evidence != 'stage35_pair_theorem_sha256:' + SOURCE_SHA256:
            raise ValueError('wrong stage35 proof source')
        result = recognize_pair(record.state, alphabet)
        valid = verify_pair(result, alphabet)
    else:
        raise ValueError('unsupported exact producer in v10 reader')
    if not valid or result.status != 'exact' or result.distance != record.exact_distance:
        raise ValueError('exact claim does not match full matrix')
    if not any(word.physical_cost == result.distance for word in record.verified_words):
        raise ValueError('stored exact word has wrong physical cost')
    return record

def decode_record(raw):
    return validate_exact(_decode_record(raw))

def read_epoch(connection, epoch, *, suffixes_per_root=1):
    for record in _read_epoch(connection, epoch, suffixes_per_root=suffixes_per_root):
        yield validate_exact(record)
