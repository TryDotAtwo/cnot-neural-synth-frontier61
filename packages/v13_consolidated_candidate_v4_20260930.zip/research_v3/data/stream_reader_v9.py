"""Versioned reader guard for stage35 exact labels in v9 stream."""
from .stream_reader import decode_record as _decode_record, read_epoch as _read_epoch
from .stage35_pair_exact_v1 import recognize, verify_result, SOURCE_SHA256
from ..contracts import AlphabetSpec


def validate_exact(record):
    if record.exact_distance is None:
        if record.exact_evidence is not None:
            raise ValueError('exact evidence without exact distance')
        return record
    expected = 'stage35_pair_theorem_sha256:' + SOURCE_SHA256
    if record.exact_evidence != expected or record.source != 'stage35_pair_exact_v1':
        raise ValueError('unsupported exact evidence in v9 reader')
    alphabet = AlphabetSpec.all_to_all(record.state.n)
    result = recognize(record.state, alphabet)
    if result.status != 'exact' or result.distance != record.exact_distance:
        raise ValueError('stage35 exact claim does not match recognized matrix')
    if not verify_result(result, alphabet):
        raise ValueError('stage35 theorem witness failed full verification')
    if not any(word.physical_cost == record.exact_distance for word in record.verified_words):
        raise ValueError('stored exact word has wrong physical cost')
    return record


def decode_record(raw):
    return validate_exact(_decode_record(raw))


def read_epoch(connection, epoch, *, suffixes_per_root=1):
    for record in _read_epoch(connection, epoch, suffixes_per_root=suffixes_per_root):
        yield validate_exact(record)
