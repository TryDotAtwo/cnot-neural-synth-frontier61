"""Verified finite full-program augmentations of own training records."""
from dataclasses import replace

from ..contracts import AlphabetSpec, Gate, MatrixState, WordCertificate
from ..symmetry import map_problem
from ..words import verify_word


def augment_record(record, transform):
    alphabet = AlphabetSpec.all_to_all(record.state.n)
    mapped = map_problem(record.state, alphabet, transform)
    certificates = []
    for word in record.verified_words:
        verify_word(word, alphabet)
        if word.start != record.state or word.end != MatrixState.identity(alphabet):
            raise ValueError('augmentation requires a complete reduction')
        if transform == 'inverse':
            gates = tuple(reversed(word.gates))
        elif transform == 'transpose':
            gates = tuple(Gate(gate.target, gate.control) for gate in reversed(word.gates))
        elif isinstance(transform, tuple):
            gates = tuple(Gate(transform[gate.control], transform[gate.target])
                          for gate in word.gates)
        else:
            raise ValueError('unsupported training symmetry')
        cert = WordCertificate(mapped.state, MatrixState.identity(mapped.alphabet), gates,
                               word.physical_cost, word.producer + '_symmetry',
                               word.lineage_id + ':symmetry')
        verify_word(cert, mapped.alphabet)
        certificates.append(cert)
    if mapped.alphabet != alphabet:
        raise ValueError('augmentation changed fixed all-to-all alphabet')
    # Exact labels need their own mapped proof record; upper bounds suffice here.
    return replace(record, state=mapped.state, verified_words=tuple(certificates),
                   lineage_id=record.lineage_id + ':symmetry:' + str(transform),
                   exact_distance=None, exact_evidence=None)


def deterministic_transform(n, epoch, position):
    choice = (epoch * 10_000 + position) % 3
    return ('inverse', 'transpose', tuple(reversed(range(n))))[choice]
