import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/marimo/cnot_work')
from research_v3.data.composition_program_v1 import composition_program
from research_v3.contracts import AlphabetSpec,MatrixState
from research_v3.words import verify_word
results=[]
for n in (8,13):
 record,audit=composition_program(17,n,split='dev')
 record2,audit2=composition_program(17,n,split='dev')
 assert record==record2
 assert audit['family']=='composition' and len(audit['components'])==3
 alphabet=AlphabetSpec.all_to_all(n)
 for cert in record.verified_words:
  verify_word(cert,alphabet)
  assert cert.start==record.state and cert.end==MatrixState.identity(alphabet)
 assert record.split=='dev' and record.exact_distance is None
 results.append({'n':n,'certificates':len(record.verified_words),'selected_length':audit['selected_length'],'component_costs':[x['cost'] for x in audit['components']],'deterministic_record':True,'matrix_sha256':hashlib.sha256(str(record.state.key).encode()).hexdigest()})
for args in ((False,8,'dev'),(17,3,'dev'),(17,8,'other')):
 try:composition_program(args[0],args[1],split=args[2])
 except ValueError:pass
 else:raise AssertionError(('accepted_invalid',args))
report={'results':results,'negative_cases':3,'module_sha256':hashlib.sha256(Path('/marimo/cnot_work/research_v3/data/composition_program_v1.py').read_bytes()).hexdigest(),'exact_label_claimed':False}
p=Path('/marimo/cnot_work/research_v3/data/composition_program_v1_test.json');p.write_text(json.dumps(report,sort_keys=True,indent=2))
print(json.dumps(report,sort_keys=True))