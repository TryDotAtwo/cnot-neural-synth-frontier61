import sys,time,json,hashlib
sys.path.insert(0,'/marimo/cnot_work')
from research_v3.contracts import AlphabetSpec,Gate
from research_v3.data.fast_cost_v1 import fast_cost,ORIGINAL_COST
cases=0
for n in (2,3,8,26,144):
 a=AlphabetSpec.all_to_all(n)
 for g in a.allowed:
  assert ORIGINAL_COST(a,g)==fast_cost(a,g);cases+=1
 b=AlphabetSpec(n,tuple(reversed(a.allowed)),tuple(i+1 for i in range(len(a.allowed))),f'reversed:{n}')
 for g in b.allowed:
  assert ORIGINAL_COST(b,g)==fast_cost(b,g);cases+=1
 p=AlphabetSpec(n,a.allowed[:1],(7,),f'partial:{n}')
 for g in (a.allowed[0],a.allowed[-1],Gate(0,0),Gate(-1,0),Gate(n,0),Gate(0,n),Gate(True,1),Gate(0,False),'bad'):
  for z in (a,b,p):
   def outcome(fn):
    try:return ('ok',fn(z,g))
    except Exception as e:return ('error',type(e).__name__,str(e))
   assert outcome(ORIGINAL_COST)==outcome(fast_cost),(n,g,z.id);cases+=1
n=144;a=AlphabetSpec.all_to_all(n);seq=a.allowed[:10000]
t=time.perf_counter();x=sum(ORIGINAL_COST(a,g) for g in seq);old=time.perf_counter()-t
t=time.perf_counter();y=sum(fast_cost(a,g) for g in seq);new=time.perf_counter()-t
assert x==y
report={'parity_cases':cases,'benchmark_n':n,'benchmark_calls':len(seq),'original_s':old,'fast_s':new,'speedup':old/new,'source_sha256':hashlib.sha256(open('/marimo/cnot_work/research_v3/data/fast_cost_v1.py','rb').read()).hexdigest()}
from pathlib import Path
p=Path('/marimo/cnot_work/research_v3/data/fast_cost_v1_parity.json');p.write_text(json.dumps(report,sort_keys=True,indent=2))
print(json.dumps(report,sort_keys=True))