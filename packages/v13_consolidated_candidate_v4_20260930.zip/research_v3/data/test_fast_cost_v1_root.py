import sys,time,hashlib,json
from pathlib import Path
sys.path.insert(0,'/marimo/cnot_work')
from research_v3.contracts import AlphabetSpec
from research_v3.data.fast_cost_v1 import ORIGINAL_COST,fast_cost
from research_v3.data.stream_solver_dataset_v6 import make_root
args=('train',0,7,0,2700)
AlphabetSpec.cost=ORIGINAL_COST
t=time.perf_counter();a=make_root(*args);old=time.perf_counter()-t
AlphabetSpec.cost=fast_cost
try:
 t=time.perf_counter();b=make_root(*args);new=time.perf_counter()-t
finally:AlphabetSpec.cost=ORIGINAL_COST
assert a[0]==b[0]
def normalize(d):
 z=dict(d);z.pop('solver_seconds',None)
 if isinstance(z.get('synthesizer'),dict):
  z['synthesizer']=dict(z['synthesizer']);z['synthesizer'].pop('seconds',None)
 return z
assert normalize(a[1])==normalize(b[1])
report={'args':args,'identical_sample_record':True,'audit_equal_excluding_timing':True,'timing_fields':['solver_seconds','synthesizer.seconds'],'baseline_seconds':old,'fast_seconds':new,'speedup':old/new,'fast_module_sha256':hashlib.sha256(Path('/marimo/cnot_work/research_v3/data/fast_cost_v1.py').read_bytes()).hexdigest()}
p=Path('/marimo/cnot_work/research_v3/data/fast_cost_v1_root_parity.json');p.write_text(json.dumps(report,sort_keys=True,indent=2))
print(json.dumps(report,sort_keys=True),flush=True)