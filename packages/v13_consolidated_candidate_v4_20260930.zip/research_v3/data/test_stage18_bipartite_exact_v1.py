import unittest
from dataclasses import replace
from random import Random
from research_v3.contracts import AlphabetSpec, MatrixState
from research_v3.data.stage18_bipartite_exact_v1 import (
    GraphModel, _target_rows, generate, recognize, verify_result)

def layer_ball(start, radius):
    n = len(start)
    seen = {start}
    frontier = {start}
    for _ in range(radius):
        following = set()
        for rows in frontier:
            for control in range(n):
                for target in range(n):
                    if target == control:
                        continue
                    updated = list(rows)
                    updated[target] ^= updated[control]
                    next_rows = tuple(updated)
                    if next_rows not in seen:
                        following.add(next_rows)
        seen |= following
        frontier = following
    return seen

class Stage18Test(unittest.TestCase):
    def test_full_gl3_bfs_and_n6_lower(self):
        model = GraphModel(3, 0, (1,), (2,), (), ())
        target = _target_rows(model)
        identity = (1, 2, 4)
        self.assertNotIn(target, layer_ball(identity, 1))
        self.assertIn(target, layer_ball(identity, 2))
        result = recognize(MatrixState(3, target, AlphabetSpec.all_to_all(3).id), AlphabetSpec.all_to_all(3))
        self.assertEqual(result.distance, 2)
        model6 = GraphModel(6, 0, (1, 2), (3, 4), ((0, 1),), (5,))
        target6 = _target_rows(model6)
        result6 = recognize(MatrixState(6, target6, AlphabetSpec.all_to_all(6).id), AlphabetSpec.all_to_all(6))
        self.assertEqual(result6.distance, 7)
        self.assertFalse(layer_ball(tuple(1 << i for i in range(6)), 3) & layer_ball(target6, 3))

    def test_generated_all_widths(self):
        for n in (8, 10, 13, 25, 26, 34, 45, 50, 58, 72, 90, 108, 122, 144):
            for seed in (19, 73):
                with self.subTest(n=n, seed=seed):
                    result = generate(seed + n, n, split='test')
                    self.assertTrue(verify_result(result, AlphabetSpec.all_to_all(n)))
                    self.assertEqual(result.distance, result.word.physical_cost)
                    self.assertEqual(len(result.witness['matching']), len(result.witness['cover']))
                    self.assertFalse(verify_result(replace(result, distance=result.distance + 1), AlphabetSpec.all_to_all(n)))

    def test_small_cover_optimum_and_unsupported(self):
        rng = Random(20260928)
        for v in range(2, 8):
            candidates = [(a, b) for a in range(v // 2) for b in range(v // 2, v)]
            for _ in range(12):
                edges = tuple(e for e in candidates if rng.getrandbits(1))
                n = 1 + 2*v + len(edges)
                model = GraphModel(n, 0, tuple(range(1, v+1)), tuple(range(v+1, 2*v+1)), edges,
                                   tuple(range(2*v+1, n)))
                alphabet = AlphabetSpec.all_to_all(n)
                state = MatrixState(n, _target_rows(model), alphabet.id)
                result = recognize(state, alphabet)
                self.assertEqual(result.status, 'exact')
                brute = min(mask.bit_count() for mask in range(1 << v)
                            if all((mask >> a & 1) or (mask >> b & 1) for a, b in edges))
                self.assertEqual(len(result.witness['cover']), brute)
        triangle = GraphModel(10, 0, (1,2,3), (4,5,6), ((0,1),(0,2),(1,2)), (7,8,9))
        alpha = AlphabetSpec.all_to_all(10)
        bad = recognize(MatrixState(10, _target_rows(triangle), alpha.id), alpha)
        self.assertEqual(bad.status, 'unsupported')
        self.assertIsNone(bad.distance)
        identity = MatrixState.identity(alpha)
        self.assertEqual(recognize(identity, alpha).status, 'unsupported')

if __name__ == '__main__':
    unittest.main()
