import sys,time,json,hashlib
from dataclasses import replace
from pathlib import Path
sys.path.insert(0,'/marimo/cnot_work')
from research_v3.contracts import AlphabetSpec,Gate,MatrixState
from research_v3.data.exact_small import build_exact_small
from research_v3.data.stage35_pair_exact_v1 import recognize,verify_result,generate,ingest_exact,SOURCE_SHA256
from research_v3.data.replay import Replay
from research_v3.words import verify_word
started=time.perf_counter();counts={};unsupported={}
for n,total in ((2,6),(3,168),(4,20160)):
 alphabet=AlphabetSpec.all_to_all(n)
 catalog=build_exact_small(n,alphabet)
 assert catalog.status=='complete' and len(catalog.distances)==total
 count=0
 for state,distance in catalog.distances.items():
  result=recognize(state,alphabet)
  if result.status=='exact':
   assert verify_result(result,alphabet)
   assert result.distance==distance,(n,state.packed_rows,result.distance,distance)
   verify_word(result.word,alphabet)
   count+=1
  else:assert result.status=='unsupported' and result.distance is None and result.word is None
 counts[n]=count;unsupported[n]=total-count
assert sum(counts.values())==582,(counts,unsupported)
for n in (8,13,31,64):
 a=AlphabetSpec.all_to_all(n)
 for seed in range(10):
  r=generate(seed,n,split='train')
  assert verify_result(r,a) and r.distance==r.word.physical_cost
r=generate(71,8,split='train');a=AlphabetSpec.all_to_all(8)
replay=Replay(a);stored=ingest_exact(replay,r,seed=71,split='train')
assert stored.exact_distance==r.distance and stored.upper_bound==r.distance
for corrupt in (replace(r,distance=r.distance+1),replace(r,word=replace(r.word,physical_cost=r.distance+1))):
 try:ingest_exact(Replay(a),corrupt,seed=71,split='train')
 except ValueError:pass
 else:raise AssertionError('corrupt exact accepted')
try:ingest_exact(Replay(a,forbidden_keys={r.state.key}),r,seed=71,split='train')
except ValueError:pass
else:raise AssertionError('forbidden exact accepted')
restricted=AlphabetSpec(2,(Gate(0,1),),(1,),'restricted')
rs=MatrixState(2,(1,3),restricted.id)
assert recognize(rs,restricted).status=='unsupported'
three=next(s for s in build_exact_small(4,AlphabetSpec.all_to_all(4)).distances if sum(row!=(1<<i) for i,row in enumerate(s.packed_rows))>2)
assert recognize(three,AlphabetSpec.all_to_all(4)).status=='unsupported'
report={'gl_supported':counts,'gl_unsupported':unsupported,'random_verified':40,'negative_cases':5,'replay_ingest_verified':True,'source_sha256':SOURCE_SHA256,'adapter_sha256':hashlib.sha256(Path('/marimo/cnot_work/research_v3/data/stage35_pair_exact_v1.py').read_bytes()).hexdigest(),'seconds':time.perf_counter()-started,'scope':'stage35 at most two changed rows, full unit CNOT'}
p=Path('/marimo/cnot_work/research_v3/data/stage35_pair_exact_v1_test.json');p.write_text(json.dumps(report,sort_keys=True,indent=2))
print(json.dumps(report,sort_keys=True),flush=True)