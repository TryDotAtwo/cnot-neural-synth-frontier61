"""Independent small-group and full-word checks for the stage-37 adapter."""
from __future__ import annotations
import unittest
from research_v3.contracts import AlphabetSpec, MatrixState
from research_v3.data.exact_small import build_exact_small
from research_v3.data.stage37_zero_excess_exact_v1 import recognize, verify_result

class Stage37ZeroExcessTests(unittest.TestCase):
    def test_all_small_groups_against_full_bfs(self):
        for n, expected in ((2, 6), (3, 168), (4, 20160)):
            alphabet = AlphabetSpec.all_to_all(n)
            catalog = build_exact_small(n, alphabet)
            self.assertEqual(catalog.status, 'complete')
            self.assertEqual(len(catalog.distances), expected)
            positives = 0
            for state, distance in catalog.distances.items():
                result = recognize(state, alphabet)
                changed = sum(row != (1 << i) for i, row in enumerate(state.packed_rows))
                if result.status == 'exact':
                    positives += 1
                    self.assertEqual(result.distance, changed)
                    self.assertEqual(distance, changed)
                    self.assertTrue(verify_result(result, alphabet))
                else:
                    self.assertEqual(result.status, 'certified_no_solution_within_scope')
                    self.assertGreater(distance, changed)
                    self.assertIsNone(result.distance)
                    self.assertIsNone(result.word)
            self.assertGreater(positives, 0)
            print('small_group', n, 'states', expected, 'zero_excess', positives, flush=True)

    def test_constructed_large_full_words(self):
        for n in (8, 13, 25, 34, 50, 72, 90, 108, 122, 144):
            alphabet = AlphabetSpec.all_to_all(n)
            rows = [1 << i for i in range(n)]
            for i in range(1, n):
                rows[i] ^= rows[(i * 17 + 3) % i]
            state = MatrixState(n, tuple(rows), alphabet.id)
            result = recognize(state, alphabet)
            self.assertEqual(result.status, 'exact')
            self.assertEqual(result.distance, n - 1)
            self.assertTrue(verify_result(result, alphabet))
            print('large_word', n, result.distance, flush=True)

    def test_swap_excludes_only_changed_row_bound(self):
        alphabet = AlphabetSpec.all_to_all(2)
        state = MatrixState(2, (2, 1), alphabet.id)
        result = recognize(state, alphabet)
        self.assertEqual(result.status, 'certified_no_solution_within_scope')
        self.assertEqual(result.witness['excluded_length'], 2)
        self.assertIsNone(result.distance)
        self.assertEqual(build_exact_small(2, alphabet).distances[state], 3)

if __name__ == '__main__':
    unittest.main()
