import hashlib
import json
import unittest
from dataclasses import asdict, replace
from pathlib import Path
from research_v3.data.stream_solver_dataset_v10 import FAMILIES,SIZES,make_root,data_source_hashes
from research_v3.data.stream_reader_v10 import decode_record,validate_exact

class V10Test(unittest.TestCase):
    def test_exact_quarter_schedule(self):
        for roots in (32,128):
            counts={(n,f):0 for n in SIZES for f in FAMILIES}
            subtype={(n,k):0 for n in SIZES for k in ('stage18','stage35')}
            for i in range(len(SIZES)*roots):
                n=SIZES[i%len(SIZES)]; f=FAMILIES[(i//len(SIZES))%4]
                counts[n,f]+=1
                if f=='guarded_exact':
                    k='stage18' if (i//(len(SIZES)*4))%2==0 else 'stage35'
                    subtype[n,k]+=1
            self.assertEqual(set(counts.values()),{roots//4})
            self.assertEqual(set(subtype.values()),{roots//8})

    def test_both_exact_families_all_widths(self):
        for block,source in ((1,'stage18_bipartite_exact_v1'),(5,'stage35_pair_exact_v1')):
            for k,n in enumerate(SIZES):
                with self.subTest(source=source,n=n):
                    record,audit=make_root('test',0,block*len(SIZES)+k,0,7000)
                    self.assertEqual(record.source,source)
                    self.assertEqual(record.exact_distance,record.upper_bound)
                    self.assertEqual(audit['family'],'guarded_exact')
                    self.assertTrue(audit['verified_word'])
                    json.dumps(audit,sort_keys=True)
                    restored=decode_record(json.dumps(asdict(record),sort_keys=True))
                    self.assertEqual(restored.exact_distance,record.exact_distance)
                    for change in (dict(exact_distance=record.exact_distance+1),
                                   dict(exact_evidence='bogus'),dict(source='other')):
                        with self.assertRaises(ValueError):
                            validate_exact(replace(record,**change))

    def test_manifest(self):
        hashes=data_source_hashes()
        for name in ('data/stream_solver_dataset_v10.py','data/stream_reader_v10.py',
                     'data/stage18_bipartite_exact_v1.py','data/stage35_pair_exact_v1.py'):
            self.assertIn(name,hashes)
        for name,digest in hashes.items():
            self.assertEqual(hashlib.sha256((Path('research_v3')/name).read_bytes()).hexdigest(),digest)

if __name__=='__main__':
    unittest.main()
