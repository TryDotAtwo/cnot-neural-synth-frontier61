import hashlib
import json
import sqlite3
import tempfile
import unittest
from dataclasses import asdict, replace
from pathlib import Path
from unittest.mock import patch

from research_v3.contracts import AlphabetSpec, Gate
from research_v3.data.generators import record_from_word
from research_v3.data import stream_solver_dataset_v13 as generator
from research_v3.data import stream_reader_v13 as reader


class StreamV13Tests(unittest.TestCase):
    def test_compiler_drift_rejected_before_write_or_read(self):
        with tempfile.TemporaryDirectory() as directory:
            db = self.store(Path(directory) / 'roots.sqlite')
            try:
                generator.seal_holdout(db)
                with patch.object(generator, 'source_hashes', return_value={'drift': 'bad'}):
                    with self.assertRaisesRegex(ValueError, 'source drift'):
                        generator.build_epoch(db, split='train', epoch=0, count=1, seed_base=7000)
                    with self.assertRaisesRegex(ValueError, 'source drift'):
                        tuple(reader.read_epoch(db, 0))
                self.assertEqual(db.execute('SELECT COUNT(*) FROM roots').fetchone()[0], 0)
            finally:
                db.close()

    def test_v13_records_pass_cpu_gpu_transfer_validation(self):
        from research_v3.gpu import record_batch_v13
        for index in (0, 14, 28, 42, 70, 126):
            record, _ = generator.make_root('train', 0, index, 0, 7000)
            selected = record_batch_v13.validate_own_records((record,))
            self.assertEqual(len(selected), 1)
            self.assertEqual(selected[0].physical_cost, record.upper_bound)
            with self.assertRaises(ValueError):
                record_batch_v13.validate_own_records((replace(record, source='foreign'),))

    def test_seal_rejects_disjoint_roots_with_cross_split_symmetry(self):
        from research_v3.data.symmetry_records import augment_record
        alphabet = AlphabetSpec.all_to_all(8)
        dev = replace(record_from_word(alphabet, (Gate(0, 1), Gate(1, 2)),
                                       'dev:11', 11), split='dev')
        test = replace(augment_record(dev, 'transpose'), split='test', seed=22,
                       lineage_id='test:22')
        self.assertNotEqual(dev.state, test.state)
        with tempfile.TemporaryDirectory() as directory:
            db, _ = generator.open_store(Path(directory) / 'roots.sqlite', seed_base=7000,
                                          expected_dev_roots=1, expected_test_roots=1)
            try:
                for split, record in (('dev', dev), ('test', test)):
                    with patch.object(generator, 'make_root', return_value=(record, {
                        'family':'walk_mixture','solver_called':True,'solver_status':'verified'})):
                        generator.build_epoch(db, split=split, epoch=0, count=1, seed_base=7000)
                with self.assertRaisesRegex(ValueError, 'symmetry'):
                    generator.seal_holdout(db)
                self.assertIsNone(db.execute("SELECT 1 FROM metadata WHERE key='holdout_seal'").fetchone())
            finally:
                db.close()

    def store(self, path):
        return generator.open_store(path, seed_base=7000, expected_dev_roots=0,
                                    expected_test_roots=0)[0]

    def test_exact_records_commit_resume_and_read_epoch999(self):
        with tempfile.TemporaryDirectory() as directory:
            db = self.store(Path(directory) / 'roots.sqlite')
            try:
                generator.seal_holdout(db)
                # Start directly with the exact quarter so build_epoch really
                # commits exact records, rather than merely calling make_root.
                def exact_root(split, epoch, index, attempt, seed_base):
                    return generator.make_root_original(split, epoch,
                        len(generator.SIZES) + index, attempt, seed_base)
                original = generator.make_root
                with patch.object(generator, 'make_root_original', original, create=True), \
                     patch.object(generator, 'make_root', exact_root):
                    stats = generator.build_epoch(db, split='train', epoch=999,
                                                  count=1, seed_base=7000)
                    resumed = generator.build_epoch(db, split='train', epoch=999,
                                                    count=1, seed_base=7000)
                self.assertEqual(stats['new_roots'], 1)
                self.assertEqual(stats['solver_attempts'], 0)
                self.assertEqual(resumed['new_roots'], 0)
                records = tuple(reader.read_epoch(db, 999, suffixes_per_root=0))
                self.assertEqual(len(records), 1)
                self.assertIsNotNone(records[0].exact_distance)
            finally:
                db.close()

    def test_epoch_reader_rejects_onehop_leak_before_yield(self):
        alphabet = AlphabetSpec.all_to_all(8)
        root = replace(record_from_word(alphabet, (Gate(0, 1), Gate(2, 3), Gate(4, 5)),
                                        'train:1', 1), split='train')
        from research_v3.words import apply
        forbidden = apply(root.state, Gate(6, 7), alphabet)
        with tempfile.TemporaryDirectory() as directory:
            db = self.store(Path(directory) / 'roots.sqlite')
            try:
                generator.seal_holdout(db)
                with patch.object(generator, 'make_root', return_value=(root, {
                    'family': 'walk_mixture', 'solver_called': True,
                    'solver_status': 'verified'})):
                    generator.build_epoch(db, split='train', epoch=0, count=1, seed_base=7000)
                digest = hashlib.sha256(generator.canonical(forbidden.key).encode('ascii')).hexdigest()
                db.execute('INSERT INTO forbidden_hashes VALUES(?)', (digest,))
                with self.assertRaisesRegex(ValueError, 'neighbor|holdout'):
                    next(reader.read_epoch(db, 0, suffixes_per_root=0))
            finally:
                db.close()

    def test_stage37_exact_roundtrip_all_widths(self):
        from research_v3.data.stage37_zero_excess_generator_v1 import generate
        from research_v3.data.stage37_zero_excess_exact_v1 import SOURCE_NOTES_SHA256
        from research_v3.data.records import SampleRecord
        for n in generator.SIZES:
            result = generate(91, n)
            record = SampleRecord(result.state, (result.word,), 'stage37:train:91',
                91, 'stage37_zero_excess_exact_v1', 'train', result.distance,
                'stage37_zero_excess_theorem_sha256:' + SOURCE_NOTES_SHA256)
            restored = reader.decode_record(generator.canonical(asdict(record)))
            self.assertEqual(restored, record)
            with self.assertRaises(ValueError):
                reader.validate_exact(replace(record, exact_distance=result.distance + 1))


if __name__ == '__main__':
    unittest.main()
