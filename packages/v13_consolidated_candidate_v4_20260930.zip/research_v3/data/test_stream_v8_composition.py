import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,'/marimo/cnot_work')
from research_v3.data.stream_solver_dataset_v8 import make_root,epoch_seed,data_source_hashes,FAMILIES,SIZES,SCHEMA
from research_v3.data.composition_program_v1 import composition_program
from research_v3.contracts import AlphabetSpec,MatrixState
from research_v3.words import verify_word
assert len(FAMILIES)==4 and len(SIZES)==14 and FAMILIES[3]=='composition'
index=3*len(SIZES);record,audit=make_root('dev',0,index,0,3700)
seed=epoch_seed('dev',0,index,0,3700)
record2,audit2=composition_program(seed,SIZES[0],split='dev')
assert record==record2 and audit['family']=='composition'
a=AlphabetSpec.all_to_all(record.state.n)
for cert in record.verified_words:
 verify_word(cert,a)
 assert cert.start==record.state and cert.end==MatrixState.identity(a)
h=data_source_hashes();assert h['data/stream_solver_dataset_v8.py']==hashlib.sha256(Path('/marimo/cnot_work/research_v3/data/stream_solver_dataset_v8.py').read_bytes()).hexdigest()
assert h['data/composition_program_v1.py']==hashlib.sha256(Path('/marimo/cnot_work/research_v3/data/composition_program_v1.py').read_bytes()).hexdigest()
report={'schema':SCHEMA,'family':audit['family'],'index':index,'n':record.state.n,'certificates_verified':len(record.verified_words),'record_matches_direct_composition':True,'selected_length':audit['selected_length'],'source_hashes_verified':True,'source_hashes':h,'scope':'nonnormative integration smoke'}
p=Path('/marimo/cnot_work/research_v3/data/own14_v8_composition_integration.json');p.write_text(json.dumps(report,sort_keys=True,indent=2))
print(json.dumps({k:v for k,v in report.items() if k!='source_hashes'},sort_keys=True))