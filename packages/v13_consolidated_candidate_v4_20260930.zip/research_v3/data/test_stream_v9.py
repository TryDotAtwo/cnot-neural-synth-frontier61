import hashlib
import json
import unittest
from dataclasses import asdict, replace
from pathlib import Path
from research_v3.data.stream_solver_dataset_v9 import make_root, FAMILIES, SIZES, data_source_hashes
from research_v3.data.stream_reader_v9 import decode_record, validate_exact

class StreamV9Test(unittest.TestCase):
    def test_schedule(self):
        for roots in (32, 128):
            counts = {(n, f): 0 for n in SIZES for f in FAMILIES}
            for i in range(len(SIZES) * roots):
                counts[SIZES[i % len(SIZES)], FAMILIES[(i // len(SIZES)) % 4]] += 1
            self.assertEqual(set(counts.values()), {roots // 4})

    def test_stage35_all_sizes_and_roundtrip(self):
        for k, n in enumerate(SIZES):
            with self.subTest(n=n):
                record, audit = make_root('test', 0, len(SIZES) + k, 0, 91000)
                self.assertEqual(record.state.n, n)
                self.assertEqual(record.exact_distance, record.upper_bound)
                self.assertEqual(audit['family'], 'stage35_pair_exact')
                json.dumps(audit, sort_keys=True)
                restored = decode_record(json.dumps(asdict(record), sort_keys=True))
                self.assertEqual(restored.exact_distance, record.exact_distance)
                for change in (dict(exact_distance=record.exact_distance + 1),
                               dict(exact_evidence='bogus'), dict(source='other')):
                    with self.assertRaises(ValueError):
                        validate_exact(replace(record, **change))

    def test_source_manifest(self):
        hashes = data_source_hashes()
        self.assertIn('data/stream_solver_dataset_v9.py', hashes)
        self.assertIn('data/stream_reader_v9.py', hashes)
        self.assertIn('data/stage35_pair_exact_v1.py', hashes)
        for name, digest in hashes.items():
            self.assertEqual(hashlib.sha256((Path('research_v3') / name).read_bytes()).hexdigest(), digest)

if __name__ == '__main__':
    unittest.main()
