"""Complete small-catalog proof context for root-only exact CUDA anchors."""
from types import MappingProxyType
from dataclasses import dataclass
from typing import Mapping
from ..contracts import MatrixState
from ..words import verify_word
from .replay import Replay


@dataclass(frozen=True, init=False)
class VerifiedExactCatalog:
    alphabet: object
    records: Mapping
    evidence: str

    def __init__(self, catalog):
        replay = Replay(catalog.alphabet)
        replay.ingest_exact(catalog)  # Complete closure, Lipschitz potential, words.
        records = MappingProxyType(dict(replay.records))
        object.__setattr__(self, 'alphabet', catalog.alphabet)
        object.__setattr__(self, 'records', records)
        object.__setattr__(self, 'evidence',
                           records[MatrixState.identity(catalog.alphabet).key].exact_evidence)

    def validate(self, record):
        if (record.source != 'exact_small_bfs_v1' or record.split != 'train' or
                record.state.n != self.alphabet.n or
                record.state.alphabet_id != self.alphabet.id):
            raise ValueError('exact anchor source/split/alphabet mismatch')
        expected = self.records.get(record.state.key)
        if (expected is None or record.exact_distance != expected.exact_distance or
                record.exact_evidence != self.evidence or record.exact_distance == 0):
            raise ValueError('exact anchor differs from complete catalog proof')
        if not record.verified_words:
            raise ValueError('exact anchor lacks full word')
        has_exact = False
        for word in record.verified_words:
            verify_word(word, self.alphabet)
            if (word.start != record.state or word.end != MatrixState.identity(self.alphabet) or
                    word.physical_cost < record.exact_distance or
                    word.producer not in ('exact_small_bfs_v1', 'own_neural_refresh_v13')):
                raise ValueError('invalid exact anchor word/provenance')
            has_exact |= word.physical_cost == record.exact_distance
        if not has_exact:
            raise ValueError('exact anchor has no exact-distance witness')
        return record
