"""Reference uniform ordered-CNOT continuous-time projections."""
