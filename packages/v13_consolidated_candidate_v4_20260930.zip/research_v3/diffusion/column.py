import math
from .common import projection, profile


def column_chain(n):
    if type(n) is not int or n < 1:
        raise ValueError('positive column width required')
    states = tuple((b,k) for b in (0,1) for k in range(n) if b+k)
    index = {s:i for i,s in enumerate(states)}
    entries = []
    for i,(b,k) in enumerate(states):
        moves = [((b,k), (n-b-k)*(n-1)), ((1-b,k),k),
                 ((b,k+1),(b+k)*(n-1-k)), ((b,k-1),k*(b+k-1))]
        entries.extend((i,index[s],count) for s,count in moves if count)
    return projection(states,entries,[math.comb(n-1,k) for b,k in states],n,'source_relative_column_class')


def column_profile(n, times):
    """Start exactly at e_j; uniformity within source-relative classes applies."""
    return profile(column_chain(n),(1,0),times,endpoint_uniform=True)
