from dataclasses import dataclass
import math
import numpy as np
from scipy.sparse import csr_matrix, eye
from scipy.sparse.linalg import expm_multiply


@dataclass
class Projection:
    states: tuple
    counts: object
    generator: object
    class_sizes: tuple
    stationary: object
    scope: str


def projection(states, entries, sizes, n, scope):
    states = tuple(states)
    rows, cols, counts = zip(*entries) if entries else ((), (), ())
    transitions = csr_matrix((counts, (rows, cols)), shape=(len(states),len(states)), dtype=np.float64)
    rate = n*(n-1)
    q = transitions / rate - eye(len(states), format='csr') if rate else transitions.copy()
    total = sum(sizes)
    return Projection(states, transitions, q, tuple(sizes), np.array([s/total for s in sizes]), scope)


def profile(chain, initial, times, endpoint_uniform=False):
    if initial not in chain.states:
        raise ValueError('initial state outside projection')
    times = tuple(times)
    if any(not math.isfinite(t) or t < 0 for t in times):
        raise ValueError('nonnegative finite diffusion times required')
    start = np.zeros(len(chain.states)); start[chain.states.index(initial)] = 1.
    masses = np.stack([start.copy() if t == 0 else expm_multiply(chain.generator.T*t, start) for t in times])
    if (masses < -1e-12).any():
        raise ArithmeticError('negative numerical diffusion mass')
    exact_zero = np.array([(start == 0) if t == 0 else np.zeros(len(start),dtype=bool) for t in times])
    underflow = (masses == 0) & ~exact_zero
    with np.errstate(divide='ignore',invalid='ignore'):
        logmass = np.log(masses)
        logsize = np.array([math.log(size) for size in chain.class_sizes])
        logrelative = logmass - np.log(chain.stationary)[None,:]
    return {'states':chain.states,'times':times,'raw_class_mass':masses,'log_class_size':logsize,
            'stationary_class_mass':chain.stationary,'log_relative_density':logrelative,
            'density_scope':chain.scope, 'exact_zero':exact_zero,'underflow':underflow,
            'endpoint_log_probability':logmass-logsize if endpoint_uniform else None,
            'endpoint_uniformity':endpoint_uniform,'mass_error':np.abs(masses.sum(axis=1)-1),
            'accuracy':'exact integer transition counts; floating sparse exponential, no formal numerical error certificate'}
