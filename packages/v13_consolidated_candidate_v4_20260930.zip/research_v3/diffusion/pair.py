import math
from .common import projection, profile


def pair_chain(n, max_states=100000):
    if type(n) is not int or n < 2:
        raise ValueError('rank2 projection requires n>=2')
    count = math.comb(n+3,3)-1-3*n
    if count > max_states:
        raise MemoryError(f'pair resource_limit: {count} states exceeds {max_states}')
    states = tuple((a,b,c,n-a-b-c) for a in range(n+1) for b in range(n-a+1)
                   for c in range(n-a-b+1) if sum(x>0 for x in (b,c,n-a-b-c)) >= 2)
    index = {state:i for i,state in enumerate(states)}
    entries, sizes = [], []
    for i,h in enumerate(states):
        sizes.append(math.factorial(n)//math.prod(math.factorial(x) for x in h))
        for a in range(4):
            for b in range(4):
                ways = h[a]*(h[b]-(a==b))
                if ways:
                    successor = list(h)
                    successor[b] -= 1
                    successor[a^b] += 1
                    entries.append((i,index[tuple(successor)],ways))
    return projection(states,entries,sizes,n,'rank2_pair_histogram_class')


def pair_profile(n, initial_histogram, times, max_states=100000):
    # Histogram input does not justify uniformity over labeled endpoints.
    return profile(pair_chain(n,max_states),tuple(initial_histogram),times,endpoint_uniform=False)
