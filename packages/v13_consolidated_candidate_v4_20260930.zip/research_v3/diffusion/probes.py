"""Joint column moments under one shared Poisson CNOT word per sample."""
import math
import numpy as np


def joint_probes(state, *, time, samples, seed, columns=None):
    if not math.isfinite(time) or time < 0 or type(samples) is not int or samples < 2:
        raise ValueError('finite nonnegative time and at least two samples required')
    columns = tuple(range(state.n)) if columns is None else tuple(columns)
    if not columns or any(type(c) is not int or not 0 <= c < state.n for c in columns):
        raise ValueError('invalid probe columns')
    rng = np.random.default_rng(seed)
    values = np.empty((samples,len(columns)),dtype=np.float64)
    intersections = np.empty((samples,len(columns),len(columns)),dtype=np.float64)
    xor_weights = np.empty_like(intersections)
    character = np.empty_like(values)
    total_gates = 0
    for i in range(samples):
        rows = list(state.packed_rows)
        steps = int(rng.poisson(time)) if state.n > 1 else 0
        total_gates += steps
        for _ in range(steps):
            control = int(rng.integers(state.n))
            target = int(rng.integers(state.n-1))
            target += target >= control
            rows[target] ^= rows[control]
        masks = [sum(((row>>c)&1)<<r for r,row in enumerate(rows)) for c in columns]
        values[i] = [mask.bit_count() for mask in masks]
        character[i] = [(-1.)**int(mask.bit_count()&1) for mask in masks]
        for c,left in enumerate(masks):
            for d,right in enumerate(masks):
                intersections[i,c,d] = (left&right).bit_count()
                xor_weights[i,c,d] = (left^right).bit_count()
    covariance = np.atleast_2d(np.cov(values,rowvar=False,ddof=1))
    character_pair = character[:,:,None]*character[:,None,:]
    weight_centered = values-values.mean(axis=0)
    intersection_centered = intersections-intersections.mean(axis=0)
    xor_centered = xor_weights-xor_weights.mean(axis=0)
    weight_intersection_covariance = np.einsum('sc,scd->cd',weight_centered,intersection_centered)/(samples-1)
    weight_xor_covariance = np.einsum('sc,scd->cd',weight_centered,xor_centered)/(samples-1)
    standard_error = lambda data: data.std(axis=0,ddof=1)/math.sqrt(samples)
    return {'mean_column_weight':values.mean(axis=0),'covariance_column_weight':covariance,
            'covariance_weight_intersection':weight_intersection_covariance,
            'covariance_weight_xor':weight_xor_covariance,
            'mean_intersection':intersections.mean(axis=0),'mean_xor_weight':xor_weights.mean(axis=0),
            'character_mean':character.mean(axis=0),'character_pair_mean':character_pair.mean(axis=0),
            'character_pair_covariance':character_pair.mean(axis=0)-character.mean(axis=0)[:,None]*character.mean(axis=0)[None,:],
            'intersection_standard_error':standard_error(intersections),'xor_standard_error':standard_error(xor_weights),
            'character_pair_standard_error':standard_error(character_pair),
            'mean_standard_error':values.std(axis=0,ddof=1)/math.sqrt(samples),
            'raw_samples':values,'samples':samples,'seed':seed,'time':time,'physical_gates_sampled':total_gates,
            'process':'uniform ordered CNOT; rate1; one shared word for all columns',
            'accuracy':'Monte Carlo moments, not exact heat probabilities'}
