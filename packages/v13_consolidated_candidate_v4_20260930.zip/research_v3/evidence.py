"""Independent source and word evidence audit (T00)."""
import hashlib
import json
from pathlib import Path


def sha256(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def audit_explained_drift(record):
    """Undo recorded textual patches in memory, never modifying the source."""
    source = Path(record['source_file'])
    if not source.is_file():
        return {'status': 'missing'}
    actual = sha256(source)
    result = {'status': 'unresolved', 'actual_sha256': actual}
    if actual != record['current_sha256']:
        return result
    text = source.read_text(encoding='utf-8')
    try:
        for patch in reversed(record['patches']):
            hunks = []
            current = None
            for line in patch['patch'].splitlines():
                if line.startswith('@@'):
                    current = []
                    hunks.append(current)
                elif line.startswith('***'):
                    current = None
                elif current is not None:
                    current.append(line)
            for hunk in reversed(hunks):
                before = '\n'.join(line[1:] for line in hunk if line.startswith((' ', '-')))
                after = '\n'.join(line[1:] for line in hunk if line.startswith((' ', '+')))
                if not after or text.count(after + '\n') != 1:
                    raise ValueError('ambiguous or missing patch context')
                text = text.replace(after + '\n', before + '\n', 1)
        reconstructed = hashlib.sha256(text.encode('utf-8')).hexdigest()
        result['reconstructed_sha256'] = reconstructed
        if reconstructed == record['pinned_sha256']:
            result['status'] = 'explained'
    except ValueError as error:
        result['reason'] = str(error)
    return result


def audit_sources(source_manifest: Path, allowed_root: Path) -> dict:
    """Report integrity and path scope separately from mathematical validity."""
    manifest = json.loads(Path(source_manifest).read_text(encoding='utf-8-sig'))
    root = Path(allowed_root).resolve()
    files = []
    for entry in manifest['current_project_files']:
        path = Path(entry['path']).resolve()
        actual = None
        if not path.is_relative_to(root):
            status = 'outside_allowed_root'
        elif not path.is_file():
            status = 'missing'
        else:
            actual = sha256(path)
            status = 'match' if actual == entry['sha256'] else 'drift'
        files.append({'path': str(path), 'expected_sha256': entry['sha256'],
                      'actual_sha256': actual, 'status': status})
    return {'files': files, 'source_integrity': all(f['status'] == 'match' for f in files),
            'word_validity': 'uncomputed', 'optimality': 'uncomputed',
            'provenance_scope': str(root)}


def verify_encoder(matrix, cert) -> dict:
    """Replay every bit independently; stored verified flags are not trusted."""
    n = len(matrix)
    if n < 1 or any(len(row) != n or any(type(x) not in (int, bool) or x not in (0, 1)
                                        for x in row) for row in matrix):
        raise ValueError('invalid square binary matrix')
    gates = cert['gates']
    if type(cert['count']) is not int or cert['count'] != len(gates):
        raise ValueError('count mismatch')
    rows = [1 << i for i in range(n)]
    target = [sum(int(bit) << j for j, bit in enumerate(row)) for row in matrix]
    for gate in gates:
        if len(gate) != 2 or any(type(i) is not int or not 0 <= i < n for i in gate):
            raise ValueError('invalid gate')
        c, t = gate
        if c == t:
            raise ValueError('self gate')
        rows[t] ^= rows[c]
    if rows != target:
        raise ValueError('encoder endpoint mismatch')
    reduction = target.copy()
    for c, t in reversed(gates):
        reduction[t] ^= reduction[c]
    if reduction != [1 << i for i in range(n)]:
        raise ValueError('reduction endpoint mismatch')
    alphabet_id = f'all_to_all_unit_cnot:{n}'
    key = [n, alphabet_id, target]
    serialized = json.dumps(key, separators=(',', ':')).encode('ascii')
    legacy = n.to_bytes(4, 'big') + b''.join(r.to_bytes((n + 7) // 8, 'little') for r in target)
    return {'word_validity': 'verified', 'optimality': 'uncomputed', 'upper_bound': len(gates),
            'orientation': 'encoder_I_to_M', 'canonical_key': key,
            'canonical_sha256': hashlib.sha256(serialized).hexdigest(),
            'legacy_matrix_sha256': hashlib.sha256(legacy).hexdigest()}
