"""Typed, scoped features computed from complete states."""
