"""Exact zero-template J17 descriptors for a deterministic partial shear."""
from functools import lru_cache
import numpy as np

from .packet import FeatureSpec
from ..search.basis_macros import partial_shear


def register_basis_gradient(registry):
    """Register raw-policy E01/E04/E05 without solved-distance labels.

    The full state determines the first-half source/second-half target partial
    elimination block. For each ordered source preparation add(c,t), the
    coordinate derivative at all-zero Bernoulli probabilities is exactly
    2 + |B[:,t]| - 2 <B[:,c],B[:,t]>. The two paid preparation/restoration
    gates are included. Non-source pairs carry an explicit applicability mask.
    """
    specs = {
        'E01': FeatureSpec('E01', 'global', 1, scope='selected_partial_elimination',
                           producer_version='partial_J17_zero_v1', cost_tier='T1'),
        'E04': FeatureSpec('E04', 'pair', 2, scope='selected_partial_elimination',
                           producer_version='partial_J17_zero_gradient_v1', cost_tier='T1'),
        'E05': FeatureSpec('E05', 'global', 4, scope='selected_partial_elimination',
                           producer_version='partial_J17_gradient_stats_v1',
                           exactness='float32_rounded_from_exact_counts', cost_tier='T1'),
    }

    @lru_cache(maxsize=128)
    def data(state):
        parsed = partial_shear(state)
        if parsed is None:
            return None
        sources, _targets, block, _pivots = parsed
        width = len(sources)
        if width < 2:
            return None
        block = np.asarray(block, dtype=np.int32)
        weights = block.sum(axis=0)
        overlap = block.T @ block
        gradient = 2 + weights[None, :] - 2*overlap
        mask = ~np.eye(width, dtype=bool)
        values = gradient[mask]
        pair = np.zeros((state.n, state.n, 2), dtype=np.float32)
        for c, source_c in enumerate(sources):
            for t, source_t in enumerate(sources):
                if c != t:
                    pair[source_c, source_t] = (gradient[c, t], 1)
        stats = np.array([values.min(), values.mean(), values.max(), (values < 0).mean()],
                         dtype=np.float32)
        return (np.array([block.sum()], dtype=np.float32), pair, stats)

    for key, spec in specs.items():
        index = {'E01': 0, 'E04': 1, 'E05': 2}[key]
        registry.register(spec, lambda state, policy, index=index: (
            'unsupported' if data(state) is None else (data(state)[index], None)),
            symmetry_contract='augmentation_only')
    return specs
