from copy import deepcopy
from collections import deque
import sys


def storage_bytes(value):
    """Conservative owned-entry accounting, not a process RSS measurement."""
    if isinstance(value, dict):
        return sys.getsizeof(value) + sum(storage_bytes(k) + storage_bytes(v) for k, v in value.items())
    if isinstance(value, (tuple, list)):
        return sys.getsizeof(value) + sum(storage_bytes(v) for v in value)
    return sys.getsizeof(value)


class FeatureCache:
    """Hashes index buckets; equality always checks the complete immutable key."""
    def __init__(self, hash_fn=hash, max_entries=128, max_bytes=64 * 1024 * 1024):
        if type(max_entries) is not int or max_entries < 0 or type(max_bytes) is not int or max_bytes < 0:
            raise ValueError('nonnegative cache budgets required')
        self.hash_fn = hash_fn
        self.max_entries, self.max_bytes = max_entries, max_bytes
        self.order = deque()
        self.bytes = 0
        self.evictions = 0
        self.buckets = {}
        self.hits = 0
        self.calls = 0

    def get_or_compute(self, full_key, producer):
        self.calls += 1
        hashed = self.hash_fn(full_key)
        bucket = self.buckets.get(hashed, [])
        for key, value in bucket:
            if key == full_key:
                self.hits += 1
                return deepcopy(value)
        value = producer()
        stored = deepcopy(value)
        size = storage_bytes(full_key) + storage_bytes(stored)
        if self.max_entries and size <= self.max_bytes:
            while self.order and (len(self.order) >= self.max_entries or self.bytes + size > self.max_bytes):
                old_hash, old_key, old_size = self.order.popleft()
                self.buckets[old_hash] = [(k, v) for k, v in self.buckets[old_hash] if k != old_key]
                if not self.buckets[old_hash]:
                    del self.buckets[old_hash]
                self.bytes -= old_size
                self.evictions += 1
            self.buckets.setdefault(hashed, []).append((full_key, stored))
            self.order.append((hashed, full_key, size))
            self.bytes += size
        return value
