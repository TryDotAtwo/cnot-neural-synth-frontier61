"""Opt-in diffusion producers. Never enabled implicitly in an existing run."""
from functools import lru_cache
import hashlib
import json
import math
import numpy as np
from .packet import FeatureSpec
from ..diffusion.column import column_profile
from ..diffusion.pair import pair_profile
from ..diffusion.probes import joint_probes


def register_diffusion(registry, taus=(.25,1.,4.,16.), floor=1e-30, max_n=256, max_pair_states=10000, mc_samples=256, mc_tau=1.):
    taus = tuple(float(t) for t in taus)
    if (len(taus) < 2 or any(not math.isfinite(t) or t < 0 for t in taus) or not 0 < floor < 1 or
            type(max_pair_states) is not int or max_pair_states < 1 or
            type(mc_samples) is not int or mc_samples < 2 or not math.isfinite(mc_tau) or mc_tau < 0):
        raise ValueError('invalid diffusion grid/floor')
    config = {'taus':taus,'floor':floor,'max_n':max_n,'max_pair_states':max_pair_states,'mc_samples':mc_samples,'mc_tau':mc_tau,'dtype':'float32_features_float64_reference',
              'profile_channels':['raw_class_mass','log_class_size','stationary_class_mass','floored_log_relative_density',
                                  'exact_zero','underflow','floor_applied']}
    version = 'column_heat_v1:' + hashlib.sha256(json.dumps(config,sort_keys=True).encode()).hexdigest()

    @lru_cache(maxsize=16)
    def tables(n):
        if n > max_n:
            raise MemoryError('column diffusion explicit width budget exceeded')
        return column_profile(n,tuple(n*t for t in taus))

    @lru_cache(maxsize=8)
    def pair_table(n):
        if math.comb(n+3,3)-1-3*n > max_pair_states:
            return None
        return pair_profile(n,(n-2,1,1,0),tuple(n*t for t in taus),max_states=max_pair_states)

    @lru_cache(maxsize=8)
    def pair_feature_table(n):
        table=pair_table(n)
        if table is None:return None
        raw=table['raw_class_mass'].T
        stationary=np.broadcast_to(table['stationary_class_mass'][:,None],raw.shape)
        log_size=np.broadcast_to(table['log_class_size'][:,None],raw.shape)
        exact_zero=table['exact_zero'].T
        underflow=table['underflow'].T | ((raw.astype(np.float32)==0)&(raw>0))
        with np.errstate(divide='ignore',invalid='ignore'):
            relative=np.log(np.maximum(raw,floor))-np.log(np.maximum(stationary,floor))
        profiles=np.stack((raw,log_size,stationary,relative,exact_zero,underflow,raw<floor),axis=-1)
        return {h:i for i,h in enumerate(table['states'])},profiles.reshape(len(table['states']),-1).astype(np.float32)

    def exact_pair_histograms(state):
        n=state.n
        bits=np.array([[(row>>c)&1 for c in range(n)] for row in state.packed_rows],dtype=np.int32)
        weights=bits.sum(axis=0)
        overlap=bits.T@bits
        h3=overlap
        h1=weights[:,None]-overlap
        h2=weights[None,:]-overlap
        h0=n-weights[:,None]-weights[None,:]+overlap
        return np.stack((h0,h1,h2,h3),axis=-1)

    @lru_cache(maxsize=16)
    def mc_table(n, rows, seed):
        # Three pair-sample arrays and temporaries are needed by joint_probes.
        if n > max_n or mc_samples*n*n*8*8 > 256*1024*1024:
            return None
        from ..contracts import AlphabetSpec, MatrixState
        state = MatrixState(n,tuple(rows),AlphabetSpec.all_to_all(n).id)
        return joint_probes(state,time=n*mc_tau,samples=mc_samples,seed=seed)

    def column_data(state, transposed=False):
        n = state.n
        packet = tables(n)
        rows = state.packed_rows
        column_weights = [sum((row>>j)&1 for row in rows) for j in range(n)]
        if transposed:
            column_weights = [row.bit_count() for row in rows]
        index = {s:i for i,s in enumerate(packet['states'])}
        selected = [index[((rows[j]>>j)&1,column_weights[j]-((rows[j]>>j)&1))] for j in range(n)]
        raw = packet['raw_class_mass'][:,selected].T
        size = np.broadcast_to(packet['log_class_size'][selected,None],raw.shape)
        stationary = np.broadcast_to(packet['stationary_class_mass'][selected,None],raw.shape)
        logmass = np.log(np.maximum(raw,floor))
        exactzero = packet['exact_zero'][:,selected].T
        underflow = (packet['underflow'][:,selected].T | ((raw.astype(np.float32)==0) & (raw>0)) |
                     ((stationary.astype(np.float32)==0) & (stationary>0)))
        return raw,size,stationary,logmass,exactzero,underflow

    def produce(key, state, policy):
        if key in ('G07','G08','G09','G10'):
            table = mc_table(state.n,state.packed_rows,policy.seed)
            if table is None:
                return None
            if key == 'G07':
                output=table['mean_column_weight'][:,None]
            elif key == 'G08':
                output=np.stack((table['covariance_column_weight'],table['mean_intersection'],
                                 table['mean_xor_weight'],table['covariance_weight_intersection'],
                                 table['covariance_weight_xor']),axis=-1)
            elif key == 'G09':
                output=np.stack((table['character_pair_mean'],table['character_pair_covariance']),axis=-1)
            else:
                stationary_character=-1.0/((1<<state.n)-1)
                stationary_pair=np.full((state.n,state.n),stationary_character)
                np.fill_diagonal(stationary_pair,1.)
                output=np.stack((table['intersection_standard_error'],table['xor_standard_error'],
                                 table['character_pair_standard_error'],
                                 np.abs(table['character_pair_mean']-stationary_pair),
                                 np.full((state.n,state.n),float(table['samples'])),
                                 np.full((state.n,state.n),float(table['physical_gates_sampled'])/table['samples']),
                                 np.full((state.n,state.n),float(mc_tau))),axis=-1)
            return output.astype(np.float32),None
        if key == 'G06':
            n = state.n
            if n < 2:
                return 'unsupported'
            precomputed = pair_feature_table(n)
            if precomputed is None:
                return None
            index,profiles=precomputed
            hist=exact_pair_histograms(state)
            keys=np.zeros((n,n),dtype=np.int32)
            for c in range(n):
                for d in range(n):
                    if c!=d:keys[c,d]=index[tuple(int(x) for x in hist[c,d])]
            result=profiles[keys].copy()
            result[np.diag_indices(n)]=0
            return result,None
        if key == 'G05':
            return exact_pair_histograms(state).astype(np.float32),None
        raw,size,stationary,logmass,exactzero,underflow = column_data(state,key=='G02')
        if key in ('G01','G02'):
            output = np.stack((raw,size,stationary,logmass-np.log(stationary),exactzero,underflow,raw<floor),axis=-1)
        elif key == 'G03':
            output = np.stack((logmass,exactzero,underflow,raw<floor),axis=-1)
        else:
            output = np.diff(raw,axis=1)
        return output.reshape(state.n,-1),None

    channels = {'G01':7*len(taus),'G02':7*len(taus),'G03':4*len(taus),'G04':len(taus)-1,'G05':4,'G06':7*len(taus),'G07':1,'G08':5,'G09':2,'G10':7}
    for key,count in channels.items():
        spec = FeatureSpec(key,'pair' if key in ('G05','G06','G08','G09','G10') else 'node',count,
                           scope=('full_labeled_matrix; histogram_class_mass_not_labeled_endpoint' if key=='G06'
                                  else 'full_labeled_matrix; shared_word_MC_joint_moments_empirical_uncertainty' if key in ('G07','G08','G09','G10')
                                  else 'full_labeled_matrix; source_relative_uniform_CNOT'),
                           producer_version=version, exactness='exact' if key=='G05' else 'monte_carlo' if key in ('G07','G08','G09','G10') else 'floating_semigroup',
                           cost_tier='T2' if key in ('G06','G07','G08','G09','G10') else 'T1')
        registry.register(spec,lambda state,policy,key=key:produce(key,state,policy),
                          'augmentation_only' if key in ('G07','G08','G09','G10') else 'exact_relabel')
    return config
