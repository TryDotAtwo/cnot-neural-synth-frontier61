from dataclasses import dataclass
import numpy as np


@dataclass(frozen=True)
class FeatureSpec:
    id: str
    role: str
    channels: int
    scope: str = 'full_labeled_matrix'
    producer_version: str = 'structural_v1'
    dependencies: tuple = ('M',)
    exactness: str = 'exact'
    cost_tier: str = 'T1'
    wire_roles: tuple = ('source', 'target')
    requires_solver_assisted: bool = False


@dataclass(frozen=True)
class TypedFeature:
    values: np.ndarray
    available: np.ndarray
    role: str
    exactness: str
    scope: str
    status: str
    uncertainty: object = None
    token_valid: object = None


@dataclass(frozen=True)
class FeaturePacket:
    state_keys: tuple
    alphabet_ids: tuple
    schema_id: str
    policy_id: str
    valid: np.ndarray
    features: dict
    group_incidence: dict
    audit: dict
