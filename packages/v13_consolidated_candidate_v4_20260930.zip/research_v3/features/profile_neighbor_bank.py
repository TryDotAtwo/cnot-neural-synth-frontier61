"""CPU feature cost on the same complete CNOT successor batch for 26/29 arms."""
import argparse
import json
from pathlib import Path
from time import perf_counter

from ..contracts import AlphabetSpec, MatrixState
from .basis_gradient import register_basis_gradient
from .diffusion import register_diffusion
from .registry import FeaturePolicy, FeatureRegistry
from .subspace_views import register_subspace_views


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--widths', type=int, nargs='+', default=[8, 13, 25, 34])
    parser.add_argument('--neighbors', type=int, default=32)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    configs = [json.loads((root / f'configs/{name}.json').read_text(encoding='utf-8'))
               for name in ('joint_rich_structure_2700', 'joint_rich_basis_gradient_2700')]
    rows = []
    for n in args.widths:
        alphabet = AlphabetSpec.all_to_all(n)
        matrix = [1 << i for i in range(n)]
        for step in range(3*n):
            c, t = (step*17+3) % n, (step*29+5) % n
            if c == t:
                t = (t+1) % n
            matrix[t] ^= matrix[c]
        state = MatrixState(n, tuple(matrix), alphabet.id)
        successors = []
        for gate in alphabet.allowed[:args.neighbors]:
            changed = list(state.packed_rows)
            changed[gate.target] ^= changed[gate.control]
            successors.append(MatrixState(n, tuple(changed), alphabet.id))
        registry = FeatureRegistry()
        register_subspace_views(registry)
        register_basis_gradient(registry)
        register_diffusion(registry, **configs[0]['diffusion'])
        for config in configs:
            policy = FeaturePolicy(tuple(config['features']), seed=config['feature_seed'],
                                   symmetry_contract=config['feature_symmetry'])
            # Warm width-level diffusion tables before timing distinct neighbors.
            registry.build((state,), policy)
            started = perf_counter()
            packet = registry.build(tuple(successors), policy)
            rows.append({'n': n, 'features': len(policy.enabled_ids), 'neighbors': len(successors),
                         'seconds': perf_counter()-started,
                         'structural_bundle_seconds': packet.audit['structural_bundle_seconds'],
                         'bytes': packet.audit['bytes'], 'omitted_ids': packet.audit['omitted_ids']})
    print(json.dumps({'scope': 'CPU complete feature build on same first directed CNOT successors; warmed tables, distinct states; no model forward/backward',
                      'rows': rows}, indent=2))


if __name__ == '__main__':
    main()
