"""Cold CPU build profile for the complete rich training feature policy."""
import json
import argparse
from pathlib import Path
from time import perf_counter

from ..contracts import AlphabetSpec, MatrixState
from .diffusion import register_diffusion
from .registry import FeaturePolicy, FeatureRegistry
from .subspace_views import register_subspace_views
from .basis_gradient import register_basis_gradient


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--widths', type=int, nargs='+')
    parser.add_argument('--include-basis-gradient', action='store_true')
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    config = json.loads((root / 'configs/joint_rich_structure_2700.json').read_text(encoding='utf-8'))
    rows = []
    for n in (args.widths or config['train_sizes']):
        matrix = [1 << i for i in range(n)]
        for step in range(3*n):
            c, t = (step*17+3) % n, (step*29+5) % n
            if c == t:
                t = (t+1) % n
            matrix[t] ^= matrix[c]
        state = MatrixState(n, tuple(matrix), AlphabetSpec.all_to_all(n).id)
        registry = FeatureRegistry()
        register_subspace_views(registry)
        if args.include_basis_gradient:
            register_basis_gradient(registry)
        register_diffusion(registry, **config['diffusion'])
        ids = tuple(config['features']) + (('E01', 'E04', 'E05') if args.include_basis_gradient else ())
        policy = FeaturePolicy(ids, seed=config['feature_seed'],
                               symmetry_contract=config['feature_symmetry'])
        start = perf_counter()
        packet = registry.build((state,), policy)
        cold_seconds = perf_counter()-start
        second = list(matrix)
        second[1] ^= second[0]
        second_state = MatrixState(n, tuple(second), state.alphabet_id)
        warm_start = perf_counter()
        warm_packet = registry.build((second_state,), policy)
        rows.append({'n': n, 'seconds': cold_seconds,
                     'cold_seconds': cold_seconds,
                     'warm_distinct_state_seconds': perf_counter()-warm_start,
                     'structural_bundle_seconds': packet.audit['structural_bundle_seconds'],
                     'bytes': packet.audit['bytes'],
                     'unavailable': packet.audit['omitted_ids'],
                     'warm_unavailable': warm_packet.audit['omitted_ids'],
                     'per_feature': packet.audit['per_feature']})
    print(json.dumps({'scope': 'one cold then one distinct-state warm CPU build per width; no GPU step or search',
                      'rows': rows}, indent=2))


if __name__ == '__main__':
    main()
