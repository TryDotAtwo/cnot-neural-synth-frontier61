"""CPU feature-build microprofile on deterministic, verified invertible states."""
import json
from statistics import median
from time import perf_counter

from ..contracts import AlphabetSpec, MatrixState
from .registry import FeaturePolicy, FeatureRegistry
from .subspace_views import register_subspace_views


def main():
    rows = []
    for n in (8, 13, 25, 34, 50, 72, 122):
        matrix = [1 << i for i in range(n)]
        for step in range(3 * n):
            c = (step * 17 + 3) % n
            t = (step * 29 + 5) % n
            if c == t:
                t = (t + 1) % n
            matrix[t] ^= matrix[c]
        state = MatrixState(n, tuple(matrix), AlphabetSpec.all_to_all(n).id)
        for arm, ids in (
            ('pilot10', ('A01', 'B01', 'F01', 'G01', 'G05', 'G06', 'G07', 'G08', 'G09', 'G10')),
            ('structure18', ('A01', 'A04', 'A05', 'A07', 'A08', 'A15', 'A16', 'A20',
                             'B01', 'B03', 'B06', 'B07', 'F01', 'C01', 'H01', 'H02', 'H03', 'H04')),
        ):
            # Do not build G in this benchmark: isolate the shared structural bundle
            # and added exact C/H views. The pilot row uses only its structural IDs.
            ids = tuple(key for key in ids if not key.startswith('G'))
            samples = []
            for _ in range(3):
                registry = FeatureRegistry()
                register_subspace_views(registry)
                start = perf_counter()
                packet = registry.build((state,), FeaturePolicy(ids))
                samples.append((perf_counter() - start, packet.audit['structural_bundle_seconds']))
            rows.append({'n': n, 'arm': arm, 'ids': ids, 'feature_build_seconds_median': median(x[0] for x in samples),
                         'structural_bundle_seconds_median': median(x[1] for x in samples),
                         'all_available': all(x.available.all() for x in packet.features.values()),
                         'feature_bytes': packet.audit['bytes']})
    print(json.dumps({'scope': 'CPU only, one deterministic state per width, three cold independent builds; G excluded',
                      'rows': rows}, indent=2))


if __name__ == '__main__':
    main()
