from dataclasses import dataclass
import hashlib
import json
from time import perf_counter
import numpy as np
from .cache import FeatureCache
from .packet import FeatureSpec, FeaturePacket, TypedFeature
from .structural import compute


@dataclass(frozen=True)
class FeaturePolicy:
    enabled_ids: tuple[str, ...]
    seed: int = 0
    schema_id: str = 'feature_bank_v3_1'
    solver_assisted: bool = False
    symmetry_contract: str = 'exact_relabel'
    evaluations: int | None = None
    max_bytes: int | None = None

    @property
    def id(self):
        return hashlib.sha256(json.dumps(self.__dict__, sort_keys=True).encode()).hexdigest()


class FeatureRegistry:
    def __init__(self, cache=None):
        self.cache = cache if cache is not None else FeatureCache()
        self.specs = {}
        self.providers = {}
        counts = dict(A=20, B=12, C=10, D=14, E=9, F=10, G=10, H=7, I=11)
        for family, count in counts.items():
            for i in range(1, count + 1):
                key = f'{family}{i:02}'
                self.specs[key] = FeatureSpec(key, 'group', 1, producer_version='unimplemented', exactness='unknown')
        pair = {f'A{i:02}' for i in (1, 2, 3, 4, 13, 14, 15, 16, 17, 18, 19, 20)} | {'B06', 'B07', 'B08'}
        glob = {'B01': 1, 'B12': 16, 'F01': 2}
        channels = dict(A03=2, A05=2, A12=2, A17=2, A18=2, A19=2, A20=2,
                        B04=3, B08=2, B10=2, B11=3)
        for key in self.specs:
            if key[0] in 'AB' or key == 'F01':
                role = 'pair' if key in pair else 'global' if key in glob else 'node'
                self.specs[key] = FeatureSpec(key, role, glob.get(key, channels.get(key, 1)))

    def register(self, spec, producer, symmetry_contract='exact_relabel'):
        if spec.role not in ('node', 'pair', 'group', 'global') or spec.channels < 1:
            raise ValueError('invalid feature shape')
        if spec.producer_version == 'unimplemented' or spec.id in self.providers:
            raise ValueError('producer requires unique registration/version')
        if spec.id in self.specs and self.specs[spec.id].producer_version != 'unimplemented':
            raise ValueError('cannot replace implemented producer')
        self.specs[spec.id] = spec
        self.providers[spec.id] = (producer, symmetry_contract)

    def build(self, states, policy):
        if not states or len(set(policy.enabled_ids)) != len(policy.enabled_ids):
            raise ValueError('empty batch or repeated feature ID')
        if any(key not in self.specs for key in policy.enabled_ids):
            raise ValueError('unknown feature ID')
        if not policy.solver_assisted and any(self.specs[key].requires_solver_assisted for key in policy.enabled_ids):
            raise ValueError('solver-assisted exact-answer feature cannot enter raw policy')
        if policy.evaluations is not None and policy.evaluations < 0:
            raise ValueError('negative evaluations budget')
        for key in policy.enabled_ids:
            if key in self.providers and policy.symmetry_contract == 'exact_relabel' and self.providers[key][1] != 'exact_relabel':
                raise ValueError('producer symmetry contract mismatch')
        start = perf_counter()
        nmax = max(s.n for s in states)
        # Explicit conservative workspace estimate, not an OS-enforced RSS cap.
        # Includes packed-to-dense intermediates and copies for this reference producer.
        estimated_workspace = sum(1024 * s.n * s.n + 256 * s.n for s in states)
        if policy.max_bytes is not None and estimated_workspace > policy.max_bytes:
            raise MemoryError(f'feature resource_limit: estimated {estimated_workspace} bytes exceeds {policy.max_bytes}')
        valid = np.array([[i < s.n for i in range(nmax)] for s in states], dtype=bool)
        before_hits, before_calls = self.cache.hits, self.cache.calls
        structural_start = perf_counter()
        rows = [self.cache.get_or_compute((s.key, policy.id, 'structural_v1'), lambda s=s: compute(s)) for s in states]
        structural_seconds = perf_counter() - structural_start
        features = {}
        incidences = {}
        profiling = {}
        remaining = policy.evaluations
        for key in policy.enabled_ids:
            spec = self.specs[key]
            custom = []
            limited = False
            oracle_evaluations_reported = 0
            oracle_scopes = set()
            oracle_provenance = set()
            t0, hits0, calls0 = perf_counter(), self.cache.hits, self.cache.calls
            if key in self.providers:
                producer = self.providers[key][0]
                for state in states:
                    if remaining == 0:
                        custom.append(None)
                        limited = True
                        continue
                    if remaining is not None:
                        remaining -= 1
                    # Budget counts requests, including cache hits, to preserve fixed semantics.
                    item = self.cache.get_or_compute((state.key, policy.id, key, spec.producer_version),
                                                     lambda state=state: producer(state, policy))
                    if item is None or isinstance(item, str):
                        if isinstance(item, str) and item != 'unsupported':
                            raise ValueError('unknown producer unavailability status')
                        custom.append(None)
                        limited |= item is None
                        continue
                    if len(item) not in (2, 3):
                        raise ValueError('custom producer must return value, incidence, optional audit')
                    value = np.asarray(item[0], dtype=np.float32)
                    incidence = item[1]
                    if len(item) == 3:
                        metadata = item[2]
                        if (not isinstance(metadata, dict) or
                                type(metadata.get('oracle_evaluations', 0)) is not int or
                                metadata.get('oracle_evaluations', 0) < 0):
                            raise ValueError('invalid custom oracle audit')
                        oracle_evaluations_reported += metadata.get('oracle_evaluations', 0)
                        if metadata.get('oracle_scope'):
                            oracle_scopes.add(str(metadata['oracle_scope']))
                        if metadata.get('provenance'):
                            oracle_provenance.add(str(metadata['provenance']))
                    expected = {'node': (state.n, spec.channels), 'pair': (state.n, state.n, spec.channels),
                                'global': (spec.channels,)}.get(spec.role)
                    if expected is not None and value.shape != expected:
                        raise ValueError('producer value shape mismatch')
                    if not np.isfinite(value).all():
                        raise ValueError('nonfinite feature')
                    if spec.role == 'group':
                        incidence = np.asarray(incidence, dtype=np.float32)
                        if value.ndim != 2 or value.shape[1] != spec.channels or incidence.shape != (len(value), state.n, len(spec.wire_roles)):
                            raise ValueError('group incidence shape mismatch')
                        if not np.isfinite(incidence).all() or (incidence < 0).any():
                            raise ValueError('invalid group incidence')
                    custom.append((value, incidence))
            groups = max((len(item[0]) for item in custom if item is not None), default=0)
            shape = {'node': (nmax,), 'pair': (nmax, nmax), 'global': (), 'group': (groups,)}[spec.role]
            values = np.zeros((len(states), *shape, spec.channels), dtype=np.float32)
            available = np.zeros(len(states), dtype=bool)
            token_valid = np.zeros((len(states), groups), dtype=bool) if spec.role == 'group' else None
            if spec.role == 'group':
                incidences[key] = np.zeros((len(states), groups, nmax, len(spec.wire_roles)), dtype=np.float32)
            for b, (state, computed) in enumerate(zip(states, rows)):
                if custom:
                    if custom[b] is None:
                        continue
                    value, incidence = custom[b]
                    if spec.role == 'group':
                        incidences[key][b, :len(value), :state.n] = incidence
                        token_valid[b, :len(value)] = True
                elif key in computed:
                    value = computed[key]
                else:
                    continue
                slices = (b,) + tuple(slice(0, size) for size in value.shape)
                values[slices] = value
                available[b] = True
            values.setflags(write=False)
            available.setflags(write=False)
            if token_valid is not None:
                token_valid.setflags(write=False)
                incidences[key].setflags(write=False)
            features[key] = TypedFeature(values, available, spec.role, spec.exactness if available.any() else 'unknown',
                                         spec.scope, 'available' if available.all() else 'resource_limit' if limited else 'unsupported',
                                         token_valid=token_valid)
            profiling[key] = {'assembly_and_custom_seconds': perf_counter() - t0,
                              'custom_calls': self.cache.calls - calls0, 'custom_hits': self.cache.hits - hits0,
                              'bytes': values.nbytes + available.nbytes,
                              'oracle_evaluations_reported': oracle_evaluations_reported,
                              'oracle_scopes': tuple(sorted(oracle_scopes)),
                              'oracle_provenance': tuple(sorted(oracle_provenance)),
                              'scope': spec.scope, 'cost_tier': spec.cost_tier,
                              'requires_solver_assisted': spec.requires_solver_assisted}
        valid.setflags(write=False)
        return FeaturePacket(tuple(s.key for s in states), tuple(s.alphabet_id for s in states),
                             policy.schema_id, policy.id, valid, features, incidences,
                             {'seconds': perf_counter() - start,
                              'structural_bundle_seconds': structural_seconds,
                              'per_feature': profiling,
                              'estimated_workspace_bytes': estimated_workspace,
                              'bytes': sum(f.values.nbytes + f.available.nbytes for f in features.values()),
                              'calls': self.cache.calls - before_calls, 'hits': self.cache.hits - before_hits,
                              'omitted_ids': [k for k, f in features.items() if not f.available.all()],
                              'producer_versions': {k: self.specs[k].producer_version for k in features}})
