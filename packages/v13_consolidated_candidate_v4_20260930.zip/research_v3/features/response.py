"""Opt-in certified local-response feature producers.

I10 here is available only when an exact tiny full-matrix word series has a
positive leading coefficient within the explicit horizon. A missing term is
not an exact global zero and never becomes a training label.
"""
from math import log1p
import numpy as np

from ..contracts import AlphabetSpec
from ..response.local import LocalBudget, ResponseQuery, RestrictedProblem, local_response
from ..response.types import LabeledPorts
from .packet import FeatureSpec


def leading_full_response(state, *, max_n, max_degree, budget):
    if state.n > max_n or state.alphabet_id != AlphabetSpec.all_to_all(state.n).id:
        return None
    alphabet = tuple((gate.control, gate.target) for gate in AlphabetSpec.all_to_all(state.n).allowed)
    problem = RestrictedProblem(state.packed_rows, alphabet, LabeledPorts(()),
                                (), (), (), "exact_full_endpoint")
    result = local_response(problem, ResponseQuery(max_degree), budget)
    if result.status != "exact" or not result.response.terms:
        return None
    first = min(result.response.terms, key=lambda term: term.degree.value)
    return result, first.degree.value, first.multiplicity


def register_tiny_i10(registry, *, max_n, max_degree, budget):
    """Register an exact-leader I10 projection with explicit finite resources.

    Four channels: leading physical degree, log(1+exact coefficient),
    exact-positive flag, and zero interval width for that coefficient.
    They do not assert that a no-hit endpoint has zero full response.
    """
    if type(max_n) is not int or max_n < 2 or type(max_degree) is not int or max_degree < 0:
        raise ValueError("explicit positive tiny width and finite horizon required")
    if not isinstance(budget, LocalBudget):
        raise TypeError("typed exact local budget required")
    version = (f"tiny_full_i10_solver_assisted_v2_n{max_n}_d{max_degree}_"
               f"s{budget.max_layer_states}_t{budget.max_transitions}")
    spec = FeatureSpec("I10", "global", 4, scope="solver_assisted:full_cnot_alphabet:exact_leading_only",
                       producer_version=version, dependencies=("M", "unit_full_alphabet", "local_budget"),
                       exactness="derived_from_exact_positive_coefficient", cost_tier="T3",
                       wire_roles=(), requires_solver_assisted=True)

    def produce(state, policy):
        if not policy.solver_assisted:
            raise ValueError("full-target exact I10 requires solver_assisted=True")
        leader = leading_full_response(state, max_n=max_n, max_degree=max_degree, budget=budget)
        if leader is None:
            return "unsupported"
        result, degree, coefficient = leader
        audit = {"oracle_evaluations": result.evaluations, "oracle_scope": result.scope_id,
                 "provenance": "research_v3.response.local:complete_positive_full_endpoint_dp"}
        return np.asarray((degree, log1p(coefficient), 1.0, 0.0), dtype=np.float32), None, audit

    registry.register(spec, produce, symmetry_contract="exact_relabel")
    return spec
