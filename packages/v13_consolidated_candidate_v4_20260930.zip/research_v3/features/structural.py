import numpy as np


def compute(state):
    n = state.n
    m = np.array([[(row >> j) & 1 for j in range(n)] for row in state.packed_rows], dtype=np.int64)
    eye = np.eye(n, dtype=np.int64)
    e = m ^ eye
    rw, cw = m.sum(1), m.sum(0)
    rd, cd = e.sum(1), e.sum(0)
    ri, ci = m @ m.T, m.T @ m
    rowdiff = rw[:, None] - ri
    coldiff = cw[:, None] - ci
    result = {}
    def put(key, value):
        result[key] = np.asarray(value, dtype=np.float32)
    def node(key, value):
        put(key, np.asarray(value)[:, None])
    def pair(key, value):
        put(key, np.asarray(value)[:, :, None])
    for key, value in [('A01', m), ('A02', m.T), ('A04', e)]:
        pair(key, value)
    put('A03', np.stack((eye, np.ones_like(eye)), -1))
    put('A05', np.stack((rw, rw / n), -1))
    for key, value in [('A06', cw), ('A07', rd), ('A08', cd), ('A09', rd > 0),
                       ('A10', cd > 0), ('A11', 1 - m.diagonal())]:
        node(key, value)
    put('A12', np.stack((rw % 2, cw % 2), -1))
    for key, value in [('A13', ri), ('A14', ci), ('A15', rw[:, None] + rw[None, :] - 2 * ri),
                       ('A16', cw[:, None] + cw[None, :] - 2 * ci)]:
        pair(key, value)
    put('A17', np.stack((rowdiff, rowdiff.T), -1))
    put('A18', np.stack((coldiff, coldiff.T), -1))
    put('A19', np.stack((rowdiff == 0, coldiff == 0), -1))
    # For c→t, |m_t xor m_c|-|m_t| = |m_c|-2<m_t,m_c>.
    # The target residual e_t changes by xor m_c as well. Compute all
    # source/target pairs with two integer matrix products; diagonal moves
    # are invalid and retain the historical zero convention.
    delta = np.stack((rw[:, None] - 2 * ri,
                      rw[:, None] - 2 * (e @ m.T).T), axis=-1)
    delta[np.arange(n), np.arange(n)] = 0
    put('A20', delta)

    adj = m.copy()
    np.fill_diagonal(adj, 0)
    und = (adj | adj.T).astype(np.int64)
    components = []
    unseen = set(range(n))
    while unseen:
        root = min(unseen)
        visited = {root}
        todo = [root]
        for i in todo:
            for j in np.flatnonzero(und[i]):
                if int(j) not in visited:
                    visited.add(int(j))
                    todo.append(int(j))
        unseen -= visited
        components.append(tuple(sorted(visited)))
    sizes = np.zeros(n, dtype=np.int64)
    stats = np.zeros((n, 3), dtype=np.int64)
    for component in components:
        idx = list(component)
        sizes[idx] = len(idx)
        stats[idx] = [(1 - m.diagonal())[idx].sum(), rw[idx].sum(), cw[idx].sum()]
    put('B01', [len(components)])
    node('B02', sizes)
    # Reachability closure and SCC condensation: exact and independent of numbering.
    reach = adj.astype(bool) | np.eye(n, dtype=bool)
    for k in range(n):
        reach |= reach[:, k, None] & reach[k, None, :]
    mutual = reach & reach.T
    node('B03', mutual.sum(1))
    sccs, remaining = [], set(range(n))
    while remaining:
        members = tuple(int(i) for i in np.flatnonzero(mutual[min(remaining)]))
        sccs.append(members)
        remaining -= set(members)
    labels = {v: k for k, comp in enumerate(sccs) for v in comp}
    dag = np.zeros((len(sccs), len(sccs)), dtype=np.int64)
    for i, j in zip(*np.nonzero(adj)):
        if labels[i] != labels[j]:
            dag[labels[i], labels[j]] = 1
    depth = np.zeros(len(sccs), dtype=np.int64)
    pending = set(range(len(sccs)))
    while pending:
        ready = [i for i in pending if not any(dag[j, i] for j in pending)]
        for i in ready:
            parents = np.flatnonzero(dag[:, i])
            depth[i] = max((int(depth[j]) + 1 for j in parents), default=0)
        pending -= set(ready)
    put('B04', [[depth[labels[i]], dag[:, labels[i]].sum(), dag[labels[i]].sum()] for i in range(n)])
    node('B05', (adj * adj.T).sum(1))
    paths = adj @ adj
    pair('B06', paths)
    pair('B07', paths % 2)
    put('B08', np.stack((adj.T @ adj, adj @ adj.T), -1))
    node('B09', (paths @ adj).diagonal())
    common = und @ und
    triangles = (common * und).sum(1) // 2
    # Each simple 4-cycle through i has one opposite vertex j and two common neighbors.
    four = np.array([sum(int(common[i, j]) * (int(common[i, j]) - 1) // 2
                         for j in range(n) if i != j) for i in range(n)])
    put('B10', np.stack((triangles, four), -1))
    put('B11', stats)
    summary = []
    for weights in (rw, cw):
        summary.extend([float(weights.mean()), float(weights.var()), int(weights.max())])
        summary.extend(int((weights == k).sum()) for k in range(5))
    put('B12', summary)
    put('F01', [(rd > 0).sum(), (cd > 0).sum()])
    return result
