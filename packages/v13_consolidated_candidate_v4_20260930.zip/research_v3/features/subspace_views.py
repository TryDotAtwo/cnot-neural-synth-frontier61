"""Opt-in, full-matrix subspace, parity, and symmetry views for raw policies."""

import numpy as np

from .packet import FeatureSpec
from ..gf2 import inverse, rank, transpose


def _dense(rows):
    n = len(rows)
    return np.array([[(row >> j) & 1 for j in range(n)] for row in rows], dtype=np.float32)[..., None]


def register_subspace_views(registry):
    """Register exact C01, width-two D03, H01–H04; no distance oracle is used."""
    specs = {
        'C01': FeatureSpec('C01', 'global', 1, producer_version='gf2_rank_residual_v1', cost_tier='T1'),
        'D03': FeatureSpec('D03', 'pair', 3, producer_version='width2_parity_multiplicity_v1',
                           cost_tier='T1', dependencies=('M', 'width2_source_pair')),
        'H01': FeatureSpec('H01', 'pair', 1, producer_version='matrix_view_v1', cost_tier='T0'),
        'H02': FeatureSpec('H02', 'pair', 1, producer_version='matrix_transpose_view_v1', cost_tier='T0'),
        'H03': FeatureSpec('H03', 'pair', 1, producer_version='matrix_inverse_view_v1', cost_tier='T1'),
        'H04': FeatureSpec('H04', 'pair', 1, producer_version='matrix_inverse_transpose_view_v1', cost_tier='T1'),
    }

    def produce(key, state, _policy):
        rows = state.packed_rows
        if key == 'C01':
            residual = tuple(row ^ (1 << i) for i, row in enumerate(rows))
            return np.array([rank(residual)], dtype=np.float32), None
        if key == 'D03':
            n = state.n
            weights = np.fromiter((row.bit_count() for row in rows), dtype=np.int32, count=n)
            shared = np.fromiter(((rows[i] & rows[j]).bit_count() for i in range(n) for j in range(n)),
                                 dtype=np.int32, count=n*n).reshape(n, n)
            # For an ordered pair of physical source rows (i,j), count the
            # column patterns 10, 01, 11. The 00 bin is n minus their sum.
            return np.stack((weights[:, None] - shared,
                             weights[None, :] - shared, shared), axis=-1).astype(np.float32), None
        if key in ('H03', 'H04'):
            rows = inverse(rows)
        if key in ('H02', 'H04'):
            rows = transpose(rows)
        return _dense(rows), None

    for key, spec in specs.items():
        registry.register(spec, lambda state, policy, key=key: produce(key, state, policy))
    return specs
