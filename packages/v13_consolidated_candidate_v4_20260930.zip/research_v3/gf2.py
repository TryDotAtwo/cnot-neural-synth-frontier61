"""Exact packed-row GF(2) operations; bit j is column j."""


def rank(rows):
    pivots = {}
    for value in rows:
        while value:
            bit = value.bit_length() - 1
            if bit in pivots:
                value ^= pivots[bit]
            else:
                pivots[bit] = value
                break
    return len(pivots)


def inverse(rows):
    n = len(rows)
    left, right = list(rows), [1 << i for i in range(n)]
    for j in range(n):
        pivot = next((i for i in range(j, n) if (left[i] >> j) & 1), None)
        if pivot is None:
            raise ValueError('singular matrix')
        left[j], left[pivot] = left[pivot], left[j]
        right[j], right[pivot] = right[pivot], right[j]
        for i in range(n):
            if i != j and (left[i] >> j) & 1:
                left[i] ^= left[j]
                right[i] ^= right[j]
    return tuple(right)


def transpose(rows):
    return tuple(sum(((row >> j) & 1) << i for i, row in enumerate(rows)) for j in range(len(rows)))


def permute(rows, permutation):
    result = [0] * len(rows)
    for i, row in enumerate(rows):
        result[permutation[i]] = sum(((row >> j) & 1) << permutation[j] for j in range(len(rows)))
    return tuple(result)
