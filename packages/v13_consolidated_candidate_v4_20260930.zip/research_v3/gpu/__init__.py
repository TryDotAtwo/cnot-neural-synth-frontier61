"""GPU data-plane experiments; not yet the production synthesizer."""
