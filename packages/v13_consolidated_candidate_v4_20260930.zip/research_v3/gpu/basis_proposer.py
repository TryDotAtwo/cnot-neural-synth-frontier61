"""Batched CUDA ordered source-choice sampling and existing proposer weights."""

import torch


def sample_ordered_source_pairs(batch: int, width: int, choices: int,
                                *, generator: torch.Generator,
                                device: torch.device) -> torch.Tensor:
    total = width * (width - 1)
    if (batch < 1 or width < 2 or not 1 <= choices <= total or
            device.type != 'cuda' or generator.device.type != 'cuda'):
        raise ValueError('CUDA ordered source sampling contract')
    # IID continuous ranks select a uniformly random ordered sample without
    # replacement. The caller must checkpoint generator state with the stream.
    ranks = torch.rand((batch, total), device=device, generator=generator)
    ids = torch.argsort(ranks, dim=1, stable=True)[:, :choices]
    control = ids // (width - 1)
    relative_target = ids % (width - 1)
    target = relative_target + (relative_target >= control).to(torch.int64)
    return torch.stack((control, target), dim=-1)


def batched_basis_proposal(proposer, encoded, pairs: torch.Tensor,
                           *, source_width: int) -> torch.Tensor:
    if (pairs.device.type != 'cuda' or pairs.dtype != torch.int64 or
            pairs.ndim != 3 or pairs.shape[0] != encoded.wire.shape[0] or
            pairs.shape[2] != 2 or source_width < 2 or
            encoded.wire.shape[1] <= source_width or
            bool(((pairs < 0) | (pairs >= source_width) |
                  (pairs[:, :, :1] == pairs[:, :, 1:])).any().item())):
        raise ValueError('CUDA batched basis-proposal shape/choice contract')
    batch, choices, _ = pairs.shape
    dimension = encoded.wire.shape[2]
    ids = torch.arange(batch, device=pairs.device)[:, None]
    control = encoded.wire[ids, pairs[:, :, 0]]
    target = encoded.wire[ids, pairs[:, :, 1]]
    source_summary = encoded.wire[:, :source_width].mean(dim=1)[:, None].expand(-1, choices, -1)
    target_summary = encoded.wire[:, source_width:].mean(dim=1)[:, None].expand(-1, choices, -1)
    metadata = encoded.wire.new_zeros((batch, choices, 4))
    metadata[:, :, 0] = 1  # one physical CNOT in each add preparation
    metadata[:, :, 2] = torch.arange(choices, device=pairs.device,
                                    dtype=metadata.dtype)[None] / max(1, choices)
    metadata[:, :, 3] = choices
    input_values = torch.cat((control, target, source_summary, target_summary,
                              metadata), dim=-1)
    if input_values.shape != (batch, choices, 4 * dimension + 4):
        raise AssertionError('basis proposer input shape drift')
    return proposer.network(input_values).squeeze(-1).sigmoid()
