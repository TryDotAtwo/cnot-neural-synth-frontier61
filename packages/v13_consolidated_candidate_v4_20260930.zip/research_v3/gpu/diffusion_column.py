"""CUDA column-class heat semigroup for the G01 feature."""

import math
from functools import lru_cache

import torch

from .structural_a import dense_bits


DEFAULT_TAUS = (0.25, 1.0, 4.0, 16.0)


def column_generator(n: int, device: torch.device) -> tuple[torch.Tensor, torch.Tensor]:
    if n < 2 or n > 256:
        raise ValueError('unsupported column width')
    k = torch.arange(n, device=device, dtype=torch.int64)
    bits = torch.cat((torch.zeros(n - 1, device=device, dtype=torch.int64),
                      torch.ones(n, device=device, dtype=torch.int64)))
    others = torch.cat((k[1:], k))
    size = 2 * n - 1
    source = torch.arange(size, device=device)
    transition = torch.zeros((size, size), device=device, dtype=torch.float64)

    def index(bit: torch.Tensor, count: torch.Tensor) -> torch.Tensor:
        return torch.where(bit == 0, count - 1, n - 1 + count)

    moves = (
        (bits, others, (n - bits - others) * (n - 1)),
        (1 - bits, others, others),
        (bits, others + 1, (bits + others) * (n - 1 - others)),
        (bits, others - 1, others * (bits + others - 1)),
    )
    for next_bit, next_count, weight in moves:
        valid = weight > 0
        transition.index_put_((source[valid], index(next_bit, next_count)[valid]),
                              weight[valid].to(torch.float64), accumulate=True)
    generator = transition / (n * (n - 1)) - torch.eye(size, device=device,
                                                       dtype=torch.float64)
    log_size = (torch.lgamma(torch.tensor(float(n), device=device, dtype=torch.float64)) -
                torch.lgamma(others.to(torch.float64) + 1) -
                torch.lgamma((n - 1 - others).to(torch.float64) + 1))
    return generator, log_size


@lru_cache(maxsize=16)
def _column_feature_table(n: int, device: torch.device, taus: tuple[float, ...],
                          floor: float) -> torch.Tensor:
    generator, log_size = column_generator(n, device)
    size = 2 * n - 1
    initial = torch.zeros(size, device=device, dtype=torch.float64)
    initial[n - 1] = 1
    times = torch.tensor(tuple(float(n * t) for t in taus), device=device,
                         dtype=torch.float64)
    semigroup = torch.linalg.matrix_exp(generator.T[None] * times[:, None, None])
    mass = semigroup @ initial
    if bool((mass < -1e-12).any().item()):
        raise ArithmeticError('negative CUDA diffusion mass')
    log_total = torch.log(torch.expm1(torch.tensor(n * math.log(2), device=device,
                                                  dtype=torch.float64)))
    stationary = torch.exp(log_size - log_total)
    log_mass = torch.log(mass.clamp_min(floor))
    exact_zero = torch.zeros_like(mass)
    underflow = ((mass == 0) |
                 ((mass.to(torch.float32) == 0) & (mass > 0)) |
                 ((stationary.to(torch.float32) == 0) & (stationary > 0))[None]).to(torch.float64)
    table = torch.stack((mass, log_size[None].expand_as(mass),
                         stationary[None].expand_as(mass),
                         log_mass - torch.log(stationary)[None],
                         exact_zero, underflow, (mass < floor).to(torch.float64)), dim=-1)
    return table


def g01_column_heat(rows: torch.Tensor, *, taus=DEFAULT_TAUS,
                    floor: float = 1e-30) -> torch.Tensor:
    taus = tuple(float(t) for t in taus)
    if not taus or any(not math.isfinite(t) or t < 0 for t in taus) or \
            not (0 < floor < 1):
        raise ValueError('invalid CUDA diffusion grid')
    matrix = dense_bits(rows)
    batch, n, _ = matrix.shape
    table = _column_feature_table(n, rows.device, taus, float(floor))
    size = 2 * n - 1
    columns = matrix.sum(dim=1).to(torch.int64)
    diagonal = matrix.diagonal(dim1=1, dim2=2).to(torch.int64)
    count = columns - diagonal
    selected = torch.where(diagonal == 0, count - 1, n - 1 + count)
    if bool(((selected < 0) | (selected >= size)).any().item()):
        raise ValueError('zero column or malformed packed invertible matrix')
    per_column = table[:, selected].permute(1, 2, 0, 3)
    return per_column.reshape(batch, n, 7 * len(taus)).to(torch.float32)
