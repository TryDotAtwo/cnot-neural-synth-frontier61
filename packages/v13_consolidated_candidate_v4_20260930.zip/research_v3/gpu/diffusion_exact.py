"""Exact CUDA pair-histogram feature used by the diffusion family."""

import torch

from .structural_a import dense_bits


def g05_pair_histogram(rows: torch.Tensor) -> torch.Tensor:
    matrix = dense_bits(rows)
    _, n, _ = matrix.shape
    weight = matrix.sum(dim=1)
    overlap = matrix.transpose(1, 2) @ matrix
    both = overlap
    left_only = weight[:, :, None] - overlap
    right_only = weight[:, None, :] - overlap
    neither = n - weight[:, :, None] - weight[:, None, :] + overlap
    return torch.stack((neither, left_only, right_only, both), dim=-1)
