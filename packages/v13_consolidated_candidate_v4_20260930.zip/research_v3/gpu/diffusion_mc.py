"""CUDA shared-word Monte Carlo G07–G10 moment features.

The distribution matches the reference Poisson(rate=n*tau) process. PyTorch's
RNG is intentionally a different seeded stream from NumPy's reference RNG.
"""

from dataclasses import dataclass
from functools import lru_cache
import math

import torch

from .packed_walk import apply_gates
from .structural_a import dense_bits


SELECTED_MC_G = ('G07', 'G08', 'G09', 'G10')


@dataclass(frozen=True)
class GpuJointProbes:
    features: dict[str, torch.Tensor]
    sampled_rows: torch.Tensor
    controls: torch.Tensor
    targets: torch.Tensor
    lengths: torch.Tensor
    seed: int
    samples: int
    tau: float


def joint_moments_from_samples(sampled_rows: torch.Tensor,
                               lengths: torch.Tensor, *, tau: float) -> dict[str, torch.Tensor]:
    if (sampled_rows.device.type != 'cuda' or sampled_rows.ndim != 4 or
            lengths.device != sampled_rows.device or
            lengths.shape != sampled_rows.shape[:2] or
            sampled_rows.shape[1] < 2):
        raise ValueError('CUDA shared-word sample shape required')
    batch, samples, n, words = sampled_rows.shape
    dense = dense_bits(sampled_rows.reshape(batch * samples, n, words))
    columns = dense.reshape(batch, samples, n, n).to(torch.float64)
    weight = columns.sum(dim=2)
    pairs = columns.transpose(2, 3) @ columns
    xor = weight[:, :, :, None] + weight[:, :, None, :] - 2 * pairs
    character = 1 - 2 * weight.remainder(2)
    character_pair = character[:, :, :, None] * character[:, :, None, :]
    weight_mean = weight.mean(dim=1)
    pair_mean = pairs.mean(dim=1)
    xor_mean = xor.mean(dim=1)
    character_mean = character.mean(dim=1)
    character_pair_mean = character_pair.mean(dim=1)
    weight_centered = weight - weight_mean[:, None, :]
    pair_centered = pairs - pair_mean[:, None, :, :]
    xor_centered = xor - xor_mean[:, None, :, :]
    covariance_weight = (weight_centered.transpose(1, 2) @ weight_centered) / (samples - 1)
    covariance_weight_pair = (weight_centered[:, :, :, None] *
                              pair_centered).sum(dim=1) / (samples - 1)
    covariance_weight_xor = (weight_centered[:, :, :, None] *
                             xor_centered).sum(dim=1) / (samples - 1)
    covariance_character = (character_pair_mean -
                            character_mean[:, :, None] * character_mean[:, None, :])
    standard_error = lambda values: values.std(dim=1, correction=1) / math.sqrt(samples)
    stationary = torch.full((n, n), -1.0 / ((1 << n) - 1),
                            device=sampled_rows.device, dtype=torch.float64)
    index = torch.arange(n, device=sampled_rows.device)
    stationary[index, index] = 1.0
    gate_mean = lengths.sum(dim=1).to(torch.float64) / samples
    outputs = {
        'G07': weight_mean[..., None],
        'G08': torch.stack((covariance_weight, pair_mean, xor_mean,
                            covariance_weight_pair, covariance_weight_xor), dim=-1),
        'G09': torch.stack((character_pair_mean, covariance_character), dim=-1),
        'G10': torch.stack((standard_error(pairs), standard_error(xor),
                            standard_error(character_pair),
                            torch.abs(character_pair_mean - stationary),
                            torch.full_like(pair_mean, float(samples)),
                            gate_mean[:, None, None].expand(-1, n, n),
                            torch.full_like(pair_mean, float(tau))), dim=-1),
    }
    return {key: value.to(torch.float32) for key, value in outputs.items()}


@lru_cache(maxsize=16)
def _shared_word_bank(n: int, samples: int, tau: float, seed: int,
                      device: torch.device) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """One immutable seeded word bank per width and probe configuration."""
    generator = torch.Generator(device=device)
    generator.manual_seed(seed)
    rates = torch.full((samples,), n * tau, device=device)
    lengths = torch.poisson(rates, generator=generator).to(torch.int64)
    depth = int(lengths.max().item())
    controls = torch.randint(n, (samples, depth), device=device, generator=generator)
    offsets = torch.randint(n - 1, (samples, depth), device=device, generator=generator)
    targets = (controls + offsets + 1) % n
    return controls, targets, lengths


def shared_word_mc_features(rows: torch.Tensor, *, samples: int = 8,
                            tau: float = 1.0, seed: int = 0) -> GpuJointProbes:
    if (rows.device.type != 'cuda' or rows.ndim != 3 or rows.dtype != torch.int64 or
            samples < 2 or not math.isfinite(tau) or tau < 0 or seed < 0):
        raise ValueError('invalid CUDA joint probe specification')
    batch, n, words = rows.shape
    # Reference policy restarts the same seeded shared-word process for every
    # state. Broadcast one CUDA word bank so features are invariant to chunking.
    sample_controls, sample_targets, sample_lengths = _shared_word_bank(
        n, samples, float(tau), seed, rows.device)
    depth = sample_controls.shape[1]
    controls = sample_controls[None].expand(batch, -1, -1).reshape(batch * samples, depth)
    targets = sample_targets[None].expand(batch, -1, -1).reshape(batch * samples, depth)
    lengths = sample_lengths[None].expand(batch, -1).reshape(batch * samples)
    starts = rows.repeat_interleave(samples, dim=0)
    sampled = apply_gates(starts, controls, targets, lengths)
    sampled = sampled.reshape(batch, samples, n, words)
    length_grid = lengths.reshape(batch, samples)
    features = joint_moments_from_samples(sampled, length_grid, tau=tau)
    return GpuJointProbes(features, sampled,
                          controls.reshape(batch, samples, depth),
                          targets.reshape(batch, samples, depth),
                          length_grid, seed, samples, tau)
