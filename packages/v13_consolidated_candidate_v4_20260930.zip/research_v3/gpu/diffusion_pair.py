"""CUDA rank-two class diffusion for G06, with the reference state cap."""

from dataclasses import dataclass
from functools import lru_cache
import math

import torch

from .diffusion_exact import g05_pair_histogram


DEFAULT_TAUS = (0.25, 1.0, 4.0, 16.0)


@dataclass(frozen=True)
class G06Features:
    values: torch.Tensor
    available: torch.Tensor
    class_count: int


def _pair_states(n: int, device: torch.device) -> tuple[torch.Tensor, torch.Tensor]:
    axis = torch.arange(n + 1, device=device, dtype=torch.int64)
    a, b, c = torch.meshgrid(axis, axis, axis, indexing='ij')
    d = n - a - b - c
    allowed = (d >= 0) & ((b > 0).to(torch.int64) +
                          (c > 0).to(torch.int64) + (d > 0).to(torch.int64) >= 2)
    states = torch.stack((a[allowed], b[allowed], c[allowed], d[allowed]), dim=1)
    base = n + 1
    weights = torch.tensor((base**3, base**2, base, 1),
                           device=device, dtype=torch.int64)
    keys = (states * weights).sum(dim=1)
    return states, keys


def _pair_transition(n: int, states: torch.Tensor, keys: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    device = states.device
    count = states.shape[0]
    source = torch.arange(count, device=device).repeat_interleave(16)
    left = torch.arange(4, device=device).repeat_interleave(4).repeat(count)
    right = torch.arange(4, device=device).repeat(4).repeat(count)
    histogram = states[source]
    ways = histogram.gather(1, left[:, None]).squeeze(1) * \
           (histogram.gather(1, right[:, None]).squeeze(1) -
            (left == right).to(torch.int64))
    active = ways > 0
    source, left, right, ways, histogram = (value[active] for value in
                                           (source, left, right, ways, histogram))
    successor = histogram.clone()
    index = torch.arange(successor.shape[0], device=device)
    successor[index, right] -= 1
    successor[index, left ^ right] += 1
    base = n + 1
    encoding = torch.tensor((base**3, base**2, base, 1),
                            device=device, dtype=torch.int64)
    successor_key = (successor * encoding).sum(dim=1)
    location = torch.searchsorted(keys, successor_key)
    if bool(((location >= count) |
             (keys[location.clamp(max=count - 1)] != successor_key)).any().item()):
        raise AssertionError('rank-two class transition left the state space')
    return source, location, ways.to(torch.float64) / (n * (n - 1))


def _poisson_heat(start: torch.Tensor, source: torch.Tensor,
                  destination: torch.Tensor, probability: torch.Tensor,
                  times: torch.Tensor) -> torch.Tensor:
    maximum = float(times.max().item())
    terms = math.ceil(maximum + 12 * math.sqrt(maximum + 1) + 50)
    orders = torch.arange(terms + 1, device=start.device, dtype=torch.float64)
    logs = (-times[:, None] + orders[None] * torch.log(times[:, None].clamp_min(1e-300)) -
            torch.lgamma(orders[None] + 1))
    weights = torch.exp(logs)
    weights = torch.where((times == 0)[:, None],
                          torch.nn.functional.one_hot(torch.zeros(len(times), device=start.device,
                                                                  dtype=torch.int64), terms + 1).to(torch.float64),
                          weights)
    distribution = start
    result = torch.zeros((len(times), len(start)), device=start.device,
                         dtype=torch.float64)
    for step in range(terms + 1):
        result += weights[:, step, None] * distribution[None]
        if step < terms:
            next_distribution = torch.zeros_like(distribution)
            next_distribution.scatter_add_(0, destination,
                                           distribution[source] * probability)
            distribution = next_distribution
    return result


@lru_cache(maxsize=8)
def _pair_feature_table(n: int, device: torch.device, taus: tuple[float, ...],
                        floor: float) -> tuple[torch.Tensor, torch.Tensor]:
    class_count = math.comb(n + 3, 3) - 1 - 3 * n
    states, keys = _pair_states(n, device)
    if states.shape[0] != class_count:
        raise AssertionError('rank-two state count mismatch')
    source, destination, probability = _pair_transition(n, states, keys)
    initial_histogram = torch.tensor((n - 2, 1, 1, 0), device=device,
                                     dtype=torch.int64)
    base = n + 1
    initial_key = (initial_histogram * torch.tensor((base**3, base**2, base, 1),
                                                   device=device, dtype=torch.int64)).sum()
    initial_index = torch.searchsorted(keys, initial_key)
    start = torch.zeros(class_count, device=device, dtype=torch.float64)
    start[initial_index] = 1
    times = torch.tensor(tuple(n * float(t) for t in taus), device=device,
                         dtype=torch.float64)
    mass = _poisson_heat(start, source, destination, probability, times)
    if bool((mass < -1e-12).any().item()):
        raise ArithmeticError('negative CUDA rank-two diffusion mass')
    log_size = (torch.lgamma(torch.tensor(float(n + 1), device=device,
                                         dtype=torch.float64)) -
                torch.lgamma(states.to(torch.float64) + 1).sum(dim=1))
    total = (2**n - 1) * (2**n - 2)
    stationary = torch.exp(log_size - math.log(total))
    underflow = ((mass == 0) |
                 ((mass.to(torch.float32) == 0) & (mass > 0))).to(torch.float64)
    profile = torch.stack((mass, log_size[None].expand_as(mass),
                           stationary[None].expand_as(mass),
                           torch.log(mass.clamp_min(floor)) -
                           torch.log(stationary.clamp_min(floor))[None],
                           torch.zeros_like(mass), underflow,
                           (mass < floor).to(torch.float64)), dim=-1)
    return keys, profile


def g06_pair_heat(rows: torch.Tensor, *, taus=DEFAULT_TAUS, floor: float = 1e-30,
                  max_states: int = 10000) -> G06Features:
    taus = tuple(float(t) for t in taus)
    if (rows.device.type != 'cuda' or rows.ndim != 3 or rows.dtype != torch.int64 or
            max_states < 1 or not taus or any(not math.isfinite(t) or t < 0 for t in taus) or
            not (0 < floor < 1)):
        raise ValueError('invalid CUDA rank-two diffusion specification')
    batch, n, _ = rows.shape
    if n < 2:
        raise ValueError('rank-two diffusion requires n>=2')
    class_count = math.comb(n + 3, 3) - 1 - 3 * n
    shape = (batch, n, n, 7 * len(taus))
    if class_count > max_states:
        return G06Features(torch.zeros(shape, device=rows.device),
                           torch.zeros(batch, device=rows.device, dtype=torch.bool),
                           class_count)
    keys, profile = _pair_feature_table(n, rows.device, taus, float(floor))
    histograms = g05_pair_histogram(rows).to(torch.int64)
    base = n + 1
    encoding = torch.tensor((base**3, base**2, base, 1),
                            device=rows.device, dtype=torch.int64)
    selected_key = (histograms * encoding).sum(dim=-1)
    location = torch.searchsorted(keys, selected_key)
    safe_location = location.clamp(max=class_count - 1)
    diagonal = torch.eye(n, device=rows.device, dtype=torch.bool)[None]
    if bool(((location >= class_count) | (keys[safe_location] != selected_key)).logical_and(~diagonal).any().item()):
        raise AssertionError('labeled pair histogram missing from class states')
    selected = profile[:, safe_location].permute(1, 2, 3, 0, 4)
    values = selected.reshape(batch, n, n, 7 * len(taus)).to(torch.float32)
    values = values.masked_fill(diagonal[..., None], 0)
    return G06Features(values, torch.ones(batch, device=rows.device,
                                          dtype=torch.bool), class_count)
