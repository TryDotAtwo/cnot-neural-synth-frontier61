"""GPU feature routing and complete primitive Bellman selection/recompute.

This bypasses CPU MatrixState/FeatureRegistry wrappers. It does not yet cover
paid macros or the full training objective (bounds, Qhat, teacher, basis).
"""
from dataclasses import dataclass
from time import perf_counter

import torch

from ..features.packet import TypedFeature
from ..objectives.auxiliary import absolute_qhat_loss
from .neighbors import all_action_pairs, primitive_neighbor_chunks
from .structural_a import ALL_A, all_a_features, dense_bits
from .structural_b import SELECTED_BF, selected_bf_features
from .structural_cdh import SELECTED_CDH, selected_cdh_features
from .structural_e import SELECTED_E, selected_e_features
from .diffusion_exact import g05_pair_histogram
from .diffusion_mc import SELECTED_MC_G, shared_word_mc_features
from .diffusion_column import g01_column_heat
from .diffusion_pair import g06_pair_heat


@dataclass(frozen=True)
class GpuMatrixBatch:
    matrix: torch.Tensor
    valid: torch.Tensor


@dataclass(frozen=True)
class GpuFeaturePacket:
    features: dict
    group_incidence: dict


def gpu_field_inputs(rows: torch.Tensor, *, mc_samples: int = 0,
                     mc_seed: int = 0, mc_tau: float = 1.0,
                     column_heat: bool = False, pair_heat: bool = False,
                     max_pair_states: int = 10000):
    matrix = dense_bits(rows).bool()
    batch, n, _ = matrix.shape
    partial = selected_e_features(rows)
    features = (all_a_features(rows) | selected_bf_features(rows) |
                selected_cdh_features(rows) | partial.features |
                {'G05': g05_pair_histogram(rows)})
    if mc_samples:
        features |= shared_word_mc_features(rows, samples=mc_samples,
                                            tau=mc_tau, seed=mc_seed).features
    if column_heat:
        features['G01'] = g01_column_heat(rows)
    pair_available = None
    if pair_heat:
        pair_result = g06_pair_heat(rows, max_states=max_pair_states)
        features['G06'] = pair_result.values
        pair_available = pair_result.available
    available = torch.ones(batch, dtype=torch.bool, device=rows.device)
    packet = GpuFeaturePacket({key: TypedFeature(value, partial.available if key in SELECTED_E else
                                                  pair_available if key == 'G06' else available,
                                                  'global' if key in ('B01', 'F01', 'C01', 'E01', 'E05') else
                                                  'pair' if value.ndim == 4 else 'node',
                                                  'monte_carlo' if key in SELECTED_MC_G else
                                                  'floating_semigroup' if key in ('G01', 'G06') else 'exact',
                                                  'selected_partial_elimination' if key in SELECTED_E else
                                                  'full_labeled_matrix; shared_word_MC_joint_moments_empirical_uncertainty'
                                                  if key in SELECTED_MC_G else
                                                  'full_labeled_matrix; histogram_class_mass_not_labeled_endpoint'
                                                  if key == 'G06' else 'full_labeled_matrix',
                                                  'available' if key not in SELECTED_E and key != 'G06' else
                                                  'per_sample_resource_mask' if key == 'G06' else
                                                  'per_sample_applicability_mask')
                               for key, value in features.items()}, {})
    return GpuMatrixBatch(matrix, torch.ones((batch, n), device=rows.device,
                                              dtype=torch.bool)), packet


def gpu_field_value(model, rows: torch.Tensor, *, mc_samples: int = 8,
                    mc_seed: int = 0, mc_tau: float = 1.0,
                    max_pair_states: int = 10000) -> torch.Tensor:
    use_mc = any(key in model.stem.specs for key in SELECTED_MC_G)
    batch, packet = gpu_field_inputs(rows, mc_samples=mc_samples if use_mc else 0,
                                     mc_seed=mc_seed, mc_tau=mc_tau,
                                     column_heat='G01' in model.stem.specs,
                                     pair_heat='G06' in model.stem.specs,
                                     max_pair_states=max_pair_states)
    encoded = model.stem(batch, packet)
    return model.value(encoded)


def gpu_qhat_loss(model, rows: torch.Tensor, primitive_totals: torch.Tensor, *,
                  mc_samples: int = 8, mc_seed: int = 0,
                  mc_tau: float = 1.0,
                  max_pair_states: int = 10000) -> torch.Tensor:
    """Absolute detached cost-plus-successor targets for every allowed CNOT."""
    if (rows.device.type != 'cuda' or rows.ndim != 3 or
            primitive_totals.device != rows.device or
            primitive_totals.shape != (rows.shape[0], rows.shape[1] * (rows.shape[1] - 1))):
        raise ValueError('complete CUDA primitive targets required')
    use_mc = any(key in model.stem.specs for key in SELECTED_MC_G)
    batch, packet = gpu_field_inputs(rows, mc_samples=mc_samples if use_mc else 0,
                                     mc_seed=mc_seed, mc_tau=mc_tau,
                                     column_heat='G01' in model.stem.specs,
                                     pair_heat='G06' in model.stem.specs,
                                     max_pair_states=max_pair_states)
    encoded = model.stem(batch, packet)
    value = model.value(encoded)
    _, qhat, allowed = model.auxiliary(encoded.wire, encoded.pair, value,
                                        encoded.valid)
    controls, targets = all_action_pairs(rows.shape[1], str(rows.device))
    expected_mask = torch.zeros_like(allowed)
    expected_mask[:, controls, targets] = True
    if not torch.equal(allowed, expected_mask):
        raise ValueError('Qhat action mask differs from complete CNOT alphabet')
    target = torch.zeros_like(qhat)
    target[:, controls, targets] = primitive_totals.detach()
    return absolute_qhat_loss(qhat, target, allowed)


def complete_bellman_slice(model, rows: torch.Tensor, *, action_chunk: int,
                           mc_samples: int = 8, mc_seed: int = 0,
                           mc_tau: float = 1.0, max_pair_states: int = 10000,
                           phase_profile: bool = False):
    """Select all CNOT children without grad, then differentiate the chosen edge.

    The action order and strict-less update implement the reference's stable
    first-in-alphabet tie rule. Every primitive total is retained for Qhat.
    """
    if (rows.device.type != 'cuda' or rows.ndim != 3 or rows.dtype != torch.int64 or
            rows.shape[0] < 1 or rows.shape[1] < 2 or action_chunk < 1):
        raise ValueError('nonempty packed CUDA batch and positive action chunk required')
    if phase_profile:
        torch.cuda.synchronize(rows.device)
        phase_started = perf_counter()
    root_value = gpu_field_value(model, rows, mc_samples=mc_samples,
                                 mc_seed=mc_seed, mc_tau=mc_tau,
                                 max_pair_states=max_pair_states)
    if phase_profile:
        torch.cuda.synchronize(rows.device)
        root_seconds = perf_counter() - phase_started
        phase_started = perf_counter()
    batch_size, n, _ = rows.shape
    identity = torch.eye(n, dtype=torch.bool, device=rows.device)
    terminal = (dense_bits(rows) == identity[None]).all(dim=(1, 2))
    best = torch.full_like(root_value, torch.inf)
    selected_action = torch.full((batch_size,), -1, device=rows.device,
                                 dtype=torch.int64)
    selected_rows = rows.clone()
    primitive_totals = torch.empty((batch_size, n * (n - 1)),
                                   dtype=root_value.dtype, device=rows.device)
    observed = 0
    with torch.no_grad():
        for chunk in primitive_neighbor_chunks(rows, action_chunk):
            batch, count, n, words = chunk.rows.shape
            values = gpu_field_value(model, chunk.rows.reshape(batch * count, n, words),
                                     mc_samples=mc_samples, mc_seed=mc_seed, mc_tau=mc_tau,
                                     max_pair_states=max_pair_states)
            totals = 1 + values.reshape(batch, count)
            if not bool(torch.isfinite(totals).all().item()):
                raise ValueError('nonfinite Bellman candidates')
            primitive_totals[:, chunk.action_ids] = totals
            local_best, local_index = totals.min(dim=1)
            improved = (local_best < best) & ~terminal
            candidate_rows = chunk.rows[torch.arange(batch, device=rows.device),
                                        local_index]
            selected_rows = torch.where(improved[:, None, None], candidate_rows,
                                        selected_rows)
            selected_action = torch.where(improved,
                                          chunk.action_ids[local_index],
                                          selected_action)
            best = torch.where(improved, local_best, best)
            observed += count
    if observed != rows.shape[1] * (rows.shape[1] - 1):
        raise AssertionError('incomplete primitive neighborhood')
    if bool(((selected_action < 0) & ~terminal).any().item()):
        raise AssertionError('nonterminal without a selected primitive')
    if phase_profile:
        torch.cuda.synchronize(rows.device)
        neighbor_seconds = perf_counter() - phase_started
        phase_started = perf_counter()
    selected_value = gpu_field_value(model, selected_rows, mc_samples=mc_samples,
                                     mc_seed=mc_seed, mc_tau=mc_tau,
                                     max_pair_states=max_pair_states)
    residual = torch.where(terminal, root_value,
                           root_value - 1 - selected_value)
    loss = torch.nn.functional.smooth_l1_loss(residual, torch.zeros_like(residual))
    if not bool(torch.isfinite(loss).item()):
        raise ValueError('nonfinite Bellman loss')
    if phase_profile:
        torch.cuda.synchronize(rows.device)
        selected_seconds = perf_counter() - phase_started
    return loss, {'candidate_actions_per_root': observed,
                  'action_chunk': action_chunk,
                  'phase_seconds': {'root_forward': root_seconds,
                                    'complete_neighbor_forward': neighbor_seconds,
                                    'selected_forward_and_loss': selected_seconds}
                  if phase_profile else None,
                  'root_value': root_value.detach(),
                  'bellman_target': torch.where(terminal, torch.zeros_like(best), best).detach(),
                  'selected_action_ids': selected_action.detach(),
                  'primitive_totals': primitive_totals.detach(),
                  'terminal': terminal.detach(),
                  'features': ALL_A + SELECTED_BF + SELECTED_CDH + SELECTED_E + ('G05',) +
                  (SELECTED_MC_G if any(key in model.stem.specs for key in SELECTED_MC_G) else ()) +
                  (('G01',) if 'G01' in model.stem.specs else ()) +
                  (('G06',) if 'G06' in model.stem.specs else ())}
