"""CUDA port of the own general-macro compiler's Gaussian input word.

This word is a valid starting candidate. Production synthesis still requires
GPU paid-basis macro detection, pricing, carry, and postprocessing.
"""
from dataclasses import dataclass

import torch

from .packed_walk import identity_rows


@dataclass(frozen=True)
class GpuGaussianWords:
    controls: torch.Tensor
    targets: torch.Tensor
    lengths: torch.Tensor


def gaussian_encoder_words(rows: torch.Tensor) -> GpuGaussianWords:
    if (rows.device.type != 'cuda' or rows.ndim != 3 or rows.dtype != torch.int64 or
            rows.shape[1] < 1 or rows.shape[2] != (rows.shape[1] + 63) // 64):
        raise ValueError('packed CUDA square matrix batch required')
    batch, n, _ = rows.shape
    capacity = n * (n - 1) + 3 * n
    sentinel = capacity
    reduction_control = torch.zeros((batch, capacity + 1), device=rows.device,
                                    dtype=torch.int64)
    reduction_target = torch.zeros_like(reduction_control)
    lengths = torch.zeros((batch,), device=rows.device, dtype=torch.int64)
    work = rows.clone()
    ids = torch.arange(batch, device=rows.device)
    wire = torch.arange(n, device=rows.device)
    for column in range(n):
        present = ((work[:, :, column // 64] >> (column % 64)) & 1).bool()
        eligible = present & (wire[None, :] >= column)
        pivot = torch.where(eligible, wire[None, :], n).min(dim=1).values
        singular = pivot == n
        safe_pivot = torch.where(singular, column, pivot)
        swap = (~singular) & (safe_pivot != column)
        pivot_row = work[ids, safe_pivot].clone()
        column_row = work[:, column, :].clone()
        work[ids, column] = torch.where(swap[:, None], pivot_row, column_row)
        work[ids, safe_pivot] = torch.where(swap[:, None], column_row, pivot_row)
        swap_steps = torch.arange(3, device=rows.device)[None, :]
        swap_index = torch.where(swap[:, None], lengths[:, None] + swap_steps, sentinel)
        swap_controls = torch.stack((safe_pivot, torch.full_like(pivot, column),
                                     safe_pivot), dim=1)
        swap_targets = torch.stack((torch.full_like(pivot, column), safe_pivot,
                                    torch.full_like(pivot, column)), dim=1)
        reduction_control.scatter_(1, swap_index, swap_controls)
        reduction_target.scatter_(1, swap_index, swap_targets)
        lengths += 3 * swap.to(torch.int64)
        present = ((work[:, :, column // 64] >> (column % 64)) & 1).bool()
        active = present & (wire[None, :] != column) & (~singular[:, None])
        source = work[:, column, :].clone()
        work ^= source[:, None, :] * active[:, :, None].to(torch.int64)
        rank = active.to(torch.int64).cumsum(dim=1) - 1
        add_index = torch.where(active, lengths[:, None] + rank, sentinel)
        reduction_control.scatter_(1, add_index,
                                   torch.full((batch, n), column, device=rows.device,
                                              dtype=torch.int64))
        reduction_target.scatter_(1, add_index, wire[None, :].expand(batch, -1))
        lengths += active.sum(dim=1, dtype=torch.int64)
    expected = identity_rows(batch, n, str(rows.device))
    if not bool((work == expected).flatten(1).all(dim=1).all().item()):
        raise ValueError('matrix is singular or Gaussian reduction failed')
    positions = torch.arange(capacity, device=rows.device)[None, :]
    reverse_index = (lengths[:, None] - 1 - positions).clamp(min=0)
    controls = reduction_control.gather(1, reverse_index)
    targets = reduction_target.gather(1, reverse_index)
    return GpuGaussianWords(controls, targets, lengths)
