"""One GPU-paid shear replacement inside an arbitrary full-matrix word.

This is a complete-word correctness slice, not yet the stage-17 global
candidate/DP/carry/reordering compiler. No Hamming score is used.
"""
from dataclasses import dataclass

import torch

from .gaussian_backbone import GpuGaussianWords, gaussian_encoder_words
from .macro_windows import shear_window_mask
from .packed_walk import apply_gates, identity_rows


@dataclass(frozen=True)
class OneMacroWord:
    controls: torch.Tensor
    targets: torch.Tensor
    lengths: torch.Tensor
    improved: torch.Tensor
    preparation_lengths: torch.Tensor
    macro_start: torch.Tensor


@dataclass(frozen=True)
class GeneralPaidWord:
    controls: torch.Tensor
    targets: torch.Tensor
    lengths: torch.Tensor
    gaussian_lengths: torch.Tensor
    paid_macro_passes: int
    chosen_spans: tuple[int, ...]


def shorten_one_paid_shear_window(matrix: torch.Tensor, word: GpuGaussianWords,
                                  *, span: int) -> OneMacroWord:
    if (matrix.device.type != 'cuda' or matrix.ndim != 3 or matrix.shape[0] != 1 or
            word.controls.shape[0] != 1 or span < 4):
        raise ValueError('one-root CUDA macro slice contract')
    used = int(word.lengths[0].item())
    original_replay = apply_gates(identity_rows(1, matrix.shape[1], str(matrix.device)),
                                  word.controls[:, :used], word.targets[:, :used],
                                  word.lengths)
    if not torch.equal(original_replay, matrix):
        raise ValueError('input word does not encode the supplied full matrix')
    available = shear_window_mask(word, span)[0]
    starts = torch.nonzero(available).flatten()
    no_change = OneMacroWord(word.controls, word.targets, word.lengths,
                             torch.zeros((1,), device=matrix.device, dtype=torch.bool),
                             torch.zeros((1,), device=matrix.device, dtype=torch.int64),
                             torch.full((1,), -1, device=matrix.device, dtype=torch.int64))
    if starts.numel() == 0:
        return no_change
    offset = torch.arange(span, device=matrix.device)
    controls = word.controls[0, starts[:, None] + offset[None, :]]
    targets = word.targets[0, starts[:, None] + offset[None, :]]
    earlier = torch.tril(torch.ones((span, span), dtype=torch.bool,
                                     device=matrix.device), diagonal=-1)
    source_equal = controls[:, :, None] == controls[:, None, :]
    target_equal = targets[:, :, None] == targets[:, None, :]
    unique_source = ~(source_equal & earlier).any(dim=2)
    unique_target = ~(target_equal & earlier).any(dim=2)
    counts = torch.bmm(target_equal.to(torch.float32),
                       source_equal.to(torch.float32).transpose(1, 2))
    block = ((counts.to(torch.int64) & 1) != 0) & \
            unique_target[:, :, None] & unique_source[:, None, :]
    x = block.to(torch.float32)
    column_weight = x.sum(dim=1)
    overlap = x.transpose(1, 2) @ x
    delta = 2 + column_weight[:, None, :] - 2 * overlap
    valid_pair = (unique_source[:, :, None] & unique_source[:, None, :] &
                  (controls[:, :, None] != controls[:, None, :]))
    delta = torch.where(valid_pair, delta, 1e6)
    minimum_delta, pair = delta.flatten(1).min(dim=1)
    prep = minimum_delta < 0
    cost = block.sum(dim=(1, 2), dtype=torch.int64) + \
           torch.where(prep, minimum_delta.to(torch.int64), 0)
    gain = span - cost
    winner = gain.argmax()
    if not bool((gain[winner] > 0).item()):
        return no_change
    start = starts[winner]
    source_slot, added_slot = pair[winner] // span, pair[winner] % span
    selected_controls = controls[winner]
    selected_targets = targets[winner]
    core = block[winner].clone()
    selected_prep = prep[winner]
    before = core[:, source_slot]
    after = before ^ core[:, added_slot]
    core[:, source_slot] = torch.where(selected_prep, after, before)
    core_mask = core.flatten()
    core_count = core_mask.sum(dtype=torch.int64)
    prep_count = selected_prep.to(torch.int64)
    macro_capacity = span * span + 2
    sentinel = macro_capacity
    macro_control = torch.zeros((macro_capacity + 1,), device=matrix.device,
                                dtype=torch.int64)
    macro_target = torch.zeros_like(macro_control)
    prep_index = torch.where(selected_prep, 0, sentinel)
    prep_control = selected_controls[source_slot]
    prep_target = selected_controls[added_slot]
    macro_control[prep_index] = prep_control
    macro_target[prep_index] = prep_target
    rank = core_mask.to(torch.int64).cumsum(dim=0) - 1
    core_index = torch.where(core_mask, prep_count + rank, sentinel)
    core_control = selected_controls[offset.repeat(span)]
    core_target = selected_targets[offset.repeat_interleave(span)]
    macro_control.scatter_(0, core_index, core_control)
    macro_target.scatter_(0, core_index, core_target)
    restore_index = torch.where(selected_prep, prep_count + core_count, sentinel)
    macro_control[restore_index] = prep_control
    macro_target[restore_index] = prep_target
    macro_length = 2 * prep_count + core_count
    new_length = word.lengths[0] - span + macro_length
    output_capacity = int(new_length.item())
    position = torch.arange(output_capacity, device=matrix.device)
    original_control = word.controls[0]
    original_target = word.targets[0]
    before_macro = position < start
    inside_macro = (position >= start) & (position < start + macro_length)
    suffix_index = (position - macro_length + span).clamp(0, original_control.numel() - 1)
    macro_index = (position - start).clamp(0, macro_capacity)
    prefix_index = position.clamp(0, original_control.numel() - 1)
    output_control = torch.where(before_macro, original_control[prefix_index],
                                 torch.where(inside_macro, macro_control[macro_index],
                                             original_control[suffix_index]))
    output_target = torch.where(before_macro, original_target[prefix_index],
                                torch.where(inside_macro, macro_target[macro_index],
                                            original_target[suffix_index]))
    result = OneMacroWord(output_control[None, :], output_target[None, :],
                          new_length[None], torch.ones((1,), device=matrix.device,
                                                       dtype=torch.bool),
                          prep_count[None], start[None])
    replay = apply_gates(identity_rows(1, matrix.shape[1], str(matrix.device)),
                         result.controls, result.targets, result.lengths)
    if not torch.equal(replay, matrix):
        raise AssertionError('paid macro changed the full matrix')
    return result


def synthesize_general_paid(matrix: torch.Tensor, *, spans=(8, 16, 32)) -> GeneralPaidWord:
    """Greedy strictly improving paid macro passes on an arbitrary invertible M."""
    if (matrix.device.type != 'cuda' or matrix.ndim != 3 or matrix.shape[0] != 1 or
            not spans or any(type(span) is not int or span < 4 or span > 32 for span in spans) or
            len(set(spans)) != len(spans)):
        raise ValueError('one-root CUDA paid-macro schedule contract')
    baseline = gaussian_encoder_words(matrix)
    initial = int(baseline.lengths[0].item())
    current = GpuGaussianWords(baseline.controls[:, :initial],
                               baseline.targets[:, :initial], baseline.lengths)
    chosen = []
    while True:
        current_length = int(current.lengths[0].item())
        winner = None
        winner_length = current_length
        winner_span = None
        for span in spans:
            if span > current_length:
                continue
            candidate = shorten_one_paid_shear_window(matrix, current, span=span)
            candidate_length = int(candidate.lengths[0].item())
            if candidate_length < winner_length:
                winner, winner_length, winner_span = candidate, candidate_length, span
        if winner is None:
            break
        chosen.append(winner_span)
        current = GpuGaussianWords(winner.controls, winner.targets, winner.lengths)
    replay = apply_gates(identity_rows(1, matrix.shape[1], str(matrix.device)),
                         current.controls, current.targets, current.lengths)
    if not torch.equal(replay, matrix):
        raise AssertionError('general paid macro output changed the full matrix')
    return GeneralPaidWord(current.controls, current.targets, current.lengths,
                           baseline.lengths, len(chosen), tuple(chosen))
