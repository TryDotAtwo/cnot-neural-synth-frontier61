"""Exact full-matrix GPU holdout admission with a hash prefilter.

The hash only locates possible matches. Every match, including deliberate
collisions, is compared against the entire packed matrix on CUDA.
"""

from dataclasses import dataclass

import torch

from .neighbors import primitive_neighbor_chunks
from .structural_a import dense_bits
from .structural_cdh import gf2_inverse_dense


def _pack_dense_bool(matrix: torch.Tensor) -> torch.Tensor:
    batch, n, columns = matrix.shape
    if columns != n or matrix.device.type != 'cuda':
        raise ValueError('square CUDA matrix required')
    words = (n + 63) // 64
    padded = torch.zeros((batch, n, words * 64), dtype=torch.bool,
                         device=matrix.device)
    padded[:, :, :n] = matrix
    weights = torch.ones(64, device=matrix.device, dtype=torch.int64) << \
              torch.arange(64, device=matrix.device, dtype=torch.int64)
    return (padded.reshape(batch, n, words, 64).to(torch.int64) *
            weights[None, None, None]).sum(dim=-1)


def declared_finite_views(roots: torch.Tensor) -> torch.Tensor:
    """GPU identity/inverse/transpose/inverse-transpose and wire reversal.

    This is exactly the finite declared set used by ``forbidden_views``;
    it makes no claim about all wire permutations or a full symmetry orbit.
    """
    if (roots.device.type != 'cuda' or roots.dtype != torch.int64 or
            roots.ndim != 3 or roots.shape[0] < 1 or
            roots.shape[2] != (roots.shape[1] + 63) // 64):
        raise ValueError('nonempty packed CUDA roots required')
    matrix = dense_bits(roots).bool()
    inverse = gf2_inverse_dense(matrix)
    four = (matrix, inverse, matrix.transpose(1, 2),
            inverse.transpose(1, 2))
    views = torch.cat(tuple(_pack_dense_bool(view) for view in four) +
                      tuple(_pack_dense_bool(view.flip((1, 2))) for view in four),
                      dim=0)
    return torch.unique(views, dim=0)


@dataclass(frozen=True)
class GpuExactHoldout:
    sorted_rows: torch.Tensor
    sorted_hashes: torch.Tensor
    hash_weights: torch.Tensor

    @classmethod
    def empty_projection(cls, n: int, *, device='cuda'):
        """Explicit empty width projection; sealed-loader owns absence proof."""
        if type(n) is not int or not 2 <= n <= 256:
            raise ValueError('valid exact holdout width required')
        target = torch.device(device)
        if target.type != 'cuda':
            raise ValueError('CUDA holdout projection required')
        words = (n + 63) // 64
        return cls(torch.empty((0, n, words), dtype=torch.int64, device=target),
                   torch.empty((0,), dtype=torch.int64, device=target),
                   torch.ones((n, words), dtype=torch.int64, device=target))

    @classmethod
    def from_matrices(cls, matrices: torch.Tensor, *,
                      hash_weights: torch.Tensor | None = None):
        if (matrices.device.type != 'cuda' or matrices.dtype != torch.int64 or
                matrices.ndim != 3 or matrices.shape[0] < 1 or
                matrices.shape[2] != (matrices.shape[1] + 63) // 64):
            raise ValueError('nonempty packed CUDA forbidden matrices required')
        _, n, words = matrices.shape
        if hash_weights is None:
            generator = torch.Generator(device=matrices.device)
            generator.manual_seed(0x19D2765)
            hash_weights = torch.randint(1, 2**63 - 1, (n, words),
                                         device=matrices.device,
                                         dtype=torch.int64, generator=generator)
        if (hash_weights.device != matrices.device or hash_weights.dtype != torch.int64 or
                hash_weights.shape != (n, words)):
            raise ValueError('CUDA hash weight shape mismatch')
        fingerprints = (matrices * hash_weights[None]).flatten(1).sum(dim=1)
        order = torch.argsort(fingerprints, stable=True)
        return cls(matrices[order].contiguous(), fingerprints[order].contiguous(),
                   hash_weights)

    @classmethod
    def from_frozen_roots(cls, roots: torch.Tensor, *, neighbor_chunk: int,
                          max_entries: int):
        if (roots.device.type != 'cuda' or roots.ndim != 3 or
                neighbor_chunk < 1 or max_entries < 1):
            raise ValueError('CUDA frozen root closure specification required')
        batch, n, _ = roots.shape
        required = batch * (1 + n * (n - 1))
        if required > max_entries:
            raise MemoryError(f'holdout closure requires {required} entries; cap {max_entries}')
        parts = [roots]
        for chunk in primitive_neighbor_chunks(roots, neighbor_chunk):
            parts.append(chunk.rows.reshape(-1, n, roots.shape[2]))
        return cls.from_matrices(torch.cat(parts, dim=0))

    @classmethod
    def from_declared_root_views(cls, roots: torch.Tensor, *,
                                 neighbor_chunk: int, max_entries: int):
        return cls.from_frozen_roots(declared_finite_views(roots),
                                     neighbor_chunk=neighbor_chunk,
                                     max_entries=max_entries)

    def matches(self, rows: torch.Tensor) -> torch.Tensor:
        if (rows.device != self.sorted_rows.device or rows.dtype != torch.int64 or
                rows.ndim not in (3, 4) or rows.shape[-2:] != self.sorted_rows.shape[-2:]):
            raise ValueError('CUDA packed holdout query shape/device mismatch')
        leading = rows.shape[:-2]
        queries = rows.reshape(-1, *self.sorted_rows.shape[-2:])
        fingerprints = (queries * self.hash_weights[None]).flatten(1).sum(dim=1)
        left = torch.searchsorted(self.sorted_hashes, fingerprints, right=False)
        right = torch.searchsorted(self.sorted_hashes, fingerprints, right=True)
        counts = right - left
        maximum = int(counts.max().item())
        if maximum == 0:
            return torch.zeros(leading, device=rows.device, dtype=torch.bool)
        offsets = torch.arange(maximum, device=rows.device)[None]
        indices = (left[:, None] + offsets).clamp(max=self.sorted_rows.shape[0] - 1)
        exact = (queries[:, None] == self.sorted_rows[indices]).flatten(2).all(dim=2)
        return (exact & (offsets < counts[:, None])).any(dim=1).reshape(leading)


def admit_complete_neighborhood(holdout: GpuExactHoldout,
                                roots: torch.Tensor, *, chunk_size: int) -> int:
    if chunk_size < 1:
        raise ValueError('positive admission chunk required')
    if bool(holdout.matches(roots).any().item()):
        raise ValueError('training parent intersects exact GPU holdout closure')
    checked = roots.shape[0]
    for chunk in primitive_neighbor_chunks(roots, chunk_size):
        if bool(holdout.matches(chunk.rows).any().item()):
            raise ValueError('complete CNOT neighbor intersects exact GPU holdout closure')
        checked += chunk.rows.shape[0] * chunk.rows.shape[1]
    expected = roots.shape[0] * (1 + roots.shape[1] * (roots.shape[1] - 1))
    if checked != expected:
        raise AssertionError('incomplete GPU neighborhood admission')
    return checked
