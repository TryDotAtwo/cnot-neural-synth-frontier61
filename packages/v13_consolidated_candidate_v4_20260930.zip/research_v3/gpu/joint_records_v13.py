"""Full Bellman/basis route with independently admitted exact root labels."""
import torch
from torch.nn import functional as F

from .field_slice import gpu_field_value
from .joint_basis_slice import complete_joint_basis_batch
from .record_batch_v13 import validate_own_records


def exact_root_loss(values, distances):
    if values.shape != (len(distances),) or not distances:
        raise ValueError('exact root label shape mismatch')
    if any(d is not None and (type(d) is not int or d < 0) for d in distances):
        raise ValueError('invalid exact root distance')
    mask = torch.tensor([d is not None for d in distances],
                        device=values.device, dtype=torch.bool)
    if not bool(mask.any().item()):
        return values.sum() * 0
    targets = values.new_tensor([0 if d is None else d for d in distances])
    # FullGraphObjective averages per-record terms over the entire batch.
    # Unknown distances contribute zero, rather than changing the denominator.
    return F.smooth_l1_loss(values[mask], targets[mask], reduction='sum') / len(distances)


def complete_joint_basis_records(model, batch, records, *, exact_catalog=None, **kwargs):
    """Exact supervision applies only to the original complete input roots.

    Prefix/symmetry records must carry their own independently checked labels.
    A word length is never substituted for an unavailable exact distance.
    """
    records = tuple(records)
    validate_own_records(records, exact_catalog=exact_catalog)
    if (batch.exact_distances != tuple(r.exact_distance for r in records) or
            batch.exact_evidence != tuple(r.exact_evidence for r in records) or
            batch.lineages != tuple(r.lineage_id for r in records)):
        raise ValueError('exact root metadata mismatch')
    n = records[0].state.n
    packed = [[[(row >> (64 * slot)) & ((1 << 64) - 1)
                for slot in range((n + 63) // 64)]
               for row in r.state.packed_rows] for r in records]
    signed = [[[x - (1 << 64) if x & (1 << 63) else x for x in row]
               for row in matrix] for matrix in packed]
    expected = torch.tensor(signed, device=batch.walk.rows.device, dtype=torch.int64)
    if not torch.equal(expected, batch.walk.rows):
        raise ValueError('exact labels belong to different full matrices')
    if 'training_walk' in kwargs:
        raise ValueError('record route owns its verified training word')
    loss, audit = complete_joint_basis_batch(
        model, batch.walk.rows, training_walk=batch.walk, **kwargs)
    weight = kwargs.get('supervision_weight', 1.0)
    if weight < 0:
        raise ValueError('negative supervision weight')
    count = sum(d is not None for d in batch.exact_distances)
    exact = loss * 0
    if count and weight:
        values = gpu_field_value(
            model.field, batch.walk.rows,
            mc_samples=kwargs.get('mc_samples', 8),
            mc_seed=kwargs.get('mc_seed', 0),
            max_pair_states=kwargs.get('max_pair_states', 10000))
        exact = exact_root_loss(values, batch.exact_distances)
    if 'objective_components' in audit:
        main, basis, templates = audit['objective_components']
        from .joint_terms_v13 import JointTerms
        audit = {**audit, 'objective_components': JointTerms(
            main + weight * exact, len(records), basis, templates)}
    return loss + weight * exact, {**audit, 'exact_root_loss': exact.detach(),
                                  'exact_root_examples': count}
