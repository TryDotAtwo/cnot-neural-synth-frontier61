"""Reference denominators for separately evaluated complete-width batches."""
from dataclasses import dataclass
import math
import torch


@dataclass(frozen=True)
class JointTerms:
    main: torch.Tensor
    records: int
    basis: torch.Tensor
    templates: int


def merge_joint_terms(groups, *, weight):
    groups = tuple(groups)
    if not groups or not math.isfinite(weight) or weight < 0:
        raise ValueError('nonempty joint groups and finite nonnegative weight required')
    device = groups[0].main.device
    for group in groups:
        if (type(group.records) is not int or group.records < 1 or
                type(group.templates) is not int or
                not 0 <= group.templates <= group.records):
            raise ValueError('invalid joint denominators')
        if any(term.ndim != 0 or term.device != device
               for term in (group.main, group.basis)):
            raise ValueError('scalar joint terms on one device required')
    total = sum(group.records for group in groups)
    active = sum(group.templates for group in groups)
    main = sum(group.main * group.records for group in groups) / total
    if not active:
        return main
    basis = sum(group.basis * group.templates for group in groups
                if group.templates) / active
    return main + weight * basis
