"""CUDA admission for contiguous commuting shear windows in full CNOT words."""
import torch

from .gaussian_backbone import GpuGaussianWords


def shear_window_mask(word: GpuGaussianWords, span: int) -> torch.Tensor:
    """Return one device bool per start; true windows form a disjoint shear."""
    if (span < 1 or word.controls.device.type != 'cuda' or
            word.targets.shape != word.controls.shape or
            word.controls.dtype != torch.int64 or word.targets.dtype != torch.int64 or
            word.lengths.shape != (word.controls.shape[0],)):
        raise ValueError('CUDA word-window contract')
    batch, capacity = word.controls.shape
    if span > capacity:
        return torch.zeros((batch, 0), device=word.controls.device, dtype=torch.bool)
    controls = word.controls.unfold(1, span, 1)
    targets = word.targets.unfold(1, span, 1)
    start = torch.arange(capacity - span + 1, device=word.controls.device)
    in_word = start[None, :] + span <= word.lengths[:, None]
    disjoint = (controls[..., :, None] != targets[..., None, :]).all(dim=(-1, -2))
    earlier = torch.tril(torch.ones((span, span), device=word.controls.device,
                                     dtype=torch.bool), diagonal=-1)
    control_repeat = (controls[..., :, None] == controls[..., None, :]) & earlier
    target_repeat = (targets[..., :, None] == targets[..., None, :]) & earlier
    distinct_controls = (~control_repeat.any(dim=-1)).sum(dim=-1)
    distinct_targets = (~target_repeat.any(dim=-1)).sum(dim=-1)
    return in_word & disjoint & (distinct_controls >= 2) & (distinct_targets >= 2)
