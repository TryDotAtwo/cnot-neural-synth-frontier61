"""Complete primitive CNOT-neighbor enumeration over packed CUDA matrices."""
from dataclasses import dataclass
from typing import Iterator

import torch


@dataclass(frozen=True)
class NeighborChunk:
    rows: torch.Tensor       # [batch, actions, n, words], CUDA
    controls: torch.Tensor   # [actions], CUDA
    targets: torch.Tensor    # [actions], CUDA
    action_ids: torch.Tensor # original [0,n(n-1)) IDs, CUDA


def all_action_pairs(n: int, device: str = 'cuda'):
    if n < 2:
        raise ValueError('CNOT needs at least two wires')
    controls = torch.arange(n, device=device, dtype=torch.int64).repeat_interleave(n - 1)
    relative = torch.arange(n - 1, device=device, dtype=torch.int64).repeat(n)
    targets = relative + (relative >= controls).to(torch.int64)
    return controls, targets


def primitive_neighbor_chunks(rows: torch.Tensor, chunk_size: int) -> Iterator[NeighborChunk]:
    if rows.ndim != 3 or rows.dtype != torch.int64 or rows.device.type != 'cuda' or chunk_size < 1:
        raise ValueError('packed CUDA parent batch and positive chunk size required')
    batch, n, words = rows.shape
    if words != (n + 63) // 64:
        raise ValueError('packed word count mismatch')
    controls, targets = all_action_pairs(n, str(rows.device))
    total = n * (n - 1)
    batch_ids = torch.arange(batch, device=rows.device)[:, None]
    for start in range(0, total, chunk_size):
        stop = min(total, start + chunk_size)
        control, target = controls[start:stop], targets[start:stop]
        count = stop - start
        child = rows[:, None, :, :].expand(-1, count, -1, -1).clone()
        action_ids = torch.arange(start, stop, device=rows.device, dtype=torch.int64)
        action_slot = torch.arange(count, device=rows.device)[None, :]
        child[batch_ids, action_slot, target[None, :]] ^= rows[:, control, :]
        yield NeighborChunk(child, control, target, action_ids)
