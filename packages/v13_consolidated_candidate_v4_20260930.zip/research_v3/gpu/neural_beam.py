"""Bounded full-matrix neural CNOT beam with exact output replay.

Qhat ranks a per-parent shortlist; V scores every retained child. Both heads
come from the learned field. The shortlist is explicitly approximate. No
Hamming score, external word, or historical result is used by this search.
"""

from dataclasses import dataclass
from time import perf_counter

import torch

from .field_slice import gpu_field_inputs, gpu_field_value
from .neighbors import all_action_pairs
from .packed_walk import identity_rows


@dataclass(frozen=True)
class NeuralBeamResult:
    status: str
    word: tuple[tuple[int, int], ...] | None
    verified: bool
    expanded: int
    generated: int
    value_evaluations: int
    seconds: float
    beam_width: int
    shortlist: int


def _state_key(rows: torch.Tensor) -> bytes:
    return rows.detach().cpu().contiguous().numpy().tobytes()


def _verify_reduction(root: torch.Tensor,
                      word: tuple[tuple[int, int], ...]) -> bool:
    """Independent CPU row-XOR replay after the search finishes."""
    n = root.shape[0]
    rows = root.detach().cpu().tolist()
    for control, target in word:
        if not (0 <= control < n and 0 <= target < n and control != target):
            return False
        rows[target] = [a ^ b for a, b in zip(rows[target], rows[control])]
    for wire in range(n):
        for slot in range((n + 63) // 64):
            wanted = 1 << (wire % 64) if slot == wire // 64 else 0
            if wanted >= 1 << 63:
                wanted -= 1 << 64
            if rows[wire][slot] != wanted:
                return False
    return True


def beam_search(root: torch.Tensor, score_actions, score_states, *,
                beam_width: int, shortlist: int, max_depth: int,
                inference_batch: int = 16, max_expanded: int = 100000) -> NeuralBeamResult:
    """Search a full CNOT word; callbacks may run a CUDA neural field.

    ``score_actions`` returns finite lower-is-better shortlist scores for all
    n(n-1) actions in the order of ``all_action_pairs`` (absolute Qhat or
    negated proposal logits), or is None for a complete-action sweep.
    ``score_states`` returns V for packed states. The first callback only
    chooses a strict shortlist; at K=all its scores are bypassed to preserve
    the exact direct-V tie/dedup order. The second ranks full child matrices.
    Every reported word is independently replayed.
    """
    if (root.ndim != 3 or root.dtype != torch.int64 or root.shape[0] != 1 or
            root.shape[1] < 2 or root.shape[2] != (root.shape[1] + 63) // 64 or
            beam_width < 1 or shortlist < 1 or max_depth < 0 or
            inference_batch < 1 or max_expanded < 1):
        raise ValueError('invalid complete-matrix neural beam specification')
    started = perf_counter()
    n = root.shape[1]
    actions = n * (n - 1)
    if score_actions is None and shortlist < actions:
        raise ValueError('full-action scorer requires the complete action alphabet')
    shortlist = min(shortlist, actions)
    controls, targets = all_action_pairs(n, str(root.device))
    controls_cpu, targets_cpu = controls.cpu().tolist(), targets.cpu().tolist()
    identity = identity_rows(1, n, str(root.device))[0] if root.device.type == 'cuda' else _cpu_identity(n)

    def result(status, word, expanded, generated, evaluations):
        verified = word is not None and _verify_reduction(root[0], word)
        if word is not None and not verified:
            raise AssertionError('neural beam emitted invalid complete CNOT word')
        return NeuralBeamResult(status, word, verified, expanded, generated,
                                evaluations, perf_counter() - started,
                                beam_width, shortlist)

    if torch.equal(root[0], identity):
        return result('solved', (), 0, 0, 0)
    frontier = [(root[0].clone(), ())]
    closed = {_state_key(root[0])}
    expanded = generated = evaluations = 0
    for _depth in range(max_depth):
        if expanded + len(frontier) > max_expanded:
            return result('resource_limit', None, expanded, generated, evaluations)
        parents = torch.stack([state for state, _word in frontier])
        expanded += len(frontier)
        # Check the goal against the *complete* primitive alphabet before an
        # approximate shortlist. A state is one CNOT from I exactly when one
        # row differs from I and its residual equals another current row.
        difference = parents ^ identity[None]
        changed_rows = (difference != 0).any(dim=2)
        one_changed = changed_rows.sum(dim=1) == 1
        target_rows = changed_rows.to(torch.int64).argmax(dim=1)
        parent_ids = torch.arange(len(frontier), device=root.device)
        needed = difference[parent_ids, target_rows]
        matching_controls = (parents == needed[:, None]).all(dim=2)
        matching_controls[parent_ids, target_rows] = False
        matching_controls &= one_changed[:, None]
        if bool(matching_controls.any().item()):
            goals = []
            for parent_index, control in torch.nonzero(
                    matching_controls).cpu().tolist():
                goals.append(frontier[parent_index][1] +
                             ((control, int(target_rows[parent_index].item())),))
            return result('solved', min(goals), expanded, generated, evaluations)
        if shortlist == actions:
            ranked = torch.arange(actions, device=root.device)[None].expand(
                len(frontier), -1)
        else:
            qparts = []
            for start in range(0, len(frontier), inference_batch):
                qparts.append(score_actions(parents[start:start + inference_batch]))
            qhat = torch.cat(qparts)
            if qhat.shape != (len(frontier), actions):
                raise ValueError('neural action head must score the complete finite alphabet')
            if not bool(torch.isfinite(qhat).all().item()):
                raise FloatingPointError('nonfinite neural action scores')
            ranked = torch.argsort(qhat, dim=1, stable=True)[:, :shortlist]
        children = {}
        # Form shortlisted successors in memory-bounded device batches. One
        # host transfer per batch avoids synchronization per candidate; the
        # batch boundary does not change exact deduplication or beam order.
        parent_count = len(frontier)
        per_parent_bytes = shortlist * n * root.shape[2] * 8
        parents_per_batch = max(1, (64 << 20) // per_parent_bytes)
        for first in range(0, parent_count, parents_per_batch):
            last = min(parent_count, first + parents_per_batch)
            subset = ranked[first:last]
            count = last - first
            parent_ids = torch.arange(count, device=root.device)[:, None]
            selected_controls = controls[subset]
            selected_targets = targets[subset]
            successor_rows = parents[first:last, None].expand(
                -1, shortlist, -1, -1).clone()
            successor_rows[parent_ids,
                           torch.arange(shortlist, device=root.device)[None],
                           selected_targets] ^= parents[first:last][
                               parent_ids, selected_controls]
            flattened = successor_rows.reshape(count * shortlist, n, root.shape[2])
            host_rows = flattened.detach().cpu().contiguous().numpy()
            ranked_cpu = subset.cpu().tolist()
            for flat_index in range(count * shortlist):
                local_parent, action_offset = divmod(flat_index, shortlist)
                parent_index = first + local_parent
                action_id = ranked_cpu[local_parent][action_offset]
                generated += 1
                key = host_rows[flat_index].tobytes()
                if key in closed or key in children:
                    continue
                control, target = controls_cpu[action_id], targets_cpu[action_id]
                word = frontier[parent_index][1] + ((control, target),)
                children[key] = (flattened[flat_index].clone(), word)
        if not children:
            return result('exhausted', None, expanded, generated, evaluations)
        candidates = list(children.values())
        goal_rows = torch.stack([state for state, _word in candidates])
        goal_mask = (goal_rows == identity[None]).flatten(1).all(dim=1)
        if bool(goal_mask.any().item()):
            words = [candidates[index][1] for index in torch.nonzero(goal_mask).flatten().cpu().tolist()]
            return result('solved', min(words), expanded, generated, evaluations)
        values = []
        for start in range(0, len(candidates), inference_batch):
            values.append(score_states(goal_rows[start:start + inference_batch]))
        value = torch.cat(values)
        evaluations += len(candidates)
        if value.shape != (len(candidates),):
            raise ValueError('neural field returned nonfinite or incomplete child values')
        if not bool(torch.isfinite(value).all().item()):
            raise FloatingPointError('nonfinite neural child values')
        value_cpu = value.detach().cpu().tolist()
        ranked_children = sorted((float(value_cpu[i]) + len(word), word, i)
                                 for i, (_state, word) in enumerate(candidates))
        frontier = [candidates[index] for _score, _word, index in ranked_children[:beam_width]]
        closed.update(_state_key(state) for state, _word in frontier)
    return result('depth_limit', None, expanded, generated, evaluations)


def _cpu_identity(n: int) -> torch.Tensor:
    rows = torch.zeros((n, (n + 63) // 64), dtype=torch.int64)
    for wire in range(n):
        value = 1 << (wire % 64)
        rows[wire, wire // 64] = value if value < 1 << 63 else value - (1 << 64)
    return rows


def neural_field_callbacks(model, *, mc_samples: int, mc_seed: int,
                           max_pair_states: int, head: str = 'qhat'):
    """Bind search callbacks to one trained full29 field on CUDA."""
    if head not in ('qhat', 'proposal'):
        raise ValueError('unknown neural action ranking head')
    field = model.field if hasattr(model, 'field') else model

    @torch.inference_mode()
    def actions(rows: torch.Tensor) -> torch.Tensor:
        if rows.device.type != 'cuda':
            raise ValueError('production neural scorer requires CUDA')
        batch, packet = gpu_field_inputs(
            rows, mc_samples=mc_samples, mc_seed=mc_seed,
            column_heat='G01' in field.stem.specs,
            pair_heat='G06' in field.stem.specs,
            max_pair_states=max_pair_states)
        encoded = field.stem(batch, packet)
        value = field.value(encoded)
        proposal, qhat, _mask = field.auxiliary(
            encoded.wire, encoded.pair, value, encoded.valid)
        control, target = all_action_pairs(rows.shape[1], str(rows.device))
        return (qhat if head == 'qhat' else -proposal)[:, control, target]

    @torch.inference_mode()
    def states(rows: torch.Tensor) -> torch.Tensor:
        return gpu_field_value(field, rows, mc_samples=mc_samples,
                               mc_seed=mc_seed,
                               max_pair_states=max_pair_states)

    return actions, states


def matrix_hamming_callbacks():
    """Own matrix-entry Hamming control under the identical beam engine.

    The action callback includes all primitives; the child score is the exact
    number of entries where the full matrix differs from identity.
    """
    def states(rows: torch.Tensor) -> torch.Tensor:
        n = rows.shape[1]
        columns = torch.arange(n, device=rows.device, dtype=torch.int64)
        matrix = ((rows[:, :, columns // 64] >> (columns % 64)) & 1).to(
            torch.float32)
        eye = torch.eye(n, device=rows.device, dtype=torch.float32)
        return torch.abs(matrix - eye[None]).sum(dim=(1, 2))

    return None, states
