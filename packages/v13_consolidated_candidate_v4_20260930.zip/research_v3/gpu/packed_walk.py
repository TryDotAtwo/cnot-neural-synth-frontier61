"""Batched complete GF(2) walk generation and certificate replay on CUDA.

The inverse walk is a generation certificate, not the stage-17 basis solver.
All matrix/gate arithmetic stays on device; Python only dispatches each depth.
"""
from dataclasses import dataclass

import torch


@dataclass(frozen=True)
class PackedWalkBatch:
    rows: torch.Tensor          # int64 [batch, n, ceil(n/64)], CUDA
    controls: torch.Tensor      # int64 [batch, max_length], CUDA
    targets: torch.Tensor       # int64 [batch, max_length], CUDA
    lengths: torch.Tensor       # int64 [batch], CUDA


def identity_rows(batch: int, n: int, device: str = 'cuda') -> torch.Tensor:
    if batch < 1 or n < 2 or n > 256:
        raise ValueError('unsupported packed CUDA batch shape')
    rows = torch.zeros((batch, n, (n + 63) // 64), dtype=torch.int64, device=device)
    wire = torch.arange(n, dtype=torch.int64, device=device)
    diagonal = torch.ones(n, dtype=torch.int64, device=device) << (wire % 64)
    rows[:, wire, wire // 64] = diagonal[None, :]
    return rows


def apply_gates(rows: torch.Tensor, controls: torch.Tensor,
                targets: torch.Tensor, lengths: torch.Tensor,
                *, reverse: bool = False) -> torch.Tensor:
    """Return a fresh batch after full row-XOR words, preserving padded gates."""
    if (rows.device.type != 'cuda' or controls.device != rows.device or
            targets.device != rows.device or lengths.device != rows.device or
            rows.dtype != torch.int64 or controls.dtype != torch.int64 or
            targets.dtype != torch.int64 or lengths.dtype != torch.int64 or
            rows.ndim != 3 or controls.shape != targets.shape or
            controls.ndim != 2 or controls.shape[0] != rows.shape[0] or
            lengths.shape != (rows.shape[0],)):
        raise ValueError('CUDA packed CNOT shape/device contract')
    batch, n, _ = rows.shape
    ids = torch.arange(batch, device=rows.device)
    result = rows.clone()
    depth = controls.shape[1]
    order = range(depth - 1, -1, -1) if reverse else range(depth)
    for step in order:
        control = controls[:, step]
        target = targets[:, step]
        active = lengths > step
        source = result[ids, control]
        destination = result[ids, target]
        result[ids, target] = torch.where(active[:, None],
                                          destination ^ source, destination)
    return result


def generate_walk_batch(n: int, batch: int, mean_steps: int, seed: int,
                        *, family: str = 'ordinary_walk') -> PackedWalkBatch:
    if n < 2 or n > 256 or batch < 1 or mean_steps < 0 or seed < 0 or \
            family not in ('ordinary_walk', 'poisson_walk'):
        raise ValueError('invalid CUDA walk specification')
    device = 'cuda'
    generator = torch.Generator(device=device)
    generator.manual_seed(seed)
    if family == 'ordinary_walk':
        lengths = torch.full((batch,), mean_steps, dtype=torch.int64, device=device)
        depth = mean_steps
    else:
        rates = torch.full((batch,), float(mean_steps), device=device)
        lengths = torch.poisson(rates, generator=generator).to(torch.int64)
        depth = int(lengths.max().item())  # One batch-size boundary, never per matrix/gate.
    controls = torch.randint(n, (batch, depth), device=device, generator=generator)
    offsets = torch.randint(n - 1, (batch, depth), device=device, generator=generator)
    targets = (controls + offsets + 1) % n
    rows = apply_gates(identity_rows(batch, n, device), controls, targets, lengths)
    return PackedWalkBatch(rows, controls, targets, lengths)


def verify_inverse(batch: PackedWalkBatch) -> torch.Tensor:
    """Device bool for each complete M→I inverse word; caller may reduce once."""
    restored = apply_gates(batch.rows, batch.controls, batch.targets,
                           batch.lengths, reverse=True)
    expected = identity_rows(batch.rows.shape[0], batch.rows.shape[1],
                             str(batch.rows.device))
    return (restored == expected).flatten(1).all(dim=1)
