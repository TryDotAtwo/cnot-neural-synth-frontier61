"""GPU-resident shared-basis synthesis for disjoint source/target shears.

This is a paid-improvement slice of the own basis method. It implements a
finite-width GPU variational action, but not the exact atlas or arbitrary GL(n).
"""
from dataclasses import dataclass

import torch

from .packed_walk import apply_gates, identity_rows
from .shared_action import GpuSharedAction


@dataclass(frozen=True)
class PaidShearBatch:
    controls: torch.Tensor
    targets: torch.Tensor
    lengths: torch.Tensor
    preparation_lengths: torch.Tensor
    core_lengths: torch.Tensor
    prepared_blocks: torch.Tensor
    converged: torch.Tensor
    gradient_selected: torch.Tensor | None = None


def _assemble_paid(current, prep_control, prep_target, prep_length,
                   source_wires, target_wires, converged):
    batch, t_count, s_count = current.shape
    max_preparation = prep_control.shape[1]
    core_mask = current.flatten(1)
    core_rank = core_mask.to(torch.int64).cumsum(dim=1) - 1
    core_length = core_mask.sum(dim=1, dtype=torch.int64)
    gate_capacity = 2 * max_preparation + t_count * s_count
    sentinel = gate_capacity
    controls = torch.zeros((batch, gate_capacity + 1), dtype=torch.int64, device=current.device)
    targets = torch.zeros_like(controls)
    steps = torch.arange(max_preparation, device=current.device)[None, :]
    prep_index = torch.where(steps < prep_length[:, None], steps, sentinel)
    controls.scatter_(1, prep_index, prep_control)
    targets.scatter_(1, prep_index, prep_target)
    flat = torch.arange(t_count * s_count, device=current.device)[None, :]
    core_index = torch.where(core_mask, prep_length[:, None] + core_rank, sentinel)
    controls.scatter_(1, core_index, source_wires[flat % s_count].expand(batch, -1))
    targets.scatter_(1, core_index, target_wires[flat // s_count].expand(batch, -1))
    restore_index = torch.where(steps < prep_length[:, None],
                                prep_length[:, None] + core_length[:, None] +
                                prep_length[:, None] - 1 - steps, sentinel)
    controls.scatter_(1, restore_index, prep_control)
    targets.scatter_(1, restore_index, prep_target)
    lengths = 2 * prep_length + core_length
    return PaidShearBatch(controls[:, :gate_capacity], targets[:, :gate_capacity],
                          lengths, prep_length, core_length, current, converged)


def _deltas(block: torch.Tensor):
    x = block.to(torch.float32)
    column_weight = x.sum(dim=1)
    column_overlap = x.transpose(1, 2) @ x
    source = 2 + column_weight[:, None, :] - 2 * column_overlap
    row_weight = x.sum(dim=2)
    row_overlap = x @ x.transpose(1, 2)
    target = 2 + row_weight[:, :, None] - 2 * row_overlap
    source.diagonal(dim1=1, dim2=2).fill_(1e6)
    target.diagonal(dim1=1, dim2=2).fill_(1e6)
    return source, target


def select_weighted_source_group(block: torch.Tensor, *, width: int) -> torch.Tensor:
    """Pick the heaviest source columns per matrix with low-index tie break."""
    if (block.device.type != 'cuda' or block.ndim != 3 or block.dtype != torch.bool or
            not 2 <= width <= min(8, block.shape[2])):
        raise ValueError('CUDA source group selection contract')
    weight = block.sum(dim=1, dtype=torch.int64)
    return torch.argsort(-weight, dim=1, stable=True)[:, :width]


def compile_paid_shear(block: torch.Tensor, source_wires: torch.Tensor,
                       target_wires: torch.Tensor, *, max_preparation: int) -> PaidShearBatch:
    if (block.device.type != 'cuda' or block.ndim != 3 or block.dtype != torch.bool or
            source_wires.device != block.device or target_wires.device != block.device or
            source_wires.dtype != torch.int64 or target_wires.dtype != torch.int64 or
            source_wires.shape != (block.shape[2],) or
            target_wires.shape != (block.shape[1],) or max_preparation < 0):
        raise ValueError('CUDA paid shear block/wire contract')
    batch, t_count, s_count = block.shape
    wires = torch.cat((source_wires, target_wires))
    if torch.unique(wires).numel() != wires.numel() or bool((wires < 0).any().item()):
        raise ValueError('source and target wires must be distinct nonnegative')
    ids = torch.arange(batch, device=block.device)
    current = block.clone()
    prep_control = torch.zeros((batch, max_preparation), dtype=torch.int64, device=block.device)
    prep_target = torch.zeros_like(prep_control)
    prep_length = torch.zeros((batch,), dtype=torch.int64, device=block.device)
    for step in range(max_preparation):
        source_delta, target_delta = _deltas(current)
        candidates = torch.cat((source_delta.flatten(1), target_delta.flatten(1)), dim=1)
        chosen = candidates.argmin(dim=1)
        active = candidates.gather(1, chosen[:, None]).squeeze(1) < 0
        source_side = chosen < s_count * s_count
        source_choice = chosen.clamp(max=s_count * s_count - 1)
        target_choice = (chosen - s_count * s_count).clamp(min=0)
        sc, st = source_choice // s_count, source_choice % s_count
        tc, tt = target_choice // t_count, target_choice % t_count
        selected_source = source_side & active
        selected_target = (~source_side) & active
        source_row = current[ids, :, st]
        target_row = current[ids, tt, :]
        current[ids, :, sc] = current[ids, :, sc] ^ (source_row & selected_source[:, None])
        current[ids, tt, :] = current[ids, tt, :] ^ (current[ids, tc, :] &
                                                     selected_target[:, None])
        prep_control[:, step] = torch.where(source_side, source_wires[sc], target_wires[tc])
        prep_target[:, step] = torch.where(source_side, source_wires[st], target_wires[tt])
        prep_length += active.to(torch.int64)
    source_delta, target_delta = _deltas(current)
    converged = ((source_delta.flatten(1).min(dim=1).values >= 0) &
                 (target_delta.flatten(1).min(dim=1).values >= 0))
    return _assemble_paid(current, prep_control, prep_target, prep_length,
                          source_wires, target_wires, converged)


def compile_gradient_source_shear(block: torch.Tensor, source_wires: torch.Tensor,
                                  target_wires: torch.Tensor, *, group: torch.Tensor,
                                  gradient_steps: int, learning_rate: float) -> PaidShearBatch:
    """Optimize one source-basis group, round on GPU, and pay every physical gate."""
    if (block.device.type != 'cuda' or block.ndim != 3 or block.dtype != torch.bool or
            source_wires.device != block.device or target_wires.device != block.device or
            group.device != block.device or group.dtype != torch.int64 or group.ndim not in (1, 2) or
            source_wires.shape != (block.shape[2],) or
            target_wires.shape != (block.shape[1],) or
            gradient_steps < 0 or learning_rate <= 0):
        raise ValueError('CUDA wide source-basis contract')
    if group.ndim == 1 and (torch.unique(group).numel() != group.numel() or
                            bool(((group < 0) | (group >= block.shape[2])).any().item())):
        raise ValueError('invalid source-basis group')
    batch, _, _ = block.shape
    if group.ndim == 1:
        group = group[None, :].expand(batch, -1)
    if group.shape[0] != batch or not 2 <= group.shape[1] <= 8:
        raise ValueError('invalid per-matrix source-basis group shape')
    ordered = torch.sort(group, dim=1).values
    if bool(((ordered[:, 1:] == ordered[:, :-1]) |
             ((group < 0) | (group >= block.shape[2])).any(dim=1, keepdim=True)).any().item()):
        raise ValueError('duplicate or out-of-range source-basis group')
    wires = torch.cat((source_wires, target_wires))
    if torch.unique(wires).numel() != wires.numel() or bool((wires < 0).any().item()):
        raise ValueError('physical source/target wires must be distinct')
    width = group.shape[1]
    ops = tuple(('add', control, target) for control in range(width)
                for target in range(width) if control != target)
    vectors = block.gather(2, group[:, None, :].expand(-1, block.shape[1], -1))
    action = GpuSharedAction(vectors, ops, side='source')
    theta = torch.nn.Parameter(torch.full((batch, len(ops)), .1,
                                          dtype=torch.float64, device=block.device))
    optimizer = torch.optim.Adam((theta,), lr=learning_rate)
    for _ in range(gradient_steps):
        optimizer.zero_grad(set_to_none=True)
        action.value(theta).sum().backward()
        optimizer.step()
        with torch.no_grad():
            theta.clamp_(0, 1)
    chosen = action.conditional_round(theta.detach())
    current = block.clone()
    ids = torch.arange(batch, device=block.device)
    raw_control = torch.zeros_like(chosen, dtype=torch.int64)
    raw_target = torch.zeros_like(raw_control)
    for step, (_, control, target) in enumerate(ops):
        changed = chosen[:, step]
        destination = group[:, control]
        source = group[:, target]
        current[ids, :, destination] ^= current[ids, :, source] & changed[:, None]
        raw_control[:, step] = source_wires[destination]
        raw_target[:, step] = source_wires[source]
    ranks = chosen.to(torch.int64).cumsum(dim=1) - 1
    prep_length = chosen.sum(dim=1, dtype=torch.int64)
    sentinel = len(ops)
    packed_control = torch.zeros((batch, sentinel + 1), dtype=torch.int64, device=block.device)
    packed_target = torch.zeros_like(packed_control)
    compact_index = torch.where(chosen, ranks, sentinel)
    packed_control.scatter_(1, compact_index, raw_control)
    packed_target.scatter_(1, compact_index, raw_target)
    actual_cost = 2 * prep_length + current.sum(dim=(1, 2), dtype=torch.int64)
    direct_cost = block.sum(dim=(1, 2), dtype=torch.int64)
    improved = actual_cost < direct_cost
    current = torch.where(improved[:, None, None], current, block)
    prep_length = torch.where(improved, prep_length, 0)
    source_delta, target_delta = _deltas(current)
    converged = ((source_delta.flatten(1).min(dim=1).values >= 0) &
                 (target_delta.flatten(1).min(dim=1).values >= 0))
    return _assemble_paid(current, packed_control[:, :sentinel],
                          packed_target[:, :sentinel], prep_length,
                          source_wires, target_wires, converged)


def compile_paid_shear_portfolio(block: torch.Tensor, source_wires: torch.Tensor,
                                 target_wires: torch.Tensor, *, max_preparation: int,
                                 gradient_group: torch.Tensor, gradient_steps: int,
                                 learning_rate: float) -> PaidShearBatch:
    """Select the shorter of two fully paid device words; deterministic ties use greedy."""
    greedy = compile_paid_shear(block, source_wires, target_wires,
                                max_preparation=max_preparation)
    gradient = compile_gradient_source_shear(
        block, source_wires, target_wires, group=gradient_group,
        gradient_steps=gradient_steps, learning_rate=learning_rate)
    choose_gradient = gradient.lengths < greedy.lengths
    capacity = max(greedy.controls.shape[1], gradient.controls.shape[1])
    def padded(value):
        return torch.nn.functional.pad(value, (0, capacity - value.shape[1]))
    return PaidShearBatch(
        torch.where(choose_gradient[:, None], padded(gradient.controls),
                    padded(greedy.controls)),
        torch.where(choose_gradient[:, None], padded(gradient.targets),
                    padded(greedy.targets)),
        torch.minimum(greedy.lengths, gradient.lengths),
        torch.where(choose_gradient, gradient.preparation_lengths,
                    greedy.preparation_lengths),
        torch.where(choose_gradient, gradient.core_lengths, greedy.core_lengths),
        torch.where(choose_gradient[:, None, None], gradient.prepared_blocks,
                    greedy.prepared_blocks),
        torch.where(choose_gradient, gradient.converged, greedy.converged),
        choose_gradient)


def verify_paid_shear(block: torch.Tensor, source_wires: torch.Tensor,
                      target_wires: torch.Tensor, word: PaidShearBatch,
                      *, n: int) -> torch.Tensor:
    """Replay every physical gate on GPU against the full target matrix."""
    batch = block.shape[0]
    expected = identity_rows(batch, n, str(block.device))
    if bool((torch.cat((source_wires, target_wires)) >= n).any().item()):
        raise ValueError('physical wire exceeds full matrix width')
    source_word = source_wires // 64
    source_bit = torch.ones_like(source_wires) << (source_wires % 64)
    contributions = block.to(torch.int64) * source_bit[None, None, :]
    for word_index in range((n + 63) // 64):
        bits = (contributions * (source_word == word_index)[None, None, :]).sum(dim=2)
        expected[:, target_wires, word_index] ^= bits
    actual = apply_gates(identity_rows(batch, n, str(block.device)),
                         word.controls, word.targets, word.lengths)
    return (actual == expected).flatten(1).all(dim=1)
