"""Exact finite-width paid-basis action and autograd on CUDA.

The state space is 2**width local parity codes, never the full GL(n) graph.
This ports the stage-17 local objective without invoking CPU optimizers.
"""
import torch


class GpuSharedAction:
    def __init__(self, vectors: torch.Tensor, ops: tuple, *, side: str):
        if (vectors.device.type != 'cuda' or vectors.ndim != 3 or vectors.dtype != torch.bool or
                side not in ('source', 'target') or not 1 <= vectors.shape[2] <= 8):
            raise ValueError('CUDA local basis action contract')
        self.batch, _, self.width = vectors.shape
        self.ops = tuple(ops)
        codes = (vectors.to(torch.int64) *
                 (torch.ones(self.width, dtype=torch.int64, device=vectors.device) <<
                  torch.arange(self.width, device=vectors.device))).sum(dim=2)
        size = 1 << self.width
        self.initial = torch.zeros((self.batch, size), dtype=torch.float64,
                                   device=vectors.device)
        self.initial.scatter_add_(1, codes,
                                  torch.ones_like(codes, dtype=torch.float64))
        ids = torch.arange(size, dtype=torch.int64, device=vectors.device)
        self.population = torch.stack([((ids >> i) & 1) for i in range(self.width)],
                                      dim=0).sum(dim=0).to(torch.float64)
        permutations, prices = [], []
        for kind, control, target in self.ops:
            if control == target or min(control, target) < 0 or \
                    max(control, target) >= self.width:
                raise ValueError('invalid local physical operation')
            if kind == 'add':
                index = target if side == 'source' else control
                flip = control if side == 'source' else target
                perm = ids ^ (((ids >> index) & 1) << flip)
                price = 2
            elif kind == 'swap':
                bit = ((ids >> control) ^ (ids >> target)) & 1
                perm = ids ^ (bit << control) ^ (bit << target)
                price = 6
            else:
                raise ValueError('invalid local operation type')
            permutations.append(perm)
            prices.append(price)
        self.permutations = tuple(permutations)
        self.prices = torch.tensor(prices, dtype=torch.float64, device=vectors.device)

    def value(self, theta: torch.Tensor) -> torch.Tensor:
        if theta.device != self.initial.device or theta.shape != (self.batch, len(self.ops)):
            raise ValueError('local action theta shape/device mismatch')
        x = self.initial
        for step, permutation in enumerate(self.permutations):
            probability = theta[:, step, None]
            x = (1 - probability) * x + probability * x[:, permutation]
        return (x * self.population[None, :]).sum(dim=1) + \
            (theta * self.prices[None, :]).sum(dim=1)

    def conditional_round(self, theta: torch.Tensor) -> torch.Tensor:
        if theta.shape != (self.batch, len(self.ops)):
            raise ValueError('local action theta shape mismatch')
        back = [None] * (len(self.ops) + 1)
        back[-1] = self.population[None, :].expand(self.batch, -1)
        for step in range(len(self.ops) - 1, -1, -1):
            prior = back[step + 1]
            probability = theta[:, step, None]
            back[step] = ((1 - probability) * prior +
                          probability * prior[:, self.permutations[step]])
        x = self.initial
        choices = []
        for step, permutation in enumerate(self.permutations):
            delta = (self.prices[step] +
                     (back[step + 1] * (x[:, permutation] - x)).sum(dim=1))
            chosen = delta < 0
            choices.append(chosen)
            x = torch.where(chosen[:, None], x[:, permutation], x)
        return torch.stack(choices, dim=1)
