"""CUDA batch implementation of the selected A-family structural features."""
import torch


SELECTED_A = ('A01', 'A04', 'A05', 'A07', 'A08', 'A15', 'A16', 'A20')
ALL_A = tuple(f'A{index:02d}' for index in range(1, 21))


def dense_bits(rows: torch.Tensor) -> torch.Tensor:
    if rows.device.type != 'cuda' or rows.ndim != 3 or rows.dtype != torch.int64:
        raise ValueError('packed CUDA rows required')
    _, n, words = rows.shape
    if words != (n + 63) // 64:
        raise ValueError('packed word count mismatch')
    columns = torch.arange(n, device=rows.device, dtype=torch.int64)
    return ((rows[:, :, columns // 64] >> (columns % 64)) & 1).to(torch.float32)


def all_a_features(rows: torch.Tensor) -> dict[str, torch.Tensor]:
    matrix = dense_bits(rows)
    batch, n, _ = matrix.shape
    eye = torch.eye(n, device=rows.device, dtype=torch.float32)[None, :, :]
    residual = torch.abs(matrix - eye)
    row_weight = matrix.sum(dim=2)
    column_weight = matrix.sum(dim=1)
    residual_row = residual.sum(dim=2)
    residual_column = residual.sum(dim=1)
    row_intersection = matrix @ matrix.transpose(1, 2)
    column_intersection = matrix.transpose(1, 2) @ matrix
    residual_intersection = residual @ matrix.transpose(1, 2)
    rowdiff = row_weight[:, :, None] - row_intersection
    coldiff = column_weight[:, :, None] - column_intersection
    delta = torch.stack((row_weight[:, :, None] - 2 * row_intersection,
                         row_weight[:, :, None] - 2 * residual_intersection.transpose(1, 2)), dim=-1)
    index = torch.arange(n, device=rows.device)
    delta[:, index, index, :] = 0
    return {
        'A01': matrix[..., None],
        'A02': matrix.transpose(1, 2)[..., None],
        'A03': torch.stack((eye.expand(batch, -1, -1),
                            torch.ones_like(matrix)), dim=-1),
        'A04': residual[..., None],
        'A05': torch.stack((row_weight, row_weight / n), dim=-1),
        'A06': column_weight[..., None],
        'A07': residual_row[..., None],
        'A08': residual_column[..., None],
        'A09': (residual_row > 0).to(torch.float32)[..., None],
        'A10': (residual_column > 0).to(torch.float32)[..., None],
        'A11': (1 - matrix[:, index, index])[..., None],
        'A12': torch.stack((row_weight.remainder(2),
                            column_weight.remainder(2)), dim=-1),
        'A13': row_intersection[..., None],
        'A14': column_intersection[..., None],
        'A15': (row_weight[:, :, None] + row_weight[:, None, :] -
                2 * row_intersection)[..., None],
        'A16': (column_weight[:, :, None] + column_weight[:, None, :] -
                2 * column_intersection)[..., None],
        'A17': torch.stack((rowdiff, rowdiff.transpose(1, 2)), dim=-1),
        'A18': torch.stack((coldiff, coldiff.transpose(1, 2)), dim=-1),
        'A19': torch.stack(((rowdiff == 0).to(torch.float32),
                            (coldiff == 0).to(torch.float32)), dim=-1),
        'A20': delta,
    }


def selected_a_features(rows: torch.Tensor) -> dict[str, torch.Tensor]:
    full = all_a_features(rows)
    return {key: full[key] for key in SELECTED_A}
