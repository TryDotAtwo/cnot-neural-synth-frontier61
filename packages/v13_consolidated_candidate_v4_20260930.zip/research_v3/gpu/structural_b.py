"""CUDA implementation of structural B/F features used by the 100M field."""

import torch

from .structural_a import dense_bits


SELECTED_BF = ('B01', 'B03', 'B06', 'B07', 'F01')


def _reachability(adjacency: torch.Tensor) -> torch.Tensor:
    batch, n, _ = adjacency.shape
    reach = adjacency | torch.eye(n, device=adjacency.device,
                                  dtype=torch.bool)[None]
    # Exact Boolean Warshall recurrence. The loop dispatches fixed dimensions;
    # every state update and reduction remains on CUDA.
    for pivot in range(n):
        reach = reach | (reach[:, :, pivot, None] & reach[:, None, pivot, :])
    return reach


def selected_bf_features(rows: torch.Tensor) -> dict[str, torch.Tensor]:
    matrix = dense_bits(rows)
    batch, n, _ = matrix.shape
    index = torch.arange(n, device=rows.device)
    adjacency = matrix.bool()
    adjacency[:, index, index] = False
    undirected = adjacency | adjacency.transpose(1, 2)
    undirected_reach = _reachability(undirected)
    # Every component has exactly one least-index representative.
    representatives = (undirected_reach &
                       (index[None, :, None] >= index[None, None, :])).sum(dim=2) == 1
    component_count = representatives.sum(dim=1).to(torch.float32)
    reach = _reachability(adjacency)
    scc_size = (reach & reach.transpose(1, 2)).sum(dim=2).to(torch.float32)
    adjacency_float = adjacency.to(torch.float32)
    paths = adjacency_float @ adjacency_float
    eye = torch.eye(n, device=rows.device, dtype=torch.float32)[None]
    residual = torch.abs(matrix - eye)
    changed_rows = (residual.sum(dim=2) > 0).sum(dim=1)
    changed_columns = (residual.sum(dim=1) > 0).sum(dim=1)
    return {
        'B01': component_count[:, None],
        'B03': scc_size[..., None],
        'B06': paths[..., None],
        'B07': paths.remainder(2)[..., None],
        'F01': torch.stack((changed_rows, changed_columns), dim=-1).to(torch.float32),
    }
