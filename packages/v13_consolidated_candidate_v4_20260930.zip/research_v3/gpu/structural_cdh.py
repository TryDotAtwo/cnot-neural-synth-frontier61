"""Exact CUDA GF(2) rank, inverse and selected C/D/H feature views."""

import torch

from .structural_a import dense_bits


SELECTED_CDH = ('C01', 'D03', 'H01', 'H02', 'H03', 'H04')


def gf2_rank_dense(matrix: torch.Tensor) -> torch.Tensor:
    if matrix.device.type != 'cuda' or matrix.ndim != 3 or matrix.shape[1] != matrix.shape[2]:
        raise ValueError('square CUDA matrix required')
    values = matrix.bool().clone()
    batch, n, _ = values.shape
    ids = torch.arange(batch, device=matrix.device)
    row_ids = torch.arange(n, device=matrix.device)[None, :]
    rank = torch.zeros(batch, dtype=torch.int64, device=matrix.device)
    for column in range(n):
        eligible = values[:, :, column] & (row_ids >= rank[:, None])
        found = eligible.any(dim=1)
        pivot = eligible.to(torch.int64).argmax(dim=1)
        destination = rank.clamp(max=n - 1)
        pivot_row = values[ids, pivot].clone()
        destination_row = values[ids, destination].clone()
        values[ids, destination] = torch.where(found[:, None], pivot_row,
                                               destination_row)
        values[ids, pivot] = torch.where(found[:, None], destination_row,
                                         pivot_row)
        active_row = values[ids, destination].clone()
        elimination = found[:, None] & values[:, :, column] & (row_ids != destination[:, None])
        values = values ^ (elimination[:, :, None] & active_row[:, None, :])
        rank = rank + found.to(torch.int64)
    return rank


def gf2_inverse_dense(matrix: torch.Tensor) -> torch.Tensor:
    if matrix.device.type != 'cuda' or matrix.ndim != 3 or matrix.shape[1] != matrix.shape[2]:
        raise ValueError('square CUDA matrix required')
    values = matrix.bool()
    batch, n, _ = values.shape
    eye = torch.eye(n, dtype=torch.bool, device=matrix.device)[None].expand(batch, -1, -1)
    augmented = torch.cat((values, eye), dim=2)
    ids = torch.arange(batch, device=matrix.device)
    row_ids = torch.arange(n, device=matrix.device)[None, :]
    for column in range(n):
        eligible = augmented[:, :, column] & (row_ids >= column)
        found = eligible.any(dim=1)
        pivot = eligible.to(torch.int64).argmax(dim=1)
        pivot_row = augmented[ids, pivot].clone()
        destination_row = augmented[ids, column].clone()
        augmented[ids, column] = torch.where(found[:, None], pivot_row,
                                             destination_row)
        augmented[ids, pivot] = torch.where(found[:, None], destination_row,
                                            pivot_row)
        active_row = augmented[ids, column].clone()
        elimination = found[:, None] & augmented[:, :, column] & (row_ids != column)
        augmented = augmented ^ (elimination[:, :, None] & active_row[:, None, :])
    if not bool((augmented[:, :, :n] == eye).all().item()):
        raise ValueError('singular GF(2) matrix')
    return augmented[:, :, n:]


def selected_cdh_features(rows: torch.Tensor) -> dict[str, torch.Tensor]:
    matrix = dense_bits(rows)
    batch, n, _ = matrix.shape
    eye = torch.eye(n, device=rows.device, dtype=torch.float32)[None]
    residual = (matrix - eye).abs()
    rank = gf2_rank_dense(residual)
    row_weights = matrix.sum(dim=2)
    shared = matrix @ matrix.transpose(1, 2)
    inverse = gf2_inverse_dense(matrix).to(torch.float32)
    return {
        'C01': rank.to(torch.float32)[:, None],
        'D03': torch.stack((row_weights[:, :, None] - shared,
                            row_weights[:, None, :] - shared, shared), dim=-1),
        'H01': matrix[..., None],
        'H02': matrix.transpose(1, 2)[..., None],
        'H03': inverse[..., None],
        'H04': inverse.transpose(1, 2)[..., None],
    }
