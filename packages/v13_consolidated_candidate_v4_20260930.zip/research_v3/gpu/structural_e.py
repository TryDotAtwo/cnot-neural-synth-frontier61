"""CUDA raw E01/E04/E05 descriptors of the deterministic partial shear."""

from dataclasses import dataclass

import torch

from .structural_a import dense_bits
from .structural_cdh import gf2_inverse_dense


SELECTED_E = ('E01', 'E04', 'E05')


@dataclass(frozen=True)
class PartialShearFeatures:
    features: dict[str, torch.Tensor]
    available: torch.Tensor
    pivots: torch.Tensor
    block: torch.Tensor


def selected_e_features(rows: torch.Tensor) -> PartialShearFeatures:
    matrix = dense_bits(rows).bool()
    batch, n, _ = matrix.shape
    width = n // 2
    pair = torch.zeros((batch, n, n, 2), device=rows.device, dtype=torch.float32)
    empty = PartialShearFeatures({
        'E01': torch.zeros((batch, 1), device=rows.device),
        'E04': pair,
        'E05': torch.zeros((batch, 4), device=rows.device),
    }, torch.zeros(batch, device=rows.device, dtype=torch.bool),
        torch.empty((batch, 0), device=rows.device, dtype=torch.int64),
        torch.zeros((batch, n - width, width), device=rows.device, dtype=torch.bool))
    if width < 2:
        return empty
    echelon = matrix[:, :width, :].clone()
    ids = torch.arange(batch, device=rows.device)
    row_ids = torch.arange(width, device=rows.device)[None, :]
    rank = torch.zeros(batch, device=rows.device, dtype=torch.int64)
    pivots = torch.zeros((batch, width), device=rows.device, dtype=torch.int64)
    for column in range(n):
        eligible = echelon[:, :, column] & (row_ids >= rank[:, None])
        found = eligible.any(dim=1)
        pivot = eligible.to(torch.int64).argmax(dim=1)
        destination = rank.clamp(max=width - 1)
        pivot_row = echelon[ids, pivot].clone()
        destination_row = echelon[ids, destination].clone()
        echelon[ids, destination] = torch.where(found[:, None], pivot_row,
                                                destination_row)
        echelon[ids, pivot] = torch.where(found[:, None], destination_row,
                                          pivot_row)
        active_row = echelon[ids, destination].clone()
        eliminate = found[:, None] & echelon[:, :, column] & \
                    (row_ids > destination[:, None])
        echelon = echelon ^ (eliminate[:, :, None] & active_row[:, None, :])
        pivots[ids, destination] = torch.where(found, column,
                                               pivots[ids, destination])
        rank = rank + found.to(torch.int64)
    if not bool((rank == width).all().item()):
        raise ValueError('dependent first-half rows in invertible full matrix')
    selected_columns = pivots[:, None, :]
    source_minor = torch.gather(matrix[:, :width, :], 2,
                                selected_columns.expand(-1, width, -1))
    target_minor = torch.gather(matrix[:, width:, :], 2,
                                selected_columns.expand(-1, n - width, -1))
    inverse = gf2_inverse_dense(source_minor)
    block = (torch.bmm(target_minor.to(torch.float32),
                       inverse.to(torch.float32)).remainder(2)).to(torch.float32)
    available = block.sum(dim=(1, 2)) > 0
    weight = block.sum(dim=1)
    overlap = block.transpose(1, 2) @ block
    gradient = 2 + weight[:, None, :] - 2 * overlap
    valid_pairs = ~torch.eye(width, device=rows.device, dtype=torch.bool)
    values = gradient[:, valid_pairs]
    pair[:, :width, :width, 0] = gradient * valid_pairs[None]
    pair[:, :width, :width, 1] = valid_pairs.to(torch.float32)[None]
    stats = torch.stack((values.min(dim=1).values,
                         values.to(torch.float64).mean(dim=1).to(torch.float32),
                         values.max(dim=1).values,
                         (values < 0).to(torch.float64).mean(dim=1).to(torch.float32)), dim=1)
    outputs = {'E01': block.sum(dim=(1, 2))[:, None], 'E04': pair, 'E05': stats}
    outputs = {key: value * available.reshape(batch, *([1] * (value.ndim - 1)))
               for key, value in outputs.items()}
    return PartialShearFeatures(outputs, available, pivots, block.bool())
