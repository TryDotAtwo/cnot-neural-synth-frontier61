"""Fast verified-edge pretraining of the full-matrix neural value field.

Every sampled edge lies on a fully replayed own CNOT word. Interval labels are
honest lower/upper bounds, never assumed exact distances. This route visits
many graph states cheaply; periodic complete-neighbor Bellman updates remain
a separate required quality/control arm.
"""

from dataclasses import dataclass

import torch
from torch.nn import functional as F

from .basis_proposer import batched_basis_proposal, sample_ordered_source_pairs
from .field_slice import gpu_field_inputs, gpu_field_value
from .holdout import GpuExactHoldout, admit_complete_neighborhood
from .joint_basis_slice import differentiable_gpu_batched_mc_cost
from .packed_walk import PackedWalkBatch, apply_gates, identity_rows
from .structural_e import selected_e_features
from .verified_supervision import (GpuVerifiedInterval,
                                   interval_from_verified_walk,
                                   interval_hinge_loss,
                                   verified_walk_teacher_loss)


@dataclass(frozen=True)
class GpuVerifiedGraphEdges:
    parent_word: PackedWalkBatch
    child_word: PackedWalkBatch
    parent_labels: GpuVerifiedInterval
    child_labels: GpuVerifiedInterval
    controls: torch.Tensor
    targets: torch.Tensor
    sampled_prefixes: torch.Tensor


def sample_verified_graph_edges(walk: PackedWalkBatch, *,
                                generator: torch.Generator,
                                samples_per_root: int) -> GpuVerifiedGraphEdges:
    if (walk.rows.device.type != 'cuda' or generator.device.type != 'cuda' or
            samples_per_root < 1 or walk.rows.shape[0] < 1 or
            bool((walk.lengths < 1).any().item())):
        raise ValueError('nonempty verified own CUDA word batch required')
    # Reject malformed source words before sampling any suffix state.
    interval_from_verified_walk(walk)
    batch, n, _ = walk.rows.shape
    random_prefixes = 1 + torch.floor(
        torch.rand((batch, samples_per_root - 1), device=walk.rows.device,
                   generator=generator) * walk.lengths[:, None]
    ).to(torch.int64)
    prefixes = torch.cat((walk.lengths[:, None], random_prefixes), dim=1)
    count = batch * samples_per_root
    controls = walk.controls[:, None, :].expand(-1, samples_per_root, -1).reshape(
        count, -1)
    targets = walk.targets[:, None, :].expand(-1, samples_per_root, -1).reshape(
        count, -1)
    lengths = prefixes.reshape(-1)
    parent = apply_gates(identity_rows(count, n, str(walk.rows.device)),
                         controls, targets, lengths)
    parent_word = PackedWalkBatch(parent, controls, targets, lengths)
    parent_labels = interval_from_verified_walk(parent_word)
    ids = torch.arange(count, device=walk.rows.device)
    reduction_control = controls[ids, lengths - 1]
    reduction_target = targets[ids, lengths - 1]
    child = parent.clone()
    child[ids, reduction_target] ^= parent[ids, reduction_control]
    child_word = PackedWalkBatch(child, controls, targets, lengths - 1)
    child_labels = interval_from_verified_walk(child_word)
    return GpuVerifiedGraphEdges(parent_word, child_word, parent_labels,
                                 child_labels, reduction_control,
                                 reduction_target, prefixes)


def verified_trajectory_joint_loss(model, walk: PackedWalkBatch, *,
                                   generator: torch.Generator,
                                   samples_per_root: int,
                                   holdout: GpuExactHoldout | None,
                                   admission_chunk: int,
                                   mc_samples: int,
                                   mc_seed: int,
                                   max_pair_states: int,
                                   teacher_weight: float = 0.1,
                                   qhat_weight: float = 0.1,
                                   edge_weight: float = 0.1,
                                   basis_weight: float = 0.1,
                                   basis_choices: int = 2,
                                   basis_samples: int = 2,
                                   basis_max_evaluations: int = 5000,
                                   basis_max_bytes: int = 268435456):
    """Differentiate V, Qhat and paid-basis proposer along certified edges.

    The edge term enforces the true one-CNOT Lipschitz inequality. It does not
    assert equality along a possibly nonoptimal certificate word.
    """
    if (admission_chunk < 1 or min(teacher_weight, qhat_weight, edge_weight,
                                   basis_weight) < 0):
        raise ValueError('nonnegative trajectory weights and positive admission chunk required')
    edges = sample_verified_graph_edges(
        walk, generator=generator, samples_per_root=samples_per_root)
    parents = edges.parent_word.rows
    children = edges.child_word.rows
    admitted = admit_complete_neighborhood(
        holdout, parents, chunk_size=admission_chunk) if holdout is not None else 0
    field = model.field
    batch, packet = gpu_field_inputs(
        parents, mc_samples=mc_samples, mc_seed=mc_seed,
        column_heat='G01' in field.stem.specs,
        pair_heat='G06' in field.stem.specs,
        max_pair_states=max_pair_states)
    encoded = field.stem(batch, packet)
    parent_value = field.value(encoded)
    child_value = gpu_field_value(
        field, children, mc_samples=mc_samples, mc_seed=mc_seed,
        max_pair_states=max_pair_states)
    parent_interval = interval_hinge_loss(parent_value, parents,
                                          edges.parent_labels)
    child_interval = interval_hinge_loss(child_value, children,
                                         edges.child_labels)
    edge_loss = torch.relu(torch.abs(parent_value - child_value) - 1).square().mean()
    proposal, qhat, allowed = field.auxiliary(
        encoded.wire, encoded.pair, parent_value, encoded.valid)
    ids = torch.arange(len(parents), device=parents.device)
    if not bool(allowed[ids, edges.controls, edges.targets].all().item()):
        raise AssertionError('verified reduction gate absent from full CNOT head')
    teacher_loss = verified_walk_teacher_loss(
        proposal, edges.parent_word, edges.parent_labels)
    selected_q = qhat[ids, edges.controls, edges.targets]
    qhat_loss = F.smooth_l1_loss(selected_q, 1 + child_value.detach())
    basis_loss = parent_value.sum() * 0
    basis_status = 'unavailable'
    if basis_weight and parents.shape[1] // 2 >= 2:
        partial = selected_e_features(parents)
        active = torch.nonzero(partial.available).flatten()
        if active.numel():
            width = parents.shape[1] // 2
            pairs = sample_ordered_source_pairs(
                len(parents), width, basis_choices,
                generator=generator, device=parents.device)
            theta = batched_basis_proposal(model.proposer, encoded, pairs,
                                           source_width=width)
            basis_loss, _basis_audit = differentiable_gpu_batched_mc_cost(
                partial.block[active], theta[active], pairs[active],
                samples=basis_samples, generator=generator,
                available=torch.ones(len(active), device=parents.device,
                                     dtype=torch.bool),
                max_evaluations=basis_max_evaluations,
                max_bytes=basis_max_bytes)
            basis_status = 'evaluated'
    loss = (parent_interval + child_interval + edge_weight * edge_loss +
            teacher_weight * teacher_loss + qhat_weight * qhat_loss +
            basis_weight * basis_loss)
    if not bool(torch.isfinite(loss).item()):
        raise ValueError('nonfinite verified trajectory loss')
    return loss, {'sampled_edges': len(parents),
                  'admitted_parent_and_neighbors': admitted,
                  'interval_parent': parent_interval.detach(),
                  'interval_child': child_interval.detach(),
                  'edge_lipschitz': edge_loss.detach(),
                  'teacher': teacher_loss.detach(),
                  'qhat': qhat_loss.detach(),
                  'basis': basis_loss.detach(),
                  'basis_status': basis_status,
                  'parent_lower': edges.parent_labels.lower.detach(),
                  'parent_upper': edges.parent_labels.upper.detach(),
                  'sampled_prefixes': edges.sampled_prefixes.detach()}
