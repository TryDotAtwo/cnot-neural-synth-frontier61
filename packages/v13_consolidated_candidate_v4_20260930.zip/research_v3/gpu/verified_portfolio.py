"""Full-matrix GPU certificate replay and shortest verified program selection."""
from dataclasses import dataclass

import torch

from .packed_walk import apply_gates, identity_rows


@dataclass(frozen=True)
class GpuProgramCandidate:
    controls: torch.Tensor
    targets: torch.Tensor
    lengths: torch.Tensor
    source: str


@dataclass(frozen=True)
class VerifiedGpuPortfolio:
    controls: torch.Tensor
    targets: torch.Tensor
    lengths: torch.Tensor
    source_index: torch.Tensor
    candidate_lengths: torch.Tensor
    sources: tuple[str, ...]


def choose_shortest_verified(matrix: torch.Tensor,
                             candidates: tuple[GpuProgramCandidate, ...]) -> VerifiedGpuPortfolio:
    if matrix.device.type != 'cuda' or matrix.ndim != 3 or matrix.shape[0] != 1 or not candidates:
        raise ValueError('one-root CUDA program portfolio contract')
    n = matrix.shape[1]
    lengths = []
    controls = []
    targets = []
    sources = []
    for candidate in candidates:
        if (candidate.controls.device != matrix.device or candidate.targets.device != matrix.device or
                candidate.lengths.device != matrix.device or
                candidate.controls.shape != candidate.targets.shape or
                candidate.controls.ndim != 2 or candidate.controls.shape[0] != 1 or
                candidate.lengths.shape != (1,) or candidate.controls.dtype != torch.int64 or
                candidate.targets.dtype != torch.int64 or candidate.lengths.dtype != torch.int64 or
                not candidate.source):
            raise ValueError('invalid CUDA program candidate')
        used = int(candidate.lengths[0].item())
        if used < 0 or used > candidate.controls.shape[1]:
            raise ValueError('invalid GPU program length')
        control = candidate.controls[:, :used]
        target = candidate.targets[:, :used]
        if bool(((control == target) | (control < 0) | (target < 0) |
                 (control >= n) | (target >= n)).any().item()):
            raise ValueError('invalid active CNOT gate')
        replay = apply_gates(identity_rows(1, n, str(matrix.device)), control, target,
                             candidate.lengths)
        if not torch.equal(replay, matrix):
            raise ValueError('candidate word does not encode the full matrix')
        lengths.append(candidate.lengths[0])
        controls.append(control[0])
        targets.append(target[0])
        sources.append(candidate.source)
    length_tensor = torch.stack(lengths)
    selected = length_tensor.argmin()
    capacity = max(item.numel() for item in controls)
    padded_controls = torch.stack([torch.nn.functional.pad(item, (0, capacity - item.numel()))
                                   for item in controls])
    padded_targets = torch.stack([torch.nn.functional.pad(item, (0, capacity - item.numel()))
                                  for item in targets])
    return VerifiedGpuPortfolio(padded_controls[selected][None, :],
                                padded_targets[selected][None, :],
                                length_tensor[selected][None], selected,
                                length_tensor, tuple(sources))
