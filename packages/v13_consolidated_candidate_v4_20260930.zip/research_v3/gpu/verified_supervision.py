"""GPU interval labels derived only from a fully replayed own CNOT word.

The generated word supplies an upper bound, never an exact distance. The
elementary lower bound has the all-to-all unit-cost scope of ``cheap_bounds``.
"""
from dataclasses import dataclass

import torch
from torch.nn import functional as F

from .packed_walk import PackedWalkBatch, verify_inverse
from .structural_a import dense_bits
from .structural_cdh import gf2_rank_dense


@dataclass(frozen=True)
class GpuVerifiedInterval:
    rows: torch.Tensor
    lower: torch.Tensor
    upper: torch.Tensor
    lower_components: torch.Tensor  # changed rows, changed columns, rank
    provenance: str


def interval_from_verified_walk(walk: PackedWalkBatch) -> GpuVerifiedInterval:
    """Verify a full reduction word and emit L<=d(M)<=U on CUDA."""
    rows, controls, targets, lengths = (walk.rows, walk.controls,
                                         walk.targets, walk.lengths)
    if (rows.device.type != 'cuda' or rows.ndim != 3 or rows.dtype != torch.int64 or
            controls.device != rows.device or targets.device != rows.device or
            lengths.device != rows.device or controls.dtype != torch.int64 or
            targets.dtype != torch.int64 or lengths.dtype != torch.int64 or
            controls.shape != targets.shape or controls.ndim != 2 or
            controls.shape[0] != rows.shape[0] or lengths.shape != (rows.shape[0],)):
        raise ValueError('packed CUDA walk and word required')
    n = rows.shape[1]
    if (n < 2 or rows.shape[2] != (n + 63) // 64 or
            bool(((lengths < 0) | (lengths > controls.shape[1])).any().item())):
        raise ValueError('invalid word length or packed width')
    active = torch.arange(controls.shape[1], device=rows.device)[None] < lengths[:, None]
    invalid = ((controls == targets) & active) | (controls < 0) | (targets < 0) | \
              (controls >= n) | (targets >= n)
    if bool(invalid.any().item()):
        raise ValueError('invalid active CNOT gate')
    if not bool(verify_inverse(walk).all().item()):
        raise ValueError('full-matrix word replay failed')
    matrix = dense_bits(rows).bool()
    residual = matrix ^ torch.eye(n, dtype=torch.bool, device=rows.device)[None]
    changed_rows = residual.any(dim=2).sum(dim=1, dtype=torch.int64)
    changed_columns = residual.any(dim=1).sum(dim=1, dtype=torch.int64)
    rank = gf2_rank_dense(residual)
    components = torch.stack((changed_rows, changed_columns, rank), dim=1)
    lower = components.max(dim=1).values
    if bool((lower > lengths).any().item()):
        raise ValueError('verified word contradicts elementary lower bound')
    return GpuVerifiedInterval(rows.clone(), lower, lengths.clone(), components,
                               'full_gpu_inverse_replay; elementary_unit_cnot_lower')


def interval_hinge_loss(values: torch.Tensor, rows: torch.Tensor,
                        labels: GpuVerifiedInterval) -> torch.Tensor:
    if (values.device.type != 'cuda' or values.ndim != 1 or
            rows.device != values.device or labels.rows.device != values.device or
            rows.shape != labels.rows.shape or not torch.equal(rows, labels.rows) or
            labels.lower.device != values.device or
            labels.upper.device != values.device or
            labels.lower.shape != values.shape or labels.upper.shape != values.shape or
            labels.provenance != 'full_gpu_inverse_replay; elementary_unit_cnot_lower'):
        raise ValueError('verified CUDA interval labels required')
    lower = labels.lower.to(values.dtype)
    upper = labels.upper.to(values.dtype)
    return (torch.relu(lower - values).square() +
            torch.relu(values - upper).square()).mean()


def verified_walk_teacher_loss(proposal: torch.Tensor,
                               walk: PackedWalkBatch,
                               labels: GpuVerifiedInterval | None = None) -> torch.Tensor:
    """Imitate the first inverse gate of each fully verified generation word.

    This is a portfolio imitation label, not an exact-distance target. Padded
    and diagonal actions are excluded from the softmax normalization.
    """
    if labels is None:
        labels = interval_from_verified_walk(walk)
    elif (labels.provenance != 'full_gpu_inverse_replay; elementary_unit_cnot_lower' or
          labels.rows.shape != walk.rows.shape or
          not torch.equal(labels.rows, walk.rows) or
          not torch.equal(labels.upper, walk.lengths)):
        raise ValueError('verified teacher labels do not match the walk')
    batch, n, n2 = proposal.shape
    if (n != n2 or batch != walk.rows.shape[0] or
            proposal.device != walk.rows.device):
        raise ValueError('verified teacher words and square logits required')
    active = walk.lengths > 0
    if not bool(active.any().item()):
        return proposal[torch.isfinite(proposal)].sum() * 0
    valid = ~torch.eye(n, dtype=torch.bool, device=proposal.device)[None]
    logits = proposal.masked_fill(~valid, -torch.inf).reshape(batch, n * n)[active]
    indices = torch.arange(batch, device=proposal.device)[active]
    last = walk.lengths[active] - 1
    control = walk.controls[indices, last]
    target = walk.targets[indices, last]
    return F.cross_entropy(logits, control * n + target)
