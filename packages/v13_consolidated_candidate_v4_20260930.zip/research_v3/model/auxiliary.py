import torch
from torch import nn
from ..objectives.auxiliary import AuxRouting


class AuxiliaryHeads(nn.Module):
    def __init__(self, d, pair_d, hidden=128, routing=AuxRouting()):
        super().__init__()
        if routing.value_input not in ('detached', 'shared') or routing.encoder not in ('detached', 'shared'):
            raise ValueError('unsupported auxiliary gradient routing')
        self.routing = routing
        self.proposal = nn.Sequential(nn.Linear(2 * d + 2 * pair_d + 1, hidden), nn.GELU(), nn.Linear(hidden, 1))
        self.qhat = nn.Sequential(nn.Linear(2 * d + 2 * pair_d + 1, hidden), nn.GELU(), nn.Linear(hidden, 1))

    def forward(self, wire, pair, value, valid, action_mask=None):
        b, n, _ = wire.shape
        if self.routing.encoder == 'detached':
            wire, pair = wire.detach(), pair.detach()
        if self.routing.value_input == 'detached':
            value = value.detach()
        control = wire[:, :, None].expand(-1, -1, n, -1)
        target = wire[:, None, :].expand(-1, n, -1, -1)
        inputs = torch.cat((control, target, pair, pair.transpose(1, 2), value[:, None, None, None].expand(b, n, n, 1)), -1)
        allowed = valid[:, :, None] & valid[:, None, :] & ~torch.eye(n, dtype=torch.bool, device=valid.device)[None]
        if action_mask is not None:
            if action_mask.shape != allowed.shape:
                raise ValueError('action mask shape mismatch')
            allowed = allowed & action_mask
        proposal = self.proposal(inputs).squeeze(-1).masked_fill(~allowed, -torch.inf)
        qhat = (1 + nn.functional.softplus(self.qhat(inputs).squeeze(-1))).masked_fill(~allowed, torch.inf)
        return proposal, qhat, allowed
