import torch
from torch import nn


class FamilyHeads(nn.Module):
    def __init__(self, families, d, pair_d):
        super().__init__()
        self.heads = nn.ModuleDict({family: nn.Sequential(nn.Linear(d + 2 * pair_d, d), nn.GELU(), nn.Linear(d, d))
                                    for family in sorted(families)})

    def forward(self, encoded):
        size = encoded.valid.sum(1)[:, None, None]
        inputs = torch.cat((encoded.wire, encoded.pair.sum(1) / size, encoded.pair.sum(2) / size), -1)
        tokens, masks = [], []
        for family, head in self.heads.items():
            mask = encoded.valid & encoded.availability[family][:, None]
            tokens.append(head(inputs) * mask[..., None])
            masks.append(mask)
        return torch.stack(tokens, 2), torch.stack(masks, 2)
