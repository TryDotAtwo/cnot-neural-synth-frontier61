import torch
from torch import nn
from ..contracts import ModelOutput
from .stem import StructuralStem
from .family_heads import FamilyHeads
from .fusion import FusionTransformer
from .auxiliary import AuxiliaryHeads


class FusionDistanceField(nn.Module):
    def __init__(self, specs, d=128, pair_d=32, blocks=6, heads=4, ffn=256, fusion_blocks=2):
        super().__init__()
        specs = tuple(specs)
        if not specs or len({s.id for s in specs}) != len(specs):
            raise ValueError('nonempty unique feature specs required')
        families = {s.id[0] for s in specs}
        self.stem = StructuralStem(specs, d, pair_d, blocks, heads, ffn)
        self.family_heads = FamilyHeads(families, d, pair_d)
        self.fusion = FusionTransformer(d, pair_d, heads, ffn, fusion_blocks, len(families))
        self.auxiliary = AuxiliaryHeads(d, pair_d)
        self.config = dict(d=d, pair_d=pair_d, blocks=blocks, heads=heads, ffn=ffn, fusion_blocks=fusion_blocks,
                           feature_ids=[s.id for s in specs], schema='fusion_distance_field_v3_2',
                           auxiliary_value_input='detached', auxiliary_encoder='shared')

    def encode(self, batch, packet):
        if tuple(s.key for s in batch.states) != packet.state_keys:
            raise ValueError('packet/state mismatch')
        return self.stem(batch, packet)

    def value(self, encoded):
        tokens, available = self.family_heads(encoded)
        raw = self.fusion(encoded, tokens, available)
        return torch.where(encoded.identity, torch.zeros_like(raw), nn.functional.softplus(raw))

    def forward(self, batch, packet):
        encoded = self.encode(batch, packet)
        value = self.value(encoded)
        proposal, qhat, _ = self.auxiliary(encoded.wire, encoded.pair, value, encoded.valid)
        return ModelOutput(value, proposal, qhat)
