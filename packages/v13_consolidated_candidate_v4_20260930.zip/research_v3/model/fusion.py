import torch
from torch import nn
from .stem import StructuralBlock


class FusionTransformer(nn.Module):
    def __init__(self, d, pair_d, heads, ffn, blocks, family_count):
        super().__init__()
        self.family_type = nn.Parameter(torch.randn(family_count, d) * 0.02)
        self.family_attention = nn.TransformerEncoderLayer(d, heads, ffn, dropout=0, batch_first=True)
        self.blocks = nn.ModuleList(StructuralBlock(d, pair_d, heads, ffn) for _ in range(blocks))
        self.dist = nn.Parameter(torch.randn(1, 1, d) * 0.02)
        self.read = nn.MultiheadAttention(d, heads, dropout=0, batch_first=True)
        self.norm = nn.LayerNorm(d)
        self.output = nn.Sequential(nn.Linear(d + 2, ffn), nn.GELU(), nn.Linear(ffn, 1))

    def forward(self, encoded, family_tokens, available):
        b, n, k, d = family_tokens.shape
        typed = (family_tokens + self.family_type) * available[..., None]
        # Null family slot also handles a physical wire with no available optional families.
        tokens = torch.cat((typed, typed.new_zeros(b, n, 1, d)), 2).reshape(b * n, k + 1, d)
        mask = torch.cat((available, torch.ones(b, n, 1, dtype=torch.bool, device=available.device)), 2).reshape(b * n, k + 1)
        attended = self.family_attention(tokens, src_key_padding_mask=~mask)
        pooled = (attended * mask[..., None]).sum(1) / mask.sum(1)[:, None]
        h = (encoded.wire + pooled.reshape(b, n, d)) * encoded.valid[..., None]
        z = encoded.pair
        for block in self.blocks:
            h, z = block(h, z, encoded.valid)
        globals_, global_valid = encoded.global_tokens
        context = torch.cat((h, globals_), 1)
        valid = torch.cat((encoded.valid, global_valid), 1)
        dist = self.dist.expand(b, -1, -1)
        read, _ = self.read(dist, context, context, key_padding_mask=~valid, need_weights=False)
        summary = self.norm(dist + read)[:, 0]
        size = encoded.valid.sum(1).to(summary.dtype)
        return self.output(torch.cat((summary, size[:, None], size.log1p()[:, None]), -1)).squeeze(-1)
