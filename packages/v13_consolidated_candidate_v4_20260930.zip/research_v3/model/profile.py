"""Untrained reference diagnostics; not a synthesis benchmark."""
import argparse
import json
from pathlib import Path
from time import perf_counter
import torch
from ..contracts import AlphabetSpec, MatrixState, MatrixBatch
from ..features.registry import FeatureRegistry, FeaturePolicy
from ..evidence import sha256
from .field import FusionDistanceField


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    torch.set_num_threads(1)
    torch.manual_seed(712)
    registry = FeatureRegistry()
    ids = tuple(k for k in registry.specs if k[0] in 'AB') + ('F01',)
    policy = FeaturePolicy(ids)
    model = FusionDistanceField([registry.specs[k] for k in ids]).eval()
    stage = Path(__file__).resolve().parents[3]
    baseline = stage / 'improved/research_v2/baselines.json'
    rows = []
    with torch.no_grad():
        for case in json.loads(baseline.read_text())['cases']:
            source = stage / case['input_source']
            matrix = json.loads(source.read_text())['matrix']
            state = MatrixState.from_dense(matrix, AlphabetSpec.all_to_all(len(matrix)))
            packet = registry.build((state,), policy)
            batch = MatrixBatch.from_states((state,))
            start = perf_counter()
            output = model(batch, packet)
            rows.append({'case': case['case'], 'n': state.n, 'input_sha256': sha256(source),
                         'inference_cpu_seconds': perf_counter() - start,
                         'feature_seconds': packet.audit['seconds'], 'value_untrained': output.value.item()})
    # Architecture collision diagnostic only: no distance inequality is assumed.
    cycle_states = []
    for lengths in ((10,), (5, 5)):
        packed = [1 << i for i in range(10)]
        offset = 0
        for length in lengths:
            for i in range(length):
                packed[offset + i] ^= 1 << (offset + (i - 1) % length)
                packed[offset + i] ^= 1 << (offset + (i + 1) % length)
            offset += length
        cycle_states.append(MatrixState(10, tuple(packed), AlphabetSpec.all_to_all(10).id))
    with torch.no_grad():
        packet = registry.build(tuple(cycle_states), policy)
        values = model(MatrixBatch.from_states(cycle_states), packet).value.tolist()
    report = {'status': 'untrained_reference_only', 'config': model.config,
              'parameters': sum(p.numel() for p in model.parameters()), 'torch': torch.__version__,
              'cases': rows, 'cycle_diagnostic_values': values,
              'cycle_distances': 'not_certified', 'training_started': False,
              'source_hashes': {str(p): sha256(p) for p in sorted(Path(__file__).parent.glob('*.py'))}}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.open('x', encoding='utf-8').write(json.dumps(report, indent=2))
    print(json.dumps({'parameters': report['parameters'], 'cases': len(rows), 'cycle_values': values}))


if __name__ == '__main__':
    main()
