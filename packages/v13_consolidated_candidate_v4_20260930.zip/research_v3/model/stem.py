import math
import torch
from torch import nn
from ..contracts import EncodedState


def tensor(value, like, boolean=False):
    dtype = torch.bool if boolean else like.dtype
    if isinstance(value, torch.Tensor):
        return value.to(device=like.device, dtype=dtype)
    return torch.tensor(value, device=like.device, dtype=dtype)


class StructuralBlock(nn.Module):
    def __init__(self, d, pair_d, heads, ffn):
        super().__init__()
        if d % heads:
            raise ValueError('embedding dimension must divide attention heads')
        self.d, self.heads = d, heads
        self.pair_update = nn.Sequential(nn.Linear(2 * pair_d + 2 * d, ffn), nn.GELU(), nn.Linear(ffn, pair_d))
        self.pair_norm = nn.LayerNorm(pair_d)
        self.qkv = nn.Linear(d, 3 * d)
        self.bias = nn.Linear(pair_d, heads)
        self.out = nn.Linear(d, d)
        self.relations = nn.Linear(2 * pair_d, d)
        self.norm = nn.LayerNorm(d)
        self.ff = nn.Sequential(nn.Linear(d, ffn), nn.GELU(), nn.Linear(ffn, d))
        self.ff_norm = nn.LayerNorm(d)

    def forward(self, h, z, valid):
        b, n, _ = h.shape
        pair_mask = (valid[:, :, None] & valid[:, None, :])[..., None]
        left = h[:, :, None].expand(-1, -1, n, -1)
        right = h[:, None, :].expand(-1, n, -1, -1)
        z = self.pair_norm(z + self.pair_update(torch.cat((z, z.transpose(1, 2), left, right), -1))) * pair_mask
        q, k, v = [x.reshape(b, n, self.heads, self.d // self.heads).transpose(1, 2) for x in self.qkv(h).chunk(3, -1)]
        scores = q @ k.transpose(-1, -2) / math.sqrt(self.d // self.heads)
        scores = scores + self.bias(z).permute(0, 3, 1, 2)
        scores = scores.masked_fill(~valid[:, None, None, :], -torch.inf)
        message = (scores.softmax(-1) @ v).transpose(1, 2).reshape(b, n, self.d)
        size = valid.sum(1)[:, None, None]
        relations = self.relations(torch.cat((z.sum(1), z.sum(2)), -1) / size)
        h = self.norm(h + self.out(message) + relations) * valid[..., None]
        return self.ff_norm(h + self.ff(h)) * valid[..., None], z


class StructuralStem(nn.Module):
    def __init__(self, specs, d=128, pair_d=32, blocks=6, heads=4, ffn=256):
        super().__init__()
        self.specs = {s.id: s for s in specs}
        self.d, self.pair_d = d, pair_d
        self.projections = nn.ModuleDict({s.id: nn.Linear(s.channels, pair_d if s.role == 'pair' else d) for s in specs})
        self.raw_matrix = nn.Linear(3, pair_d)
        self.pair_to_node = nn.Linear(2 * pair_d, d)
        self.size_projection = nn.Linear(2, d)
        self.group_roles = nn.ModuleDict({s.id: nn.ModuleList(nn.Linear(d, d, bias=False) for _ in s.wire_roles)
                                         for s in specs if s.role == 'group'})
        self.context_q = nn.Linear(d, d)
        self.context_k = nn.Linear(d, d)
        self.context_v = nn.Linear(d, d)
        self.blocks = nn.ModuleList(StructuralBlock(d, pair_d, heads, ffn) for _ in range(blocks))

    def forward(self, batch, packet):
        like = self.raw_matrix.weight
        valid = batch.valid.to(device=like.device)
        matrix = batch.matrix.to(device=like.device, dtype=like.dtype)
        b, n, _ = matrix.shape
        pmask = valid[:, :, None] & valid[:, None, :]
        eye = torch.eye(n, device=like.device, dtype=like.dtype)[None].expand(b, -1, -1)
        z = self.raw_matrix(torch.stack((matrix, matrix.transpose(1, 2), eye), -1)) * pmask[..., None]
        size = valid.sum(1).to(like.dtype)
        h = self.size_projection(torch.stack((size, size.log1p()), -1))[:, None].expand(-1, n, -1)
        h = h * valid[..., None]
        context, context_masks, groups, families = [], [], {}, {}
        for key, spec in self.specs.items():
            if key not in packet.features:
                raise ValueError('model feature absent from packet schema')
            feature = packet.features[key]
            if feature.role != spec.role or feature.values.shape[-1] != spec.channels:
                raise ValueError('feature role/shape mismatch')
            available = tensor(feature.available, like, True)
            families[key[0]] = families.get(key[0], torch.zeros(b, dtype=torch.bool, device=like.device)) | available
            value = tensor(feature.values, like)
            projected = self.projections[key](value)
            projected = projected * available.reshape(b, *([1] * (projected.ndim - 1)))
            if spec.role == 'node':
                h = h + projected * valid[..., None]
            elif spec.role == 'pair':
                z = z + projected * pmask[..., None]
            elif spec.role == 'global':
                context.append(projected[:, None])
                context_masks.append(available[:, None])
            elif spec.role == 'group':
                if projected.shape[1] == 0:
                    continue
                incidence = tensor(packet.group_incidence[key], like)
                mask = tensor(feature.token_valid, like, True) & available[:, None]
                projected = projected * mask[..., None]
                # Role-specific messages preserve the physical attachment of every group.
                for r, projection in enumerate(self.group_roles[key]):
                    attach = incidence[..., r] * mask[..., None] * valid[:, None, :]
                    h = h + torch.einsum('bkn,bkd->bnd', attach, projection(projected)) / attach.sum(1).clamp_min(1)[..., None]
                context.append(projected)
                context_masks.append(mask)
                groups[key] = (projected, incidence, mask)
        h = h + self.pair_to_node(torch.cat((z.sum(1), z.sum(2)), -1) / size[:, None, None])
        # A masked null token prevents all-masked softmax for absent optional families.
        ctx = torch.cat(context + [h.new_zeros((b, 1, self.d))], 1)
        ctx_valid = torch.cat(context_masks + [torch.ones((b, 1), dtype=torch.bool, device=like.device)], 1)
        logits = self.context_q(h) @ self.context_k(ctx).transpose(1, 2) / math.sqrt(self.d)
        logits = logits.masked_fill(~ctx_valid[:, None, :], -torch.inf)
        h = (h + logits.softmax(-1) @ self.context_v(ctx)) * valid[..., None]
        for block in self.blocks:
            h, z = block(h, z, valid)
        identity = ((matrix - eye).abs() * pmask).sum((1, 2)) == 0
        return EncodedState(h, z, groups, (ctx, ctx_valid), valid, families, identity)
