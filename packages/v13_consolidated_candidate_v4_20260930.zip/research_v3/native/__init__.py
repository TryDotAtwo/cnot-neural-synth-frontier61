"""Tensor ABI and parity-gated exports; separate from legacy native runtime."""
