"""Compile inside the existing pinned Docker image; no download or pip install."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import torch
from torch.utils.cpp_extension import include_paths, library_paths

parser = argparse.ArgumentParser()
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--cuda',action='store_true')
args = parser.parse_args()
if args.output.exists():
    raise FileExistsError(args.output)
source = Path(__file__).with_name('runtime_cuda.cpp' if args.cuda else 'runtime.cpp')
command = ['g++','-O2','-std=c++17','-D_GLIBCXX_USE_CXX11_ABI='+str(int(torch._C._GLIBCXX_USE_CXX11_ABI)),str(source),'-o',str(args.output)]
command += ['-I'+p for p in include_paths()]+['-L'+p for p in library_paths()]
command += ['-Wl,-rpath,'+p for p in library_paths()]+['-ltorch','-ltorch_cpu','-lc10']
print(json.dumps({'torch':str(torch.__version__),'command':command}),flush=True)
subprocess.run(command,check=True)
manifest={'torch':str(torch.__version__),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
          'binary_sha256':hashlib.sha256(args.output.read_bytes()).hexdigest(),'command':command}
with args.output.with_suffix('.json').open('x') as stream:json.dump(manifest,stream,indent=2)
print('build complete',flush=True)
