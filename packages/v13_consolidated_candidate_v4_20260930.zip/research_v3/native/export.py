from dataclasses import asdict
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import warnings
import torch


class TensorField(torch.nn.Module):
    """Fixed feature schema, dynamic batch/wire sizes; validated host packing."""
    def __init__(self, model):
        super().__init__()
        self.model = model
        self.specs = tuple(model.stem.specs.values())

    def forward(self, matrix, valid, feature_tensors):
        features, incidence = {}, {}
        offset = 0
        for spec in self.specs:
            value, available = feature_tensors[offset], feature_tensors[offset+1]
            offset += 2
            token_valid = None
            if spec.role == 'group':
                token_valid, incidence[spec.id] = feature_tensors[offset], feature_tensors[offset+1]
                offset += 2
            features[spec.id] = SimpleNamespace(values=value,available=available,role=spec.role,token_valid=token_valid)
        encoded = self.model.stem(SimpleNamespace(matrix=matrix,valid=valid),
                                  SimpleNamespace(features=features,group_incidence=incidence))
        value = self.model.value(encoded)
        proposal,qhat,allowed = self.model.auxiliary(encoded.wire,encoded.pair,value,encoded.valid)
        return value,proposal,qhat,allowed


def pack(model, batch, packet):
    if tuple(s.key for s in batch.states) != packet.state_keys:
        raise ValueError('export packet/state mismatch')
    parameter = next(model.parameters())
    values = []
    for key,spec in model.stem.specs.items():
        feature = packet.features[key]
        if feature.role != spec.role or feature.values.shape[-1] != spec.channels:
            raise ValueError('export feature schema mismatch')
        tensor = torch.tensor(feature.values.copy(),device=parameter.device,dtype=parameter.dtype)
        available = torch.tensor(feature.available.copy(),device=parameter.device,dtype=torch.bool)
        if not torch.isfinite(tensor).all():
            raise ValueError('nonfinite export input')
        if spec.role == 'group':
            mask = torch.tensor(feature.token_valid.copy(),device=parameter.device,dtype=torch.bool)
            incidence = torch.tensor(packet.group_incidence[key].copy(),device=parameter.device,dtype=parameter.dtype)
            # One masked dummy group gives a stable traced branch for empty groups.
            if tensor.shape[1] == 0:
                b,n = batch.valid.shape
                tensor = parameter.new_zeros((b,1,spec.channels))
                mask = torch.zeros((b,1),dtype=torch.bool,device=parameter.device)
                incidence = parameter.new_zeros((b,1,n,len(spec.wire_roles)))
            values.extend((tensor,available,mask,incidence))
        else:
            values.extend((tensor,available))
    return batch.matrix.to(parameter.device), batch.valid.to(parameter.device), values


def export_model(model, batch, packet, path, provenance):
    path = Path(path)
    if path.exists() or path.with_suffix('.json').exists():
        raise FileExistsError('immutable export already exists')
    if not provenance:
        raise ValueError('export provenance required')
    modes = {name:m.training for name,m in model.named_modules()}
    fastpath = torch.backends.mha.get_fastpath_enabled()
    torch.backends.mha.set_fastpath_enabled(False)
    model.eval()
    try:
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            traced = torch.jit.trace(TensorField(model),pack(model,batch,packet),check_trace=True,strict=True)
        with path.open('xb') as stream:
            torch.jit.save(traced,stream)
        manifest = {'schema':'fusion_tensor_abi_v1','model_config':model.config,
                    'features':[asdict(s) for s in model.stem.specs.values()],
                    'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'provenance':provenance,
                    'inputs':'bool matrix[B,N,N], bool valid[B,N], ordered feature tensor list; host validates full state',
                    'outputs':'V[B], proposal[B,control,target], Qhat[B,control,target], bool allowed[B,N,N]',
                    'trace_warnings':sorted({str(w.message) for w in caught}),
                    'status':'exported; independent shape/device/gradient parity required'}
        with path.with_suffix('.json').open('x',encoding='utf-8') as stream:
            json.dump(manifest,stream,indent=2)
        return manifest
    finally:
        torch.backends.mha.set_fastpath_enabled(fastpath)
        for name,m in model.named_modules():
            m.training = modes[name]
