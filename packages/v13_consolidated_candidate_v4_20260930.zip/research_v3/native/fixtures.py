from pathlib import Path
import torch


class InputFixture(torch.nn.Module):
    def __init__(self, inputs):
        super().__init__()
        matrix,valid,features = inputs
        self.register_buffer('matrix',matrix)
        self.register_buffer('valid',valid)
        self.count = len(features)
        for i,value in enumerate(features):
            self.register_buffer(f'feature_{i}',value)

    def forward(self):
        return self.matrix,self.valid,[getattr(self,f'feature_{i}') for i in range(self.count)]


def save_fixture(inputs,path):
    path = Path(path)
    module = torch.jit.trace(InputFixture(inputs),(),strict=False,check_trace=True)
    with path.open('xb') as stream:torch.jit.save(module,stream)
