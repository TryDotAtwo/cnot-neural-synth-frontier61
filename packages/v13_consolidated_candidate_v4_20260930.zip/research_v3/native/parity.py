import torch
from .export import pack


def compare(model, exported, batch, packet, atol=2e-5, rtol=2e-5):
    with torch.no_grad():
        reference = model(batch,packet)
        value,proposal,qhat,mask = exported(*pack(model,batch,packet))
    expected = batch.valid[:,:,None] & batch.valid[:,None,:] & ~torch.eye(batch.matrix.shape[1],device=batch.matrix.device,dtype=torch.bool)[None]
    if not torch.equal(mask,expected.to(mask.device)):
        raise AssertionError('export action mask mismatch')
    report = {}
    for name,left,right in (('value',reference.value,value),('proposal',reference.proposal[mask],proposal[mask]),
                            ('qhat',reference.qhat[mask],qhat[mask])):
        if not torch.isfinite(left).all() or not torch.isfinite(right).all():
            raise AssertionError('nonfinite valid output')
        torch.testing.assert_close(left,right,atol=atol,rtol=rtol)
        report[name] = float((left-right).detach().abs().max()) if left.numel() else 0.
    if not torch.isneginf(proposal[~mask]).all() or not torch.isposinf(qhat[~mask]).all():
        raise AssertionError('export invalid action values mismatch')
    return report
