import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time

parser=argparse.ArgumentParser()
parser.add_argument('--directory',type=Path,required=True)
parser.add_argument('--model',type=Path,required=True)
args=parser.parse_args()
rows=[]
for source in sorted(args.directory.glob('input_*.pt')):
    target=source.with_name(source.name.replace('input_','output_'))
    if target.exists():raise FileExistsError(target)
    start=time.perf_counter()
    subprocess.run([str(args.directory/'v3_runtime'),str(args.model),str(source),str(target)],check=True)
    rows.append({'input':source.name,'input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
                 'output':target.name,'output_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
                 'process_seconds':time.perf_counter()-start})
with (args.directory/'runtime_manifest.json').open('x') as stream:
    json.dump({'cases':rows,'model_sha256':hashlib.sha256(args.model.read_bytes()).hexdigest(),
               'runtime_sha256':hashlib.sha256((args.directory/'v3_runtime').read_bytes()).hexdigest()},stream,indent=2)
print('completed '+str(len(rows))+' native cases',flush=True)
