"""TorchScript inference adapter for the own full-matrix reference search."""
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import torch
from torch import nn
from ..contracts import ModelOutput
from .export import pack


class ExportedSearchField(nn.Module):
    def __init__(self, source_model, export_path, *, device='cpu'):
        super().__init__()
        export_path=Path(export_path)
        manifest=json.loads(export_path.with_suffix('.json').read_text(encoding='utf-8'))
        if hashlib.sha256(export_path.read_bytes()).hexdigest()!=manifest['sha256']:
            raise ValueError('export hash mismatch')
        if manifest['schema']!='fusion_tensor_abi_v1' or manifest['model_config']!=source_model.config:
            raise ValueError('export/model schema mismatch')
        specs=tuple(source_model.stem.specs.values())
        if manifest['features']!=json.loads(json.dumps([asdict(spec) for spec in specs])):
            raise ValueError('export feature order mismatch')
        self.stem=SimpleNamespace(specs=dict(source_model.stem.specs))
        self.device_anchor=nn.Parameter(torch.zeros((),device=device),requires_grad=False)
        self.exported=torch.jit.load(str(export_path),map_location=device).eval()
        self.export_sha256=manifest['sha256']
        self.eval()

    def forward(self,batch,packet):
        with torch.no_grad():
            value,proposal,qhat,allowed=self.exported(*pack(self,batch,packet))
        expected=batch.valid[:,:,None]&batch.valid[:,None,:]&~torch.eye(batch.matrix.shape[1],device=batch.matrix.device,dtype=torch.bool)[None]
        if not torch.equal(allowed,expected):
            raise ValueError('export action mask mismatch')
        if (not torch.isfinite(value).all() or not torch.isfinite(proposal[allowed]).all() or
                not torch.isfinite(qhat[allowed]).all() or not torch.isneginf(proposal[~allowed]).all() or
                not torch.isposinf(qhat[~allowed]).all()):
            raise ValueError('invalid exported search outputs')
        return ModelOutput(value,proposal,qhat)
