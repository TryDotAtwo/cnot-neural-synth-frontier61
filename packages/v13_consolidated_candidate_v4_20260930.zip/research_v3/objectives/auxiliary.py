from dataclasses import dataclass
import torch


@dataclass(frozen=True)
class AuxRouting:
    value_input: str = 'detached'
    encoder: str = 'shared'


def absolute_qhat_loss(qhat, cost_plus_successor_value, allowed):
    if qhat.shape != cost_plus_successor_value.shape or allowed.shape != qhat.shape:
        raise ValueError('action tensor shape mismatch')
    if not allowed.any():
        return qhat.masked_fill(~allowed, 0).sum() * 0
    return torch.nn.functional.smooth_l1_loss(qhat[allowed], cost_plus_successor_value.detach()[allowed])


def proposal_imitation_loss(logits, teacher_actions, allowed):
    if logits.ndim != 2 or allowed.shape != logits.shape or teacher_actions.shape != (logits.shape[0],):
        raise ValueError('proposal tensor shape mismatch')
    if not allowed.gather(1, teacher_actions[:, None]).all():
        raise ValueError('teacher action outside alphabet')
    return torch.nn.functional.cross_entropy(logits.masked_fill(~allowed, -torch.inf), teacher_actions)


def build_qhat_targets(model, states, registry, policy, alphabet, chunk_size=None):
    from ..contracts import MatrixBatch
    from ..words import apply
    if not states:
        raise ValueError('empty Qhat batch')
    if chunk_size is not None and (type(chunk_size) is not int or chunk_size < 1):
        raise ValueError('positive neighbor chunk size required')
    parameter = next(model.parameters())
    n = max(state.n for state in states)
    targets = parameter.new_zeros((len(states), n, n))
    allowed = torch.zeros_like(targets, dtype=torch.bool)
    with torch.no_grad():
        for b, state in enumerate(states):
            if state.n != alphabet.n or state.alphabet_id != alphabet.id:
                raise ValueError('state/alphabet mismatch')
            successors = tuple(apply(state, gate, alphabet) for gate in alphabet.allowed)
            if not successors:
                continue
            width = chunk_size or len(successors)
            for start in range(0, len(successors), width):
                chunk = successors[start:start + width]
                packet = registry.build(chunk, policy)
                values = model(MatrixBatch.from_states(chunk, parameter.device), packet).value
                if not torch.isfinite(values).all():
                    raise ValueError('nonfinite Qhat teacher values')
                for local, i in enumerate(range(start, min(start + width, len(successors)))):
                    gate, cost = alphabet.allowed[i], alphabet.costs[i]
                    targets[b, gate.control, gate.target] = cost + values[local]
                    allowed[b, gate.control, gate.target] = True
    return targets, allowed
