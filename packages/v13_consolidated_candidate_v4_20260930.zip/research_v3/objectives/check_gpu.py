"""Fixed-branch CPU64/CUDA32 diagnostic under the preregistered tolerance."""
import argparse
from copy import deepcopy
from dataclasses import replace
import json
from pathlib import Path
import torch
from ..contracts import AlphabetSpec, MatrixState, MatrixBatch
from ..features.registry import FeatureRegistry, FeaturePolicy
from ..model.field import FusionDistanceField
from .bellman import select_backup, recompute_backup, theta_fingerprint


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    if not torch.cuda.is_available():
        raise RuntimeError('CUDA unavailable; GPU gate uncomputed')
    torch.set_num_threads(1)
    torch.manual_seed(887)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    registry = FeatureRegistry()
    policy = FeaturePolicy(('A01', 'A05', 'B01'))
    a = AlphabetSpec.all_to_all(3)
    states = (MatrixState(3, (1, 3, 7), a.id), MatrixState(3, (3, 2, 6), a.id))
    cpu = FusionDistanceField([registry.specs[k] for k in policy.enabled_ids],
                              d=24, pair_d=8, blocks=2, heads=4, ffn=48, fusion_blocks=2).double()
    gpu = deepcopy(cpu).float().cuda()
    reference_selection = select_backup(cpu, states, registry, policy, a)
    natural_gpu = select_backup(gpu, states, registry, policy, a)
    fixed_gpu = replace(reference_selection, theta_hash=theta_fingerprint(gpu))
    comparisons = []
    def compare(name, test, ref):
        test, ref = test.detach().cpu().double(), ref.detach().cpu().double()
        delta = (test - ref).abs()
        comparisons.append({'name': name, 'maxabs': delta.max().item(),
                            'maxrel': (delta / ref.abs().clamp_min(1e-30)).max().item(),
                            'passed': bool((delta <= 2e-5 + 2e-5 * ref.abs()).all())})
    packet = registry.build(states, policy)
    cpu_output = cpu(MatrixBatch.from_states(states), packet)
    gpu_output = gpu(MatrixBatch.from_states(states, 'cuda'), packet)
    compare('value', gpu_output.value, cpu_output.value)
    mask = torch.isfinite(cpu_output.qhat)
    compare('qhat_valid', gpu_output.qhat[mask.cuda()], cpu_output.qhat[mask])
    cpu_loss = recompute_backup(cpu, reference_selection).loss
    gpu_loss = recompute_backup(gpu, fixed_gpu).loss
    compare('fixed_branch_loss', gpu_loss, cpu_loss)
    cpu_loss.backward()
    gpu_loss.backward()
    for (name, p), (other_name, q) in zip(cpu.named_parameters(), gpu.named_parameters()):
        assert name == other_name
        if p.grad is None or q.grad is None:
            if (p.grad is None) != (q.grad is None):
                comparisons.append({'name': 'gradient:' + name, 'passed': False, 'reason': 'None mismatch'})
            continue
        compare('gradient:' + name, q.grad, p.grad)
    opt_cpu = torch.optim.Adam(cpu.parameters(), lr=1e-4)
    opt_gpu = torch.optim.Adam(gpu.parameters(), lr=1e-4)
    opt_cpu.step()
    opt_gpu.step()
    for (name, p), (_, q) in zip(cpu.named_parameters(), gpu.named_parameters()):
        compare('parameter_after_step:' + name, q, p)
        if p in opt_cpu.state:
            for moment in ('exp_avg', 'exp_avg_sq'):
                compare(moment + ':' + name, opt_gpu.state[q][moment], opt_cpu.state[p][moment])
    report = {'scope': 'two synthetic GL3 roots, small d24 reference architecture; not native export parity',
              'device': torch.cuda.get_device_name(), 'torch': torch.__version__, 'tf32': False,
              'atol': 2e-5, 'rtol': 2e-5,
              'reference_actions': [b.selected_index for b in reference_selection.branches],
              'natural_gpu_actions': [b.selected_index for b in natural_gpu.branches],
              'gradient_branch': 'forced_reference', 'comparisons': comparisons,
              'passed': all(x['passed'] for x in comparisons)}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.open('x', encoding='utf-8').write(json.dumps(report, indent=2))
    print(json.dumps({'passed': report['passed'], 'comparisons': len(comparisons),
                      'failures': [x['name'] for x in comparisons if not x['passed']]}))


if __name__ == '__main__':
    main()
