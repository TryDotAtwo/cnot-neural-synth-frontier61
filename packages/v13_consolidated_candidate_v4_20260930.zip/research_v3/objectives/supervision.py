import torch
from dataclasses import replace
from ..bounds import cheap_bounds, verify_bounds
from ..words import verify_word
from ..contracts import MatrixBatch
from ..symmetry import map_problem
from ..data.replay import Replay
from .bellman import LossReport


def supervised_losses(values, records, alphabet, exact_catalog=None):
    if values.shape != (len(records),) or not records:
        raise ValueError('supervision shape mismatch')
    exact = {}
    if exact_catalog is not None:
        verified = Replay(alphabet)
        verified.ingest_exact(exact_catalog)
        exact = {key: record.exact_distance for key, record in verified.records.items()}
    interval_losses, exact_losses = [], []
    for value, record in zip(values, records):
        bounds = replace(cheap_bounds(record.state), upper=record.verified_words)
        verify_bounds(record.state, bounds, alphabet)
        if not bounds.upper:
            raise ValueError('supervision requires a verified upper bound')
        if record.exact_distance is not None and exact.get(record.state.key) != record.exact_distance:
            raise ValueError('exact label without independently verified matching catalog')
        lower, upper = bounds.lower_bound, record.upper_bound
        interval_losses.append(torch.relu(lower - value).square() + torch.relu(value - upper).square())
        if record.state.key in exact:
            exact_losses.append(torch.nn.functional.smooth_l1_loss(value, value.new_tensor(exact[record.state.key])))
    interval = torch.stack(interval_losses).mean()
    exact_loss = torch.stack(exact_losses).mean() if exact_losses else values.sum() * 0
    return LossReport(interval + exact_loss, {'interval': interval, 'exact': exact_loss},
                      {'examples': len(records), 'exact_examples': len(exact_losses)})


def verified_path_loss(start_values, end_values, certificates, alphabet, one_sided=False):
    if start_values.shape != end_values.shape or start_values.shape != (len(certificates),):
        raise ValueError('path tensor shape mismatch')
    for cert in certificates:
        verify_word(cert, alphabet)
    costs = start_values.new_tensor([cert.physical_cost for cert in certificates])
    difference = start_values - end_values
    if not one_sided:
        difference = difference.abs()
    return torch.relu(difference - costs).square().mean()


def symmetry_loss(model, states, registry, policy, alphabet, transform):
    mapped = tuple(map_problem(state, alphabet, transform).state for state in states)
    device = next(model.parameters()).device
    left = model(MatrixBatch.from_states(states, device), registry.build(states, policy)).value
    right = model(MatrixBatch.from_states(mapped, device), registry.build(mapped, policy)).value
    return (left - right).square().mean()
