"""Full-operator contiguous-window resynthesis with explicit work limits."""
from dataclasses import dataclass, replace
import heapq
from .contracts import MatrixState
from .words import verify_word
from .symmetry import map_problem, map_word_back


def symmetry_restarts(state, alphabet, compiler, transforms, evaluations_per_restart):
    """Restart an explicit-budget compiler and independently verify every mapping.

    The caller must supply its own audited compiler; no legacy time-limited
    helper or external solver is imported by this module.
    """
    if type(evaluations_per_restart) is not int or evaluations_per_restart < 0:
        raise ValueError('invalid compiler evaluation budget')
    runs, best = [], None
    for transform in transforms:
        try:
            mapped = map_problem(state, alphabet, transform)
        except ValueError as error:
            runs.append({'transform': transform, 'status': 'unsupported', 'reason': str(error)})
            continue
        cert = compiler(mapped.state, mapped.alphabet, evaluations=evaluations_per_restart)
        if cert is None:
            runs.append({'transform': transform, 'status': 'no_certificate', 'budget': evaluations_per_restart})
            continue
        original = map_word_back(cert, mapped)
        verify_word(original, alphabet)
        runs.append({'transform': transform, 'status': 'verified', 'budget': evaluations_per_restart,
                     'certificate': original})
        if best is None or original.physical_cost < best.physical_cost:
            best = original
    return {'best': best, 'runs': runs, 'scope': 'symmetry restart only; no neural or postprocessing attribution'}


@dataclass(frozen=True)
class WindowBudget:
    passes: int
    max_window: int
    evaluations: int
    max_states: int
    support_restricted: bool = False

    def __post_init__(self):
        if any(type(x) is not int or x < 0 for x in (self.passes, self.max_window, self.evaluations, self.max_states)):
            raise ValueError('invalid window budget')
        if type(self.support_restricted) is not bool:
            raise ValueError('support restriction must be boolean')


@dataclass
class PostprocessResult:
    before: object
    after: object
    status: str
    window_records: list
    evaluations: int

    @property
    def savings(self):
        return self.before.physical_cost - self.after.physical_cost


def operator_rows(n, word):
    rows = [1 << i for i in range(n)]
    for gate in word:
        rows[gate.target] ^= rows[gate.control]
    return tuple(rows)


def replace_window(cert, start, stop, replacement, alphabet):
    verify_word(cert, alphabet)
    if not 0 <= start <= stop <= len(cert.gates):
        raise ValueError('invalid window range')
    replacement = tuple(replacement)
    for gate in replacement:
        alphabet.cost(gate)
    original = cert.gates[start:stop]
    if operator_rows(alphabet.n, original) != operator_rows(alphabet.n, replacement):
        raise ValueError('full window operator mismatch')
    old_cost = sum(alphabet.cost(g) for g in original)
    new_cost = sum(alphabet.cost(g) for g in replacement)
    if new_cost >= old_cost:
        raise ValueError('replacement must strictly decrease physical cost')
    gates = cert.gates[:start] + replacement + cert.gates[stop:]
    result = replace(cert, gates=gates, physical_cost=cert.physical_cost - old_cost + new_cost,
                     producer=cert.producer + ':verified_window')
    verify_word(result, alphabet)
    return result


def _shorter_operator(target, max_cost, alphabet, evaluations, max_states, support=None):
    identity = tuple(1 << i for i in range(alphabet.n))
    if identity == target:
        return (), 0, 'shorter_found', 1
    if max_states < 1:
        return None, 0, 'resource_limit', 0
    candidates = tuple((gate,cost) for gate,cost in zip(alphabet.allowed,alphabet.costs)
                       if support is None or (gate.control in support and gate.target in support))
    queue = [(0, identity, ())]
    best = {identity: 0}
    work = 0
    while queue:
        cost, rows, word = heapq.heappop(queue)
        if best[rows] != cost:
            continue
        for gate, gate_cost in candidates:
            if cost + gate_cost > max_cost:
                continue
            if work >= evaluations:
                return None, work, 'resource_limit', len(best)
            work += 1
            successor = list(rows)
            successor[gate.target] ^= successor[gate.control]
            successor = tuple(successor)
            new_cost = cost + gate_cost
            if successor == target:
                return word + (gate,), work, 'shorter_found', len(best)
            if new_cost >= best.get(successor, float('inf')):
                continue
            if successor not in best and len(best) >= max_states:
                return None, work, 'resource_limit', len(best)
            best[successor] = new_cost
            heapq.heappush(queue, (new_cost, successor, word + (gate,)))
    return None, work, 'no_shorter_within_window_operator', len(best)


def shorten(cert, alphabet, budget):
    verify_word(cert, alphabet)
    current = cert
    records = []
    total = 0
    for pass_index in range(budget.passes):
        changed = False
        start = 0
        while start < len(current.gates):
            if total >= budget.evaluations:
                return PostprocessResult(cert, current, 'resource_limit', records, total)
            replaced = False
            for length in range(min(budget.max_window, len(current.gates) - start), 0, -1):
                old = current.gates[start:start + length]
                target = operator_rows(alphabet.n, old)
                old_cost = sum(alphabet.cost(g) for g in old)
                support = frozenset(i for gate in old for i in (gate.control,gate.target)) if budget.support_restricted else None
                word, work, status, states = _shorter_operator(target, old_cost - 1, alphabet,
                                                              budget.evaluations - total, budget.max_states,support)
                total += work
                record = {'pass': pass_index, 'start': start, 'length': length,
                          'full_operator_rows': target, 'before_cost': old_cost,
                          'status': status, 'evaluations': work, 'states': states,
                          'support_wires':None if support is None else sorted(support),
                          'scope':('same full operator; candidate gates restricted to original window support; original alphabet and physical costs'
                                   if support is not None else 'same full operator; full alphabet and physical costs')}
                records.append(record)
                if word is not None:
                    current = replace_window(current, start, start + length, word, alphabet)
                    record['after_cost'] = sum(alphabet.cost(g) for g in word)
                    record['replacement'] = tuple((g.control, g.target) for g in word)
                    replaced = changed = True
                    break
                if status == 'resource_limit':
                    return PostprocessResult(cert, current, status, records, total)
            start = max(0, start - 1) if replaced else start + 1
        if not changed:
            break
    verify_word(current, alphabet)
    return PostprocessResult(cert, current, 'passes_complete', records, total)
