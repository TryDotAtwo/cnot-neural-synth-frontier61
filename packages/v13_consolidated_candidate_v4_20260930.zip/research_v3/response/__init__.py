"""Typed, scoped response objects; exact tiny reference before fast backends."""
