"""Exact six-block 4x4 Schur solve for the stage48 two-carrier modes.

Each block fixes the GL(2,2) linear frame of the two carriers; its four
coordinates retain both source bits. Block elimination sums all returns.
"""
from fractions import Fraction

from .joint_carriers import _FRAMES, _INDEX, _ORIGIN, _mode_data


def _zero():
    return [[Fraction(0) for _ in range(4)] for _ in range(4)]


def _inverse4(matrix):
    augmented = [[Fraction(x) for x in row] +
                 [Fraction(int(i == j)) for j in range(4)]
                 for i, row in enumerate(matrix)]
    for column in range(4):
        pivot = next((i for i in range(column, 4) if augmented[i][column]), None)
        if pivot is None:
            raise ArithmeticError("singular stage48 four-state Schur block")
        augmented[column], augmented[pivot] = augmented[pivot], augmented[column]
        divisor = augmented[column][column]
        augmented[column] = [x / divisor for x in augmented[column]]
        for i in range(4):
            if i == column or not augmented[i][column]:
                continue
            factor = augmented[i][column]
            augmented[i] = [x - factor*y for x, y in zip(augmented[i], augmented[column])]
    return [row[4:] for row in augmented]


def _multiply(left, right):
    return [[sum(left[i][k] * right[k][j] for k in range(4))
             for j in range(4)] for i in range(4)]


def _multiply_vector(matrix, vector):
    return [sum(matrix[i][j] * vector[j] for j in range(4)) for i in range(4)]


def _subtract(left, right):
    return [[left[i][j] - right[i][j] for j in range(4)] for i in range(4)]


def _frame_blocks():
    root = (1, 2)
    labels = (root,) + tuple((a, b) for a in range(1, 4) for b in range(1, 4)
                              if a != b and (a, b) != root)
    groups = tuple(tuple(_INDEX[frame] for frame in _FRAMES
                         if (frame[0] >> 1, frame[1] >> 1) == label)
                   for label in labels)
    if len(groups) != 6 or any(len(group) != 4 for group in groups):
        raise ArithmeticError("stage48 frame partition is not six four-state blocks")
    coordinates = {frame: (block, local) for block, group in enumerate(groups)
                   for local, frame in enumerate(group)}
    return groups, coordinates


def carrier_schur_mode(histogram, z: Fraction, *, coupled=True, source_vector=None):
    """All 24 exact endpoint values for an arbitrary rational right-hand side."""
    if type(z) is not Fraction or z < 0 or type(coupled) is not bool:
        raise ValueError("nonnegative exact fugacity and explicit coupling flag required")
    if len(histogram) != 8 or any(type(x) is not int or x < 0 for x in histogram):
        raise ValueError("eight nonnegative joint frequency counts required")
    if source_vector is not None and (len(source_vector) != 24 or
                                      any(type(value) is not Fraction for value in source_vector)):
        raise ValueError("exact 24-component rational source vector required")
    m = sum(histogram)
    if z * (2 + 2*int(coupled) + 2*m) >= 1:
        raise ValueError("outside positive absolute-convergence disk")
    groups, coordinates = _frame_blocks()
    diagonal, outgoing = _mode_data(histogram)
    blocks = [[_zero() for _ in range(6)] for _ in range(6)]
    rhs = [[Fraction(0)] * 4 for _ in range(6)]
    for source in range(24):
        b, k = coordinates[source]
        blocks[b][b][k][k] += 1 - z * diagonal[source]
        for destination in outgoing[source][:4 if coupled else 2]:
            a, j = coordinates[destination]
            blocks[a][b][j][k] -= z
    if source_vector is None:
        origin_block, origin_local = coordinates[_ORIGIN]
        rhs[origin_block][origin_local] = Fraction(1)
    else:
        for frame, value in enumerate(source_vector):
            block, local = coordinates[frame]
            rhs[block][local] = value
    eliminated = {}
    for k in range(5, 0, -1):
        inverse = _inverse4(blocks[k][k])
        row_to_earlier = [blocks[k][j] for j in range(k)]
        eliminated[k] = (inverse, rhs[k][:], row_to_earlier)
        for i in range(k):
            left = _multiply(blocks[i][k], inverse)
            rhs_update = _multiply_vector(left, rhs[k])
            rhs[i] = [a - b for a, b in zip(rhs[i], rhs_update)]
            for j in range(k):
                blocks[i][j] = _subtract(blocks[i][j], _multiply(left, blocks[k][j]))
    solved = [_multiply_vector(_inverse4(blocks[0][0]), rhs[0])]
    for k in range(1, 6):
        inverse, original_rhs, row = eliminated[k]
        residual = original_rhs[:]
        for j in range(k):
            contribution = _multiply_vector(row[j], solved[j])
            residual = [a - b for a, b in zip(residual, contribution)]
        solved.append(_multiply_vector(inverse, residual))
    values = [Fraction(0)] * 24
    for block, group in enumerate(groups):
        for local, frame in enumerate(group):
            values[frame] = solved[block][local]
    return tuple(values)
