"""Positive finite response of the stage51 dynamic-source restricted alphabet.

The full four-row GL(4,2) core and one joint frequency tuple are retained for
the entire word. No stage50 fixed-source or separate-passive approximation is
used. All exposed coefficients count physical CNOT words.
"""
from functools import lru_cache
from dataclasses import replace
from fractions import Fraction

import numpy as np

from .shared_feedback import _histograms
from .types import (CostDegree, OracleResult, RationalIntervalCertificate,
                    ScalarResponse, ScalarTerm)


_CORE_GATES = ((0, 1), (0, 2), (1, 2), (2, 1),
               (1, 3), (2, 3), (3, 1), (1, 0))


@lru_cache(maxsize=1)
def _core():
    frames = []
    for a in range(1, 16):
        for b in range(1, 16):
            if b in (a,):
                continue
            span2 = {0, a, b, a ^ b}
            for c in range(1, 16):
                if c in span2:
                    continue
                span3 = span2 | {v ^ c for v in span2}
                for d in range(1, 16):
                    if d not in span3:
                        frames.append((a, b, c, d))
    frames = tuple(frames)
    index = {frame: i for i, frame in enumerate(frames)}
    if len(frames) != 20160 or len(index) != 20160:
        raise ArithmeticError("GL(4,2) frame inventory is incomplete")
    permutations = []
    for control, target in _CORE_GATES:
        mapping = []
        for frame in frames:
            moved = list(frame)
            moved[target] ^= frame[control]
            mapping.append(index[tuple(moved)])
        permutations.append(np.asarray(mapping, dtype=np.int32))
    rows = np.asarray(frames, dtype=np.int16)
    return frames, index, tuple(permutations), rows


def _boundary(problem, query):
    active = problem.active_wires
    n = len(problem.target_rows)
    scope = f"stage51_dynamic_source_alphabet:n{n}:source_hky{active}"
    if (len(active) != 4 or problem.ports.labels or problem.frequencies or
            query.mutual_uses is not None or query.charged_uses is not None):
        return scope, None
    s, h, k, y = active
    if query.feedback_control is not None and query.feedback_control != y:
        return scope, None
    passive = tuple(wire for wire in range(n) if wire not in active)
    expected = {(active[c], active[t]) for c, t in _CORE_GATES}
    expected |= {(carrier, receiver) for receiver in passive for carrier in (h, k)}
    if set(problem.alphabet) != expected:
        return scope, None
    allowed = sum(1 << wire for wire in active)
    if any(problem.target_rows[wire] & ~allowed for wire in active):
        return scope, None
    def local(row):
        return sum(((row >> wire) & 1) << j for j, wire in enumerate(active))
    endpoint = tuple(local(problem.target_rows[wire]) for wire in active)
    if endpoint not in _core()[1]:
        return scope, None
    additions = []
    for receiver in passive:
        row = problem.target_rows[receiver]
        if row & ~(allowed | (1 << receiver)) or not ((row >> receiver) & 1):
            return scope, None
        additions.append(local(row))
    return scope, (endpoint, tuple(additions))


def dynamic_source_response(problem, query, budget):
    scope, boundary = _boundary(problem, query)
    if boundary is None:
        return OracleResult("unsupported", None, 0,
                            "outside full-row dynamic-source sector", scope)
    endpoint, additions = boundary
    feedback = query.feedback_uses
    source = query.source_uses
    private = query.source_private_uses
    if feedback is not None:
        scope += f":feedback_uses{feedback}"
    if source is not None:
        scope += f":source_uses{source}"
    if private is not None:
        scope += f":source_private_uses{private}"
    alphabet_size = 8 + 2 * len(additions)
    if query.fugacity is not None and (query.fugacity < 0 or
                                       query.fugacity * alphabet_size >= 1):
        return OracleResult("unsupported", None, 0,
                            "nonnegative fugacity below inverse alphabet size required", scope)
    source_wire, _, _, private_wire = problem.active_wires
    full_private_restored = all(
        ((row >> private_wire) & 1) == int(i == private_wire)
        for i, row in enumerate(problem.target_rows))
    zero_reason = None
    if source == 1 and problem.target_rows[source_wire] == 1 << source_wire:
        zero_reason = "one source-row update cannot restore the original source row"
    elif feedback == 1 and full_private_restored:
        zero_reason = "one private-control feedback cannot restore the full private column"
    elif private is not None and private % 2 and not (problem.target_rows[source_wire] >> private_wire & 1):
        zero_reason = "odd private transfers into source cannot leave its private bit zero"
    if zero_reason is not None:
        if query.fugacity is None:
            response = ScalarResponse("physical_cnot", scope, "words", ())
            return OracleResult("exact", response, 0, zero_reason, scope)
        zero = Fraction(0)
        interval = RationalIntervalCertificate(
            query.fugacity, zero, zero, "own_stage51_full_operator_selection_rule",
            "all_order_source_row_or_private_column_parity_identity", 0, 0)
        return OracleResult("certified_interval", interval, 0, zero_reason,
                            f"{scope}:z{query.fugacity}")
    if query.fugacity is not None:
        z = query.fugacity
        finite = dynamic_source_response(problem, replace(query, fugacity=None), budget)
        if finite.status != "exact":
            return finite
        prefix = sum(Fraction(term.multiplicity) * z ** term.degree.value
                     for term in finite.response.terms)
        tail = (alphabet_size * z) ** (query.max_degree + 1) / (1 - alphabet_size * z)
        mode_count = len(_histograms(additions, budget.max_layer_states)[0])
        interval = RationalIntervalCertificate(
            z, prefix, prefix + tail,
            f"own_stage51_complete_prefix_degree{query.max_degree}_geometric_alphabet_tail",
            "all_physical_words_nonnegative_coefficient_and_alphabet_cardinality_bound",
            mode_count, mode_count)
        return OracleResult("certified_interval", interval, finite.evaluations,
                            "all-order dynamic-source pointwise enclosure with rigorous tail",
                            f"{scope}:z{z}:prefix_degree{query.max_degree}")
    modes, histogram_ops = _histograms(additions, budget.max_layer_states)
    if modes is None or histogram_ops > budget.max_transitions:
        return OracleResult("resource_limit", None, histogram_ops,
                            "joint frequency histogram budget", scope)
    states = (len(modes) * 20160 *
              (1 if feedback is None else feedback + 1) *
              (1 if source is None else source + 1) *
              (1 if private is None else private + 1))
    estimate = states * (8 + 2 * len(additions)) * query.max_degree
    if states > budget.max_layer_states or histogram_ops + estimate > budget.max_transitions:
        return OracleResult("resource_limit", None, histogram_ops,
                            "complete dynamic-source recurrence budget", scope)
    frames, index, permutations, rows = _core()
    from .source_channels import pushed_frequency_bits, source_channel_maps
    channels = source_channel_maps()
    source_map = channels.source_update
    if not np.array_equal(source_map, permutations[7]):
        raise ArithmeticError("15-channel source sewing disagrees with physical h-to-s")
    dtype = np.int64 if (8 + 2 * len(additions)) ** query.max_degree < 2 ** 60 else object
    weights = tuple(modes.values())
    histograms = tuple(modes)
    signs = np.asarray([1 - 2 * (x.bit_count() & 1) for x in range(16)], dtype=np.int32)
    fixed_rows = np.asarray([frame for frame in frames if frame[0] == 1], dtype=np.int16)
    histogram_matrix = np.asarray(histograms, dtype=np.int32)
    diagonal = np.empty((len(modes), len(frames)), dtype=np.int32)
    for source_row in range(1, 16):
        frequencies = tuple(pushed_frequency_bits(source_row, f) for f in range(16))
        characters = np.stack([
            signs[fixed_rows[:, 1] & frequency] + signs[fixed_rows[:, 2] & frequency]
            for frequency in frequencies])
        positions = np.flatnonzero(channels.sector == source_row - 1)
        diagonal[:, positions] = histogram_matrix @ characters[:, channels.local_index[positions]]
    tracked = any(x is not None for x in (feedback, source, private))
    if not tracked:
        current = np.zeros((len(modes), len(frames)), dtype=dtype)
        current[:, index[(1, 2, 4, 8)]] = 1
    else:
        current = np.zeros(((feedback + 1 if feedback is not None else 1),
                            (source + 1 if source is not None else 1),
                            (private + 1 if private is not None else 1),
                            len(modes), len(frames)), dtype=dtype)
        current[0, 0, 0, :, index[(1, 2, 4, 8)]] = 1
        dirty = np.flatnonzero(rows[:, 1] & 8)
        clean = np.flatnonzero((rows[:, 1] & 8) == 0)
    terminal = index[endpoint]
    normalization = 16 ** len(additions)
    terms = []
    for degree in range(query.max_degree + 1):
        target_vector = current if not tracked else current[-1, -1, -1]
        signed = sum(weight * int(target_vector[mode, terminal])
                     for mode, weight in enumerate(weights))
        if signed < 0 or signed % normalization:
            raise ArithmeticError("stage51 joint modes failed positive integer normalization")
        coefficient = signed // normalization
        if coefficient:
            terms.append(ScalarTerm(CostDegree("physical_cnot", degree, scope),
                                    coefficient, ()))
        if degree == query.max_degree:
            break
        following = current * diagonal
        if not tracked:
            for permutation in (*permutations[:7], source_map):
                following[:, permutation] += current
        else:
            for permutation in permutations[:6]:
                following[..., permutation] += current
            if feedback is None:
                following[..., permutations[6]] += current
            elif feedback:
                following[1:, ..., permutations[6]] += current[:-1]
            if source is None:
                following[..., source_map[clean]] += current[..., clean]
                if private is None:
                    following[..., source_map[dirty]] += current[..., dirty]
                elif private:
                    following[:, :, 1:, :, source_map[dirty]] += current[:, :, :-1, :, dirty]
            elif source:
                following[:, 1:, :, :, source_map[clean]] += current[:, :-1, :, :, clean]
                if private is None:
                    following[:, 1:, :, :, source_map[dirty]] += current[:, :-1, :, :, dirty]
                elif private:
                    following[:, 1:, 1:, :, source_map[dirty]] += current[:, :-1, :-1, :, dirty]
        current = following
    return OracleResult("exact", ScalarResponse("physical_cnot", scope, "words", tuple(terms)),
                        histogram_ops + estimate,
                        "complete finite dynamic-source positive endpoint coefficient prefix", scope)
