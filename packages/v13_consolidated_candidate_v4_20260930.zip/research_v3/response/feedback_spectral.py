"""Stage49 physical feedback words in the seven-gate four-wire sector."""
from fractions import Fraction
from ..gf2 import inverse
from .joint_spectral import _frames
from .types import CostDegree, ExactRationalPointValue, OracleResult, ScalarResponse, ScalarTerm


_FRAMES = _frames()
_INDEX = {frame: i for i, frame in enumerate(_FRAMES)}
_ORIGIN = _INDEX[(1, 2, 4)]
_LINEAR_GATES = ((0, 1), (1, 0), (0, 2), (1, 2))
_FEEDBACK = (2, 0)


def _apply(rows, vector):
    return sum(((row & vector).bit_count() & 1) << i for i, row in enumerate(rows))


def _boundary(problem, query):
    n = len(problem.target_rows)
    active = problem.active_wires
    scope = f"stage49_feedback_alphabet:n{n}:source_hky{active}"
    if len(active) != 4 or problem.ports.labels or problem.frequencies:
        return scope, None
    source, h, k, y = active
    if query.feedback_control is not None and query.feedback_control != y:
        return scope, None
    expected = {(source, h), (source, k), (h, k), (k, h),
                (h, y), (k, y), (y, h)}
    if set(problem.alphabet) != expected or problem.target_rows[source] != 1 << source:
        return scope, None
    if any(problem.target_rows[i] != 1 << i for i in range(n) if i not in active):
        return scope, None
    allowed = sum(1 << i for i in active)
    if any(problem.target_rows[i] & ~allowed for i in (h, k, y)):
        return scope, None
    target_wires = (h, k, y)
    frame = tuple(sum(((problem.target_rows[wire] >> j) & 1) << column
                      for column, j in enumerate(target_wires)) for wire in target_wires)
    if frame not in _INDEX:
        return scope, None
    alpha = sum(((problem.target_rows[wire] >> source) & 1) << i
                for i, wire in enumerate(target_wires))
    return scope, (frame, alpha)


def feedback_spectral_response(problem, query, budget):
    scope, boundary = _boundary(problem, query)
    if boundary is None:
        return OracleResult("unsupported", None, 0, "outside four-wire feedback sector", scope)
    frame, alpha = boundary
    if query.fugacity is not None:
        return feedback_spectral_resolvent(problem, query, budget, boundary=(scope, frame, alpha))
    marked = query.feedback_uses
    if marked is not None:
        scope += f":feedback_uses{marked}"
    states = 168 * (1 if marked is None else marked + 1)
    estimate = 8 * states * 8 * (query.max_degree + 1)
    if states > budget.max_layer_states or estimate > budget.max_transitions:
        return OracleResult("resource_limit", None, 0, "feedback Fourier mode budget", scope)
    inverse_frame = inverse(frame)
    transformed_alpha = _apply(inverse_frame, alpha)
    terminal = _INDEX[frame]
    inverse_frames = tuple(inverse(candidate) for candidate in _FRAMES)
    directions = tuple((_apply(inv, 1), _apply(inv, 2)) for inv in inverse_frames)
    permutations = []
    for control, target in _LINEAR_GATES + (_FEEDBACK,):
        perm = []
        for current in _FRAMES:
            moved = list(current)
            moved[target] ^= moved[control]
            perm.append(_INDEX[tuple(moved)])
        permutations.append(tuple(perm))
    totals = [0] * (query.max_degree + 1)
    for frequency in range(8):
        sign = -1 if ((frequency & transformed_alpha).bit_count() & 1) else 1
        diagonal = tuple(sum(-1 if ((frequency & direction).bit_count() & 1) else 1
                             for direction in pair) for pair in directions)
        if marked is None:
            vector = [int(i == _ORIGIN) for i in range(168)]
            for degree in range(query.max_degree + 1):
                totals[degree] += sign * vector[terminal]
                if degree == query.max_degree:
                    break
                following = [diagonal[i] * vector[i] for i in range(168)]
                for permutation in permutations:
                    for i, count in enumerate(vector):
                        if count:
                            following[permutation[i]] += count
                vector = following
        else:
            vector = [[0] * (marked + 1) for _ in range(168)]
            vector[_ORIGIN][0] = 1
            for degree in range(query.max_degree + 1):
                totals[degree] += sign * vector[terminal][marked]
                if degree == query.max_degree:
                    break
                following = [[0] * (marked + 1) for _ in range(168)]
                for i, row in enumerate(vector):
                    for uses, count in enumerate(row):
                        if not count:
                            continue
                        following[i][uses] += diagonal[i] * count
                        for permutation in permutations[:4]:
                            following[permutation[i]][uses] += count
                        if uses < marked:
                            following[permutations[4][i]][uses + 1] += count
                vector = following
    if any(value < 0 or value % 8 for value in totals):
        raise ArithmeticError("feedback Fourier modes failed positive integer normalization")
    terms = tuple(ScalarTerm(CostDegree("physical_cnot", degree, scope), value // 8, ())
                  for degree, value in enumerate(totals) if value)
    return OracleResult("exact", ScalarResponse("physical_cnot", scope, "words", terms),
                        estimate, "complete finite seven-gate feedback coefficient prefix", scope)


def feedback_spectral_resolvent(problem, query, budget, *, boundary=None):
    """Own eight-mode exact integer solve at one convergent rational fugacity."""
    if boundary is None:
        scope, endpoint = _boundary(problem, query)
        if endpoint is None:
            return OracleResult("unsupported", None, 0, "outside four-wire feedback sector", scope)
        frame, alpha = endpoint
    else:
        scope, frame, alpha = boundary
    if query.feedback_uses is not None:
        return OracleResult("unsupported", None, 0,
                            "all-order exact feedback-use coefficient is not implemented", scope)
    z = query.fugacity
    if z is None:
        return OracleResult("unsupported", None, 0, "rational fugacity is required", scope)
    if z < 0 or 7*z >= 1:
        raise ValueError("positive seven-gate feedback series requires 0 <= z < 1/7")
    if z == 0:
        value = Fraction(int(problem.target_rows == tuple(1 << i for i in range(len(problem.target_rows)))))
        return OracleResult("exact_rational_point", ExactRationalPointValue(z, value, scope), 0,
                            "exact zero-fugacity endpoint", scope)
    estimate = 8 * 168**3
    if budget.max_layer_states < 168 or budget.max_transitions < estimate:
        return OracleResult("resource_limit", None, 0, "eight exact 168-frame solves exceed budget", scope)
    from sympy import Matrix
    from sympy.polys.matrices import DomainMatrix
    inverse_frame = inverse(frame)
    transformed_alpha = _apply(inverse_frame, alpha)
    terminal = _INDEX[frame]
    inverse_frames = tuple(inverse(candidate) for candidate in _FRAMES)
    directions = tuple((_apply(inv, 1), _apply(inv, 2)) for inv in inverse_frames)
    permutations = []
    for control, target in _LINEAR_GATES + (_FEEDBACK,):
        mapping = []
        for current in _FRAMES:
            moved = list(current)
            moved[target] ^= moved[control]
            mapping.append(_INDEX[tuple(moved)])
        permutations.append(tuple(mapping))
    total = Fraction(0)
    for frequency in range(8):
        diagonal = tuple(sum(-1 if ((frequency & direction).bit_count() & 1) else 1
                             for direction in pair) for pair in directions)
        operator = [[z.denominator * int(i == j) - z.numerator * diagonal[i] * int(i == j)
                     for j in range(168)] for i in range(168)]
        for mapping in permutations:
            for source, target in enumerate(mapping):
                operator[target][source] -= z.numerator
        rhs = [z.denominator * int(i == _ORIGIN) for i in range(168)]
        numerator, denominator = DomainMatrix.from_Matrix(Matrix(operator)).solve_den(
            DomainMatrix.from_Matrix(Matrix(rhs)))
        sign = -1 if ((frequency & transformed_alpha).bit_count() & 1) else 1
        total += sign * Fraction(int(numerator.to_Matrix()[terminal]), int(denominator))
    value = total / 8
    if value < 0:
        raise ArithmeticError("negative physical feedback resolvent")
    return OracleResult("exact_rational_point", ExactRationalPointValue(z, value, scope),
                        estimate, "all-order exact point value from eight independent 168-frame solves", scope)
