"""Stage47 exact signed open-wire influence for fixed ordered currents.

The result is a Fourier character, not a positive word count. External
currents are inputs; this does not sum over CNOT programs on other wires.
"""
from dataclasses import dataclass


@dataclass(frozen=True)
class WireInfluence:
    width: int
    start: int
    end: int
    incoming: tuple[int, ...]
    outgoing: tuple[int, ...]

    def __post_init__(self):
        if type(self.width) is not int or self.width < 1:
            raise ValueError("positive full row width required")
        if len(self.incoming) != len(self.outgoing):
            raise ValueError("incoming and outgoing slice counts differ")
        for x in (self.start, self.end) + self.incoming + self.outgoing:
            if type(x) is not int or not 0 <= x < (1 << self.width):
                raise ValueError("current or boundary outside full row width")


@dataclass(frozen=True)
class SignedInfluenceValue:
    value: int
    scope_id: str = "stage47_open_wire_fixed_ordered_currents"

    def __post_init__(self):
        if self.value not in (-1, 0, 1):
            raise ValueError("influence is a signed character or zero")


def wire_influence(problem: WireInfluence) -> SignedInfluenceValue:
    """Evaluate the exact retarded character without intermediate row sums."""
    if not isinstance(problem, WireInfluence):
        raise TypeError("typed wire influence required")
    current_row = problem.start
    phase = 0
    for incoming, outgoing in zip(problem.incoming, problem.outgoing):
        phase ^= (outgoing & current_row).bit_count() & 1
        current_row ^= incoming
    if current_row != problem.end:
        return SignedInfluenceValue(0)
    return SignedInfluenceValue(-1 if phase else 1)


def sew_wire_influences(left: WireInfluence, right: WireInfluence) -> SignedInfluenceValue:
    """Sew two open time intervals at their uniquely determined shared row."""
    if left.width != right.width:
        raise ValueError("incompatible full row widths")
    if left.end != right.start:
        raise ValueError("open boundary labels do not match")
    return wire_influence(WireInfluence(left.width, left.start, right.end,
                                        left.incoming + right.incoming,
                                        left.outgoing + right.outgoing))


@dataclass(frozen=True)
class TwoCarrierInfluence:
    """Stage48 fixed internal two-line maps and full-vector open boundaries."""
    width: int
    initial: tuple[int, int]
    final: tuple[int, int]
    matrices: tuple[tuple[int, int], ...]
    incoming: tuple[tuple[int, int], ...]
    outgoing: tuple[tuple[int, int], ...]

    def __post_init__(self):
        if type(self.width) is not int or self.width < 1:
            raise ValueError("positive full-vector width required")
        if not (len(self.matrices) == len(self.incoming) == len(self.outgoing)):
            raise ValueError("each time slice needs a map and both currents")
        for pair in (self.initial, self.final) + self.incoming + self.outgoing:
            if (type(pair) is not tuple or len(pair) != 2 or
                    any(type(x) is not int or not 0 <= x < (1 << self.width) for x in pair)):
                raise ValueError("two full-vector line labels required")
        for matrix in self.matrices:
            if (type(matrix) is not tuple or len(matrix) != 2 or
                    any(type(x) is not int or not 0 <= x < 4 for x in matrix) or
                    matrix[0] == 0 or matrix[1] == 0 or matrix[0] == matrix[1]):
                raise ValueError("invertible ordered GF2 two-line map required")


def two_carrier_influence(problem: TwoCarrierInfluence) -> SignedInfluenceValue:
    if not isinstance(problem, TwoCarrierInfluence):
        raise TypeError("typed two-carrier influence required")
    state = problem.initial
    phase = 0
    for matrix, incoming, outgoing in zip(problem.matrices, problem.incoming, problem.outgoing):
        phase ^= sum((x & k).bit_count() for x, k in zip(state, outgoing)) & 1
        updated = []
        for row, current in zip(matrix, incoming):
            value = current
            if row & 1:
                value ^= state[0]
            if row & 2:
                value ^= state[1]
            updated.append(value)
        state = tuple(updated)
    return SignedInfluenceValue(0 if state != problem.final else (-1 if phase else 1),
                                "stage48_open_two_carriers_fixed_ordered_maps_currents")
