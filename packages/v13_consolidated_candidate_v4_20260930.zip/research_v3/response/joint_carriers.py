"""Stage48 two interacting carriers with fixed source and passive recipients.

The eight-bin Fourier histogram retains all labeled recipient translations.
Signed mode weights are summed before any physical word coefficient is used.
"""
from dataclasses import dataclass
from fractions import Fraction

from .joint_spectral import joint_histograms
from .types import (CostDegree, ExactRationalPointValue, ExactTemporalProfileValue,
                    OracleResult, ScalarResponse, ScalarTerm)


_FRAMES = tuple((u, v) for u in range(2, 8) for v in range(2, 8)
                if (u >> 1) != (v >> 1))
_INDEX = {frame: i for i, frame in enumerate(_FRAMES)}
_ORIGIN = _INDEX[(2, 4)]


@dataclass(frozen=True)
class CarrierTimeSlice:
    epsilon: Fraction
    weights: tuple[Fraction, Fraction, Fraction, Fraction, Fraction, Fraction]

    def __post_init__(self):
        if (type(self.epsilon) is not Fraction or len(self.weights) != 6 or
                any(type(value) is not Fraction for value in self.weights)):
            raise ValueError("one exact epsilon and six ordered CNOT weights required")


def _boundary(problem, query):
    n = len(problem.target_rows)
    active = problem.active_wires
    coupled = problem.kernel == "stage48_joint_carriers"
    scope = f"stage48_{'coupled' if coupled else 'uncoupled'}_carrier_alphabet:n{n}:source_carriers{active}"
    if (len(active) != 3 or problem.ports.labels or problem.private_wires or
            problem.frequencies or query.feedback_control is not None):
        return scope, None
    source, h, k = active
    receivers = tuple(i for i in range(n) if i not in active)
    expected = {(source, h), (source, k)}
    if coupled:
        expected |= {(h, k), (k, h)}
    expected |= {(c, r) for r in receivers for c in (h, k)}
    if set(problem.alphabet) != expected or problem.target_rows[source] != (1 << source):
        return scope, None
    def local_bits(row):
        return sum(((row >> wire) & 1) << i for i, wire in enumerate(active))
    allowed = sum(1 << wire for wire in active)
    core = (local_bits(problem.target_rows[h]), local_bits(problem.target_rows[k]))
    if core not in _INDEX or any(problem.target_rows[wire] & ~allowed for wire in (h, k)):
        return scope, None
    translations = []
    for receiver in receivers:
        row = problem.target_rows[receiver]
        if (row & ~(allowed | (1 << receiver))) or not ((row >> receiver) & 1):
            return scope, None
        translations.append(local_bits(row))
    return scope, (core, tuple(translations), coupled)


def _mode_data(histogram):
    charge = tuple(sum(count * (-1 if ((eta & direction).bit_count() & 1) else 1)
                       for eta, count in enumerate(histogram)) for direction in range(8))
    diagonal = tuple(charge[u] + charge[v] for u, v in _FRAMES)
    outgoing = tuple((_INDEX[(u ^ 1, v)], _INDEX[(u, v ^ 1)],
                      _INDEX[(u, v ^ u)], _INDEX[(u ^ v, v)]) for u, v in _FRAMES)
    return diagonal, outgoing


def joint_carrier_response(problem, query, budget):
    scope, boundary = _boundary(problem, query)
    if boundary is None:
        return OracleResult("unsupported", None, 0, "outside fixed-source two-carrier sector", scope)
    core, translations, coupled = boundary
    marked = query.mutual_uses
    if marked is not None:
        scope += f":mutual_uses{marked}"
    weights, evaluations = joint_histograms(translations, budget.max_layer_states)
    if weights is None or evaluations > budget.max_transitions:
        return OracleResult("resource_limit", None, evaluations, "joint recipient histograms exceed budget", scope)
    estimate = len(weights) * (24**3 * (1 if marked is None else marked + 1)
                               if query.fugacity is not None else
                               24 * 7 * (query.max_degree + 1) * (1 if marked is None else marked + 1))
    if evaluations + estimate > budget.max_transitions:
        return OracleResult("resource_limit", None, evaluations, "two-carrier mode computation exceeds budget", scope)
    terminal = _INDEX[core]
    normalization = 8 ** len(translations)
    if query.fugacity is not None:
        z = query.fugacity
        if z < 0 or z * (2 + 2 * int(coupled) + 2 * len(translations)) >= 1:
            raise ValueError("positive two-carrier series requires z*alphabet_size<1")
        from .carrier_schur import carrier_schur_mode
        total = Fraction(0)
        for hist, weight in weights.items():
            if marked is None:
                values = carrier_schur_mode(hist, z, coupled=coupled)
            else:
                values = carrier_schur_mode(hist, z, coupled=False)
                mutual = _mode_data(hist)[1]
                for _ in range(marked):
                    source_vector = [Fraction(0)] * 24
                    if coupled:
                        for origin, value in enumerate(values):
                            for destination in mutual[origin][2:]:
                                source_vector[destination] += z * value
                    values = carrier_schur_mode(hist, z, coupled=False,
                                                 source_vector=tuple(source_vector))
            total += weight * values[terminal]
        value = total / normalization
        if value < 0:
            raise ArithmeticError("negative physical two-carrier resolvent")
        return OracleResult("exact_rational_point", ExactRationalPointValue(z, value, scope),
                            evaluations + estimate,
                            "all-order two-carrier marked coefficient via exact four-state Schur blocks", scope)
    totals = [0] * (query.max_degree + 1)
    for hist, weight in weights.items():
        diagonal, outgoing = _mode_data(hist)
        if marked is not None:
            vector = [[0] * (marked + 1) for _ in range(24)]
            vector[_ORIGIN][0] = 1
            for degree in range(query.max_degree + 1):
                totals[degree] += weight * vector[terminal][marked]
                if degree == query.max_degree:
                    break
                following = [[0] * (marked + 1) for _ in range(24)]
                for i, row in enumerate(vector):
                    for uses, count in enumerate(row):
                        if not count:
                            continue
                        following[i][uses] += diagonal[i] * count
                        for j in outgoing[i][:2]:
                            following[j][uses] += count
                        if coupled and uses < marked:
                            for j in outgoing[i][2:]:
                                following[j][uses + 1] += count
                vector = following
            continue
        vector = [int(i == _ORIGIN) for i in range(24)]
        for degree in range(query.max_degree + 1):
            totals[degree] += weight * vector[terminal]
            if degree < query.max_degree:
                following = [diagonal[i] * vector[i] for i in range(24)]
                for i, count in enumerate(vector):
                    if count:
                        for j in outgoing[i][:4 if coupled else 2]:
                            following[j] += count
                vector = following
    if any(value < 0 or value % normalization for value in totals):
        raise ArithmeticError("joint-carrier modes failed positive integer normalization")
    terms = tuple(ScalarTerm(CostDegree("physical_cnot", degree, scope), value // normalization, ())
                  for degree, value in enumerate(totals) if value)
    return OracleResult("exact", ScalarResponse("physical_cnot", scope, "words", terms),
                        evaluations + estimate,
                        "complete finite restricted two-carrier coefficient prefix", scope)


def profiled_joint_carrier_response(problem, slices: tuple[CarrierTimeSlice, ...], budget):
    """Exact finite ordered product of I+epsilon_r H_r in the stage48 sector."""
    from .local import ResponseQuery, LocalBudget, RestrictedProblem
    if (not isinstance(problem, RestrictedProblem) or not isinstance(budget, LocalBudget) or
            type(slices) is not tuple or any(not isinstance(item, CarrierTimeSlice) for item in slices)):
        raise TypeError("typed stage48 problem, time slices and budget required")
    scope, boundary = _boundary(problem, ResponseQuery(0))
    scope += ":ordered_time_profile"
    if boundary is None or problem.kernel != "stage48_joint_carriers":
        return OracleResult("unsupported", None, 0, "time profile requires coupled stage48 alphabet", scope)
    core, translations, _ = boundary
    weights, evaluations = joint_histograms(translations, budget.max_layer_states)
    if weights is None or evaluations > budget.max_transitions:
        return OracleResult("resource_limit", None, evaluations, "joint profile histogram budget", scope)
    estimate = len(weights) * 24 * 8 * max(1, len(slices))
    if evaluations + estimate > budget.max_transitions:
        return OracleResult("resource_limit", None, evaluations, "ordered profile propagation budget", scope)
    terminal = _INDEX[core]
    total = Fraction(0)
    adjacency = _mode_data((0,) * 8)[1]
    for histogram, character_weight in weights.items():
        vector = [Fraction(int(i == _ORIGIN)) for i in range(24)]
        charges = tuple(tuple(sum(count * (-1 if ((eta & direction).bit_count() & 1) else 1)
                                  for eta, count in enumerate(histogram))
                              for direction in frame) for frame in _FRAMES)
        for item in slices:
            w = item.weights
            following = vector[:]
            for i, value in enumerate(vector):
                diagonal = w[4] * charges[i][0] + w[5] * charges[i][1]
                following[i] += item.epsilon * diagonal * value
                for move, j in enumerate(adjacency[i]):
                    following[j] += item.epsilon * w[move] * value
            vector = following
        total += character_weight * vector[terminal]
    value = total / (8 ** len(translations))
    profile = tuple((item.epsilon, item.weights) for item in slices)
    return OracleResult("exact_profiled_point", ExactTemporalProfileValue(profile, value, scope),
                        evaluations + estimate,
                        "exact finite ordered time-profile product in restricted stage48 alphabet", scope)
