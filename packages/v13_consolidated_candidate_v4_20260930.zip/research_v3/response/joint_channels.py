"""Exact 2+1 channel change of basis for the stage30 GL(3,2) sector.

Integer columns PA, SB represent twice-normalized character vectors.
N=PA.T@SB is four times the orthogonal recoupling. All channel operations
count the same physical CNOT generators as the microscopic frame operator.
"""
from dataclasses import dataclass
from functools import lru_cache

import numpy as np

from ..gf2 import inverse, rank
from .joint_spectral import _frames


def _compose(left, right):
    return tuple(_xor_rows(mask, right) for mask in left)


def _xor_rows(mask, rows):
    value = 0
    for i, row in enumerate(rows):
        if (mask >> i) & 1:
            value ^= row
    return value


def _act(rows, vector):
    return sum(((row & vector).bit_count() & 1) << i for i, row in enumerate(rows))


@dataclass(frozen=True)
class JointChannels:
    frames: tuple[tuple[int, int, int], ...]
    pair_basis_twice: np.ndarray
    single_basis_twice: np.ndarray
    recoupling_numerator: np.ndarray

    def microscopic_parts(self, histogram):
        """Integer pair and single generator matrices in the frame basis."""
        if len(histogram) != 8 or any(type(x) is not int or x < 0 for x in histogram):
            raise ValueError("eight nonnegative joint counts required")
        index = {frame: i for i, frame in enumerate(self.frames)}
        pair = np.zeros((168, 168), dtype=np.int64)
        single = np.zeros((168, 168), dtype=np.int64)
        charges = tuple(sum(c * (-1 if ((eta & v).bit_count() & 1) else 1)
                            for eta, c in enumerate(histogram)) for v in range(8))
        for source, frame in enumerate(self.frames):
            inv = inverse(frame)
            for target in range(3):
                destination = pair if target in (0, 1) else single
                direction = sum(((inv[i] >> target) & 1) << i for i in range(3))
                destination[source, source] += charges[direction]
                for control in range(3):
                    if control != target:
                        moved = list(frame)
                        moved[target] ^= moved[control]
                        destination[index[tuple(moved)], source] += 1
        return pair, single

    def coupled_operator_numerator(self, histogram):
        """Return 16 times H in pair-channel coordinates, exactly."""
        pair, single = self.microscopic_parts(histogram)
        pa, sb, n = self.pair_basis_twice, self.single_basis_twice, self.recoupling_numerator
        pair_four = pa.T @ pair @ pa
        single_four = sb.T @ single @ sb
        if np.any(pair_four % 4) or np.any(single_four % 4):
            raise ArithmeticError("channel character normalization failed")
        pair_channel = pair_four // 4
        single_channel = single_four // 4
        if np.any(single_channel - np.diag(np.diag(single_channel))):
            raise ArithmeticError("single-target channel is not diagonal")
        lam = np.diag(single_channel)
        coupled = 16 * pair_channel + (n * lam) @ n.T
        full = pair + single
        if not np.array_equal(coupled, 4 * (pa.T @ full @ pa)):
            raise ArithmeticError("coupled and microscopic operators disagree")
        return coupled


@lru_cache(maxsize=1)
def joint_channels():
    frames = _frames()
    index = {frame: i for i, frame in enumerate(frames)}
    pair_frames = tuple((a, b) for a in range(1, 4) for b in range(1, 4)
                        if rank((a, b)) == 2)
    pair_reps = tuple(next(frame for frame in frames if frame[2] == third)
                      for third in range(1, 8))
    single_reps = tuple(next(frame for frame in frames if frame[:2] == (first, second))
                        for first in range(1, 8) for second in range(1, 8) if first != second)
    pa = np.zeros((168, 168), dtype=np.int64)
    sb = np.zeros((168, 168), dtype=np.int64)
    column = 0
    for representative in pair_reps:
        for frequency in range(4):
            for pair_frame in pair_frames:
                for external in range(4):
                    column_bits = _act(pair_frame, external)
                    shear = (pair_frame[0] | ((column_bits & 1) << 2),
                             pair_frame[1] | (((column_bits >> 1) & 1) << 2), 4)
                    physical_frame = _compose(shear, representative)
                    pa[index[physical_frame], column] = -1 if ((frequency & external).bit_count() & 1) else 1
                column += 1
    column = 0
    for representative in single_reps:
        for frequency in range(4):
            for external in range(4):
                shear = (1, 2, 4 | external)
                physical_frame = _compose(shear, representative)
                sb[index[physical_frame], column] = -1 if ((frequency & external).bit_count() & 1) else 1
            column += 1
    if not np.array_equal(pa.T @ pa, 4 * np.eye(168, dtype=np.int64)):
        raise ArithmeticError("pair character basis is not orthogonal")
    if not np.array_equal(sb.T @ sb, 4 * np.eye(168, dtype=np.int64)):
        raise ArithmeticError("single character basis is not orthogonal")
    n = pa.T @ sb
    if (not np.array_equal(n.T @ n, 16 * np.eye(168, dtype=np.int64)) or
            not np.all(np.count_nonzero(n, axis=1) == 16) or
            not set(np.unique(n)) <= {-1, 0, 1}):
        raise ArithmeticError("stage30 recoupling fails exact sparse orthogonality")
    return JointChannels(frames, pa, sb, n)
