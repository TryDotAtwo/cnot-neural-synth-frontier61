"""Finite positive endpoint coefficients for the stage30 three-target sector.

The intermediate eight-character weights are signed. No joint histogram is
replaced by pair marginals; normalization occurs only after summing modes.
"""
from collections import defaultdict

from ..gf2 import inverse, rank
from .types import CostDegree, ExactRationalPointValue, OracleResult, ScalarResponse, ScalarTerm


def _frames():
    return tuple((a, b, c) for a in range(1, 8) for b in range(1, 8)
                 for c in range(1, 8) if rank((a, b, c)) == 3)


def joint_histograms(currents, cap):
    """Full eight-bin Fourier polynomial, with an explicit state cap."""
    if cap < 1:
        return None, 0
    polynomial = {(0,) * 8: 1}
    evaluations = 0
    for current in currents:
        following = defaultdict(int)
        for histogram, coefficient in polynomial.items():
            for frequency in range(8):
                shifted = list(histogram)
                shifted[frequency] += 1
                sign = -1 if ((frequency & current).bit_count() & 1) else 1
                following[tuple(shifted)] += sign * coefficient
                evaluations += 1
        polynomial = {h: c for h, c in following.items() if c}
        if len(polynomial) > cap:
            return None, evaluations
    return polynomial, evaluations


def joint_spectral_response(problem, query, budget):
    """Exact finite word prefix, not an all-order resolvent or full-alphabet distance."""
    n = len(problem.target_rows)
    active = problem.active_wires
    scope = f"stage30_three_target_alphabet:n{n}:active{active}"
    if (len(active) != 3 or len(set(active)) != 3 or
            any(i < 0 or i >= n for i in active) or problem.ports.labels or
            problem.private_wires or problem.frequencies or
            query.feedback_control is not None or query.fugacity is not None):
        return OracleResult("unsupported", None, 0, "joint kernel requires three active targets and a closed finite endpoint", scope)
    expected = {(control, target) for target in active for control in range(n) if control != target}
    if set(problem.alphabet) != expected:
        return OracleResult("unsupported", None, 0, "alphabet differs from three-target sector", scope)
    passive = tuple(i for i in range(n) if i not in active)
    if any(problem.target_rows[i] != 1 << i for i in passive):
        return OracleResult("unsupported", None, 0, "passive rows differ from identity boundary", scope)
    core = tuple(sum(((problem.target_rows[i] >> j) & 1) << k for k, j in enumerate(active))
                 for i in active)
    if rank(core) != 3:
        return OracleResult("unsupported", None, 0, "singular terminal three-row frame", scope)
    core_inverse = inverse(core)
    currents = []
    for j in passive:
        column = sum(((problem.target_rows[i] >> j) & 1) << k for k, i in enumerate(active))
        currents.append(sum(((core_inverse[k] & column).bit_count() & 1) << k for k in range(3)))
    weights, evaluations = joint_histograms(currents, budget.max_layer_states)
    if weights is None or evaluations > budget.max_transitions:
        return OracleResult("resource_limit", None, evaluations, "joint histogram construction exceeds budget", scope)
    frames = _frames()
    index = {frame: i for i, frame in enumerate(frames)}
    origin, terminal = index[(1, 2, 4)], index[core]
    directions = []
    outgoing = []
    for frame in frames:
        inv = inverse(frame)
        directions.append(tuple(sum(((inv[k] >> target) & 1) << k for k in range(3))
                                for target in range(3)))
        moved = []
        for target in range(3):
            for control in range(3):
                if control != target:
                    following = list(frame)
                    following[target] ^= following[control]
                    moved.append(index[tuple(following)])
        outgoing.append(tuple(moved))
    projected = len(weights) * (168 * 24 + query.max_degree * 168 * 7)
    if evaluations + projected > budget.max_transitions:
        return OracleResult("resource_limit", None, evaluations, "joint frame recurrence exceeds budget", scope)
    totals = [0] * (query.max_degree + 1)
    for histogram, character_weight in weights.items():
        charges = tuple(sum(count * (-1 if ((frequency & direction).bit_count() & 1) else 1)
                            for frequency, count in enumerate(histogram)) for direction in range(8))
        potential = [sum(charges[direction] for direction in row) for row in directions]
        vector = [int(i == origin) for i in range(168)]
        for degree in range(query.max_degree + 1):
            totals[degree] += character_weight * vector[terminal]
            if degree < query.max_degree:
                vector = [potential[i] * vector[i] + sum(vector[j] for j in outgoing[i])
                          for i in range(168)]
    normalization = 8 ** len(currents)
    if any(value < 0 or value % normalization for value in totals):
        raise ArithmeticError("joint signed-mode sum failed positive integer normalization")
    terms = tuple(ScalarTerm(CostDegree("physical_cnot", degree, scope), value // normalization, ())
                  for degree, value in enumerate(totals) if value)
    return OracleResult("exact", ScalarResponse("physical_cnot", scope, "words", terms),
                        evaluations + projected,
                        "complete finite three-target coefficient prefix; no all-order claim", scope)


def joint_spectral_resolvent(problem, query, budget):
    """All-order exact value at one z through the 168-frame coupled operator.

    This uses a direct frame-basis solve, independent of the source's
    pair/single-channel recoupling implementation. The solve is deliberately
    guarded by an explicit cubic-operation budget.
    """
    n = len(problem.target_rows)
    active = problem.active_wires
    scope = f"stage30_three_target_alphabet:n{n}:active{active}"
    if (len(active) != 3 or len(set(active)) != 3 or
            any(i < 0 or i >= n for i in active) or problem.ports.labels or
            problem.private_wires or problem.frequencies or query.feedback_control is not None):
        return OracleResult("unsupported", None, 0, "joint resolvent requires closed three-target boundary", scope)
    expected = {(control, target) for target in active for control in range(n) if control != target}
    if set(problem.alphabet) != expected:
        return OracleResult("unsupported", None, 0, "joint resolvent alphabet differs", scope)
    passive = tuple(i for i in range(n) if i not in active)
    if any(problem.target_rows[i] != 1 << i for i in passive):
        return OracleResult("unsupported", None, 0, "joint resolvent passive boundary differs", scope)
    z = query.fugacity
    if z < 0 or 3 * (n - 1) * z >= 1:
        raise ValueError("stage30 exact resolvent requires 0 <= z < 1/[3(n-1)]")
    core = tuple(sum(((problem.target_rows[i] >> j) & 1) << k for k, j in enumerate(active))
                 for i in active)
    if rank(core) != 3:
        return OracleResult("unsupported", None, 0, "singular terminal frame", scope)
    core_inverse = inverse(core)
    currents = []
    for j in passive:
        column = sum(((problem.target_rows[i] >> j) & 1) << k for k, i in enumerate(active))
        currents.append(sum(((core_inverse[k] & column).bit_count() & 1) << k for k in range(3)))
    weights, evaluations = joint_histograms(currents, budget.max_layer_states)
    if weights is None or evaluations > budget.max_transitions:
        return OracleResult("resource_limit", None, evaluations, "joint histograms exceed budget", scope)
    estimate = len(weights) * 168**3
    if evaluations + estimate > budget.max_transitions:
        return OracleResult("resource_limit", None, evaluations, "exact 168-frame solves exceed budget", scope)
    from sympy import Matrix
    from sympy.polys.matrices import DomainMatrix
    from fractions import Fraction

    from .joint_channels import joint_channels
    channels = joint_channels()
    index = {frame: i for i, frame in enumerate(channels.frames)}
    origin, terminal = index[(1, 2, 4)], index[core]
    pa = channels.pair_basis_twice
    total = Fraction(0)
    for histogram, weight in weights.items():
        h16 = channels.coupled_operator_numerator(histogram)
        operator = [[16 * z.denominator * int(i == j) - z.numerator * int(h16[i, j])
                     for j in range(168)] for i in range(168)]
        rhs = [8 * z.denominator * int(x) for x in pa[origin]]
        numerator, denominator = DomainMatrix.from_Matrix(Matrix(operator)).solve_den(
            DomainMatrix.from_Matrix(Matrix(rhs)))
        solved = numerator.to_Matrix()
        value = Fraction(sum(int(pa[terminal, i]) * int(solved[i]) for i in range(168)),
                         2 * int(denominator))
        total += weight * value
    result = total / (8 ** len(currents))
    if result < 0:
        raise ArithmeticError("negative reconstructed physical joint resolvent")
    return OracleResult("exact_rational_point", ExactRationalPointValue(z, result, scope),
                        evaluations + estimate,
                        "all-order rational point value through coupled pair/single channels", scope)
