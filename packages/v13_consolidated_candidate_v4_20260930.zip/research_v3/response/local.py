"""Guarded local CNOT response references and proved special costs.

The explicit enumerator is only a small-instance reference. It counts full
matrix endpoint words under the declared alphabet and never infers a distance
from an incomplete resource-limited computation.
"""
from dataclasses import dataclass
from collections import defaultdict
from hashlib import sha256
from itertools import combinations
from fractions import Fraction

from ..gf2 import inverse, rank
from .types import CostDegree, LabeledPorts, OracleResult, ScalarResponse, ScalarTerm


@dataclass(frozen=True)
class RestrictedProblem:
    target_rows: tuple[int, ...]
    alphabet: tuple[tuple[int, int], ...]
    ports: LabeledPorts
    private_wires: tuple[int, ...]
    restored_wires: tuple[int, ...]
    frequencies: tuple[int, ...]
    observable: str
    active_wires: tuple[int, ...] = ()
    kernel: str = "tiny_full_endpoint"

    def __post_init__(self):
        n = len(self.target_rows)
        if n < 2 or any(type(row) is not int or not 0 <= row < 1 << n for row in self.target_rows):
            raise ValueError("nonempty full square bitmask matrix required")
        if rank(self.target_rows) != n:
            raise ValueError("target must be an invertible CNOT operator")
        if not self.alphabet or len(set(self.alphabet)) != len(self.alphabet) or any(
            type(gate) is not tuple or len(gate) != 2 or
            any(type(x) is not int or not 0 <= x < n for x in gate) or gate[0] == gate[1]
            for gate in self.alphabet
        ):
            raise ValueError("nonempty unique ordered CNOT alphabet required")
        if not isinstance(self.ports, LabeledPorts):
            raise ValueError("typed ordered ports required")
        for wires in (self.private_wires, self.restored_wires):
            if len(set(wires)) != len(wires) or any(type(i) is not int or not 0 <= i < n for i in wires):
                raise ValueError("invalid declared wires")
        if any(self.target_rows[i] != 1 << i for i in self.restored_wires):
            raise ValueError("declared restored wires are not restored by target")
        if any(type(x) is not int or x < 0 for x in self.frequencies):
            raise ValueError("frequency counts must be nonnegative integers")
        if self.observable != "exact_full_endpoint":
            raise ValueError("only exact full endpoint observable is implemented")
        if len(set(self.active_wires)) != len(self.active_wires) or any(
            type(i) is not int or not 0 <= i < n for i in self.active_wires
        ) or self.kernel not in ("tiny_full_endpoint", "stage29_pair_spectral", "stage30_joint_spectral",
                                  "stage47_carrier_star", "stage48_joint_carriers",
                                  "stage48_uncoupled_carriers", "stage49_feedback_spectral",
                                  "stage50_shared_feedback", "stage51_dynamic_source"):
            raise ValueError("invalid declared active wires or local kernel")


@dataclass(frozen=True)
class ResponseQuery:
    max_degree: int
    feedback_control: int | None = None
    feedback_uses: int | None = None
    fugacity: Fraction | None = None
    mutual_uses: int | None = None
    charged_uses: int | None = None
    source_private_uses: int | None = None
    source_uses: int | None = None

    def __post_init__(self):
        if type(self.max_degree) is not int or self.max_degree < 0:
            raise ValueError("nonnegative finite degree required")
        if (self.feedback_control is None) != (self.feedback_uses is None):
            raise ValueError("feedback control and exact use count must be specified together")
        if self.feedback_control is not None and (type(self.feedback_control) is not int or
                                                  type(self.feedback_uses) is not int or self.feedback_uses < 0):
            raise ValueError("invalid exact feedback use count")
        if self.fugacity is not None and type(self.fugacity) is not Fraction:
            raise ValueError("exact Fraction fugacity required")
        if self.mutual_uses is not None and (type(self.mutual_uses) is not int or self.mutual_uses < 0):
            raise ValueError("nonnegative exact mutual CNOT use count required")
        if self.charged_uses is not None and (type(self.charged_uses) is not int or self.charged_uses < 0):
            raise ValueError("nonnegative exact charged transfer use count required")
        if self.source_private_uses is not None and (
                type(self.source_private_uses) is not int or self.source_private_uses < 0):
            raise ValueError("nonnegative exact private transfer into source required")
        if self.source_uses is not None and (type(self.source_uses) is not int or self.source_uses < 0):
            raise ValueError("nonnegative exact source-update use count required")


@dataclass(frozen=True)
class LocalBudget:
    max_layer_states: int
    max_transitions: int

    def __post_init__(self):
        if any(type(x) is not int or x < 0 for x in (self.max_layer_states, self.max_transitions)):
            raise ValueError("nonnegative explicit state and transition budgets required")


def _alphabet_scope(n, alphabet):
    full = {(c, t) for c in range(n) for t in range(n) if c != t}
    if set(alphabet) == full:
        return f"full_cnot_alphabet:n{n}"
    digest = sha256(repr(tuple(sorted(alphabet))).encode("ascii")).hexdigest()[:16]
    return f"restricted_cnot_alphabet:n{n}:{digest}"


def private_column_restored(rows, private_wire):
    """Full private input column, including every passive output bit."""
    rows = tuple(rows)
    n = len(rows)
    if type(private_wire) is not int or not 0 <= private_wire < n or any(
        type(row) is not int or not 0 <= row < 1 << n for row in rows
    ):
        raise ValueError("invalid full matrix or private wire")
    return all(((row >> private_wire) & 1) == int(i == private_wire)
               for i, row in enumerate(rows))


def local_response(problem: RestrictedProblem, query: ResponseQuery, budget: LocalBudget) -> OracleResult:
    """Exact positive endpoint word series through a finite degree on tiny n.

    Frequencies and exposed ports require a source-specific adapter. Returning
    unsupported here prevents their silent erasure from the response.
    """
    if not isinstance(problem, RestrictedProblem) or not isinstance(query, ResponseQuery) or not isinstance(budget, LocalBudget):
        raise TypeError("typed local response inputs required")
    if query.mutual_uses is not None and problem.kernel not in (
            "stage48_joint_carriers", "stage48_uncoupled_carriers"):
        return OracleResult("unsupported", None, 0,
                            "mutual-use marking belongs only to the stage48 two-carrier alphabet",
                            _alphabet_scope(len(problem.target_rows), problem.alphabet))
    if query.charged_uses is not None and problem.kernel != "stage50_shared_feedback":
        return OracleResult("unsupported", None, 0,
                            "charged transfer marking belongs only to the stage50 shared-feedback alphabet",
                            _alphabet_scope(len(problem.target_rows), problem.alphabet))
    if query.source_private_uses is not None and problem.kernel != "stage51_dynamic_source":
        return OracleResult("unsupported", None, 0,
                            "private source-transfer marking belongs only to stage51",
                            _alphabet_scope(len(problem.target_rows), problem.alphabet))
    if query.source_uses is not None and problem.kernel != "stage51_dynamic_source":
        return OracleResult("unsupported", None, 0,
                            "source-update marking belongs only to stage51",
                            _alphabet_scope(len(problem.target_rows), problem.alphabet))
    if problem.kernel == "stage29_pair_spectral":
        from .pair_spectral import pair_spectral_response, pair_spectral_resolvent
        return (pair_spectral_resolvent(problem, query, budget) if query.fugacity is not None
                else pair_spectral_response(problem, query, budget))
    if problem.kernel == "stage30_joint_spectral":
        from .joint_spectral import joint_spectral_response, joint_spectral_resolvent
        return (joint_spectral_resolvent(problem, query, budget) if query.fugacity is not None
                else joint_spectral_response(problem, query, budget))
    if problem.kernel == "stage47_carrier_star":
        from .star import star_response
        return star_response(problem, query, budget)
    if problem.kernel in ("stage48_joint_carriers", "stage48_uncoupled_carriers"):
        from .joint_carriers import joint_carrier_response
        return joint_carrier_response(problem, query, budget)
    if problem.kernel == "stage49_feedback_spectral":
        from .feedback_spectral import feedback_spectral_response
        return feedback_spectral_response(problem, query, budget)
    if problem.kernel == "stage50_shared_feedback":
        from .shared_feedback import shared_feedback_response
        return shared_feedback_response(problem, query, budget)
    if problem.kernel == "stage51_dynamic_source":
        from .dynamic_source import dynamic_source_response
        return dynamic_source_response(problem, query, budget)
    n = len(problem.target_rows)
    scope = _alphabet_scope(n, problem.alphabet)
    feedback = query.feedback_control
    required_uses = query.feedback_uses
    if feedback is not None:
        if not 0 <= feedback < n:
            raise ValueError("feedback control outside physical wires")
        scope += f":control{feedback}:uses{required_uses}"
    if problem.ports.labels or any(problem.frequencies):
        return OracleResult("unsupported", None, 0, "exposed ports or nonzero frequencies need a dedicated adapter", scope)
    if query.fugacity is not None:
        return OracleResult("unsupported", None, 0, "tiny word enumerator has no rational-resolvent adapter", scope)
    initial = tuple(1 << i for i in range(n))
    if (feedback is not None and required_uses == 1 and
            feedback in problem.private_wires and private_column_restored(problem.target_rows, feedback)):
        response = ScalarResponse("physical_cnot", scope, "words", ())
        return OracleResult("exact", response, 0, "stage49 one-use private-column zero theorem", scope)
    layer = {(initial, 0): 1}
    terms = []
    evaluations = 0
    if problem.target_rows == initial and (feedback is None or required_uses == 0):
        terms.append(ScalarTerm(CostDegree("physical_cnot", 0, scope), 1, ()))
    for degree in range(1, query.max_degree + 1):
        required = len(layer) * len(problem.alphabet)
        if len(layer) > budget.max_layer_states or evaluations + required > budget.max_transitions:
            return OracleResult("resource_limit", None, evaluations, "complete next layer exceeds declared budget", scope)
        next_layer = defaultdict(int)
        for (rows, uses), count in layer.items():
            for control, target in problem.alphabet:
                next_uses = uses + int(control == feedback) if feedback is not None else 0
                if feedback is not None and next_uses > required_uses:
                    evaluations += 1
                    continue
                moved = list(rows)
                moved[target] ^= moved[control]
                next_layer[(tuple(moved), next_uses)] += count
                evaluations += 1
        if len(next_layer) > budget.max_layer_states:
            return OracleResult("resource_limit", None, evaluations, "next layer state cap exceeded", scope)
        coefficient = next_layer.get((problem.target_rows, required_uses if feedback is not None else 0), 0)
        if coefficient:
            terms.append(ScalarTerm(CostDegree("physical_cnot", degree, scope), coefficient, ()))
        layer = next_layer
    response = ScalarResponse("physical_cnot", scope, "words", tuple(terms))
    return OracleResult("exact", response, evaluations, "complete through requested degree", scope)


@dataclass(frozen=True)
class ThreeRowCost:
    cost: int
    scope: str
    branch: str
    active: tuple[int, int, int]
    currents: tuple[int, ...]


@dataclass(frozen=True)
class ThreeRowProgram:
    gates: tuple[tuple[int, int], ...]
    proven_distance: int
    scope: str
    branch: str
    active: tuple[int, int, int]
    global_lower_bound: int


@dataclass(frozen=True)
class PairGeodesic:
    gates: tuple[tuple[int, int], ...]
    lower_bound: int
    certificate_kind: str
    scope: str
    active: tuple[int, int]


def _support_components(rows):
    n = len(rows)
    parent = list(range(n))

    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for i, row in enumerate(rows):
        for j in range(n):
            if j != i and (row >> j) & 1:
                a, b = root(i), root(j)
                if a != b:
                    parent[a] = b
    return len({root(i) for i in range(n)})


def _two_row_route(goal):
    """Breadth-first search over the six constant-size GL(2,2) frames."""
    initial = (1, 2)
    if goal == initial:
        return ()
    layer = [(initial, ())]
    seen = {initial}
    for _ in range(3):
        upcoming = []
        for frame, route in layer:
            for control, target in ((0, 1), (1, 0)):
                moved = list(frame)
                moved[target] ^= moved[control]
                moved = tuple(moved)
                if moved == goal:
                    return route + ((control, target),)
                if moved not in seen:
                    seen.add(moved)
                    upcoming.append((moved, route + ((control, target),)))
        layer = upcoming
    raise ValueError("unreachable two-row frame")


def pair_geodesic(rows) -> PairGeodesic:
    """Construct a globally shortest full-matrix word in the stage-35 class."""
    rows = tuple(rows)
    n = len(rows)
    if n < 2 or any(type(row) is not int or not 0 <= row < 1 << n for row in rows) or rank(rows) != n:
        raise ValueError("invertible full bitmask matrix with n>=2 required")
    changed = [i for i, row in enumerate(rows) if row != 1 << i]
    if len(changed) > 2:
        raise ValueError("outside at-most-two-changed-rows class")
    active = tuple((changed + [i for i in range(n) if i not in changed])[:2])
    passive = tuple(i for i in range(n) if i not in active)
    core = tuple(sum(((rows[i] >> j) & 1) << k for k, j in enumerate(active))
                 for i in active)
    core_inverse = inverse(core)
    currents = {}
    for j in passive:
        column = _column(rows, j, active)
        currents[j] = sum(((core_inverse[i] & column).bit_count() & 1) << i for i in range(2))
    shared = sum(x == 3 for x in currents.values())
    if core == (1, 2) and shared <= 2:
        gates = tuple((j, active[i]) for j in passive for i in range(2) if (rows[active[i]] >> j) & 1)
    else:
        route = _two_row_route(core) if core != (1, 2) else ((0, 1), (0, 1))
        frames = [(1, 2)]
        for control, target in route:
            moved = list(frames[-1])
            moved[target] ^= moved[control]
            frames.append(tuple(moved))
        frame_directions = tuple(tuple(sum(((inverse(frame)[i] >> target) & 1) << i for i in range(2))
                                       for target in range(2)) for frame in frames)
        placements = [[] for _ in frames]
        for j in passive:
            x = currents[j]
            if x == 0:
                continue
            available = next(((phase, target) for phase, directions in enumerate(frame_directions)
                              for target in range(2)
                              if directions[target] == x), None)
            if available is None:
                raise ArithmeticError("two-row frame route omitted a current")
            phase, target = available
            placements[phase].append((j, active[target]))
        word = []
        for phase, external in enumerate(placements):
            word.extend(external)
            if phase < len(route):
                control, target = route[phase]
                word.append((active[control], active[target]))
        gates = tuple(word)
    reconstructed = [1 << i for i in range(n)]
    for control, target in gates:
        reconstructed[target] ^= reconstructed[control]
    if tuple(reconstructed) != rows:
        raise ArithmeticError("pair geodesic failed its full operator contract")
    connectivity = n - _support_components(rows)
    diagonal_zeros = sum(not ((row >> i) & 1) for i, row in enumerate(rows))
    if core != (1, 2):
        lower = connectivity + diagonal_zeros
        kind = "connectivity_plus_diagonal_zeros"
    elif shared >= 2:
        lower = connectivity + 1
        kind = "tree_obstruction_two_shared_sources"
    else:
        lower = connectivity
        kind = "connectivity"
    if len(gates) != lower:
        raise ArithmeticError("pair geodesic did not match the claimed global bound")
    return PairGeodesic(gates, lower, kind, "full_cnot_alphabet", active)


def _column(rows, column, active):
    return sum(((rows[row] >> column) & 1) << i for i, row in enumerate(active))


def three_row_cost(rows, active):
    """Stage-36 formula on [[B,C],[0,I]], with an explicit alphabet scope.

    This returns a distance only for the named three-target alphabet, except
    for the separately proved B* frame. It does not produce a CNOT word.
    """
    rows = tuple(rows)
    n = len(rows)
    active = tuple(active)
    if n < 3 or len(active) != 3 or len(set(active)) != 3 or any(
        type(i) is not int or not 0 <= i < n for i in active
    ) or any(type(row) is not int or not 0 <= row < 1 << n for row in rows):
        raise ValueError("invalid full matrix or three active wires")
    passive = tuple(i for i in range(n) if i not in active)
    if any(rows[i] != 1 << i for i in passive):
        raise ValueError("passive rows must remain identity")
    core = tuple(_column(rows, column, active) for column in active)
    if core not in ((1, 2, 4), (6, 5, 7)):
        raise ValueError("outside proved stage-36 frame families")
    core_inverse = inverse(core)
    columns = tuple(_column(rows, j, active) for j in passive)
    currents = tuple(sum(((core_inverse[i] & x).bit_count() & 1) << i for i in range(3)) for x in columns)
    counts = tuple(currents.count(v) for v in range(8))
    m = sum(counts[1:])
    if core == (6, 5, 7):
        return ThreeRowCost(m + 4, "full_cnot_alphabet", "saturating_Bstar", active, currents)
    pairs = (3, 5, 6)
    pair_sum = sum(counts[p] for p in pairs)
    triple = counts[7]
    branches = (
        (pair_sum + 2 * triple, "none"),
        (2 + pair_sum - max(counts[p] for p in pairs) + triple, "pair"),
        (4 + min(counts[p] for p in pairs), "square"),
        (5 + triple, "pentagon"),
        (6, "complete"),
    )
    extra, branch = min(branches, key=lambda item: item[0])
    return ThreeRowCost(m + extra, "three_target_alphabet", branch, active, currents)


def _three_routes(core):
    if core == (6, 5, 7):
        return (("saturating_Bstar", ((0, 1), (1, 2), (2, 0), (0, 1))),)
    routes = [("none", ())]
    for pair in (3, 5, 6):
        a, b = (i for i in range(3) if (pair >> i) & 1)
        routes.append(("pair", ((a, b), (a, b))))
    for pair in (3, 5, 6):
        a, b = (i for i in range(3) if (pair >> i) & 1)
        k = next(i for i in range(3) if not (pair >> i) & 1)
        routes.append(("square", ((k, a), (k, b), (k, a), (k, b))))
    routes.append(("pentagon", ((0, 1), (1, 2), (0, 1), (0, 2), (1, 2))))
    routes.append(("complete", ((0, 1), (0, 1), (2, 0), (2, 1), (2, 0), (2, 1))))
    return tuple(routes)


def _three_route_word(route, active, passive, currents):
    frame = [1, 2, 4]
    directions = {}
    for phase in range(len(route) + 1):
        inverted = inverse(tuple(frame))
        for target in range(3):
            direction = sum(((inverted[i] >> target) & 1) << i for i in range(3))
            directions.setdefault(direction, (phase, target))
        if phase < len(route):
            control, target = route[phase]
            frame[target] ^= frame[control]
    by_phase = [[] for _ in range(len(route) + 1)]
    available = tuple(sorted(directions))
    for source, current in zip(passive, currents):
        if current == 0:
            continue
        decomposition = next((choice for size in range(1, 4)
                              for choice in combinations(available, size)
                              if _xor_values(choice) == current), None)
        if decomposition is None:
            raise ArithmeticError("internal route omitted a required three-bit current")
        for direction in decomposition:
            phase, target = directions[direction]
            by_phase[phase].append((source, active[target]))
    word = []
    for phase, external in enumerate(by_phase):
        word.extend(external)
        if phase < len(route):
            control, target = route[phase]
            word.append((active[control], active[target]))
    return tuple(word), tuple(frame)


def _xor_values(values):
    result = 0
    for value in values:
        result ^= value
    return result


def three_row_program(rows, active) -> ThreeRowProgram:
    """Construct a verified word for exactly the stage-36 proved frame families."""
    rows = tuple(rows)
    cost = three_row_cost(rows, active)
    active = cost.active
    n = len(rows)
    passive = tuple(i for i in range(n) if i not in active)
    core = tuple(sum(((rows[i] >> j) & 1) << k for k, j in enumerate(active)) for i in active)
    candidates = []
    for branch, route in _three_routes(core):
        gates, terminal = _three_route_word(route, active, passive, cost.currents)
        if terminal == core:
            candidates.append((len(gates), branch, gates))
    if not candidates:
        raise ArithmeticError("no terminal frame route in proved stage-36 family")
    length, branch, gates = min(candidates, key=lambda item: item[0])
    reconstructed = [1 << i for i in range(n)]
    for control, target in gates:
        reconstructed[target] ^= reconstructed[control]
    if tuple(reconstructed) != rows or length != cost.cost:
        raise ArithmeticError("stage-36 word failed matrix or analytic-cost contract")
    global_lower = n - _support_components(rows) + sum(not ((row >> i) & 1) for i, row in enumerate(rows))
    if cost.scope == "full_cnot_alphabet" and global_lower != length:
        raise ArithmeticError("B* word failed its global lower certificate")
    return ThreeRowProgram(gates, length, cost.scope, branch, active, global_lower)
