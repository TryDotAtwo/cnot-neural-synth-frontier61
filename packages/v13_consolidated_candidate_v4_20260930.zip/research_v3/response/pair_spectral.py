"""Stage29 two-target positive word coefficients via joint Fourier histograms.

Fourier mode coefficients may be signed. Only the final normalized sum is a
positive physical word count. This computes a finite coefficient prefix;
all-order rational resolvents require a separate adapter.
"""
from collections import defaultdict
from fractions import Fraction

from ..gf2 import inverse, rank
from .types import CostDegree, ExactRationalPointValue, OracleResult, ScalarResponse, ScalarTerm


def _frames():
    return tuple((a, b) for a in range(1, 4) for b in range(1, 4) if rank((a, b)) == 2)


def _character_histograms(currents, cap):
    polynomial = {(0, 0, 0, 0): 1}
    operations = 0
    if cap < 1:
        return None, operations
    for current in currents:
        following = defaultdict(int)
        for histogram, coefficient in polynomial.items():
            for frequency in range(4):
                shifted = list(histogram)
                shifted[frequency] += 1
                sign = -1 if ((frequency & current).bit_count() & 1) else 1
                following[tuple(shifted)] += sign * coefficient
                operations += 1
        polynomial = {h: c for h, c in following.items() if c}
        if len(polynomial) > cap:
            return None, operations
    return polynomial, operations


def pair_spectral_response(problem, query, budget):
    """Exact finite stage29 pair-alphabet response without full-state walks."""
    n = len(problem.target_rows)
    active = problem.active_wires
    scope = f"stage29_pair_target_alphabet:n{n}:active{active}"
    if (len(active) != 2 or len(set(active)) != 2 or any(i < 0 or i >= n for i in active) or
            problem.ports.labels or problem.private_wires or problem.frequencies or
            query.feedback_control is not None):
        return OracleResult("unsupported", None, 0, "pair kernel requires two active targets and no extra open boundary", scope)
    expected = {(control, target) for target in active for control in range(n) if control != target}
    if set(problem.alphabet) != expected:
        return OracleResult("unsupported", None, 0, "declared alphabet differs from exact pair-target sector", scope)
    passive = tuple(i for i in range(n) if i not in active)
    if any(problem.target_rows[i] != 1 << i for i in passive):
        return OracleResult("unsupported", None, 0, "passive rows are not the identity boundary", scope)
    core = tuple(sum(((problem.target_rows[i] >> j) & 1) << k for k, j in enumerate(active))
                 for i in active)
    if rank(core) != 2:
        return OracleResult("unsupported", None, 0, "singular two-row terminal frame", scope)
    core_inverse = inverse(core)
    currents = []
    for j in passive:
        column = sum(((problem.target_rows[i] >> j) & 1) << k for k, i in enumerate(active))
        currents.append(sum(((core_inverse[k] & column).bit_count() & 1) << k for k in range(2)))
    histogram_weights, evaluations = _character_histograms(currents, budget.max_layer_states)
    if histogram_weights is None or evaluations > budget.max_transitions:
        return OracleResult("resource_limit", None, evaluations, "histogram construction exceeds explicit budget", scope)
    frames = _frames()
    frame_index = {frame: i for i, frame in enumerate(frames)}
    terminal = frame_index[core]
    origin = frame_index[(1, 2)]
    adjacency = []
    directions = []
    for frame in frames:
        adjacency.append(tuple(frame_index[(frame[0] ^ frame[1], frame[1])] if target == 0 else
                               frame_index[(frame[0], frame[1] ^ frame[0])]
                               for target in range(2)))
        inverted = inverse(frame)
        directions.append(tuple(sum(((inverted[k] >> target) & 1) << k for k in range(2))
                                for target in range(2)))
    projected = len(histogram_weights) * (6 * 8 + query.max_degree * 6 * 3)
    if evaluations + projected > budget.max_transitions:
        return OracleResult("resource_limit", None, evaluations, "spectral recurrence exceeds explicit budget", scope)
    totals = [0] * (query.max_degree + 1)
    for histogram, character_weight in histogram_weights.items():
        potential = [sum(histogram[frequency] *
                         (-1 if ((frequency & direction).bit_count() & 1) else 1)
                         for frequency in range(4) for direction in directions[i])
                     for i in range(6)]
        vector = [int(i == origin) for i in range(6)]
        for degree in range(query.max_degree + 1):
            totals[degree] += character_weight * vector[terminal]
            if degree < query.max_degree:
                vector = [potential[i] * vector[i] + vector[adjacency[i][0]] +
                          vector[adjacency[i][1]] for i in range(6)]
    evaluations += projected
    normalization = 4 ** len(currents)
    if any(value < 0 or value % normalization for value in totals):
        raise ArithmeticError("stage29 signed-mode sum failed positive integer normalization")
    terms = tuple(ScalarTerm(CostDegree("physical_cnot", degree, scope), value // normalization, ())
                  for degree, value in enumerate(totals) if value)
    response = ScalarResponse("physical_cnot", scope, "words", terms)
    return OracleResult("exact", response, evaluations,
                        "complete finite stage29 coefficient prefix; no all-order rational claim", scope)


def _solve_exact_column(matrix, origin):
    """Fraction Gaussian elimination of a constant-size six-frame operator."""
    n = len(matrix)
    a = [row[:] for row in matrix]
    rhs = [Fraction(int(i == origin)) for i in range(n)]
    for column in range(n):
        pivot = next((i for i in range(column, n) if a[i][column]), None)
        if pivot is None:
            raise ArithmeticError("spectral resolvent is singular")
        a[column], a[pivot] = a[pivot], a[column]
        rhs[column], rhs[pivot] = rhs[pivot], rhs[column]
        divisor = a[column][column]
        a[column] = [x / divisor for x in a[column]]
        rhs[column] /= divisor
        for i in range(n):
            if i == column or not a[i][column]:
                continue
            factor = a[i][column]
            a[i] = [x - factor * y for x, y in zip(a[i], a[column])]
            rhs[i] -= factor * rhs[column]
    return rhs


def pair_spectral_resolvent(problem, query, budget):
    """All-order rational value at one safe z, through six-by-six blocks."""
    n = len(problem.target_rows)
    active = problem.active_wires
    scope = f"stage29_pair_target_alphabet:n{n}:active{active}"
    if (len(active) != 2 or len(set(active)) != 2 or any(i < 0 or i >= n for i in active) or
            problem.ports.labels or problem.private_wires or problem.frequencies or
            query.feedback_control is not None):
        return OracleResult("unsupported", None, 0, "pair resolvent boundary outside proved sector", scope)
    expected = {(control, target) for target in active for control in range(n) if control != target}
    if set(problem.alphabet) != expected:
        return OracleResult("unsupported", None, 0, "pair resolvent alphabet differs", scope)
    passive = tuple(i for i in range(n) if i not in active)
    if any(problem.target_rows[i] != 1 << i for i in passive):
        return OracleResult("unsupported", None, 0, "passive boundary differs", scope)
    z = query.fugacity
    if z < 0 or z * 2 * (n - 1) >= 1:
        raise ValueError("stage29 exact resolvent requires 0 <= z < 1/[2(n-1)]")
    core = tuple(sum(((problem.target_rows[i] >> j) & 1) << k for k, j in enumerate(active))
                 for i in active)
    core_inverse = inverse(core)
    currents = tuple(sum(((core_inverse[k] &
                           sum(((problem.target_rows[i] >> j) & 1) << r for r, i in enumerate(active))).bit_count() & 1) << k
                         for k in range(2)) for j in passive)
    weights, evaluations = _character_histograms(currents, budget.max_layer_states)
    if weights is None or evaluations > budget.max_transitions:
        return OracleResult("resource_limit", None, evaluations, "pair histograms exceed budget", scope)
    estimate = len(weights) * 300
    if evaluations + estimate > budget.max_transitions:
        return OracleResult("resource_limit", None, evaluations, "exact six-frame solves exceed budget", scope)
    frames = _frames()
    frame_index = {frame: i for i, frame in enumerate(frames)}
    origin, terminal = frame_index[(1, 2)], frame_index[core]
    directions = tuple(tuple(sum(((inverse(frame)[k] >> target) & 1) << k for k in range(2))
                             for target in range(2)) for frame in frames)
    total = Fraction(0)
    for histogram, character_weight in weights.items():
        operator = [[Fraction(int(i == j)) for j in range(6)] for i in range(6)]
        for i, frame in enumerate(frames):
            potential = sum(histogram[frequency] *
                            (-1 if ((frequency & direction).bit_count() & 1) else 1)
                            for frequency in range(4) for direction in directions[i])
            operator[i][i] -= z * potential
            for target in range(2):
                moved = (frame[0] ^ frame[1], frame[1]) if target == 0 else (frame[0], frame[1] ^ frame[0])
                operator[frame_index[moved]][i] -= z
        total += character_weight * _solve_exact_column(operator, origin)[terminal]
    result = total / (4 ** len(currents))
    if result < 0:
        raise ArithmeticError("negative physical pair resolvent after signed reconstruction")
    return OracleResult("exact_rational_point",
                        ExactRationalPointValue(z, result, scope), evaluations + estimate,
                        "all-order exact rational value at this z; not an unrestricted solver", scope)
