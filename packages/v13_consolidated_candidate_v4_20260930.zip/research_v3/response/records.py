"""Evidence-bounded import of saved stage51 pointwise intervals.

This parser checks exact rational arithmetic and selected-mode replay scope.
It does not independently regenerate all 544 source mode values or turn a
pointwise enclosure into an exact rational function of z.
"""
import hashlib
import json
from fractions import Fraction
from pathlib import Path

from .types import OracleResult, RationalIntervalCertificate


def _fraction(pair):
    if (not isinstance(pair, list) or len(pair) != 2 or
            any(type(x) is not str or not x or not x.lstrip('-').isdigit() for x in pair)):
        raise ValueError("exact rational numerator and denominator strings required")
    numerator, denominator = map(int, pair)
    if denominator <= 0:
        raise ValueError("positive rational denominator required")
    return Fraction(numerator, denominator)


def _digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def stage51_saved_intervals(certificate_file, selected_replay_file):
    """Return four typed pointwise intervals with an explicit 14/544 gap."""
    certificate = json.loads(Path(certificate_file).read_text(encoding="utf-8"))
    replay = json.loads(Path(selected_replay_file).read_text(encoding="utf-8"))
    if replay.get("selected_modes") != 14 or replay.get("coordinate_identities") != 282240:
        raise ValueError("stage51 selected-mode replay coverage differs")
    records = certificate.get("results")
    if not isinstance(records, dict) or len(records) != 4:
        raise ValueError("four stage51 interval records required")
    certificate_sha = _digest(certificate_file)
    replay_sha = _digest(selected_replay_file)
    output = {}
    for key, item in records.items():
        center, radius = _fraction(item["center"]), _fraction(item["radius"])
        lower, upper = _fraction(item["lower"]), _fraction(item["upper"])
        if radius < 0 or lower != center - radius or upper != center + radius:
            raise ValueError("stored interval endpoints fail exact arithmetic")
        denominator, order = item["denominator"], item["order"]
        if type(denominator) is not int or denominator <= 0 or type(order) is not int or order < 0:
            raise ValueError("invalid stage51 point and polynomial order")
        expected = f"results/cheb_d{denominator}_k{order}_eta{item['charge_weight']}.tsv"
        if key != expected:
            raise ValueError("stage51 result identity mismatch")
        interval = RationalIntervalCertificate(
            Fraction(1, denominator), lower, upper,
            f"stage51_saved_certificate_sha256:{certificate_sha}",
            f"source_Chebyshev_bound;selected_replay_sha256:{replay_sha};not_all_modes_replayed",
            544, 14,
        )
        output[key] = OracleResult("certified_interval", interval, 0,
                                   "pointwise source certificate with selected-mode replay; 530 mode values not independently repeated",
                                   f"stage51_dynamic_source:z=1/{denominator}")
    return output
