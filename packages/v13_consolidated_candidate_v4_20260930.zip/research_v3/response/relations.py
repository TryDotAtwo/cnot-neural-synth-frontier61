"""Exact finite reference composition; exponential by design, never silently truncated."""
from dataclasses import dataclass
from .types import (LabeledPorts,WeightedTerm,WeightedResponse,ScalarTerm,ScalarResponse,
                    RelationTerm,RelationResponse,SymbolicBudget,CostDegree,ResponseBudget,OracleResult)
from .types import AffineRelation


@dataclass(frozen=True)
class AffineComposition:
    relation: AffineRelation
    free_port_dimension: int
    fiber_multiplicity: int
    compatible: bool


def protected_initial_projection(relation:AffineRelation)->AffineRelation:
    """Row-space intersection with initial coordinates, never mask truncation."""
    protected=relation.ports.protected_initial
    index={name:i for i,name in enumerate(relation.ports.labels)}
    deleted=[i for i,name in enumerate(relation.ports.labels) if name not in protected]
    rows=[list(row) for row in relation.equations]
    pivot_count=0
    for bit_index in deleted:
        bit=1<<bit_index
        selected=next((j for j in range(pivot_count,len(rows)) if rows[j][0]&bit),None)
        if selected is None:continue
        rows[pivot_count],rows[selected]=rows[selected],rows[pivot_count]
        mask,rhs=rows[pivot_count]
        for j in range(len(rows)):
            if j!=pivot_count and rows[j][0]&bit:
                rows[j][0]^=mask;rows[j][1]^=rhs
        pivot_count+=1
    equations=tuple((sum(1<<j for j,name in enumerate(protected) if mask>>index[name]&1),rhs)
                    for mask,rhs in rows[pivot_count:])
    output_ports=LabeledPorts(protected,protected)
    output=AffineRelation(output_ports,relation.width,equations)
    return AffineRelation(output_ports,relation.width,output.canonical_equations())


def compose_affine_relations(left:AffineRelation,right:AffineRelation,interface:tuple[str,...])->AffineComposition:
    """Exact GF(2)^width fiber elimination, including affine RHS and free factor."""
    if left.width!=right.width:
        raise ValueError('relation vector widths differ')
    common=set(left.ports.labels)&set(right.ports.labels)
    if (len(set(interface))!=len(interface) or any(x not in common for x in interface) or
            any(x in left.ports.protected_initial or x in right.ports.protected_initial for x in interface)):
        raise ValueError('invalid or protected interface')
    union=left.ports.labels+tuple(x for x in right.ports.labels if x not in left.ports.labels)
    output=tuple(x for x in union if x not in interface)
    protected=tuple(dict.fromkeys(left.ports.protected_initial+right.ports.protected_initial))
    index={x:i for i,x in enumerate(union)}
    equations=[]
    for relation in (left,right):
        for mask,rhs in relation.equations:
            wide=sum(1<<index[name] for i,name in enumerate(relation.ports.labels) if mask>>i&1)
            equations.append([wide,rhs])
    # Pivot on eliminated port coefficients; remaining rows constrain the output.
    pivot_count=0
    for name in interface:
        bit=1<<index[name]
        pivot=next((j for j in range(pivot_count,len(equations)) if equations[j][0]&bit),None)
        if pivot is None:continue
        equations[pivot_count],equations[pivot]=equations[pivot],equations[pivot_count]
        p_mask,p_rhs=equations[pivot_count]
        for j in range(len(equations)):
            if j!=pivot_count and equations[j][0]&bit:
                equations[j][0]^=p_mask;equations[j][1]^=p_rhs
        pivot_count+=1
    output_equations=[]
    for mask,rhs in equations[pivot_count:]:
        if any(mask>>index[name]&1 for name in interface):raise AssertionError('interface elimination incomplete')
        projected=sum(1<<i for i,name in enumerate(output) if mask>>index[name]&1)
        output_equations.append((projected,rhs))
    compatible=not any(mask==0 and rhs!=0 for mask,rhs in output_equations)
    relation=AffineRelation(LabeledPorts(output,protected),left.width,tuple(output_equations))
    free=len(interface)-pivot_count
    return AffineComposition(relation,free,(1<<(left.width*free)) if compatible else 0,compatible)


def compose_response(left:WeightedResponse,right:WeightedResponse,interface:tuple[str,...],budget:ResponseBudget)->OracleResult:
    if not isinstance(budget,ResponseBudget):
        raise ValueError('explicit response budget required')
    if not isinstance(left,WeightedResponse) or not isinstance(right,WeightedResponse):
        return OracleResult('unsupported',None,0,'positive full-port responses required before count composition','type_guard')
    if left.width!=right.width or (left.unit,left.scope_id,left.count_kind)!=(right.unit,right.scope_id,right.count_kind):
        return OracleResult('unsupported',None,0,'incompatible width, cost scope, or count semantics',left.scope_id)
    shared=set(left.ports.labels)&set(right.ports.labels)
    if (len(set(interface))!=len(interface) or any(x not in shared for x in interface) or
            any(x in left.ports.protected_initial or x in right.ports.protected_initial for x in interface)):
        return OracleResult('unsupported',None,0,'invalid or protected interface',left.scope_id)
    output_labels=tuple(x for x in left.ports.labels if x not in interface)+tuple(
        x for x in right.ports.labels if x not in left.ports.labels and x not in interface)
    protected=tuple(dict.fromkeys(left.ports.protected_initial+right.ports.protected_initial))
    ports=LabeledPorts(output_labels,protected)
    li={x:i for i,x in enumerate(left.ports.labels)}
    ri={x:i for i,x in enumerate(right.ports.labels)}
    accumulated={};evaluations=0
    for a in left.terms:
        for b in right.terms:
            if evaluations>=budget.max_assignment_pairs:
                return OracleResult('resource_limit',None,evaluations,'assignment pair budget',left.scope_id)
            evaluations+=1
            if any(a.assignment[li[x]]!=b.assignment[ri[x]] for x in shared):continue
            assignment=tuple(a.assignment[li[x]] if x in li else b.assignment[ri[x]] for x in output_labels)
            cost=a.degree.value+b.degree.value
            key=(assignment,cost)
            if key not in accumulated and len(accumulated)>=budget.max_output_terms:
                return OracleResult('resource_limit',None,evaluations,'output term budget',left.scope_id)
            coefficient=a.multiplicity*b.multiplicity
            witness=a.witness+b.witness
            if key in accumulated:
                old,first=accumulated[key]
                accumulated[key]=(old+coefficient,first)
            else:accumulated[key]=(coefficient,witness)
    if output_labels:
        terms=tuple(WeightedTerm(assignment,CostDegree(left.unit,cost,left.scope_id),coefficient,witness)
                    for (assignment,cost),(coefficient,witness) in sorted(accumulated.items()))
        response=WeightedResponse(ports,left.width,left.unit,left.scope_id,left.count_kind,terms)
    else:
        terms=tuple(ScalarTerm(CostDegree(left.unit,cost,left.scope_id),coefficient,witness)
                    for (_,cost),(coefficient,witness) in sorted(accumulated.items()))
        response=ScalarResponse(left.unit,left.scope_id,left.count_kind,terms)
    return OracleResult('exact',response,
                        evaluations,'complete finite assignment composition',left.scope_id)


def compose_symbolic(left:RelationResponse,right:RelationResponse,interface:tuple[str,...],budget:SymbolicBudget)->OracleResult:
    """Positive relation sum/product with exact affine fiber factors and no assignment table."""
    if not isinstance(budget,SymbolicBudget):raise ValueError('explicit symbolic budget required')
    if not isinstance(left,RelationResponse) or not isinstance(right,RelationResponse):
        return OracleResult('unsupported',None,0,'positive relation responses required before symbolic composition','type_guard')
    if left.width!=right.width or (left.unit,left.scope_id,left.count_kind)!=(right.unit,right.scope_id,right.count_kind):
        return OracleResult('unsupported',None,0,'incompatible width, cost scope, or count semantics',left.scope_id)
    accumulated={};evaluations=0;ports=None
    for a in left.terms:
        for b in right.terms:
            if evaluations>=budget.max_term_pairs:
                return OracleResult('resource_limit',None,evaluations,'symbolic term pair budget',left.scope_id)
            evaluations+=1
            try:joined=compose_affine_relations(a.relation,b.relation,interface)
            except ValueError as error:
                return OracleResult('unsupported',None,evaluations,str(error),left.scope_id)
            ports=joined.relation.ports
            if not joined.compatible:continue
            relation=AffineRelation(ports,left.width,joined.relation.canonical_equations())
            cost=a.degree.value+b.degree.value
            key=(relation.equations,cost)
            if key not in accumulated and len(accumulated)>=budget.max_output_relations:
                return OracleResult('resource_limit',None,evaluations,'symbolic relation budget',left.scope_id)
            coefficient=a.multiplicity*b.multiplicity*joined.fiber_multiplicity
            witness=a.witness+b.witness
            if key in accumulated:
                old,first=accumulated[key];accumulated[key]=(old+coefficient,first)
            else:accumulated[key]=(coefficient,witness)
    if ports is None:
        # Even zero-term responses have a well-defined interface scope.
        try:ports=compose_affine_relations(AffineRelation(left.ports,left.width,()),
                                           AffineRelation(right.ports,right.width,()),interface).relation.ports
        except ValueError as error:return OracleResult('unsupported',None,evaluations,str(error),left.scope_id)
    if ports.labels:
        terms=tuple(RelationTerm(AffineRelation(ports,left.width,equations),
                                CostDegree(left.unit,cost,left.scope_id),coefficient,witness)
                    for (equations,cost),(coefficient,witness) in sorted(accumulated.items()))
        response=RelationResponse(ports,left.width,left.unit,left.scope_id,left.count_kind,terms)
    else:
        terms=tuple(ScalarTerm(CostDegree(left.unit,cost,left.scope_id),coefficient,witness)
                    for (_,cost),(coefficient,witness) in sorted(accumulated.items()))
        response=ScalarResponse(left.unit,left.scope_id,left.count_kind,terms)
    return OracleResult('exact',response,evaluations,'exact positive affine relation composition',left.scope_id)
