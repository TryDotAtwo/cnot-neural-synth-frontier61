"""Stage50 full core plus passive outputs, retaining the private input column.

The 16-bin joint Fourier frequency stays fixed across every feedback return.
Only final positive endpoint coefficients are exposed to the response API.
"""
from collections import defaultdict
from dataclasses import replace
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path

from .feedback_spectral import _FRAMES
from .types import (CostDegree, OracleResult, RationalIntervalCertificate,
                    ScalarResponse, ScalarTerm)


_CORE_GATES = ((0, 1), (0, 2), (1, 2), (2, 1), (1, 3), (2, 3), (3, 1))
_STATES = tuple(tuple((row << 1) | ((alpha >> i) & 1) for i, row in enumerate(frame))
                for frame in _FRAMES for alpha in range(8))
_INDEX = {state: i for i, state in enumerate(_STATES)}
_ORIGIN = _INDEX[(2, 4, 8)]


def _histograms(additions, cap):
    if cap < 1:
        return None, 0
    modes = {(0,) * 16: 1}
    evaluations = 0
    for addition in additions:
        following = defaultdict(int)
        for hist, weight in modes.items():
            for frequency in range(16):
                shifted = list(hist)
                shifted[frequency] += 1
                sign = -1 if ((frequency & addition).bit_count() & 1) else 1
                following[tuple(shifted)] += sign * weight
                evaluations += 1
        modes = {h: value for h, value in following.items() if value}
        if len(modes) > cap:
            return None, evaluations
    return modes, evaluations


def _boundary(problem, query):
    n = len(problem.target_rows)
    active = problem.active_wires
    scope = f"stage50_shared_feedback_alphabet:n{n}:source_hky{active}"
    if len(active) != 4 or problem.ports.labels or problem.frequencies:
        return scope, None
    source, h, k, y = active
    if query.feedback_control is not None and query.feedback_control != y:
        return scope, None
    passive = tuple(i for i in range(n) if i not in active)
    expected = {(source, h), (source, k), (h, k), (k, h),
                (h, y), (k, y), (y, h)}
    expected |= {(c, p) for p in passive for c in (h, k)}
    if set(problem.alphabet) != expected or problem.target_rows[source] != 1 << source:
        return scope, None
    allowed = sum(1 << wire for wire in active)
    if any(problem.target_rows[wire] & ~allowed for wire in (h, k, y)):
        return scope, None
    def local(row):
        return sum(((row >> wire) & 1) << j for j, wire in enumerate(active))
    endpoint = tuple(local(problem.target_rows[wire]) for wire in (h, k, y))
    if endpoint not in _INDEX:
        return scope, None
    additions = []
    for wire in passive:
        row = problem.target_rows[wire]
        if row & ~(allowed | (1 << wire)) or not ((row >> wire) & 1):
            return scope, None
        additions.append(local(row))
    return scope, (endpoint, tuple(additions))


def shared_feedback_response(problem, query, budget):
    scope, boundary = _boundary(problem, query)
    if boundary is None:
        return OracleResult("unsupported", None, 0, "outside fixed-source shared-feedback sector", scope)
    endpoint, additions = boundary
    if query.fugacity is not None:
        z = query.fugacity
        alphabet_size = 7 + 2 * len(additions)
        if z < 0 or z * alphabet_size >= 1:
            return OracleResult("unsupported", None, 0,
                                "nonnegative fugacity below inverse alphabet size required", scope)
        finite = shared_feedback_response(problem, replace(query, fugacity=None), budget)
        if finite.status != "exact":
            return finite
        prefix = sum(Fraction(term.multiplicity) * z ** term.degree.value
                     for term in finite.response.terms)
        tail = (alphabet_size * z) ** (query.max_degree + 1) / (1 - alphabet_size * z)
        mode_count = len(_histograms(additions, budget.max_layer_states)[0])
        interval = RationalIntervalCertificate(
            z, prefix, prefix + tail,
            f"own_complete_finite_prefix_degree{query.max_degree}_geometric_alphabet_tail",
            "all_physical_words_nonnegative_coefficient_and_alphabet_cardinality_bound",
            mode_count, mode_count)
        return OracleResult("certified_interval", interval, finite.evaluations,
                            "all-order pointwise enclosure from exact prefix and rigorous tail",
                            f"{finite.scope_id}:z{z}:prefix_degree{query.max_degree}")
    marked = query.feedback_uses
    charged = query.charged_uses
    if marked is not None:
        scope += f":feedback_uses{marked}"
    if charged is not None:
        scope += f":charged_uses{charged}"
    modes, evaluations = _histograms(additions, budget.max_layer_states)
    if modes is None or evaluations > budget.max_transitions:
        return OracleResult("resource_limit", None, evaluations, "joint 16-bin histogram budget", scope)
    states = 1344 * (1 if marked is None else marked + 1) * (1 if charged is None else charged + 1)
    estimate = len(modes) * states * 9 * (query.max_degree + 1)
    if states > budget.max_layer_states or evaluations + estimate > budget.max_transitions:
        return OracleResult("resource_limit", None, evaluations, "shared-feedback core recurrence budget", scope)
    permutations = []
    for control, target in _CORE_GATES:
        mapping = []
        for state in _STATES:
            moved = list(state)
            moved[target - 1] ^= 1 if control == 0 else state[control - 1]
            mapping.append(_INDEX[tuple(moved)])
        permutations.append(tuple(mapping))
    terminal = _INDEX[endpoint]
    totals = [0] * (query.max_degree + 1)
    for histogram, weight in modes.items():
        charges = tuple(sum(count * (-1 if ((frequency & direction).bit_count() & 1) else 1)
                            for frequency, count in enumerate(histogram)) for direction in range(16))
        diagonal = tuple(charges[state[0]] + charges[state[1]] for state in _STATES)
        if charged is not None:
            clean = tuple(sum(charges[row] for row in state[:2] if not row & 8)
                          for state in _STATES)
            dirty = tuple(sum(charges[row] for row in state[:2] if row & 8)
                          for state in _STATES)
            qmax = marked if marked is not None else 0
            vector = {( _ORIGIN, 0, 0): 1}
            for degree in range(query.max_degree + 1):
                totals[degree] += weight * sum(
                    count for (index, q, r), count in vector.items()
                    if index == terminal and q == qmax and r == charged)
                if degree == query.max_degree:
                    break
                following = defaultdict(int)
                for (index, q, r), count in vector.items():
                    following[(index, q, r)] += clean[index] * count
                    if r < charged:
                        following[(index, q, r + 1)] += dirty[index] * count
                    for mapping in permutations[:6]:
                        following[(mapping[index], q, r)] += count
                    if marked is None:
                        following[(permutations[6][index], q, r)] += count
                    elif q < marked:
                        following[(permutations[6][index], q + 1, r)] += count
                vector = {key: value for key, value in following.items() if value}
        elif marked is None:
            vector = [int(i == _ORIGIN) for i in range(1344)]
            for degree in range(query.max_degree + 1):
                totals[degree] += weight * vector[terminal]
                if degree == query.max_degree:
                    break
                following = [diagonal[i] * vector[i] for i in range(1344)]
                for mapping in permutations:
                    for i, count in enumerate(vector):
                        if count:
                            following[mapping[i]] += count
                vector = following
        else:
            vector = [[0] * (marked + 1) for _ in range(1344)]
            vector[_ORIGIN][0] = 1
            for degree in range(query.max_degree + 1):
                totals[degree] += weight * vector[terminal][marked]
                if degree == query.max_degree:
                    break
                following = [[0] * (marked + 1) for _ in range(1344)]
                for i, row in enumerate(vector):
                    for uses, count in enumerate(row):
                        if not count:
                            continue
                        following[i][uses] += diagonal[i] * count
                        for mapping in permutations[:6]:
                            following[mapping[i]][uses] += count
                        if uses < marked:
                            following[permutations[6][i]][uses + 1] += count
                vector = following
    normalization = 16 ** len(additions)
    if any(value < 0 or value % normalization for value in totals):
        raise ArithmeticError("shared feedback Fourier modes failed positive integer normalization")
    terms = tuple(ScalarTerm(CostDegree("physical_cnot", degree, scope), value // normalization, ())
                  for degree, value in enumerate(totals) if value)
    return OracleResult("exact", ScalarResponse("physical_cnot", scope, "words", terms),
                        evaluations + estimate,
                        "complete finite shared-feedback coefficient prefix with full passive boundary", scope)


def verify_stage50_certificate(certificate, budget, *, certificate_sha):
    """Rebuild every saved 1344-coordinate integer residual independently."""
    from .local import LocalBudget
    if not isinstance(budget, LocalBudget):
        raise TypeError("explicit local verification budget required")
    if (certificate.get("format") != 1 or certificate.get("n_core_states") != 1344 or
            certificate.get("core_rows") != [list(row) for row in _STATES]):
        raise ValueError("stage50 full-core coordinate inventory differs")
    additions = tuple(certificate["increments"])
    endpoint = tuple(certificate["endpoint"])
    denominator = certificate["denominator"]
    gamma = certificate["feedback_weight"]
    eta = certificate["charged_weight"]
    bits = certificate["dyadic_bits"]
    norm_bound = 6 + gamma + 2*len(additions)*max(1, eta)
    if (endpoint not in _INDEX or any(type(x) is not int or not 0 <= x < 16 for x in additions) or
            any(type(x) is not int or x < 0 for x in (gamma, eta)) or
            type(denominator) is not int or denominator <= norm_bound or
            type(bits) is not int or not 60 <= bits <= 800 or
            certificate["norm_bound"] != norm_bound):
        raise ValueError("stage50 certificate convergence or full endpoint hypothesis differs")
    histograms, histogram_ops = _histograms(additions, budget.max_layer_states)
    if histograms is None:
        return OracleResult("resource_limit", None, histogram_ops, "stage50 mode cap", "stage50_certificate")
    estimate = len(histograms) * 1344 * 9
    if budget.max_layer_states < 1344 or histogram_ops + estimate > budget.max_transitions:
        return OracleResult("resource_limit", None, histogram_ops,
                            "stage50 complete residual budget", "stage50_certificate")
    records = certificate["modes"]
    if len(records) != len(histograms):
        raise ValueError("stage50 certificate mode inventory incomplete")
    permutations = []
    for control, target in _CORE_GATES:
        mapping = []
        for state in _STATES:
            moved = list(state)
            moved[target - 1] ^= 1 if control == 0 else state[control - 1]
            mapping.append(_INDEX[tuple(moved)])
        permutations.append(tuple(mapping))
    dyadic = 1 << bits
    origin, terminal = _ORIGIN, _INDEX[endpoint]
    center_numerator = residual_sum = 0
    seen = set()
    for item in records:
        hist = tuple(item["histogram"])
        if hist in seen or hist not in histograms or item["weight"] != histograms[hist]:
            raise ValueError("stage50 duplicate, foreign or wrong-weight mode")
        seen.add(hist)
        column = tuple(int(value, 16) for value in item["numerators_hex"])
        if len(column) != 1344:
            raise ValueError("stage50 incomplete 1344-coordinate mode column")
        charges = tuple(sum(count * (-1 if ((frequency & direction).bit_count() & 1) else 1)
                            for frequency, count in enumerate(hist)) for direction in range(16))
        rmax = 0
        for i, state in enumerate(_STATES):
            diagonal = (charges[state[0]] * (eta if state[0] & 8 else 1) +
                        charges[state[1]] * (eta if state[1] & 8 else 1))
            action = diagonal * column[i]
            for gate, mapping in enumerate(permutations):
                action += (gamma if gate == 6 else 1) * column[mapping[i]]
            residual = denominator*dyadic*int(i == origin) - denominator*column[i] + action
            rmax = max(rmax, abs(residual))
        if rmax != int(item["residual_inf_hex"], 16):
            raise ValueError("stage50 exact integer residual differs")
        center_numerator += histograms[hist] * column[terminal]
        residual_sum += abs(histograms[hist]) * rmax
    if seen != set(histograms):
        raise ValueError("stage50 missing joint frequency mode")
    scale = (16 ** len(additions)) * dyadic
    center = Fraction(center_numerator, scale)
    radius = Fraction(residual_sum, scale * (denominator - norm_bound))
    lower, upper = center - radius, center + radius
    def saved(pair):
        if len(pair) != 2 or any(type(x) is not str for x in pair):
            raise ValueError("stage50 stored rational interval malformed")
        return Fraction(int(pair[0]), int(pair[1]))
    if (lower, upper) != (saved(certificate["lower"]), saved(certificate["upper"])):
        raise ValueError("stage50 saved interval does not follow residuals")
    scope = f"stage50_shared_feedback:z=1/{denominator}:gamma{gamma}:eta{eta}:m{len(additions)}"
    interval = RationalIntervalCertificate(Fraction(1, denominator), lower, upper,
                                           f"stage50_certificate_sha256:{certificate_sha}",
                                           "independent_all_mode_all_coordinate_integer_residuals",
                                           len(histograms), len(seen))
    return OracleResult("certified_interval", interval, histogram_ops + estimate,
                        "all saved mode coordinates independently residual-checked", scope)


def stage50_saved_interval(path, budget):
    data = Path(path).read_bytes()
    certificate = json.loads(data)
    return verify_stage50_certificate(certificate, budget,
                                      certificate_sha=sha256(data).hexdigest())
