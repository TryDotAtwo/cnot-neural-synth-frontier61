"""Exact fifteen-channel source charts for the stage51 full-row core.

Chart changes are coordinate changes only. They carry neither zero-cost CNOT
operations nor independent passive-frequency resets.
"""
from dataclasses import dataclass
from functools import lru_cache

import numpy as np

from ..gf2 import inverse, rank


def right_product(rows, matrix):
    """Multiply packed-row binary matrices, preserving physical row order."""
    return tuple(_xor_rows(row, matrix) for row in rows)


def _xor_rows(mask, rows):
    value = 0
    for column, row in enumerate(rows):
        if mask >> column & 1:
            value ^= row
    return value


@lru_cache(maxsize=15)
def source_chart(source_row):
    if type(source_row) is not int or not 1 <= source_row < 16:
        raise ValueError("nonzero four-bit source row required")
    rows = [source_row]
    for unit in (1, 2, 4, 8):
        if rank((*rows, unit)) > len(rows):
            rows.append(unit)
    if len(rows) != 4:
        raise ArithmeticError("source chart failed to span four-bit rows")
    return tuple(rows)


@lru_cache(maxsize=15)
def inverse_source_chart(source_row):
    return inverse(source_chart(source_row))


def to_channel(physical_frame):
    source = physical_frame[0]
    fixed = right_product(physical_frame, inverse_source_chart(source))
    if fixed[0] != 1:
        raise ArithmeticError("source chart did not normalize source row")
    return source, fixed


def from_channel(source, fixed_frame):
    if fixed_frame[0] != 1:
        raise ValueError("fixed-source chart frame required")
    return right_product(fixed_frame, source_chart(source))


def pushed_frequency(source, frequency):
    if type(frequency) is not int or not 0 <= frequency < 16:
        raise ValueError("four-bit passive frequency required")
    return tuple((row & frequency).bit_count() & 1 for row in source_chart(source))


def pushed_frequency_bits(source, frequency):
    return sum(bit << i for i, bit in enumerate(pushed_frequency(source, frequency)))


def source_update_in_channels(source, fixed_frame):
    """One physical h→s, including its change of source chart."""
    physical_h = right_product((fixed_frame[1],), source_chart(source))[0]
    next_source = source ^ physical_h
    if next_source == 0 or next_source == source:
        raise ArithmeticError("invertible frame left a zero or unchanged source")
    moved = list(fixed_frame)
    moved[0] ^= moved[1]
    chart_change = right_product(source_chart(source), inverse_source_chart(next_source))
    next_frame = right_product(moved, chart_change)
    if next_frame[0] != 1:
        raise ArithmeticError("source update failed new chart normalization")
    return next_source, next_frame


@dataclass(frozen=True)
class SourceChannelMaps:
    sector: np.ndarray
    local_index: np.ndarray
    source_update: np.ndarray
    channel_sizes: tuple[int, ...]


@lru_cache(maxsize=1)
def source_channel_maps():
    """Enumerate and sew all 15×1344 coordinates once."""
    from .dynamic_source import _core

    frames, index, _, _ = _core()
    fixed = tuple(frame for frame in frames if frame[0] == 1)
    fixed_index = {frame: i for i, frame in enumerate(fixed)}
    if len(fixed) != 1344:
        raise ArithmeticError("fixed-source sector is not 1344-dimensional")
    sector = np.empty(len(frames), dtype=np.int16)
    local = np.empty(len(frames), dtype=np.int16)
    source_map = np.empty(len(frames), dtype=np.int32)
    counts = [0] * 15
    for i, frame in enumerate(frames):
        source, local_frame = to_channel(frame)
        sector[i] = source - 1
        local[i] = fixed_index[local_frame]
        counts[source - 1] += 1
        next_source, next_frame = source_update_in_channels(source, local_frame)
        source_map[i] = index[from_channel(next_source, next_frame)]
    if any(count != 1344 for count in counts) or len(set(zip(sector, local))) != len(frames):
        raise ArithmeticError("source-channel coordinates are incomplete or duplicate")
    return SourceChannelMaps(sector, local, source_map, tuple(counts))
