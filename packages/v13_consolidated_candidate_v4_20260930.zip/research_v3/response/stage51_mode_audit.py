"""Exact coverage and interval audit of independently replayed stage51 modes."""
import argparse
from dataclasses import asdict, dataclass
from fractions import Fraction
from hashlib import sha256
import json
import os
from pathlib import Path

from .stage51_mode_replay import read_table


@dataclass(frozen=True)
class ModeAudit:
    completed_modes: int
    expected_modes: int
    coordinate_identities: int
    certified_tables: tuple[str, ...]
    incomplete_tables: tuple[str, ...]


def _fraction(pair):
    if (not isinstance(pair, list) or len(pair) != 2 or
            any(type(x) is not str for x in pair)):
        raise ValueError("exact saved fraction pair required")
    return Fraction(int(pair[0]), int(pair[1]))


def audit_mode_journal(journal_path, results_dir, saved_certificates_path):
    results_dir = Path(results_dir)
    journal_path = Path(journal_path)
    saved = json.loads(Path(saved_certificates_path).read_text(encoding="utf-8"))["results"]
    code_sha = sha256((Path(__file__).parent / "stage51_mode_replay.py").read_bytes()).hexdigest()
    entries = [json.loads(line) for line in journal_path.read_text(encoding="utf-8").splitlines()]
    observed = {}
    tables = []
    for denominator, order in ((312, 24), (13, 128)):
        for eta in (1, 0):
            name = f"cheb_d{denominator}_k{order}_eta{eta}.tsv"
            path = results_dir / name
            metadata, records = read_table(path)
            digest = sha256(path.read_bytes()).hexdigest()
            tables.append((path, metadata, records, digest))
            observed[str(path.resolve())] = {}
    for item in entries:
        path = item.get("source_path")
        if path not in observed or item.get("replay_code_sha256") != code_sha:
            raise ValueError("journal has a foreign table or replay code")
        target = next(table for table in tables if str(table[0].resolve()) == path)
        table_path, metadata, records, digest = target
        coordinate = (item.get("i"), item.get("j"))
        if (item.get("source_sha256") != digest or coordinate not in records or
                coordinate in observed[path] or
                item.get("endpoint_integer") != str(records[coordinate]) or
                item.get("coordinate_identities") != 20160 or
                (item.get("denominator"), item.get("order"), item.get("eta")) !=
                (metadata["denominator"], metadata["order"], metadata["eta"])):
            raise ValueError("journal mode identity, value, or all-coordinate scope differs")
        observed[path][coordinate] = item
    certified = []
    incomplete = []
    for path, metadata, records, digest in tables:
        name = f"results/{path.name}"
        replayed = observed[str(path.resolve())]
        if len(replayed) != 136:
            incomplete.append(name)
            continue
        weighted = sum((1 if i == j else 2) *
                       (-1 if (((i ^ j) & 3).bit_count() & 1) else 1) * records[(i, j)]
                       for i, j in sorted(records))
        denominator, order, pk = (metadata[key] for key in ("denominator", "order", "pk"))
        center = Fraction(denominator * weighted, 256 * pk)
        radius = Fraction(denominator * 12 ** order, (denominator - 12) * pk)
        result = saved[name]
        if (center, radius, center-radius, center+radius) != tuple(
                _fraction(result[key]) for key in ("center", "radius", "lower", "upper")):
            raise ArithmeticError("stage51 saved interval does not follow independently replayed modes")
        certified.append(name)
    return ModeAudit(len(entries), 544, 20160 * len(entries),
                     tuple(certified), tuple(incomplete))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--journal", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--certificates", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    audit = audit_mode_journal(args.journal, args.source, args.certificates)
    if audit.completed_modes != 544 or audit.incomplete_tables:
        raise ValueError("all 544 exact mode residuals required for final audit")
    source_hashes = {path.name: sha256(path.read_bytes()).hexdigest()
                     for path in sorted(args.source.glob("cheb_d*_k*_eta*.tsv"))}
    if len(source_hashes) != 4:
        raise ValueError("exactly four stage51 mode tables required")
    record = {"format": 1, "audit": asdict(audit),
              "journal_sha256": sha256(args.journal.read_bytes()).hexdigest(),
              "certificate_sha256": sha256(args.certificates.read_bytes()).hexdigest(),
              "replay_code_sha256": sha256((Path(__file__).parent / "stage51_mode_replay.py").read_bytes()).hexdigest(),
              "audit_code_sha256": sha256(Path(__file__).read_bytes()).hexdigest(),
              "current_core_file_sha256": sha256((Path(__file__).parent / "dynamic_source.py").read_bytes()).hexdigest(),
              "current_channel_file_sha256": sha256((Path(__file__).parent / "source_channels.py").read_bytes()).hexdigest(),
              "source_table_sha256": source_hashes,
              "claim": "all four stage51 pointwise intervals reconstructed from 544 exact mode values and 10967040 integer coordinate identities"}
    output = args.output
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_name(output.name + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(record, handle, sort_keys=True, indent=2)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, output)
    print(json.dumps({"output": str(output), "modes": 544,
                      "coordinate_identities": 10967040}, sort_keys=True))


if __name__ == "__main__":
    main()
