"""Independent exact replay of all saved stage51 Chebyshev mode values.

Uses the research_v3 full physical core, not the source C++ producer or its
Python verifier. Every completed mode checks all 20160 integer coordinates of
the divided-difference residual before it enters the durable journal.
"""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path

import numpy as np

from .dynamic_source import _core
from .source_channels import source_channel_maps


def _sha(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def read_table(path):
    metadata = {}
    records = {}
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        if line.startswith("# "):
            key, value = line[2:].split(" ", 1)
            if key in ("denominator", "order", "lambda", "gamma", "eta", "norm_bound", "pk"):
                metadata[key] = int(value)
        elif line and line[0].isdigit():
            i, j, weight, value = map(int, line.split())
            if not 0 <= i <= j < 16 or (i, j) in records:
                raise ValueError("duplicate or invalid stage51 mode coordinate")
            expected_weight = (1 if i == j else 2) * (-1 if (((i ^ j) & 3).bit_count() & 1) else 1)
            if weight != expected_weight:
                raise ValueError("stage51 Fourier mode weight differs")
            records[(i, j)] = value
    if (set(records) != {(i, j) for i in range(16) for j in range(i, 16)} or
            sum(abs(1 if i == j else 2) for i, j in records) != 256 or
            metadata.get("lambda") != 1 or metadata.get("gamma") != 1 or
            metadata.get("eta") not in (0, 1) or metadata.get("norm_bound") != 12 or
            metadata.get("denominator", 0) <= 12 or metadata.get("order", 0) < 1):
        raise ValueError("stage51 complete saved table contract differs")
    return metadata, records


def replay_mode(i, j, denominator, order, eta, expected):
    """Rebuild a mode and independently check its entire polynomial residual."""
    frames, index, permutations, rows = _core()
    source_map = source_channel_maps().source_update
    if not np.array_equal(source_map, permutations[7]):
        raise ArithmeticError("source chart and physical operator differ")
    signs = np.asarray([1 - 2 * (x.bit_count() & 1) for x in range(16)], dtype=np.int16)
    diagonal = np.asarray(signs[rows[:, 1] & i] + signs[rows[:, 2] & i] +
                          signs[rows[:, 1] & j] + signs[rows[:, 2] & j], dtype=object)
    source_weight = np.asarray([eta if row[1] & 8 else 1 for row in frames], dtype=object)
    origin, terminal = index[(1, 2, 4, 8)], index[(1, 2, 4, 15)]
    n = len(frames)

    def action(vector):
        result = diagonal * vector
        for permutation in permutations[:7]:
            result[permutation] += vector
        result[source_map] += source_weight * vector
        return result

    unit = np.zeros(n, dtype=object)
    unit[origin] = 1
    p_previous, p_current = unit.copy(), action(unit)
    q_previous, q_current = np.zeros(n, dtype=object), unit.copy()
    scalar_previous, scalar_current = 1, denominator
    for _ in range(1, order):
        p_previous, p_current = p_current, 2 * action(p_current) - 144 * p_previous
        q_previous, q_current = (q_current,
                                 2 * action(q_current) - 144 * q_previous + 2 * scalar_current * unit)
        scalar_previous, scalar_current = (scalar_current,
                                            2 * denominator * scalar_current - 144 * scalar_previous)
    residual = denominator * q_current - action(q_current) - scalar_current * unit + p_current
    if any(residual):
        raise ArithmeticError("stage51 full-coordinate exact polynomial residual differs")
    if int(q_current[terminal]) != expected:
        raise ArithmeticError("stage51 independently computed endpoint integer differs")
    return scalar_current, n


def replay_tables(table_paths, journal_path, *, max_modes=None):
    """Durably replay every mode, or an explicitly requested test prefix."""
    if max_modes is not None and (type(max_modes) is not int or max_modes < 1):
        raise ValueError("positive explicit test prefix required")
    tables = [(Path(path), *read_table(path)) for path in table_paths]
    script_sha = _sha(__file__)
    identities = {(str(path.resolve()), _sha(path)): (meta, records)
                  for path, meta, records in tables}
    completed = set()
    journal = Path(journal_path)
    if journal.exists():
        for line in journal.read_text(encoding="utf-8").splitlines():
            item = json.loads(line)
            key = (item["source_path"], item["source_sha256"])
            if (key not in identities or item.get("replay_code_sha256") != script_sha or
                    item.get("coordinate_identities") != 20160):
                raise ValueError("existing mode journal has foreign source, code, or scope")
            mode = (key, item["i"], item["j"])
            if mode in completed or (item["i"], item["j"]) not in identities[key][1]:
                raise ValueError("duplicate or foreign completed stage51 mode")
            completed.add(mode)
    journal.parent.mkdir(parents=True, exist_ok=True)
    attempted = 0
    with journal.open("a", encoding="utf-8", newline="\n") as output:
        for path, meta, records in tables:
            source_path, source_sha = str(path.resolve()), _sha(path)
            for (i, j), expected in sorted(records.items()):
                key = ((source_path, source_sha), i, j)
                if key in completed:
                    continue
                if max_modes is not None and attempted >= max_modes:
                    return len(completed), False
                scalar, coordinates = replay_mode(i, j, meta["denominator"],
                                                  meta["order"], meta["eta"], expected)
                if scalar != meta["pk"]:
                    raise ArithmeticError("stage51 scalar Chebyshev recurrence differs")
                item = {"source_path": source_path, "source_sha256": source_sha,
                        "replay_code_sha256": script_sha, "denominator": meta["denominator"],
                        "order": meta["order"], "eta": meta["eta"],
                        "i": i, "j": j, "endpoint_integer": str(expected),
                        "coordinate_identities": coordinates}
                output.write(json.dumps(item, sort_keys=True) + "\n")
                output.flush()
                os.fsync(output.fileno())
                completed.add(key)
                attempted += 1
                print(f"REPLAYED {len(completed)}/{sum(len(records) for _, _, records in tables)} "
                      f"d={meta['denominator']} eta={meta['eta']} mode=({i},{j})", flush=True)
    expected_total = sum(len(records) for _, _, records in tables)
    if len(completed) != expected_total:
        raise ArithmeticError("stage51 mode replay journal has incomplete table coverage")
    return len(completed), True


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--journal", type=Path, required=True)
    parser.add_argument("--max-modes", type=int)
    args = parser.parse_args()
    paths = [args.source / f"cheb_d{denominator}_k{order}_eta{eta}.tsv"
             for denominator, order in ((312, 24), (13, 128)) for eta in (1, 0)]
    completed, full = replay_tables(paths, args.journal, max_modes=args.max_modes)
    print(json.dumps({"completed_modes": completed, "expected_modes": 544,
                      "coordinate_identities": completed * 20160, "full": full}), flush=True)


if __name__ == "__main__":
    main()
