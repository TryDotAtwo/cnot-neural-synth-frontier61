"""Exact stage47 source/carrier/receivers word series in its strict alphabet."""
from fractions import Fraction

from .types import CostDegree, ExactRationalPointValue, OracleResult, ScalarResponse, ScalarTerm


def _weights(m, weight):
    """Coefficients of (1-t)^weight(1+t)^(m-weight) by integer convolution."""
    coefficients = [1]
    for i in range(m):
        sign = -1 if i < weight else 1
        next_coefficients = [0] * (len(coefficients) + 1)
        for k, value in enumerate(coefficients):
            next_coefficients[k] += value
            next_coefficients[k + 1] += sign * value
        coefficients = next_coefficients
    return tuple(coefficients)


def _boundary(problem, query):
    n = len(problem.target_rows)
    wires = problem.active_wires
    scope = f"stage47_carrier_star_alphabet:n{n}:source_carrier{wires}"
    if (len(wires) != 2 or n < 3 or problem.ports.labels or problem.private_wires or
            problem.frequencies or query.feedback_control is not None):
        return scope, None
    source, carrier = wires
    receivers = tuple(i for i in range(n) if i not in wires)
    expected = {(source, carrier)} | {(carrier, receiver) for receiver in receivers}
    if set(problem.alphabet) != expected or problem.target_rows[source] != 1 << source:
        return scope, None
    carrier_row = problem.target_rows[carrier]
    if carrier_row & ~((1 << source) | (1 << carrier)) or not (carrier_row >> carrier) & 1:
        return scope, None
    parity = (carrier_row >> source) & 1
    mask0 = mask1 = 0
    for k, receiver in enumerate(receivers):
        row = problem.target_rows[receiver]
        if row & ~((1 << receiver) | (1 << source) | (1 << carrier)) or not (row >> receiver) & 1:
            return scope, None
        bit_source = (row >> source) & 1
        bit_carrier = (row >> carrier) & 1
        mask0 |= (bit_source ^ bit_carrier) << k
        mask1 |= bit_source << k
    return scope, (len(receivers), parity, mask0, mask1)


def star_response(problem, query, budget):
    scope, boundary = _boundary(problem, query)
    if boundary is None:
        return OracleResult("unsupported", None, 0, "outside exact source/carrier/receiver sector", scope)
    m, parity, mask0, mask1 = boundary
    w0, w1 = _weights(m, mask0.bit_count()), _weights(m, mask1.bit_count())
    evaluations = (m + 1) ** 2 * (query.max_degree + 1 if query.fugacity is None else 1)
    if (m + 1) ** 2 > budget.max_layer_states or evaluations > budget.max_transitions:
        return OracleResult("resource_limit", None, 0, "star Fourier mode budget", scope)
    if query.fugacity is not None:
        z = query.fugacity
        if z < 0 or (m + 1) * z >= 1:
            raise ValueError("positive star series requires 0 <= z < 1/(m+1)")
        total = Fraction(0)
        for p, a in enumerate(w0):
            if not a:
                continue
            d0 = m - 2*p
            for q, b in enumerate(w1):
                if not b:
                    continue
                d1 = m - 2*q
                total += a*b*((1-z*d1) if parity == 0 else z) / ((1-z*d0)*(1-z*d1)-z*z)
        value = total / (1 << (2*m))
        if value < 0:
            raise ArithmeticError("negative physical star resolvent")
        return OracleResult("exact_rational_point", ExactRationalPointValue(z, value, scope),
                            evaluations, "all-order restricted carrier-star word series", scope)
    numerator = [0] * (query.max_degree + 1)
    for p, a in enumerate(w0):
        if not a:
            continue
        d0 = m - 2*p
        for q, b in enumerate(w1):
            if not b:
                continue
            d1 = m - 2*q
            weight = a*b
            previous2 = int(parity == 0)
            numerator[0] += weight*previous2
            if query.max_degree == 0:
                continue
            previous1 = d0 if parity == 0 else 1
            numerator[1] += weight*previous1
            for degree in range(2, query.max_degree + 1):
                current = (d0+d1)*previous1 + (1-d0*d1)*previous2
                numerator[degree] += weight*current
                previous2, previous1 = previous1, current
    denominator = 1 << (2*m)
    if any(value < 0 or value % denominator for value in numerator):
        raise ArithmeticError("signed star modes failed physical normalization")
    terms = tuple(ScalarTerm(CostDegree("physical_cnot", degree, scope), value // denominator, ())
                  for degree, value in enumerate(numerator) if value)
    return OracleResult("exact", ScalarResponse("physical_cnot", scope, "words", terms),
                        evaluations, "complete finite restricted carrier-star coefficient prefix", scope)
