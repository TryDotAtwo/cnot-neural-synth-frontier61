"""Reference response types. No rank-only state merge or signed minimization."""
from __future__ import annotations
from dataclasses import dataclass
from fractions import Fraction
from itertools import product


@dataclass(frozen=True)
class LabeledPorts:
    labels: tuple[str,...]
    protected_initial: tuple[str,...]=()

    def __post_init__(self):
        if (any(type(x) is not str or not x for x in self.labels) or
                len(set(self.labels))!=len(self.labels) or
                len(set(self.protected_initial))!=len(self.protected_initial) or
                any(x not in self.labels for x in self.protected_initial)):
            raise ValueError('ordered unique ports and valid protected initial ports required')


@dataclass(frozen=True)
class AffineRelation:
    """XOR equations on ordered vector ports over F_2^width."""
    ports: LabeledPorts
    width: int
    equations: tuple[tuple[int,int],...]

    def __post_init__(self):
        if type(self.width) is not int or self.width<1:
            raise ValueError('positive vector width required')
        if any(type(mask) is not int or type(rhs) is not int or mask<0 or
               mask >= (1<<len(self.ports.labels)) or rhs<0 or rhs >= (1<<self.width)
               for mask,rhs in self.equations):
            raise ValueError('equation outside ordered port scope')

    @property
    def rank(self):
        pivots={}
        for mask,_ in self.equations:
            x=mask
            while x:
                p=x.bit_length()-1
                if p not in pivots:
                    pivots[p]=x;break
                x^=pivots[p]
        return len(pivots)

    def contains(self,assignment):
        if len(assignment)!=len(self.ports.labels) or any(type(x) is not int or
                not 0<=x<(1<<self.width) for x in assignment):
            raise ValueError('invalid vector assignment')
        return all(_xor_selected(mask,assignment)==rhs for mask,rhs in self.equations)

    def assignments(self,max_assignments):
        total=1<<(self.width*len(self.ports.labels))
        if type(max_assignments) is not int or max_assignments<total:
            raise ValueError('explicit tiny enumeration budget exceeded')
        return tuple(x for x in product(range(1<<self.width),repeat=len(self.ports.labels)) if self.contains(x))

    def is_subset(self,other,max_assignments):
        if self.ports.labels!=other.ports.labels or self.width!=other.width:
            raise ValueError('incompatible relation scopes')
        return all(other.contains(x) for x in self.assignments(max_assignments))

    def canonical_equations(self):
        rows=[list(pair) for pair in self.equations]
        pivot=0
        for bit in reversed(range(len(self.ports.labels))):
            selected=next((j for j in range(pivot,len(rows)) if rows[j][0]>>bit&1),None)
            if selected is None:continue
            rows[pivot],rows[selected]=rows[selected],rows[pivot]
            mask,rhs=rows[pivot]
            for j in range(len(rows)):
                if j!=pivot and rows[j][0]>>bit&1:
                    rows[j][0]^=mask;rows[j][1]^=rhs
            pivot+=1
        if any(mask==0 and rhs!=0 for mask,rhs in rows):
            return ((0,1),)
        return tuple((mask,rhs) for mask,rhs in rows if mask)


def _xor_selected(mask,assignment):
    value=0
    for i,x in enumerate(assignment):
        if mask>>i&1:value^=x
    return value


@dataclass(frozen=True)
class CostDegree:
    unit: str
    value: int
    scope_id: str

    def __post_init__(self):
        if self.unit not in ('physical_cnot','cell','assignment') or type(self.value) is not int or self.value<0 or not self.scope_id:
            raise ValueError('explicit nonnegative degree, unit and scope required')


@dataclass(frozen=True)
class WeightedTerm:
    assignment: tuple[int,...]
    degree: CostDegree
    multiplicity: int
    witness: tuple=()

    def __post_init__(self):
        if type(self.multiplicity) is not int or self.multiplicity<1 or not isinstance(self.witness,tuple):
            raise ValueError('positive integer multiplicity and ordered witness required')


@dataclass(frozen=True)
class WeightedResponse:
    ports: LabeledPorts
    width: int
    unit: str
    scope_id: str
    count_kind: str
    terms: tuple[WeightedTerm,...]

    def __post_init__(self):
        if not self.ports.labels or type(self.width) is not int or self.width<1 or self.count_kind not in ('assignments','words','traces','diagram_coefficients'):
            raise ValueError('invalid response width or count semantics')
        CostDegree(self.unit,0,self.scope_id)
        for term in self.terms:
            if (term.degree.unit,term.degree.scope_id)!=(self.unit,self.scope_id):
                raise ValueError('degree unit/scope mismatch')
            if len(term.assignment)!=len(self.ports.labels) or any(type(x) is not int or not 0<=x<(1<<self.width) for x in term.assignment):
                raise ValueError('term assignment outside ports')

    @classmethod
    def from_relation(cls,relation,degree,*,coefficient=1,count_kind='assignments',witness=(),max_assignments=1024):
        if type(coefficient) is not int or coefficient<0:
            raise ValueError('signed/negative weights require a separate positive projection')
        assignments=relation.assignments(max_assignments)
        if not relation.ports.labels:
            terms=(ScalarTerm(degree,coefficient,witness),) if coefficient and assignments else ()
            return ScalarResponse(degree.unit,degree.scope_id,count_kind,terms)
        terms=tuple(WeightedTerm(x,degree,coefficient,witness) for x in assignments) if coefficient else ()
        return cls(relation.ports,relation.width,degree.unit,degree.scope_id,count_kind,terms)

    def coefficient(self,assignment,degree):
        return sum(t.multiplicity for t in self.terms if t.assignment==tuple(assignment) and t.degree.value==degree)


@dataclass(frozen=True)
class ResponseBudget:
    max_assignment_pairs: int
    max_output_terms: int

    def __post_init__(self):
        if any(type(x) is not int or x<0 for x in (self.max_assignment_pairs,self.max_output_terms)):
            raise ValueError('nonnegative explicit response budgets required')


@dataclass(frozen=True)
class ScalarTerm:
    degree: CostDegree
    multiplicity: int
    witness: tuple=()

    def __post_init__(self):
        if type(self.multiplicity) is not int or self.multiplicity<1 or not isinstance(self.witness,tuple):
            raise ValueError('positive integer scalar multiplicity required')


@dataclass(frozen=True)
class ScalarResponse:
    unit: str
    scope_id: str
    count_kind: str
    terms: tuple[ScalarTerm,...]

    def __post_init__(self):
        CostDegree(self.unit,0,self.scope_id)
        if self.count_kind not in ('assignments','words','traces','diagram_coefficients'):
            raise ValueError('invalid scalar count semantics')
        if any((term.degree.unit,term.degree.scope_id)!=(self.unit,self.scope_id) for term in self.terms):
            raise ValueError('scalar degree unit/scope mismatch')

    def coefficient(self,degree):
        return sum(t.multiplicity for t in self.terms if t.degree.value==degree)


@dataclass(frozen=True)
class RelationTerm:
    relation: AffineRelation
    degree: CostDegree
    multiplicity: int
    witness: tuple=()

    def __post_init__(self):
        if type(self.multiplicity) is not int or self.multiplicity<1 or not isinstance(self.witness,tuple):
            raise ValueError('positive relation coefficient and ordered witness required')


@dataclass(frozen=True)
class RelationResponse:
    ports: LabeledPorts
    width: int
    unit: str
    scope_id: str
    count_kind: str
    terms: tuple[RelationTerm,...]

    def __post_init__(self):
        CostDegree(self.unit,0,self.scope_id)
        if not self.ports.labels or self.count_kind not in ('assignments','words','traces','diagram_coefficients'):
            raise ValueError('invalid relation count semantics')
        if any(t.relation.ports!=self.ports or t.relation.width!=self.width or
               (t.degree.unit,t.degree.scope_id)!=(self.unit,self.scope_id) for t in self.terms):
            raise ValueError('relation term scope mismatch')

    def coefficient(self,assignment,degree):
        return sum(t.multiplicity for t in self.terms if t.degree.value==degree and t.relation.contains(assignment))


@dataclass(frozen=True)
class SignedAffineTerm:
    relation: AffineRelation
    coefficient: int
    phase_mask: int

    def __post_init__(self):
        if type(self.coefficient) is not int or type(self.phase_mask) is not int or self.phase_mask<0 or self.phase_mask >= (1<<len(self.relation.ports.labels)):
            raise ValueError('invalid signed affine character term')


@dataclass(frozen=True)
class SignedAffineResponse:
    """Fourier/Gauss data before positive projection; never a min/count oracle."""
    ports: LabeledPorts
    width: int
    terms: tuple[SignedAffineTerm,...]

    def __post_init__(self):
        if type(self.width) is not int or self.width<1 or any(t.relation.ports!=self.ports or t.relation.width!=self.width for t in self.terms):
            raise ValueError('signed affine response scope mismatch')


@dataclass(frozen=True)
class SymbolicBudget:
    max_term_pairs: int
    max_output_relations: int

    def __post_init__(self):
        if any(type(x) is not int or x<0 for x in (self.max_term_pairs,self.max_output_relations)):
            raise ValueError('nonnegative symbolic budgets required')


@dataclass(frozen=True)
class OracleResult:
    status: str
    response: WeightedResponse | ScalarResponse | RelationResponse | RationalIntervalCertificate | ExactRationalFunctionIdentity | ExactRationalPointValue | ExactTemporalProfileValue | None
    evaluations: int
    reason: str
    scope_id: str

    def __post_init__(self):
        kinds = {
            'exact': (WeightedResponse, ScalarResponse, RelationResponse),
            'certified_interval': (RationalIntervalCertificate,),
            'exact_rational_identity': (ExactRationalFunctionIdentity,),
            'exact_rational_point': (ExactRationalPointValue,),
            'exact_profiled_point': (ExactTemporalProfileValue,),
            'resource_limit': (type(None),),
            'unsupported': (type(None),),
        }
        if self.status not in kinds or not isinstance(self.response, kinds[self.status]):
            raise ValueError('oracle status and response disagree')


@dataclass(frozen=True)
class RationalIntervalCertificate:
    """Pointwise rational enclosure, never an all-z function identity."""
    evaluation_point: Fraction
    lower: Fraction
    upper: Fraction
    certificate_ref: str
    verification_scope: str
    modes_total: int
    modes_independently_replayed: int

    def __post_init__(self):
        if (any(type(x) is not Fraction for x in (self.evaluation_point, self.lower, self.upper)) or
                self.lower > self.upper or not self.certificate_ref or not self.verification_scope or
                type(self.modes_total) is not int or type(self.modes_independently_replayed) is not int or
                self.modes_total < 0 or not 0 <= self.modes_independently_replayed <= self.modes_total):
            raise ValueError('explicit pointwise interval and verification coverage required')


@dataclass(frozen=True)
class ExactRationalFunctionIdentity:
    """All-order polynomial numerator/denominator identity with proof reference."""
    numerator: tuple[int, ...]
    denominator: tuple[int, ...]
    identity_ref: str
    verification_scope: str

    def __post_init__(self):
        if (not self.numerator or not self.denominator or self.denominator[0] == 0 or
                any(type(x) is not int for x in self.numerator + self.denominator) or
                not self.identity_ref or not self.verification_scope):
            raise ValueError('verified polynomial identity metadata required')


@dataclass(frozen=True)
class ExactRationalPointValue:
    """Exact value at one rational fugacity; no claim about all z."""
    evaluation_point: Fraction
    value: Fraction
    mathematical_scope: str

    def __post_init__(self):
        if (type(self.evaluation_point) is not Fraction or type(self.value) is not Fraction or
                not self.mathematical_scope):
            raise ValueError('exact rational point and scope required')


@dataclass(frozen=True)
class ExactTemporalProfileValue:
    """One finite ordered profile product; neither a word count nor a z resolvent."""
    profile: tuple[tuple[Fraction, tuple[Fraction, ...]], ...]
    value: Fraction
    mathematical_scope: str

    def __post_init__(self):
        if (type(self.value) is not Fraction or not self.mathematical_scope or
                any(type(epsilon) is not Fraction or len(weights) != 6 or
                    any(type(weight) is not Fraction for weight in weights)
                    for epsilon, weights in self.profile)):
            raise ValueError('ordered six-gate rational time profile and scope required')
