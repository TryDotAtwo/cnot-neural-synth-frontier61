"""Own paid-basis full-state macro adapter, with explicit oracle accounting."""
import hashlib
import random
import numpy as np
from ..contracts import AlphabetSpec, MatrixState, WordCertificate
from ..words import verify_word, apply
from ..gf2 import inverse
from ..basis.templates import BasisTemplate, BasisChoice
from ..basis.wide import optimize_wide


def solve_with_paid_basis(state,model,registry,config,producer,incumbent=None):
    from .reference import solve
    result=solve(state,model,registry,config,incumbent=incumbent,macros=producer)
    result.provenance.update({'method':'neural_plus_paid_basis','solver_assisted':True})
    result.diagnostics['paid_basis']={'calls':producer.calls,'evaluations':producer.evaluations,'audit':producer.audit}
    # Combined searches have their own raw_search_word; do not label them raw NN.
    result.raw_neural_word=None
    return result


def recognize_shear(state):
    sources = tuple(i for i,row in enumerate(state.packed_rows) if row == 1<<i)
    targets = tuple(i for i,row in enumerate(state.packed_rows) if row != 1<<i)
    if not sources or not targets:
        return None
    source_mask = sum(1<<i for i in sources)
    if any((state.packed_rows[t] ^ (1<<t)) & ~source_mask for t in targets):
        return None
    block = np.array([[(state.packed_rows[t]>>s)&1 for s in sources] for t in targets],dtype=np.uint8)
    return sources,targets,block


def partial_shear(state):
    """B*A = M[T,P], so physical row[T] += B*row[S] zeros M[T,P]."""
    width=state.n//2
    if width==0:
        return None
    sources,targets=tuple(range(width)),tuple(range(width,state.n))
    echelon=list(state.packed_rows[:width]); pivots=[]; r=0
    for c in range(state.n):
        pivot=next((i for i in range(r,width) if (echelon[i]>>c)&1),None)
        if pivot is None:continue
        echelon[r],echelon[pivot]=echelon[pivot],echelon[r]
        for i in range(r+1,width):
            if (echelon[i]>>c)&1:echelon[i]^=echelon[r]
        pivots.append(c);r+=1
        if r==width:break
    if r!=width:raise ArithmeticError('invertible matrix has dependent row subset')
    restriction=tuple(sum(((state.packed_rows[s]>>c)&1)<<j for j,c in enumerate(pivots)) for s in sources)
    inv=inverse(restriction);block=[]
    for t in targets:
        coefficients=0
        for j,c in enumerate(pivots):
            if (state.packed_rows[t]>>c)&1:coefficients^=inv[j]
        block.append([(coefficients>>j)&1 for j in range(width)])
    block=np.array(block,dtype=np.uint8)
    return (sources,targets,block,tuple(pivots)) if block.any() else None


class PaidBasisMacros:
    """Solver-assisted extension, not a claim of raw NN-only synthesis.

    Finite seeded templates are augmentation-only under wire relabeling. The
    physical block is never narrowed to the number of selected basis choices.
    """
    def __init__(self, budget, *, max_calls, choices=3, seed=0, backend='mc', allow_partial=True):
        if type(max_calls) is not int or max_calls < 0 or type(choices) is not int or choices < 0:
            raise ValueError('invalid macro proposal budgets')
        self.budget,self.max_calls,self.choices,self.seed,self.backend=budget,max_calls,choices,seed,backend
        self.calls=0
        self.allow_partial=allow_partial
        self.evaluations=0
        self.audit=[]

    def initial_probabilities(self,state,template,block):
        return [.5]*len(template.choices),{'initialization':'constant_half'}

    def __call__(self,state):
        if self.calls >= self.max_calls:
            return ()
        self.calls+=1
        alphabet = AlphabetSpec.all_to_all(state.n)
        if state.alphabet_id != alphabet.id:
            raise ValueError('paid basis macro requires all-to-all unit CNOT')
        parsed=recognize_shear(state)
        pivots=None
        if parsed is None and self.allow_partial:
            partial=partial_shear(state)
            if partial is not None:
                parsed=partial[:3];pivots=partial[3]
        if parsed is None:
            self.audit.append({'state_key':state.key,'status':'no_applicable_nonzero_block'})
            return ()
        sources,targets,block=parsed
        key=hashlib.sha256(repr((state.key,self.seed)).encode()).hexdigest()
        rng=random.Random(int(key[:16],16))
        candidates=[(c,t) for c in range(len(sources)) for t in range(len(sources)) if c!=t]
        pairs=rng.sample(candidates,min(self.choices,len(candidates)))
        template=BasisTemplate(state.n,sources,targets,'source',tuple(BasisChoice('add',c,t) for c,t in pairs))
        initial,initialization=self.initial_probabilities(state,template,block)
        result=optimize_wide(block,template,initial,self.backend,self.budget,seed=self.seed)
        self.evaluations+=result.evaluations
        row={'state_key':state.key,'status':result.status,'width':template.width,'targets':len(targets),
             'mode':'partial_elimination' if pivots is not None else 'full_shear_reduction','pivot_columns':pivots,
             'direct_cost':int(block.sum()),'evaluations':result.evaluations,'trace':result.trace,
             'basis_choices':pairs,'backend':self.backend,'solver_assisted':True}
        row.update(initialization)
        row['initial_probabilities']=list(initial)
        self.audit.append(row)
        if result.best is None:
            return ()
        encoder=result.best.certificate
        if encoder.start!=MatrixState.identity(alphabet):
            raise ArithmeticError('basis macro full encoder endpoint mismatch')
        endpoint=state
        for gate in encoder.gates:endpoint=apply(endpoint,gate,alphabet)
        if pivots is None and endpoint!=MatrixState.identity(alphabet):
            raise ArithmeticError('full shear reduction endpoint mismatch')
        if pivots is not None and any((endpoint.packed_rows[t]>>c)&1 for t in targets for c in pivots):
            raise ArithmeticError('partial elimination failed on pivot columns')
        cert=WordCertificate(state,endpoint,encoder.gates,encoder.physical_cost,
                             'own_paid_basis_gradient_macro',key)
        verify_word(cert,alphabet)
        row.update({'physical_cost':cert.physical_cost,'preparation':len(result.best.preparation),
                    'core':len(result.best.core),'restoration':len(result.best.preparation)})
        return (cert,)
