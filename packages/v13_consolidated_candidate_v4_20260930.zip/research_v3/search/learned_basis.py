"""Inference bridge for explicitly trained BasisField checkpoints."""
import torch
from ..contracts import MatrixBatch
from ..basis.learning import BasisField
from .basis_macros import PaidBasisMacros


class LearnedBasisMacros(PaidBasisMacros):
    def __init__(self,model,registry,policy,checkpoint_id,budget,**kwargs):
        if not isinstance(model,BasisField) or not checkpoint_id:
            raise ValueError('explicit BasisField and checkpoint identity required')
        super().__init__(budget,**kwargs)
        self.model,self.registry,self.policy,self.checkpoint_id=model,registry,policy,checkpoint_id
        self.proposal_forwards=0

    def initial_probabilities(self,state,template,block):
        if not template.choices:
            return [],{'initialization':'empty_template','proposal_forwards':0,'checkpoint_id':self.checkpoint_id}
        modes={name:module.training for name,module in self.model.named_modules()}
        self.model.eval()
        try:
            with torch.no_grad():
                device=next(self.model.parameters()).device
                batch=MatrixBatch.from_states((state,),device)
                encoded=self.model.field.encode(batch,self.registry.build((state,),self.policy))
                theta=self.model.proposer(encoded,template)
                if not torch.isfinite(theta).all() or ((theta<0)|(theta>1)).any():
                    raise ValueError('invalid learned basis probabilities')
                initial=theta.cpu().tolist()
                self.proposal_forwards+=1
        finally:
            for name,module in self.model.named_modules():module.training=modes[name]
        return initial,{'initialization':'learned_basis_proposal','proposal_forwards':1,
                        'checkpoint_id':self.checkpoint_id,'feature_policy_id':self.policy.id}
