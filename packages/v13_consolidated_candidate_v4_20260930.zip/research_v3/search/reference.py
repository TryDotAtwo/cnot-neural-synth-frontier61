"""Own complete-matrix beam search. No external search code or target chains."""
from dataclasses import dataclass, asdict
import math
from time import perf_counter
from ..contracts import MatrixState, WordCertificate
from ..words import verify_word
from .results import SolveResult
from .scoring import values, action_scores, hamming


@dataclass(frozen=True)
class SearchConfig:
    alphabet: object
    feature_policy: object
    scoring: str = 'direct_v'
    beam_width: int = 16
    max_cost: int = 128
    max_expansions: int = 100000
    macro_expansions: int = 1000
    inference_batch_size: int = 64
    shortlist: int | None = None
    checkpoint_id: str = 'unrecorded'

    def __post_init__(self):
        if self.scoring not in ('direct_v', 'absolute_qhat', 'proposal_then_v', 'hamming_control'):
            raise ValueError('unknown scoring mode')
        if self.beam_width < 1 or self.inference_batch_size < 1 or min(self.max_cost, self.max_expansions, self.macro_expansions) < 0:
            raise ValueError('invalid search budget')
        if self.shortlist is not None and self.shortlist < 1:
            raise ValueError('shortlist must be positive or None=all')


@dataclass(frozen=True)
class Node:
    state: object
    g: int
    word: tuple


def _successor_known_gate(state, gate):
    """Apply an alphabet-enumerated CNOT without repeating a GF(2) rank test.

    A CNOT is the invertible elementary row operation R_t <- R_t xor R_c;
    therefore the successor of an already validated MatrixState is invertible.
    The caller must enumerate gates from the validated alphabet. Complete
    reported words still pass the independent public verifier.
    """
    rows = state.packed_rows
    target = gate.target
    changed = rows[:target] + (rows[target] ^ rows[gate.control],) + rows[target+1:]
    result = object.__new__(MatrixState)
    object.__setattr__(result, 'n', state.n)
    object.__setattr__(result, 'packed_rows', changed)
    object.__setattr__(result, 'alphabet_id', state.alphabet_id)
    return result


def solve(state, model, registry, config, incumbent=None, macros=None):
    start_time = perf_counter()
    alphabet = config.alphabet
    identity = MatrixState.identity(alphabet)
    if state.n != alphabet.n or state.alphabet_id != alphabet.id:
        raise ValueError('root/alphabet mismatch')
    if incumbent is not None:
        verify_word(incumbent, alphabet)
        if incumbent.start != state or incumbent.end != identity:
            raise ValueError('incumbent is not a root reduction')
    counts = {'expanded': 0, 'generated': 0, 'reopened': 0, 'macro_expansions': 0,
              'value_evaluations': 0, 'value_model_forwards': 0,
              'action_model_forwards': 0, 'primitive_feature_packet_builds': 0}
    trace = []
    approximate = config.scoring == 'proposal_then_v' and config.shortlist is not None and config.shortlist < len(alphabet.allowed)
    def finish(status, node=None):
        word = None
        if node is not None:
            word = WordCertificate(state, identity, node.word, node.g, config.scoring, 'search')
            verify_word(word, alphabet)
        portfolio = [cert for cert in (word, incumbent) if cert is not None]
        return SolveResult(status, word if config.scoring != 'hamming_control' else None, incumbent, None,
                           min(portfolio, key=lambda c: c.physical_cost) if portfolio else None,
                           counts.copy(), {'total_seconds': perf_counter() - start_time},
                           {'approximate_shortlist': approximate, 'trace': trace, 'global_optimality': 'not_claimed'},
                           {'root_key': state.key, 'scoring': config.scoring, 'checkpoint_id': config.checkpoint_id,
                            'config': asdict(config)}, word)
    if state == identity:
        return finish('solved', Node(state, 0, ()))
    frontier = [Node(state, 0, ())]
    expanded_g = {}
    iteration = 0
    while frontier:
        candidates = {}
        goals = []
        batches = []
        limited = False
        step_trace = {'iteration': iteration, 'expanded': [], 'retained_states': []}
        trace.append(step_trace)
        for parent in frontier:
            if counts['expanded'] >= config.max_expansions:
                limited = True
                break
            previous = expanded_g.get(parent.state.key)
            if previous is not None and previous <= parent.g:
                continue
            if previous is not None:
                counts['reopened'] += 1
            expanded_g[parent.state.key] = parent.g
            counts['expanded'] += 1
            step_trace['expanded'].append({'rows': parent.state.packed_rows, 'g': parent.g})
            edges = []
            for i, (gate, cost) in enumerate(zip(alphabet.allowed, alphabet.costs)):
                if parent.g + cost > config.max_cost:
                    continue
                successor = _successor_known_gate(parent.state, gate)
                node = Node(successor, parent.g + cost, parent.word + (gate,))
                counts['generated'] += 1
                if successor == identity:
                    goals.append(node)
                else:
                    edges.append((node, i, cost))
            if macros is not None and counts['macro_expansions'] < config.macro_expansions:
                for cert in macros(parent.state):
                    if counts['macro_expansions'] >= config.macro_expansions:
                        break
                    counts['macro_expansions'] += 1
                    verify_word(cert, alphabet)
                    if cert.start != parent.state or cert.physical_cost <= 0:
                        raise ValueError('invalid paid macro')
                    if parent.g + cert.physical_cost > config.max_cost:
                        continue
                    node = Node(cert.end, parent.g + cert.physical_cost, parent.word + cert.gates)
                    counts['generated'] += 1
                    if node.state == identity:
                        goals.append(node)
                    else:
                        edges.append((node, None, cert.physical_cost))
            batches.append((parent, edges))
        if goals:
            return finish('solved', min(goals, key=lambda n: (n.g, n.word)))
        if limited:
            return finish('resource_limit')
        for parent, edges in batches:
            output = None
            if edges and config.scoring in ('absolute_qhat', 'proposal_then_v'):
                output = action_scores(model, parent.state, registry, config.feature_policy)
                counts['action_model_forwards'] += 1
                counts['primitive_feature_packet_builds'] += 1
            permitted = None
            if approximate:
                logits = []
                for i, gate in enumerate(alphabet.allowed):
                    logit = float(output.proposal[0, gate.control, gate.target]) if output is not None else 0.
                    if not math.isfinite(logit):
                        raise ValueError('nonfinite valid proposal')
                    logits.append((-logit, i))
                permitted = {i for _, i in sorted(logits)[:config.shortlist]}
            for node, index, cost in edges:
                if permitted is not None and index is not None and index not in permitted:
                    continue
                if expanded_g.get(node.state.key, math.inf) <= node.g:
                    continue
                # Unselected beam candidates are never inserted into closed.
                score = None
                if config.scoring == 'absolute_qhat' and index is not None:
                    gate = alphabet.allowed[index]
                    q = float(output.qhat[0, gate.control, gate.target])
                    if not math.isfinite(q) or q < 0:
                        raise ValueError('invalid absolute Qhat')
                    score = parent.g + q  # Qhat already includes this action cost.
                elif config.scoring == 'hamming_control':
                    score = node.g + hamming(node.state)
                old = candidates.get(node.state.key)
                if old is None or (node.g, node.word) < (old[0].g, old[0].word):
                    candidates[node.state.key] = (node, score)
        items = [(node, score) for node, score in candidates.values()
                 if expanded_g.get(node.state.key, math.inf) > node.g]
        pending = [node.state for node, score in items if score is None]
        predicted = iter(values(model, pending, registry, config.feature_policy, config.inference_batch_size) if pending else ())
        counts['value_evaluations'] += len(pending)
        value_batches = (len(pending) + config.inference_batch_size - 1) // config.inference_batch_size
        counts['value_model_forwards'] += value_batches
        counts['primitive_feature_packet_builds'] += value_batches
        ranked = [(node.g + next(predicted) if score is None else score, node.g, node.state.packed_rows, node.word, node)
                  for node, score in items]
        ranked.sort(key=lambda item: item[:-1])
        frontier = [item[-1] for item in ranked[:config.beam_width]]
        step_trace.update({'candidates': len(items), 'retained': len(frontier),
                           'minimum_g': min((n.g for n in frontier), default=None),
                           'retained_states': [{'rows': item[-1].state.packed_rows, 'g': item[-1].g,
                                                'score': item[0]} for item in ranked[:config.beam_width]]})
        iteration += 1
    return finish('search_exhausted_within_budgets')
