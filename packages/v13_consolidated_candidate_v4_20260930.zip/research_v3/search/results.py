from dataclasses import dataclass


@dataclass
class SolveResult:
    status: str
    raw_neural_word: object
    incumbent_word: object
    postprocessed_word: object
    best_verified_word: object
    counts: dict
    timings: dict
    diagnostics: dict
    provenance: dict
    raw_search_word: object = None
