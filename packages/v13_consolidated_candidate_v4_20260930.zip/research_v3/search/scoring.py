import torch
from ..contracts import MatrixBatch


def values(model, states, registry, policy, chunk_size):
    output = []
    device = next(model.parameters()).device
    with torch.no_grad():
        for start in range(0, len(states), chunk_size):
            chunk = tuple(states[start:start + chunk_size])
            packet = registry.build(chunk, policy)
            prediction = model(MatrixBatch.from_states(chunk, device), packet).value
            if not torch.isfinite(prediction).all():
                raise ValueError('nonfinite value score')
            output.extend(prediction.detach().cpu().tolist())
    return output


def action_scores(model, state, registry, policy):
    device = next(model.parameters()).device
    with torch.no_grad():
        output = model(MatrixBatch.from_states((state,), device), registry.build((state,), policy))
    return output


def hamming(state):
    return sum((row ^ (1 << i)).bit_count() for i, row in enumerate(state.packed_rows))


def shortlist_metrics(action_values, selected, atol=0.):
    """Offline dev diagnostic; values include action cost, smaller is better."""
    import math
    action_values = tuple(float(x) for x in action_values)
    selected = set(selected)
    if (not action_values or not selected or atol < 0 or
            any(not math.isfinite(x) for x in action_values) or
            any(type(i) is not int or not 0 <= i < len(action_values) for i in selected)):
        raise ValueError('invalid shortlist diagnostic input')
    minimum = min(action_values)
    minimizers = {i for i, value in enumerate(action_values) if value <= minimum + atol}
    return {'best_set_hit': bool(selected & minimizers),
            'minimizer_coverage': len(selected & minimizers) / len(minimizers),
            'regret': min(action_values[i] for i in selected) - minimum,
            'minimizers': len(minimizers), 'selected': len(selected), 'atol': atol}
