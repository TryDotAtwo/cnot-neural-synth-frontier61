from dataclasses import dataclass
import hashlib
from .contracts import AlphabetSpec, Gate, MatrixState, WordCertificate
from .gf2 import inverse, transpose, permute
from .words import verify_word


@dataclass(frozen=True)
class MappedProblem:
    state: MatrixState
    alphabet: AlphabetSpec
    original: MatrixState
    original_alphabet: AlphabetSpec
    transform: object


def map_problem(state, alphabet, transform):
    if state.n != alphabet.n or state.alphabet_id != alphabet.id:
        raise ValueError('state/alphabet mismatch')
    mapped_alphabet = alphabet
    if transform == 'inverse':
        rows = inverse(state.packed_rows)
    elif transform == 'transpose':
        costs = dict(zip(alphabet.allowed, alphabet.costs))
        if any(costs.get(Gate(g.target, g.control)) != cost for g, cost in costs.items()):
            raise ValueError('transpose requires reverse edges of equal cost')
        rows = transpose(state.packed_rows)
    elif isinstance(transform, tuple):
        if len(transform) != state.n or any(type(i) is not int for i in transform) or sorted(transform) != list(range(state.n)):
            raise ValueError('invalid permutation')
        rows = permute(state.packed_rows, transform)
        gates = tuple(Gate(transform[g.control], transform[g.target]) for g in alphabet.allowed)
        old = dict(zip(alphabet.allowed, alphabet.costs))
        new = dict(zip(gates, alphabet.costs))
        if old != new:
            digest = hashlib.sha256(repr((state.n, gates, alphabet.costs)).encode()).hexdigest()
            mapped_alphabet = AlphabetSpec(state.n, gates, alphabet.costs, 'relabel:' + digest)
    else:
        raise ValueError('unknown transform')
    return MappedProblem(MatrixState(state.n, rows, mapped_alphabet.id), mapped_alphabet,
                         state, alphabet, transform)


def map_word_back(cert, mapping):
    verify_word(cert, mapping.alphabet)
    if cert.start != mapping.state or cert.end != MatrixState.identity(mapping.alphabet):
        raise ValueError('mapping expects full reduction of mapped target')
    transform = mapping.transform
    if transform == 'inverse':
        word = tuple(reversed(cert.gates))
    elif transform == 'transpose':
        word = tuple(Gate(g.target, g.control) for g in reversed(cert.gates))
    else:
        back = {new: old for old, new in enumerate(transform)}
        word = tuple(Gate(back[g.control], back[g.target]) for g in cert.gates)
    result = WordCertificate(mapping.original, MatrixState.identity(mapping.original_alphabet),
                             word, cert.physical_cost, cert.producer, cert.lineage_id)
    verify_word(result, mapping.original_alphabet)
    return result
