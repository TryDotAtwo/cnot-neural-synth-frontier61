import random
import unittest

from research_v3.contracts import AlphabetSpec, MatrixState
from research_v3.features.structural import compute


class A20VectorizedTests(unittest.TestCase):
    def test_every_directed_move_against_bitwise_reference(self):
        rng = random.Random(1402)
        for n in (2, 3, 5, 8, 13):
            rows = [1 << i for i in range(n)]
            for _ in range(4*n):
                c, t = rng.sample(range(n), 2)
                rows[t] ^= rows[c]
            state = MatrixState(n, tuple(rows), AlphabetSpec.all_to_all(n).id)
            actual = compute(state)['A20']
            for c in range(n):
                for t in range(n):
                    if c == t:
                        self.assertEqual(actual[c, t].tolist(), [0, 0])
                        continue
                    changed = rows[t] ^ rows[c]
                    before_mismatch = (rows[t] ^ (1 << t)).bit_count()
                    after_mismatch = (changed ^ (1 << t)).bit_count()
                    self.assertEqual(actual[c, t].tolist(),
                                     [changed.bit_count()-rows[t].bit_count(),
                                      after_mismatch-before_mismatch])


if __name__ == '__main__':
    unittest.main()
