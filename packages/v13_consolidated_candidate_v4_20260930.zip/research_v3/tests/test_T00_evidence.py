import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from research_v3 import evidence


class EvidenceTests(unittest.TestCase):
    def test_reverse_patch_requires_exact_current_and_pinned_hash(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / 'report.py'
            source.write_bytes(b'a\nb\n')
            record = {'source_file': str(source),
                      'current_sha256': hashlib.sha256(b'a\nb\n').hexdigest(),
                      'pinned_sha256': hashlib.sha256(b'a\n').hexdigest(),
                      'patches': [{'patch': '*** Begin Patch\n*** Update File: report.py\n@@\n a\n+b\n*** End Patch'}]}
            self.assertEqual(evidence.audit_explained_drift(record)['status'], 'explained')
            source.write_bytes(b'a\nc\n')
            self.assertEqual(evidence.audit_explained_drift(record)['status'], 'unresolved')

    def test_changed_source_is_drift(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            source = root / 'source.py'
            source.write_bytes(b'old')
            manifest = root / 'manifest.json'
            manifest.write_text(json.dumps({'current_project_files': [
                {'path': str(source), 'sha256': hashlib.sha256(b'old').hexdigest()}]}))
            self.assertEqual(evidence.audit_sources(manifest, root)['files'][0]['status'], 'match')
            source.write_bytes(b'new')
            self.assertEqual(evidence.audit_sources(manifest, root)['files'][0]['status'], 'drift')

    def test_missing_report_is_missing(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            manifest = root / 'manifest.json'
            manifest.write_text(json.dumps({'current_project_files': [
                {'path': str(root / 'missing.json'), 'sha256': '0' * 64}]}))
            self.assertEqual(evidence.audit_sources(manifest, root)['files'][0]['status'], 'missing')

    def test_false_verified_flag_is_rejected(self):
        cert = {'gates': [[0, 1], [1, 2]], 'count': 2, 'verified': True}
        matrix = [[1, 0, 0], [1, 1, 0], [1, 1, 1]]
        self.assertEqual(evidence.verify_encoder(matrix, cert)['word_validity'], 'verified')
        cert['gates'] = list(reversed(cert['gates']))
        with self.assertRaisesRegex(ValueError, 'endpoint'):
            evidence.verify_encoder(matrix, cert)

    def test_scope_escape_is_not_allowed_provenance(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            manifest = root / 'manifest.json'
            manifest.write_text(json.dumps({'current_project_files': [
                {'path': str(root.parent / 'outside.py'), 'sha256': '0' * 64}]}))
            self.assertEqual(evidence.audit_sources(manifest, root)['files'][0]['status'], 'outside_allowed_root')

    def test_invalid_gate_and_count_are_rejected(self):
        for cert in ({'gates': [[0, 0]], 'count': 1}, {'gates': [], 'count': 1}):
            with self.assertRaises(ValueError):
                evidence.verify_encoder([[1, 0], [0, 1]], cert)


if __name__ == '__main__':
    unittest.main()
