import unittest
import numpy as np
from research_v3.contracts import AlphabetSpec, MatrixState
from research_v3.features.registry import FeatureRegistry, FeaturePolicy
from research_v3.features.cache import FeatureCache
from research_v3.features.packet import FeatureSpec
from research_v3.symmetry import map_problem


class FeatureTests(unittest.TestCase):
    def test_group_provider_preserves_roles_and_padding(self):
        registry = FeatureRegistry()
        spec = FeatureSpec('J01', 'group', 2, producer_version='test_v1')
        def producer(state, policy):
            values = np.array([[state.n, 1]], dtype=np.float32)
            incidence = np.zeros((1, state.n, 2), dtype=np.float32)
            incidence[0, 0, 0] = 1
            incidence[0, state.n - 1, 1] = 1
            return values, incidence
        registry.register(spec, producer, symmetry_contract='augmentation_only')
        a = AlphabetSpec.all_to_all(1)
        policy = FeaturePolicy(('J01',), symmetry_contract='augmentation_only')
        packet = registry.build((MatrixState.identity(a), self.state), policy)
        self.assertEqual(packet.group_incidence['J01'].shape, (2, 1, 3, 2))
        self.assertEqual(packet.group_incidence['J01'][0, :, 1:].sum(), 0)
        np.testing.assert_array_equal(packet.features['J01'].values[:, 0, 0], [1, 3])
        with self.assertRaisesRegex(ValueError, 'symmetry'):
            registry.build((self.state,), FeaturePolicy(('J01',)))

    def test_provider_budget_zero_is_unavailable(self):
        registry = FeatureRegistry()
        def producer(state, policy):
            self.fail('zero-budget producer must not run')
        registry.register(FeatureSpec('J01', 'global', 1, producer_version='test_v1'), producer)
        packet = registry.build((self.state,), FeaturePolicy(('J01',), evaluations=0))
        self.assertEqual(packet.features['J01'].status, 'resource_limit')
        self.assertFalse(packet.features['J01'].available.any())

    def test_graph_motifs_against_hand_count(self):
        alphabet = AlphabetSpec.all_to_all(4)
        square = MatrixState(4, (1, 3, 5, 14), alphabet.id)
        packet = FeatureRegistry().build((square,), FeaturePolicy(('B01', 'B02', 'B03', 'B10')))
        np.testing.assert_array_equal(packet.features['B10'].values[0], [[0, 1]] * 4)
        np.testing.assert_array_equal(packet.features['B02'].values[0], [[4]] * 4)
        np.testing.assert_array_equal(packet.features['B03'].values[0], [[1]] * 4)

    def test_resource_limit_before_compute(self):
        registry = FeatureRegistry()
        with self.assertRaises(MemoryError):
            registry.build((self.state,), FeaturePolicy(('A01',), max_bytes=1))
        self.assertEqual(registry.cache.calls, 0)

    def test_cache_results_cannot_poison_later_packets(self):
        registry = FeatureRegistry()
        policy = FeaturePolicy(('A01',))
        first = registry.build((self.state,), policy)
        first.features['A01'].values.setflags(write=True)
        first.features['A01'].values[:] = 9
        second = registry.build((self.state,), policy)
        self.assertLess(second.features['A01'].values.max(), 2)

    def setUp(self):
        self.alphabet = AlphabetSpec.all_to_all(3)
        self.state = MatrixState(3, (1, 3, 7), self.alphabet.id)

    def test_registry_has_all_103_ids(self):
        self.assertEqual(len(FeatureRegistry().specs), 103)

    def test_missing_not_zero(self):
        packet = FeatureRegistry().build((self.state,), FeaturePolicy(('A01', 'D01')))
        self.assertTrue(packet.features['A01'].available[0])
        self.assertFalse(packet.features['D01'].available[0])
        self.assertEqual(packet.features['D01'].status, 'unsupported')
        self.assertEqual(packet.features['D01'].exactness, 'unknown')

    def test_padding_is_not_wire(self):
        a = AlphabetSpec.all_to_all(1)
        packet = FeatureRegistry().build((MatrixState.identity(a), self.state), FeaturePolicy(('A01', 'A03', 'A05')))
        np.testing.assert_array_equal(packet.valid[0], [True, False, False])
        self.assertEqual(packet.features['A03'].values[0, 1:].sum(), 0)
        self.assertEqual(packet.features['A05'].values[0, 1:].sum(), 0)

    def test_collision_safe_cache(self):
        cache = FeatureCache(hash_fn=lambda key: 0)
        self.assertEqual(cache.get_or_compute((1, 'one'), lambda: 1), 1)
        self.assertEqual(cache.get_or_compute((1, 'two'), lambda: 2), 2)
        self.assertEqual(cache.get_or_compute((1, 'one'), lambda: 999), 1)
        self.assertEqual(cache.hits, 1)

    def test_same_state_same_packet_changed_policy_invalidates(self):
        registry = FeatureRegistry()
        p1 = registry.build((self.state,), FeaturePolicy(('A01',), seed=1))
        p2 = registry.build((self.state,), FeaturePolicy(('A01',), seed=1))
        p3 = registry.build((self.state,), FeaturePolicy(('A01',), seed=2))
        np.testing.assert_array_equal(p1.features['A01'].values, p2.features['A01'].values)
        self.assertEqual(p1.policy_id, p2.policy_id)
        self.assertNotEqual(p1.policy_id, p3.policy_id)
        self.assertEqual(registry.cache.hits, 1)

    def test_relabel_equivariance_all_cheap_features(self):
        registry = FeatureRegistry()
        policy = FeaturePolicy(tuple(k for k in registry.specs if k[0] in 'AB') + ('F01',))
        permutation = (2, 0, 1)
        mapped = map_problem(self.state, self.alphabet, permutation).state
        one = registry.build((self.state,), policy)
        two = registry.build((mapped,), policy)
        back = np.argsort(permutation)
        for key, feature in one.features.items():
            actual = two.features[key].values[0]
            expected = feature.values[0]
            if feature.role == 'node':
                expected = expected[back]
            elif feature.role == 'pair':
                expected = expected[back][:, back]
            np.testing.assert_allclose(actual, expected, err_msg=key)

    def test_values_match_direct_matrix_calculation(self):
        packet = FeatureRegistry().build((self.state,), FeaturePolicy(('A01', 'A05', 'A20', 'F01')))
        np.testing.assert_array_equal(packet.features['A05'].values[0, :, 0], [1, 2, 3])
        np.testing.assert_array_equal(packet.features['F01'].values[0], [2, 2])
        # control=0,target=1 turns [1,1,0] into [0,1,0].
        np.testing.assert_array_equal(packet.features['A20'].values[0, 0, 1], [-1, -1])


if __name__ == '__main__':
    unittest.main()
