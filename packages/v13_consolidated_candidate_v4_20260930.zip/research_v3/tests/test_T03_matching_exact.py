import tempfile
import unittest
from dataclasses import replace
from pathlib import Path
import torch
from research_v3.contracts import AlphabetSpec,Gate
from research_v3.data.generators import record_from_word
from research_v3.data.matching import certify_record,verify_record
from research_v3.data.frozen import freeze,load
from research_v3.features.registry import FeaturePolicy,FeatureRegistry
from research_v3.model.field import FusionDistanceField
from research_v3.train.objective import FullGraphObjective

class MatchingExactTests(unittest.TestCase):
 def setUp(self):
  old=torch.get_num_threads();torch.set_num_threads(1);self.addCleanup(torch.set_num_threads,old)
  self.a=AlphabetSpec.all_to_all(8)
  self.record=record_from_word(self.a,(Gate(0,1),Gate(2,3),Gate(4,5)),'own_disjoint',7)
 def test_matching_bounds_frozen_roundtrip_and_bellman(self):
  exact=certify_record(replace(self.record,split='train'))
  self.assertEqual(exact.exact_distance,3)
  self.assertTrue(verify_record(exact))
  with tempfile.TemporaryDirectory() as tmp:
   path=Path(tmp)/'panel.json'
   freeze(path,{'train':[exact],'dev':[],'test':[]},(),{'source':'own matching-bound fixture'})
   panels,_,_=load(path)
   restored=panels['train'][0]
   self.assertEqual(restored.exact_distance,3)
   registry=FeatureRegistry();policy=FeaturePolicy(('A01',))
   model=FusionDistanceField([registry.specs['A01']],d=8,pair_d=4,blocks=1,heads=2,ffn=16,fusion_blocks=1)
   objective=FullGraphObjective((self.a,),registry,policy,qhat_weight=0,neighbor_chunk_size=8)
   loss=objective(model,(restored,));self.assertTrue(torch.isfinite(loss))
   loss.backward();self.assertEqual(objective.last_diagnostics['exact_examples'],1)
 def test_rejects_nonmatching_and_forged_exact(self):
  with self.assertRaisesRegex(ValueError,'does not meet'):
   certify_record(record_from_word(self.a,(Gate(0,1),Gate(0,1)),'own_cancel',8))
  exact=certify_record(self.record)
  for bad in (replace(exact,exact_distance=2),replace(exact,exact_evidence='forged')):
   with self.assertRaises(ValueError):verify_record(bad)

if __name__=='__main__':unittest.main()
