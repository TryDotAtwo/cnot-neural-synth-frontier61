import unittest
from research_v3.contracts import AlphabetSpec
from research_v3.data.exact_small import build_exact_small
from research_v3.bounds import cheap_bounds, cut_bound, action_bound
from research_v3.words import apply


class BoundsTests(unittest.TestCase):
    def test_forged_and_summed_certificates_are_rejected(self):
        from dataclasses import replace
        from research_v3.contracts import MatrixState, BoundSet
        from research_v3.bounds import verify_bounds
        a = AlphabetSpec.all_to_all(3)
        m = MatrixState(3, (1, 3, 7), a.id)
        bounds = cheap_bounds(m)
        verify_bounds(m, bounds, a)
        original = bounds.lower[0]
        for bad in (replace(original, value=999), replace(original, witness_ref='sum_all_cuts')):
            with self.assertRaises(ValueError):
                verify_bounds(m, BoundSet(lower=(bad,)), a)

    def test_all_gl4_bounds_and_action_semantics(self):
        for n in (2, 3, 4):
            a = AlphabetSpec.all_to_all(n)
            catalog = build_exact_small(n, a)
            for state, distance in catalog.distances.items():
                self.assertLessEqual(cheap_bounds(state).lower_bound, distance)
                for mask in range(1, (1 << n) - 1):
                    left = tuple(i for i in range(n) if mask >> i & 1)
                    right = tuple(i for i in range(n) if not mask >> i & 1)
                    self.assertLessEqual(cut_bound(state, left, right).value, distance)
                if n <= 3:
                    for gate in a.allowed:
                        self.assertLessEqual(action_bound(state, gate, a), 1 + catalog.distances[apply(state, gate, a)])

    def test_invalid_cut_is_rejected(self):
        from research_v3.contracts import MatrixState
        m = MatrixState.identity(AlphabetSpec.all_to_all(3))
        for left, right in (((0, 1), (1, 2)), ((0,), (1,)), ((0, 0), (1, 2))):
            with self.assertRaises(ValueError):
                cut_bound(m, left, right)


if __name__ == '__main__':
    unittest.main()
