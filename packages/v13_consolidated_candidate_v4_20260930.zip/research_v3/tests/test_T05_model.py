import unittest
import numpy as np
import torch
from research_v3.contracts import AlphabetSpec, MatrixState, MatrixBatch
from research_v3.features.registry import FeatureRegistry, FeaturePolicy
from research_v3.features.packet import FeatureSpec
from research_v3.model.field import FusionDistanceField
from research_v3.symmetry import map_problem


class ModelTests(unittest.TestCase):
    def test_corrupt_batch_and_padding_rejected(self):
        batch = MatrixBatch.from_states((self.state,))
        corrupted = batch.matrix.clone()
        corrupted[0, 0, 0] = False
        with self.assertRaises(ValueError):
            MatrixBatch(batch.states, corrupted, batch.valid)

    def test_unavailable_feature_has_no_effect(self):
        from dataclasses import replace
        registry = FeatureRegistry()
        policy = FeaturePolicy(('A01', 'D01'))
        packet = registry.build((self.state,), policy)
        model = FusionDistanceField([registry.specs[k] for k in policy.enabled_ids],
                                    d=24, pair_d=8, blocks=2, heads=4, ffn=48).double()
        batch = MatrixBatch.from_states((self.state,))
        original = model(batch, packet).value
        fake = replace(packet.features['D01'], values=np.ones((1, 2, 1), dtype=np.float32) * 1e6,
                       token_valid=np.ones((1, 2), dtype=bool))
        changed = replace(packet, features={**packet.features, 'D01': fake},
                          group_incidence={**packet.group_incidence, 'D01': np.ones((1, 2, 3, 2), dtype=np.float32)})
        torch.testing.assert_close(original, model(batch, changed).value, atol=1e-12, rtol=1e-12)

    def setUp(self):
        torch.set_num_threads(1)
        torch.manual_seed(712)
        self.registry = FeatureRegistry()
        self.policy = FeaturePolicy(('A01', 'A05', 'B01', 'B06', 'F01'))
        self.alphabet = AlphabetSpec.all_to_all(3)
        self.state = MatrixState(3, (1, 3, 7), self.alphabet.id)

    def model(self, ids=None):
        ids = ids or self.policy.enabled_ids
        return FusionDistanceField([self.registry.specs[k] for k in ids], d=24, pair_d=8,
                                   blocks=2, heads=4, ffn=48, fusion_blocks=2).double()

    def evaluate(self, model, states, policy=None):
        states = tuple(states)
        return model(MatrixBatch.from_states(states), self.registry.build(states, policy or self.policy))

    def test_identity_zero_finite_and_both_transformer_gradients(self):
        model = self.model()
        out = self.evaluate(model, (self.state, MatrixState.identity(self.alphabet)))
        self.assertEqual(out.value[1].item(), 0.0)
        self.assertGreater(out.value[0].item(), 0)
        self.assertTrue(torch.isfinite(out.value).all())
        out.value.sum().backward()
        for name in ('stem.blocks', 'fusion.blocks', 'family_heads'):
            norm = sum(p.grad.abs().sum().item() for k, p in model.named_parameters() if k.startswith(name) and p.grad is not None)
            self.assertGreater(norm, 0, name)

    def test_relabel_padding_scalar_invariance(self):
        model = self.model()
        relabeled = map_problem(self.state, self.alphabet, (2, 0, 1)).state
        first = self.evaluate(model, (self.state, relabeled)).value
        torch.testing.assert_close(first[0], first[1], atol=1e-9, rtol=1e-9)
        a = AlphabetSpec.all_to_all(5)
        padded = self.evaluate(model, (self.state, MatrixState.identity(a))).value[0]
        torch.testing.assert_close(first[0], padded, atol=1e-9, rtol=1e-9)

    def test_every_enabled_feature_reaches_first_stem(self):
        model = self.model()
        self.evaluate(model, (self.state,)).value.sum().backward()
        for key in self.policy.enabled_ids:
            norm = sum(p.grad.abs().sum().item() for p in model.stem.projections[key].parameters() if p.grad is not None)
            self.assertGreater(norm, 0, key)

    def test_group_and_ten_families(self):
        ids = []
        for letter in 'ABCDEFGHIJ':
            key = letter + '99'
            spec = FeatureSpec(key, 'group', 2, producer_version='test_v1')
            def producer(state, policy):
                incidence = np.ones((1, state.n, 2), dtype=np.float32)
                return np.array([[2., 3.]], dtype=np.float32), incidence
            self.registry.register(spec, producer)
            ids.append(key)
        model = self.model(ids)
        out = self.evaluate(model, (self.state,), FeaturePolicy(tuple(ids)))
        out.value.sum().backward()
        self.assertEqual(len(model.family_heads.heads), 10)
        for key in ids:
            self.assertGreater(model.stem.projections[key].weight.grad.abs().sum().item(), 0)

    def test_packet_for_different_state_is_rejected(self):
        model = self.model()
        packet = self.registry.build((self.state,), self.policy)
        with self.assertRaises(ValueError):
            model(MatrixBatch.from_states((MatrixState.identity(self.alphabet),)), packet)


if __name__ == '__main__':
    unittest.main()
