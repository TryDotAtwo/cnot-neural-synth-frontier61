import unittest
import torch
from research_v3.contracts import AlphabetSpec, MatrixState, MatrixBatch
from research_v3.features.registry import FeatureRegistry, FeaturePolicy
from research_v3.model.field import FusionDistanceField
from research_v3.objectives.bellman import select_backup, recompute_backup
from research_v3.words import apply


class GradientTests(unittest.TestCase):
    def test_empty_qhat_loss_is_finite_and_identity_successor_target_one(self):
        from research_v3.objectives.auxiliary import absolute_qhat_loss, build_qhat_targets
        q = torch.full((1, 1), torch.inf, dtype=torch.float64, requires_grad=True)
        loss = absolute_qhat_loss(q, q, torch.zeros_like(q, dtype=torch.bool))
        self.assertEqual(loss.item(), 0)
        loss.backward()
        from research_v3.contracts import Gate
        state = apply(MatrixState.identity(self.a), Gate(0, 1), self.a)
        target, allowed = build_qhat_targets(self.model, (state,), self.registry, self.policy, self.a)
        self.assertEqual(target[0, 0, 1].item(), 1)
        self.assertEqual(int(allowed.sum()), 6)
        self.assertFalse(target.requires_grad)

    def test_auxiliary_heads_detach_value_but_train_encoder(self):
        from research_v3.model.auxiliary import AuxiliaryHeads
        head = AuxiliaryHeads(d=8, pair_d=4).double()
        wire = torch.randn(1, 3, 8, dtype=torch.float64, requires_grad=True)
        pair = torch.randn(1, 3, 3, 4, dtype=torch.float64, requires_grad=True)
        value = torch.tensor([3.], dtype=torch.float64, requires_grad=True)
        valid = torch.tensor([[True, True, False]])
        proposal, qhat, allowed = head(wire, pair, value, valid)
        self.assertEqual(int(allowed.sum()), 2)
        self.assertTrue(torch.isfinite(qhat[allowed]).all())
        (qhat[allowed].sum() + proposal[allowed].sum()).backward()
        self.assertIsNone(value.grad)
        self.assertGreater(wire.grad.abs().sum().item(), 0)
        self.assertGreater(pair.grad.abs().sum().item(), 0)

    def test_field_returns_separate_auxiliary_outputs(self):
        batch = MatrixBatch.from_states((self.state,))
        output = self.model(batch, self.registry.build((self.state,), self.policy))
        self.assertEqual(output.proposal.shape, (1, 3, 3))
        self.assertEqual(output.qhat.shape, (1, 3, 3))
        self.assertTrue(torch.isinf(output.qhat[0].diagonal()).all())

    def test_exact_field_macros_tie_and_first_index_rule(self):
        from research_v3.data.exact_small import build_exact_small
        from research_v3.contracts import ModelOutput
        catalog = build_exact_small(3, self.a)
        class ExactField(torch.nn.Module):
            def __init__(self):
                super().__init__()
                self.scale = torch.nn.Parameter(torch.tensor(1., dtype=torch.float64))
            def forward(self, batch, packet):
                return ModelOutput(self.scale * self.scale.new_tensor([catalog.distances[s] for s in batch.states]))
        model = ExactField()
        selection = select_backup(model, (self.state,), self.registry, self.policy, self.a,
                                  macros=lambda state: (catalog.certificate(state),))
        branch = selection.branches[0]
        costs = [1 + catalog.distances[apply(self.state, g, self.a)] for g in self.a.allowed]
        self.assertEqual(branch.selected_index, costs.index(min(costs)))
        self.assertEqual(branch.macro_margin, 0)
        self.assertEqual(recompute_backup(model, selection).loss.item(), 0)

    def test_parent_offsets_detected_by_absolute_qhat(self):
        from research_v3.objectives.auxiliary import absolute_qhat_loss
        target = torch.tensor([[2., 3.], [5., 6.]], dtype=torch.float64, requires_grad=True)
        q = target.detach().clone().requires_grad_(True)
        mask = torch.ones_like(q, dtype=torch.bool)
        base = absolute_qhat_loss(q, target, mask)
        shifted = absolute_qhat_loss(q + torch.tensor([[4.], [-4.]]), target, mask)
        self.assertEqual(base.item(), 0)
        self.assertGreater(shifted.item(), 0)
        shifted.backward()
        self.assertIsNone(target.grad)

    def test_ub_not_treated_as_exact_supervision(self):
        from research_v3.data.generators import record_from_word
        from research_v3.contracts import Gate
        from research_v3.objectives.supervision import supervised_losses
        record = record_from_word(self.a, (Gate(0, 1),) * 3, 'test', 1)
        value = torch.tensor([1.5], dtype=torch.float64, requires_grad=True)
        report = supervised_losses(value, (record,), self.a)
        self.assertEqual(report.loss.item(), 0)
        self.assertEqual(report.diagnostics['exact_examples'], 0)

    def setUp(self):
        torch.set_num_threads(1)
        torch.manual_seed(887)
        self.a = AlphabetSpec.all_to_all(3)
        self.state = MatrixState(3, (1, 3, 7), self.a.id)
        self.registry = FeatureRegistry()
        self.policy = FeaturePolicy(('A01', 'A05', 'B01'))
        self.model = FusionDistanceField([self.registry.specs[k] for k in self.policy.enabled_ids],
                                        d=16, pair_d=4, heads=2, blocks=1, ffn=24, fusion_blocks=1).double()

    def test_selected_gradient_equals_all_neighbor_autograd(self):
        selected = select_backup(self.model, (self.state,), self.registry, self.policy, self.a)
        loss = recompute_backup(self.model, selected).loss
        loss.backward()
        actual = [p.grad.clone() if p.grad is not None else torch.zeros_like(p) for p in self.model.parameters()]
        self.model.zero_grad(set_to_none=True)
        states = tuple(apply(self.state, g, self.a) for g in self.a.allowed)
        values = self.model(MatrixBatch.from_states(states), self.registry.build(states, self.policy)).value
        parent = self.model(MatrixBatch.from_states((self.state,)), self.registry.build((self.state,), self.policy)).value[0]
        best = torch.min(values + 1, dim=0).values
        torch.nn.functional.smooth_l1_loss(parent - best, torch.zeros_like(parent)).backward()
        expected = [p.grad if p.grad is not None else torch.zeros_like(p) for p in self.model.parameters()]
        self.assertLessEqual(max((a - b).abs().max().item() for a, b in zip(actual, expected)), 1e-8)

    def test_changed_theta_rejected(self):
        selected = select_backup(self.model, (self.state,), self.registry, self.policy, self.a)
        with torch.no_grad():
            next(self.model.parameters()).add_(0.1)
        with self.assertRaisesRegex(ValueError, 'theta'):
            recompute_backup(self.model, selected)

    def test_changed_packet_rejected(self):
        selected = select_backup(self.model, (self.state,), self.registry, self.policy, self.a)
        values = selected.branches[0].parent_packet.features['A01'].values
        values.setflags(write=True)
        values[:] = 0
        with self.assertRaisesRegex(ValueError, 'packet'):
            recompute_backup(self.model, selected)

    def test_terminal_has_no_cost_one_residual(self):
        selected = select_backup(self.model, (MatrixState.identity(self.a),), self.registry, self.policy, self.a)
        result = recompute_backup(self.model, selected)
        self.assertEqual(result.loss.item(), 0)
        self.assertEqual(result.diagnostics['terminal_count'], 1)
        result.loss.backward()
        self.assertEqual(sum(p.grad.abs().sum().item() for p in self.model.parameters() if p.grad is not None), 0)


if __name__ == '__main__':
    unittest.main()
