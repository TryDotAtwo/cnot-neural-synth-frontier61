import itertools
from fractions import Fraction
import unittest
import numpy as np
from research_v3.basis.templates import BasisTemplate, BasisChoice, compile_basis
from research_v3.basis.objective import evaluate_J
from research_v3.basis.rounding import conditional_round
from research_v3.words import verify_word
from research_v3.contracts import AlphabetSpec


class BasisTests(unittest.TestCase):
    def test_boundary_stationary_trap_does_not_imply_global_optimum(self):
        def value(p, q):
            return 61 + 3 * p + q - 6 * p * q
        p, q = 0., 0.
        for _ in range(10):
            dp, dq = 3 - 6 * q, 1 - 6 * p
            p, q = np.clip(p - .1 * dp, 0, 1), np.clip(q - .1 * dq, 0, 1)
        self.assertEqual(value(p, q), 61)
        self.assertEqual(value(1, 1), 59)

    def test_torch_objective_and_basis_proposal_gradient(self):
        import torch
        from research_v3.basis.proposal import BasisProposal, differentiable_J
        from research_v3.contracts import EncodedState
        torch.manual_seed(77)
        template = self.template()
        wire = torch.randn(1, 8, 12, dtype=torch.float64, requires_grad=True)
        encoded = EncodedState(wire, None, None, None, torch.ones(1, 8, dtype=torch.bool), None, None)
        proposer = BasisProposal(12, 16).double()
        theta = proposer(encoded, template)
        block = ((1, 1, 1, 1),) * 4
        objective = differentiable_J(template, block, theta)
        reference, gradient = evaluate_J(template, block, theta.detach().numpy())
        actual = torch.autograd.grad(objective, theta, retain_graph=True)[0]
        np.testing.assert_allclose(actual.detach().numpy(), gradient, atol=1e-10)
        self.assertAlmostEqual(objective.item(), reference, places=10)
        objective.backward()
        self.assertGreater(wire.grad.abs().sum().item(), 0)
        self.assertGreater(sum(p.grad.abs().sum().item() for p in proposer.parameters()), 0)

    def template(self, side='source'):
        return BasisTemplate(8, (0, 1, 2, 3), (4, 5, 6, 7), side,
                             (BasisChoice('add', 0, 1), BasisChoice('swap', 1, 2), BasisChoice('add', 2, 3)))

    def test_exact_expectation_gradient_and_all_words(self):
        block = ((1, 1, 0, 1), (0, 1, 1, 0), (1, 0, 1, 1), (1, 1, 1, 1))
        theta = (Fraction(1, 3), Fraction(1, 2), Fraction(3, 4))
        for side in ('source', 'target'):
            template = self.template(side)
            costs = {}
            for bits in itertools.product((0, 1), repeat=3):
                candidate = compile_basis(template, block, bits)
                verify_word(candidate.certificate, AlphabetSpec.all_to_all(8))
                costs[bits] = candidate.certificate.physical_cost
            expected = sum(cost * np.prod([theta[j] if bit else 1 - theta[j] for j, bit in enumerate(bits)])
                           for bits, cost in costs.items())
            value, gradient = evaluate_J(template, block, theta)
            self.assertEqual(value, expected)
            for j in range(3):
                endpoints = []
                for bit in (0, 1):
                    point = list(theta)
                    point[j] = Fraction(bit)
                    endpoints.append(evaluate_J(template, block, point)[0])
                self.assertEqual(gradient[j], endpoints[1] - endpoints[0])

    def test_rounding_and_physical_price(self):
        template = self.template()
        block = ((1, 1, 1, 1),) * 4
        theta = (Fraction(1, 2),) * 3
        candidate = conditional_round(template, block, theta)
        self.assertLessEqual(candidate.certificate.physical_cost, evaluate_J(template, block, theta)[0])
        self.assertEqual(candidate.certificate.physical_cost, 2 * len(candidate.preparation) + len(candidate.core))

    def test_memory_refusal_is_explicit(self):
        with self.assertRaises(MemoryError):
            evaluate_J(self.template(), ((1, 1, 1, 1),) * 4, (0.5,) * 3, max_bytes=1)

    def test_invalid_probabilities_rejected(self):
        with self.assertRaises(ValueError):
            evaluate_J(self.template(), ((1, 1, 1, 1),) * 4, (0.5, -0.1, 0.5))


if __name__ == '__main__':
    unittest.main()
