import itertools
import unittest
import numpy as np
from research_v3.basis.templates import BasisTemplate, BasisChoice
from research_v3.basis.objective import evaluate_J
from research_v3.basis.wide import coordinate_gradient_sample, estimate_mc, optimize_wide, WideBudget


class WideTests(unittest.TestCase):
    def test_shared_optimizer_preserves_joint_bits(self):
        result = optimize_wide(((1, 1, 1),) * 3, self.template(), (.5,), 'shared_mc',
                               WideBudget(2, 4, 100, 2**20), seed=1, choice_groups=((0, 1),))
        self.assertEqual(result.status, 'budget_complete')
        self.assertEqual(result.best.bits[0], result.best.bits[1])
        self.assertEqual(result.trace[0]['gradient_kind'], 'unbiased_shared_latent_mc')

    def test_shared_choice_gradient_uses_joint_toggle(self):
        from research_v3.basis.wide import estimate_shared_mc
        from research_v3.basis.templates import compile_basis
        template = self.template()
        block = ((1, 1, 1),) * 3
        expected = compile_basis(template, block, (1, 1)).certificate.physical_cost - compile_basis(template, block, (0, 0)).certificate.physical_cost
        result = estimate_shared_mc(template, block, (.4,), ((0, 1),), samples=4, seed=8)
        self.assertEqual(result.gradient[0], expected)
        self.assertEqual(result.gradient_se[0], 0)
        with self.assertRaises(ValueError):
            estimate_shared_mc(template, block, (.4, .5), ((0, 1), (1,)), samples=4, seed=8)

    def template(self, w=3):
        return BasisTemplate(2 * w, tuple(range(w)), tuple(range(w, 2 * w)), 'source',
                             (BasisChoice('add', 0, 1), BasisChoice('add', 1, 2)))

    def test_estimator_expectation_equals_exact_gradient(self):
        template = self.template()
        block = ((1, 1, 1), (1, 0, 1), (0, 1, 1))
        for theta in ((0., 1.), (.2, .7), (.5, .5)):
            expected = np.zeros(2)
            for bits in itertools.product((0, 1), repeat=2):
                weight = np.prod([theta[j] if bit else 1 - theta[j] for j, bit in enumerate(bits)])
                expected += weight * coordinate_gradient_sample(template, block, bits)
            np.testing.assert_allclose(expected, evaluate_J(template, block, theta)[1], atol=1e-12)

    def test_endpoint_mc_is_finite(self):
        estimate = estimate_mc(self.template(), ((1, 1, 1),) * 3, (0., 1.), samples=4, seed=7)
        self.assertTrue(np.isfinite(estimate.gradient).all())
        self.assertEqual(estimate.samples, 4)
        self.assertEqual(estimate.evaluations, 20)

    def test_wide32_does_not_shrink_and_exact_refusal(self):
        template = self.template(32)
        block = np.ones((32, 32), dtype=np.uint8)
        exact = optimize_wide(block, template, (.5, .5), 'exact_messages', WideBudget(1, 4, 100, 4096), seed=1)
        self.assertEqual(exact.status, 'resource_limit')
        mc = optimize_wide(block, template, (.5, .5), 'mc', WideBudget(1, 4, 100, 2**20), seed=1)
        self.assertEqual(mc.physical_width, 32)
        self.assertIsNotNone(mc.best)
        self.assertEqual(mc.best.certificate.start.n, 64)

    def test_budget_stops_by_evaluations_not_time(self):
        result = optimize_wide(((1, 1, 1),) * 3, self.template(), (.5, .5), 'mc',
                               WideBudget(10, 100, 2, 2**20), seed=2)
        self.assertEqual(result.status, 'resource_limit')
        self.assertLessEqual(result.evaluations, 2)


if __name__ == '__main__':
    unittest.main()
