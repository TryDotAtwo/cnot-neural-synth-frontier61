import unittest
from research_v3.contracts import AlphabetSpec, Gate, MatrixState
from research_v3.basis.templates import BasisTemplate, BasisChoice, compile_basis
from research_v3.basis.compose import compose_blocks
from research_v3.basis.frames import open_frame, materialize
from research_v3.words import apply, verify_word


class FrameTests(unittest.TestCase):
    def test_shared_preparation_is_paid_once(self):
        a = AlphabetSpec.all_to_all(4)
        template = BasisTemplate(4, (0, 1), (2, 3), 'source', (BasisChoice('add', 0, 1),))
        first = compile_basis(template, ((1, 1), (0, 0)), (1,))
        second = compile_basis(template, ((0, 0), (1, 1)), (1,))
        joined = compose_blocks((first, second), a)
        self.assertEqual(first.certificate.physical_cost + second.certificate.physical_cost, 6)
        self.assertEqual(joined.physical_cost, 4)
        verify_word(joined, a)

    def test_noncommuting_preparations_and_arbitrary_start(self):
        a = AlphabetSpec.all_to_all(4)
        t1 = BasisTemplate(4, (0, 1), (2, 3), 'source', (BasisChoice('add', 0, 1),))
        t2 = BasisTemplate(4, (0, 1), (2, 3), 'source', (BasisChoice('add', 1, 0),))
        blocks = (compile_basis(t1, ((1, 1), (1, 0)), (1,)), compile_basis(t2, ((0, 1), (1, 1)), (1,)))
        start = apply(MatrixState.identity(a), Gate(3, 0), a)
        end = start
        for block in blocks:
            for gate in block.certificate.gates:
                end = apply(end, gate, a)
        joined = compose_blocks(blocks, a, start=start)
        self.assertEqual(joined.end, end)
        verify_word(joined, a)

    def test_materialization_restores_paid_swap(self):
        a = AlphabetSpec.all_to_all(3)
        prep = (Gate(0, 1), Gate(1, 0), Gate(0, 1))
        frame = open_frame(MatrixState.identity(a), prep, (Gate(1, 2),), a)
        cert = materialize(frame, a)
        self.assertEqual(cert.physical_cost, 7)
        verify_word(cert, a)
        self.assertEqual(cert.end.packed_rows, (1, 2, 5))


if __name__ == '__main__':
    unittest.main()
