import unittest
from research_v3.contracts import AlphabetSpec, Gate, MatrixState, WordCertificate
from research_v3.words import apply, verify_word
from research_v3.postprocess import shorten, WindowBudget, replace_window


def certificate(a, word):
    start = MatrixState.identity(a)
    end = start
    for gate in word:
        end = apply(end, gate, a)
    return WordCertificate(start, end, tuple(word), sum(a.cost(g) for g in word), 'test', 'test')


class WindowTests(unittest.TestCase):
    def test_symmetry_restarts_return_original_full_reductions(self):
        from research_v3.postprocess import symmetry_restarts
        from research_v3.words import invert_word
        a = AlphabetSpec.all_to_all(2)
        state = certificate(a, (Gate(0, 1), Gate(1, 0))).end
        calls = []
        def compiler(mapped, alphabet, *, evaluations):
            calls.append(evaluations)
            from research_v3.data.exact_small import build_exact_small
            return build_exact_small(2, alphabet).certificate(mapped)
        result = symmetry_restarts(state, a, compiler, ('inverse', 'transpose', (1, 0)), evaluations_per_restart=20)
        self.assertEqual(calls, [20, 20, 20])
        self.assertEqual(result['best'].start, state)
        for row in result['runs']:
            verify_word(row['certificate'], a)

    def test_commuting_cancellation(self):
        a = AlphabetSpec.all_to_all(4)
        cert = certificate(a, (Gate(0, 1), Gate(2, 3), Gate(0, 1)))
        result = shorten(cert, a, WindowBudget(2, 3, 1000, 1000))
        self.assertEqual(result.after.physical_cost, 1)
        verify_word(result.after, a)

    def test_noncommuting_window_replacement(self):
        a = AlphabetSpec.all_to_all(3)
        cert = certificate(a, (Gate(0, 1), Gate(1, 2), Gate(0, 1)))
        result = shorten(cert, a, WindowBudget(1, 3, 1000, 1000))
        self.assertEqual(result.after.physical_cost, 2)
        self.assertEqual(result.after.end, cert.end)

    def test_wrong_endpoint_is_rejected_even_on_unused_wires(self):
        a = AlphabetSpec.all_to_all(4)
        cert = certificate(a, (Gate(0, 1), Gate(0, 1)))
        with self.assertRaises(ValueError):
            replace_window(cert, 0, 2, (Gate(2, 3),), a)

    def test_resource_limit_preserves_verified_incumbent(self):
        a = AlphabetSpec.all_to_all(3)
        cert = certificate(a, (Gate(0, 1), Gate(1, 2), Gate(0, 1)))
        result = shorten(cert, a, WindowBudget(1, 3, 0, 1))
        self.assertEqual(result.after, cert)
        self.assertEqual(result.status, 'resource_limit')

    def test_no_improvement_is_explicit(self):
        a = AlphabetSpec.all_to_all(3)
        cert = certificate(a, (Gate(0, 1),))
        result = shorten(cert, a, WindowBudget(1, 3, 100, 100))
        self.assertEqual(result.after, cert)
        self.assertEqual(result.savings, 0)

    def test_wide_matrix_window_uses_only_original_support(self):
        a=AlphabetSpec.all_to_all(40)
        cert=certificate(a,(Gate(2,31),Gate(5,6),Gate(2,31)))
        result=shorten(cert,a,WindowBudget(1,3,2000,2000,True))
        self.assertEqual(result.after.physical_cost,1)
        self.assertEqual(result.after.end,cert.end)
        self.assertEqual(result.window_records[0]['support_wires'],[2,5,6,31])
        self.assertLess(result.evaluations,2000)


if __name__ == '__main__':
    unittest.main()
