import unittest
from research_v3.contracts import AlphabetSpec,MatrixState
from research_v3.basis.wide import WideBudget
from research_v3.search.basis_macros import PaidBasisMacros,recognize_shear
from research_v3.words import verify_word


class BasisMacroTests(unittest.TestCase):
    def test_partial_block_exact_endpoints_on_all_gl3(self):
        from research_v3.data.exact_small import build_exact_small
        from research_v3.search.basis_macros import partial_shear
        a=AlphabetSpec.all_to_all(3)
        used=0
        for state in build_exact_small(3,a).distances:
            parsed=partial_shear(state)
            if parsed is None:continue
            producer=PaidBasisMacros(WideBudget(0,1,1,2**20),max_calls=1)
            cert,=producer(state)
            verify_word(cert,a)
            used+=1
            if producer.audit[0]['mode']=='partial_elimination':
                self.assertTrue(all(not ((cert.end.packed_rows[t]>>c)&1) for t in parsed[1] for c in parsed[3]))
        self.assertGreater(used,100)

    def test_search_bridge_reports_solver_assistance(self):
        from research_v3.search.basis_macros import solve_with_paid_basis
        from research_v3.search.reference import SearchConfig
        from research_v3.features.registry import FeatureRegistry,FeaturePolicy
        a=AlphabetSpec.all_to_all(8)
        state=MatrixState(8,tuple((1<<i)^(15 if i>=4 else 0) for i in range(8)),a.id)
        producer=PaidBasisMacros(WideBudget(2,4,59,2**20),max_calls=1,choices=3,seed=19)
        result=solve_with_paid_basis(state,None,FeatureRegistry(),
                                    SearchConfig(a,FeaturePolicy(('A01',)),max_expansions=1,max_cost=16),producer)
        self.assertEqual(result.status,'solved')
        self.assertIsNone(result.raw_neural_word)
        self.assertTrue(result.provenance['solver_assisted'])
        verify_word(result.raw_search_word,a)
        self.assertEqual(result.diagnostics['paid_basis']['evaluations'],59)

    def test_full_width_paid_reduction_and_explicit_call_budget(self):
        a=AlphabetSpec.all_to_all(8)
        state=MatrixState(8,tuple((1<<i)^(15 if i>=4 else 0) for i in range(8)),a.id)
        producer=PaidBasisMacros(WideBudget(2,4,59,2**20),max_calls=1,choices=3,seed=19)
        word,=producer(state)
        verify_word(word,a)
        self.assertEqual(word.end,MatrixState.identity(a))
        self.assertEqual(producer.audit[0]['width'],4)
        self.assertEqual(producer.evaluations,59)
        self.assertLessEqual(word.physical_cost,16)
        audit=producer.audit[0]
        self.assertEqual(word.physical_cost,audit['preparation']+audit['core']+audit['restoration'])
        self.assertEqual(producer(state),())

    def test_general_matrix_and_zero_budget_never_fabricate_word(self):
        a=AlphabetSpec.all_to_all(3)
        state=MatrixState(3,(1,3,7),a.id)
        self.assertIsNone(recognize_shear(state))
        producer=PaidBasisMacros(WideBudget(1,1,10,2**20),max_calls=1,allow_partial=False)
        self.assertEqual(producer(state),())
        shear=MatrixState(3,(1,2,7),a.id)
        producer=PaidBasisMacros(WideBudget(1,1,0,2**20),max_calls=1)
        self.assertEqual(producer(shear),())


if __name__ == '__main__':
    unittest.main()
