import unittest
import torch
from research_v3.contracts import AlphabetSpec,MatrixState
from research_v3.features.registry import FeatureRegistry,FeaturePolicy
from research_v3.model.field import FusionDistanceField
from research_v3.basis.learning import BasisField
from research_v3.basis.wide import WideBudget
from research_v3.search.learned_basis import LearnedBasisMacros
from research_v3.words import verify_word


class LearnedBasisTests(unittest.TestCase):
    def test_real_proposal_probabilities_reach_verified_macro(self):
        old=torch.get_num_threads();torch.set_num_threads(1);self.addCleanup(torch.set_num_threads,old)
        registry=FeatureRegistry();policy=FeaturePolicy(('A01',))
        field=FusionDistanceField([registry.specs['A01']],d=8,pair_d=4,blocks=1,heads=2,ffn=16,fusion_blocks=1)
        model=BasisField(field,hidden=16)
        with torch.no_grad():
            for p in model.proposer.parameters():p.zero_()
            model.proposer.network[-1].bias.fill_(2.)
        a=AlphabetSpec.all_to_all(8)
        state=MatrixState(8,tuple((1<<i)^(15 if i>=4 else 0) for i in range(8)),a.id)
        producer=LearnedBasisMacros(model,registry,policy,'test-fixture-not-trained',WideBudget(1,2,16,2**20),max_calls=1,choices=3)
        word,=producer(state)
        verify_word(word,a)
        self.assertEqual(producer.proposal_forwards,1)
        self.assertTrue(model.training)
        expected=float(torch.sigmoid(torch.tensor(2.)))
        for value in producer.audit[0]['initial_probabilities']:self.assertAlmostEqual(value,expected,places=6)
        self.assertEqual(producer.audit[0]['initialization'],'learned_basis_proposal')
        self.assertEqual(producer(state),())
        self.assertEqual(producer.proposal_forwards,1)
        with self.assertRaises(ValueError):
            LearnedBasisMacros(field,registry,policy,'raw-field',WideBudget(1,2,16,2**20),max_calls=1)


if __name__ == '__main__':unittest.main()
