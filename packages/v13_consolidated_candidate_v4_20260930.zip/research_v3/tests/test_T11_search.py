import unittest
import torch
from research_v3.contracts import AlphabetSpec, MatrixState, Gate, ModelOutput, WordCertificate
from research_v3.words import apply, verify_word
from research_v3.features.registry import FeatureRegistry, FeaturePolicy
from research_v3.search.reference import solve, SearchConfig


class ToyField(torch.nn.Module):
    def __init__(self):
        super().__init__()
        self.weight = torch.nn.Parameter(torch.tensor(0.))
    def forward(self, batch, packet):
        b, n, _ = batch.matrix.shape
        values = self.weight + torch.tensor([1e6 if s.packed_rows == tuple(1 << i for i in range(s.n)) else 1.
                                             for s in batch.states])
        return ModelOutput(values, torch.zeros(b, n, n), torch.ones(b, n, n) * 2)


class SearchTests(unittest.TestCase):
    def test_shortlist_ties_report_hit_separately_from_coverage(self):
        from research_v3.search.scoring import shortlist_metrics
        result = shortlist_metrics([2., 2., 5.], [0])
        self.assertTrue(result['best_set_hit'])
        self.assertEqual(result['minimizer_coverage'], .5)
        self.assertEqual(result['regret'], 0.)
        result = shortlist_metrics([2., 2., 5.], [2])
        self.assertFalse(result['best_set_hit'])
        self.assertEqual(result['regret'], 3.)

    def test_reopen_with_better_physical_cost(self):
        from research_v3.data.exact_small import build_exact_small
        catalog = build_exact_small(3, self.a)
        root = next(s for s, d in catalog.distances.items() if d == 6)
        first, second = self.a.allowed[:2]
        y = apply(root, first, self.a)
        x = apply(y, second, self.a)
        self.assertGreaterEqual(catalog.distances[x], 4)
        class Ranked(ToyField):
            def forward(inner, batch, packet):
                output = super().forward(batch, packet)
                output.value = inner.weight + torch.tensor([0. if s == x else 5. if s == y else 100. for s in batch.states])
                return output
        macro = WordCertificate(root, x, (first, second, first, first), 4, 'test', 'test')
        result = solve(root, Ranked(), self.registry,
                       SearchConfig(self.a, self.policy, beam_width=2, max_cost=4),
                       macros=lambda state: (macro,) if state == root else ())
        self.assertGreaterEqual(result.counts['reopened'], 1)

    def setUp(self):
        self.a = AlphabetSpec.all_to_all(3)
        self.registry = FeatureRegistry()
        self.policy = FeaturePolicy(('A01',))
        self.model = ToyField()

    def test_goal_checked_before_bad_score_and_pruning(self):
        state = apply(MatrixState.identity(self.a), Gate(0, 1), self.a)
        result = solve(state, self.model, self.registry, SearchConfig(self.a, self.policy, beam_width=1, max_cost=1))
        self.assertEqual(result.status, 'solved')
        self.assertEqual(result.raw_neural_word.physical_cost, 1)
        verify_word(result.raw_neural_word, self.a)

    def test_goal_does_not_require_unused_action_scores(self):
        class InvalidHeads(ToyField):
            def forward(inner, batch, packet):
                raise AssertionError('goal must be accepted without model evaluation')
        state = apply(MatrixState.identity(self.a), Gate(0, 1), self.a)
        for scoring in ('absolute_qhat', 'proposal_then_v'):
            result = solve(state, InvalidHeads(), self.registry,
                           SearchConfig(self.a, self.policy, scoring=scoring, shortlist=1, max_cost=2))
            self.assertEqual(result.raw_neural_word.physical_cost, 1)

    def test_model_forward_counts_separate_action_and_value(self):
        state = MatrixState(3, (1, 3, 7), self.a.id)
        class CountingField(ToyField):
            def __init__(inner):
                super().__init__()
                inner.calls = 0
            def forward(inner, batch, packet):
                inner.calls += 1
                return super().forward(batch, packet)
        for scoring in ('direct_v', 'absolute_qhat', 'hamming_control'):
            model = CountingField()
            result = solve(state, model, self.registry,
                           SearchConfig(self.a, self.policy, scoring=scoring,
                                        beam_width=1, max_cost=3, max_expansions=1,
                                        inference_batch_size=2))
            counts = result.counts
            self.assertEqual(counts['primitive_feature_packet_builds'],
                             counts['value_model_forwards'] + counts['action_model_forwards'])
            self.assertEqual(counts['primitive_feature_packet_builds'], model.calls)
            if scoring == 'direct_v':
                self.assertGreater(counts['value_model_forwards'], 0)
                self.assertEqual(counts['action_model_forwards'], 0)
            elif scoring == 'absolute_qhat':
                self.assertEqual(counts['value_model_forwards'], 0)
                self.assertEqual(counts['action_model_forwards'], 1)
            else:
                self.assertEqual(counts['primitive_feature_packet_builds'], 0)

    def test_failure_not_replaced_with_incumbent(self):
        from research_v3.data.exact_small import build_exact_small
        state = MatrixState(3, (1, 3, 7), self.a.id)
        incumbent = build_exact_small(3, self.a).certificate(state)
        result = solve(state, self.model, self.registry, SearchConfig(self.a, self.policy, max_cost=0), incumbent=incumbent)
        self.assertNotEqual(result.status, 'solved')
        self.assertIsNone(result.raw_neural_word)
        self.assertEqual(result.best_verified_word, incumbent)

    def test_full_shortlist_equals_direct(self):
        state = MatrixState(3, (1, 3, 7), self.a.id)
        outputs = []
        for scoring in ('direct_v', 'proposal_then_v'):
            result = solve(state, self.model, self.registry,
                           SearchConfig(self.a, self.policy, scoring=scoring, shortlist=None, beam_width=16, max_cost=5))
            outputs.append(result.raw_neural_word.gates)
        self.assertEqual(outputs[0], outputs[1])

    def test_paid_macro_uses_physical_cost(self):
        state = MatrixState(3, (1, 3, 7), self.a.id)
        word = (Gate(1, 2), Gate(0, 1))
        macro = WordCertificate(state, MatrixState.identity(self.a), word, 2, 'test', 'test')
        result = solve(state, self.model, self.registry, SearchConfig(self.a, self.policy, max_cost=1),
                       macros=lambda s: (macro,) if s == state else ())
        self.assertIsNone(result.raw_neural_word)
        result = solve(state, self.model, self.registry, SearchConfig(self.a, self.policy, max_cost=2),
                       macros=lambda s: (macro,) if s == state else ())
        self.assertEqual(result.raw_neural_word.physical_cost, 2)

    def test_all_gl3_wide_zero_field_returns_exact_lengths(self):
        from research_v3.data.exact_small import build_exact_small
        catalog = build_exact_small(3, self.a)
        for state, distance in catalog.distances.items():
            result = solve(state, self.model, self.registry,
                           SearchConfig(self.a, self.policy, beam_width=168, max_cost=6))
            self.assertEqual(result.raw_neural_word.physical_cost, distance)


if __name__ == '__main__':
    unittest.main()
