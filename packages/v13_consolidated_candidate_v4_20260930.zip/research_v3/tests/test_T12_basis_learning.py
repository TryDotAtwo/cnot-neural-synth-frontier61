import unittest
import torch
import numpy as np
from research_v3.basis.templates import BasisChoice,BasisTemplate
from research_v3.basis.learning import BasisField,differentiable_mc_cost
from research_v3.basis.wide import estimate_mc
from research_v3.model.field import FusionDistanceField
from research_v3.features.registry import FeatureRegistry,FeaturePolicy
from research_v3.contracts import AlphabetSpec,MatrixState


class BasisLearningTests(unittest.TestCase):
    def test_combined_bellman_and_basis_updates_both_transformers(self):
        from dataclasses import replace
        from research_v3.contracts import Gate
        from research_v3.data.generators import record_from_word
        from research_v3.train.objective import FullGraphObjective
        old=torch.get_num_threads();torch.set_num_threads(1)
        self.addCleanup(torch.set_num_threads,old)
        torch.manual_seed(61)
        a=AlphabetSpec.all_to_all(6)
        record=replace(record_from_word(a,tuple(Gate(c,t) for c in range(3) for t in range(3,6)),'fixture',61),split='train')
        template=BasisTemplate(6,(0,1,2),(3,4,5),'source',(BasisChoice('add',0,1),))
        registry=FeatureRegistry();policy=FeaturePolicy(('A01','B01'))
        model=BasisField(FusionDistanceField([registry.specs[k] for k in policy.enabled_ids],d=8,pair_d=4,
                                            blocks=1,heads=2,ffn=16,fusion_blocks=1),hidden=16)
        objective=FullGraphObjective((a,),registry,policy)
        cost,_=model.basis_loss(record.state,template,np.ones((3,3)),registry,policy,backend='mc',samples=2)
        (objective(model,(record,))+.1*cost).backward()
        for module in (model.proposer,model.field.stem,model.field.fusion):
            self.assertGreater(sum(float(p.grad.abs().sum()) for p in module.parameters() if p.grad is not None),0)
        with self.assertRaisesRegex(ValueError,'not bound'):
            model.basis_loss(record.state,template,np.zeros((3,3)),registry,policy,backend='mc')

    def test_mc_autograd_matches_paid_conditional_estimator_at_boundaries(self):
        template=BasisTemplate(8,tuple(range(4)),tuple(range(4,8)),'source',
                               (BasisChoice('add',0,1),BasisChoice('add',2,3)))
        block=np.ones((4,4),dtype=np.uint8)
        theta=torch.tensor([0.,1.],dtype=torch.float64,requires_grad=True)
        loss,audit=differentiable_mc_cost(template,block,theta,samples=4,seed=19,max_evaluations=20,max_bytes=2**20)
        expected=estimate_mc(template,block,theta.detach().numpy(),4,19)
        loss.backward()
        np.testing.assert_allclose(theta.grad.numpy(),expected.gradient,atol=1e-12)
        self.assertEqual(loss.item(),expected.value)
        self.assertEqual(audit['evaluations'],20)
        with self.assertRaises(RuntimeError):
            differentiable_mc_cost(template,block,theta,samples=4,seed=19,max_evaluations=19,max_bytes=2**20)

    def test_full_matrix_encoder_and_proposal_receive_wide_gradient(self):
        old=torch.get_num_threads();torch.set_num_threads(1)
        self.addCleanup(torch.set_num_threads,old)
        torch.manual_seed(19)
        width=16;n=2*width;a=AlphabetSpec.all_to_all(n)
        state=MatrixState(n,tuple((1<<i)^((1<<width)-1 if i>=width else 0) for i in range(n)),a.id)
        template=BasisTemplate(n,tuple(range(width)),tuple(range(width,n)),'source',
                               (BasisChoice('add',0,1),BasisChoice('add',width-2,width-1)))
        registry=FeatureRegistry();policy=FeaturePolicy(('A01','B01'))
        field=FusionDistanceField([registry.specs[k] for k in policy.enabled_ids],d=8,pair_d=4,
                                   blocks=1,heads=2,ffn=16,fusion_blocks=1)
        model=BasisField(field,hidden=16)
        loss,audit=model.basis_loss(state,template,np.ones((width,width),dtype=np.uint8),registry,policy,
                                    backend='mc',samples=4,seed=19,max_evaluations=20)
        loss.backward()
        self.assertEqual(audit['physical_width'],16)
        for module in (model.proposer,model.field.stem):
            self.assertGreater(sum(float(p.grad.abs().sum()) for p in module.parameters() if p.grad is not None),0)
        self.assertTrue(all(p.grad is None for p in model.field.fusion.parameters()))


if __name__ == '__main__':
    unittest.main()
