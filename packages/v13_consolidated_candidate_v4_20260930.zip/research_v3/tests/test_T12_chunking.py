import unittest
import torch
from research_v3.contracts import AlphabetSpec, MatrixState
from research_v3.features.registry import FeatureRegistry, FeaturePolicy
from research_v3.features.cache import FeatureCache
from research_v3.model.field import FusionDistanceField
from research_v3.objectives.bellman import select_backup, recompute_backup
from research_v3.objectives.auxiliary import build_qhat_targets


class ChunkingTests(unittest.TestCase):
    def test_complete_selection_gradient_and_qhat_match(self):
        previous = torch.get_num_threads()
        torch.set_num_threads(1)
        self.addCleanup(torch.set_num_threads, previous)
        torch.manual_seed(812)
        alphabet = AlphabetSpec.all_to_all(3)
        states = (MatrixState(3, (1, 3, 7), alphabet.id),)
        registry, policy = FeatureRegistry(), FeaturePolicy(('A01', 'B01'))
        model = FusionDistanceField([registry.specs[k] for k in policy.enabled_ids], d=8, pair_d=4,
                                    blocks=1, heads=2, ffn=16, fusion_blocks=1).double()
        results = []
        for width in (None, 1, 2, 4):
            model.zero_grad(set_to_none=True)
            selection = select_backup(model, states, registry, policy, alphabet, chunk_size=width)
            report = recompute_backup(model, selection)
            report.loss.backward()
            gradient = torch.cat([p.grad.flatten() for p in model.parameters() if p.grad is not None])
            targets, mask = build_qhat_targets(model, states, registry, policy, alphabet, chunk_size=width)
            results.append((selection.branches[0].selected_index, gradient.clone(), targets[mask].clone()))
            self.assertEqual(selection.branches[0].candidate_count, 6)
        for index, gradient, targets in results[1:]:
            self.assertEqual(index, results[0][0])
            self.assertLess(float((gradient-results[0][1]).abs().max()), 1e-8)
            self.assertLess(float((targets-results[0][2]).abs().max()), 1e-8)

    def test_cache_cap_and_collision_eviction(self):
        cache = FeatureCache(hash_fn=lambda _:0, max_entries=2, max_bytes=10000)
        for i in range(10):
            self.assertEqual(cache.get_or_compute((i,), lambda i=i:i), i)
            self.assertLessEqual(len(cache.order), 2)
            self.assertLessEqual(cache.bytes, cache.max_bytes)
        self.assertEqual(cache.evictions, 8)
        self.assertEqual(cache.get_or_compute((9,), lambda:999), 9)
        disabled = FeatureCache(max_bytes=0)
        disabled.get_or_compute(('x',), lambda:[1]*100)
        self.assertEqual(disabled.buckets, {})


if __name__ == '__main__':
    unittest.main()
