import unittest
from dataclasses import replace
from research_v3.contracts import AlphabetSpec, Gate
from research_v3.data.generators import record_from_word
from research_v3.features.registry import FeatureRegistry, FeaturePolicy
from research_v3.tests.test_T11_search import ToyField
from research_v3.train.evaluate import evaluate_panel


class EvaluationTests(unittest.TestCase):
    def test_archived_python_does_not_enter_evaluation_source_inventory(self):
        import tempfile
        from pathlib import Path
        from research_v3.cli.evaluate import runtime_source_hashes
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            (root/'train').mkdir();(root/'train'/'runner.py').write_text('x=1\n')
            (root/'artifacts'/'old'/'research_v3').mkdir(parents=True)
            first=runtime_source_hashes(root)
            (root/'artifacts'/'old'/'research_v3'/'drift.py').write_text('x=2\n')
            self.assertEqual(runtime_source_hashes(root),first)
            self.assertEqual(list(first),['train/runner.py'])

    def test_diffusion_checkpoint_refuses_missing_or_drifted_backend(self):
        import hashlib
        import tempfile
        from pathlib import Path
        from dataclasses import asdict
        import torch
        from research_v3.features.diffusion import register_diffusion
        from research_v3.model.field import FusionDistanceField
        from research_v3.train.checkpoint import save_checkpoint
        from research_v3.train.schedule import Sampler,Progress
        from research_v3.train.evaluate import load_field
        registry=FeatureRegistry();register_diffusion(registry,taus=(0.,1.),mc_samples=8)
        policy=FeaturePolicy(('A01','G01'),symmetry_contract='augmentation_only')
        model=FusionDistanceField([registry.specs[k] for k in policy.enabled_ids],
                                  d=8,pair_d=4,blocks=1,heads=2,ffn=16,fusion_blocks=1)
        root=Path(__file__).resolve().parents[1]
        sources={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
                 for p in root.rglob('*.py') if 'artifacts' not in p.relative_to(root).parts}
        for mode in ('valid','missing','drift'):
            code=sources.copy()
            if mode=='missing':code.pop('diffusion/probes.py')
            if mode=='drift':code['diffusion/probes.py']='0'*64
            config={'model_config':model.config,'objective_config':{'policy':asdict(policy)},
                    'training':{'source_versions':{'code':code,'launch_config':{'diffusion':{'taus':[0.,1.],'mc_samples':8}}}}}
            with tempfile.TemporaryDirectory() as tmp:
                checkpoint=save_checkpoint(tmp,model,torch.optim.Adam(model.parameters()),Sampler(1,1),Progress(),config)
                if mode=='valid':
                    restored,_,_,_=load_field(checkpoint)
                    self.assertEqual(type(restored),type(model))
                else:
                    with self.assertRaisesRegex(ValueError,'diffusion'):
                        load_field(checkpoint)

    def test_checkpoint_inference_roundtrip_windows_source_paths(self):
        import hashlib
        import tempfile
        from pathlib import Path
        from dataclasses import asdict
        import torch
        from research_v3.model.field import FusionDistanceField
        from research_v3.train.checkpoint import save_checkpoint
        from research_v3.train.schedule import Sampler, Progress
        from research_v3.train.evaluate import load_field
        registry, policy = FeatureRegistry(), FeaturePolicy(('A01',))
        model = FusionDistanceField([registry.specs['A01']],d=8,pair_d=4,blocks=1,heads=2,ffn=16,fusion_blocks=1)
        root = Path(__file__).resolve().parents[1]
        sources = {str(p.relative_to(root)).replace('/','\\'):hashlib.sha256(p.read_bytes()).hexdigest()
                   for p in root.rglob('*.py')}
        config = {'model_config':model.config,'objective_config':{'policy':asdict(policy)},
                  'training':{'source_versions':{'code':sources}}}
        with tempfile.TemporaryDirectory() as tmp:
            checkpoint = save_checkpoint(tmp,model,torch.optim.Adam(model.parameters()),Sampler(1,1),Progress(),config)
            restored, _, _, digest = load_field(checkpoint)
            for x,y in zip(model.parameters(),restored.parameters()):
                self.assertTrue(torch.equal(x,y))
            self.assertEqual(len(digest),64)

    def test_complete_panel_failure_not_replaced_with_reference(self):
        a = AlphabetSpec.all_to_all(3)
        records = tuple(replace(record_from_word(a,word,str(i),i),split='dev') for i,word in enumerate(
            ((Gate(0,1),),(Gate(0,1),Gate(1,2)))))
        model = ToyField()
        registry, policy = FeatureRegistry(), FeaturePolicy(('A01',))
        saved = []
        report = evaluate_panel(model,registry,policy,records,checkpoint_id=('a'*64),scoring='direct_v',
                                beam_width=1,max_expansions=1,max_cost_multiplier=2,update=31,on_case=saved.append)
        self.assertEqual(len(saved),2)
        self.assertEqual((report['solved'],report['total']),(1,2))
        self.assertIsNone(report['cases'][1]['result']['raw_neural_word'])
        self.assertIsNone(report['cases'][1]['result']['best_verified_word'])
        self.assertEqual(report['selection_key'][:2],[-1,{'numerator':7,'denominator':2}])
        self.assertTrue(model.training)


if __name__ == '__main__':
    unittest.main()


