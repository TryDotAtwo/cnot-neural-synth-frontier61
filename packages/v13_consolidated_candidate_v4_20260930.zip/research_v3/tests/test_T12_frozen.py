from dataclasses import replace
from pathlib import Path
import tempfile
import unittest
from research_v3.contracts import AlphabetSpec, Gate
from research_v3.data.generators import record_from_word
from research_v3.data.frozen import freeze, load


class FrozenTests(unittest.TestCase):
    def record(self, n, word, seed, split):
        return replace(record_from_word(AlphabetSpec.all_to_all(n), tuple(word), str(seed), seed), split=split)

    def test_forbidden_neighbor_removes_parent_and_roundtrip(self):
        dev = self.record(3, [Gate(0,1), Gate(1,2)], 1, 'dev')
        train = self.record(3, [Gate(0,1), Gate(1,2), Gate(2,0)], 2, 'train')
        safe = self.record(4, [Gate(0,1)], 3, 'train')
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'panels.json'
            result = freeze(path, {'train':[train,safe], 'dev':[dev], 'test':[]}, (), {'fixture':'own'})
            self.assertEqual(result['rejected_train'], 1)
            panels, forbidden, _ = load(path)
            self.assertEqual(panels['train'], (safe,))
            self.assertIn(dev.state.key, forbidden)
            path.write_bytes(path.read_bytes() + b' ')
            with self.assertRaises(ValueError):
                load(path)

    def test_seed_family_cross_split_rejected(self):
        a = self.record(3, [Gate(0,1)], 1, 'train')
        b = self.record(3, [Gate(1,2)], 1, 'dev')
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaisesRegex(ValueError, 'seed family'):
                freeze(Path(tmp)/'x.json', {'train':[a], 'dev':[b], 'test':[]}, (), {'fixture':'own'})


if __name__ == '__main__':
    unittest.main()
