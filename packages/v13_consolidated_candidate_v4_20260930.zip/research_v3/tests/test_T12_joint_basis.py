import unittest
import tempfile
from pathlib import Path
from dataclasses import replace
import torch
from research_v3.contracts import AlphabetSpec,Gate
from research_v3.data.generators import record_from_word
from research_v3.model.field import FusionDistanceField
from research_v3.basis.learning import BasisField
from research_v3.features.registry import FeatureRegistry,FeaturePolicy
from research_v3.train.objective import FullGraphObjective
from research_v3.train.joint_basis import JointBasisObjective
from research_v3.train.runner import train_reference,TrainingConfig


class JointTests(unittest.TestCase):
    def test_exact_matching_and_g_features_joint_resume(self):
        from research_v3.data.matching import certify_record
        from research_v3.features.diffusion import register_diffusion
        old=torch.get_num_threads();torch.set_num_threads(1);self.addCleanup(torch.set_num_threads,old)
        a=AlphabetSpec.all_to_all(6)
        record=certify_record(replace(record_from_word(a,(Gate(0,3),Gate(1,4)),
                                                      'own_exact_joint',2702),split='train'))
        self.assertEqual(record.exact_distance,2)
        registry=FeatureRegistry();register_diffusion(registry,mc_samples=8,max_pair_states=1000)
        policy=FeaturePolicy(('A01','G01','G06','G07'),seed=2702,symmetry_contract='augmentation_only')
        def initialize():
            torch.manual_seed(2702)
            field=FusionDistanceField([registry.specs[k] for k in policy.enabled_ids],
                                      d=8,pair_d=4,blocks=1,heads=2,ffn=16,fusion_blocks=1)
            model=BasisField(field,hidden=16)
            objective=JointBasisObjective(FullGraphObjective((a,),registry,policy,neighbor_chunk_size=4,
                                                              qhat_weight=0),choices=2,samples=2,seed=2702,
                                          max_evaluations=16)
            return model,torch.optim.Adam(model.parameters()),objective
        config=TrainingConfig(4,1,2702,2,'joint_basis_bellman_v1',{'fixture':'matching_G_joint_v1'})
        with tempfile.TemporaryDirectory() as tmp:
            full,opt,obj=initialize()
            train_reference(full,opt,(record,),obj,config,Path(tmp)/'full')
            split,opt2,obj2=initialize()
            part=train_reference(split,opt2,(record,),obj2,config,Path(tmp)/'split',stop_after=2)
            resumed,opt3,obj3=initialize()
            train_reference(resumed,opt3,(record,),obj3,config,Path(tmp)/'split',resume=part['checkpoint'])
            for x,y in zip(full.parameters(),resumed.parameters()):self.assertTrue(torch.equal(x,y))
            self.assertEqual(obj.state_dict(),obj3.state_dict())
            self.assertEqual(obj3.total_evaluations,40)
            self.assertEqual(obj3.last_diagnostics['exact_examples'],1)
            self.assertEqual(obj3.last_diagnostics['basis_templates'],1)
            self.assertTrue(obj3.audit()['strict_unseen'])

    def test_joint_resume_and_forbidden_operator_admission(self):
        old=torch.get_num_threads();torch.set_num_threads(1);self.addCleanup(torch.set_num_threads,old)
        a=AlphabetSpec.all_to_all(6)
        record=replace(record_from_word(a,tuple(Gate(c,t) for c in range(3) for t in range(3,6)),'joint',19),split='train')
        registry=FeatureRegistry();policy=FeaturePolicy(('A01',))
        def initialize():
            torch.manual_seed(19)
            field=FusionDistanceField([registry.specs['A01']],d=8,pair_d=4,blocks=1,heads=2,ffn=16,fusion_blocks=1)
            model=BasisField(field,hidden=16)
            return model,torch.optim.Adam(model.parameters()),JointBasisObjective(FullGraphObjective((a,),registry,policy),choices=1,samples=2,seed=19)
        config=TrainingConfig(4,1,19,2,'joint_basis_bellman_v1',{'fixture':'own_bound_shear'})
        with tempfile.TemporaryDirectory() as tmp:
            first,opt,obj=initialize()
            train_reference(first,opt,(record,),obj,config,Path(tmp)/'full')
            second,opt2,obj2=initialize()
            part=train_reference(second,opt2,(record,),obj2,config,Path(tmp)/'split',stop_after=2)
            third,opt3,obj3=initialize()
            train_reference(third,opt3,(record,),obj3,config,Path(tmp)/'split',resume=part['checkpoint'])
            for x,y in zip(first.parameters(),third.parameters()):self.assertTrue(torch.equal(x,y))
            self.assertEqual(obj.state_dict(),obj3.state_dict())
            self.assertEqual(obj3.total_evaluations,24)
            from research_v3.search.learned_basis import LearnedBasisMacros
            from research_v3.search.basis_macros import solve_with_paid_basis
            from research_v3.search.reference import SearchConfig
            from research_v3.basis.wide import WideBudget
            from research_v3.words import verify_word
            proposer=LearnedBasisMacros(third,registry,policy,'joint-four-step-fixture',
                                        WideBudget(1,2,8,2**20),max_calls=1,choices=1,seed=19)
            result=solve_with_paid_basis(record.state,third,registry,
                                         SearchConfig(a,policy,max_expansions=1,max_cost=9),proposer)
            self.assertEqual(result.status,'solved')
            self.assertIsNone(result.raw_neural_word)
            verify_word(result.raw_search_word,a)
            self.assertEqual(proposer.proposal_forwards,1)
        forbidden=JointBasisObjective(FullGraphObjective((a,),registry,policy,forbidden_keys=(record.state.key,)))
        calls=[];hook=first.register_forward_pre_hook(lambda *args:calls.append(1))
        with self.assertRaisesRegex(ValueError,'forbidden'):forbidden(first,(record,))
        hook.remove();self.assertEqual(calls,[])


if __name__ == '__main__':unittest.main()
