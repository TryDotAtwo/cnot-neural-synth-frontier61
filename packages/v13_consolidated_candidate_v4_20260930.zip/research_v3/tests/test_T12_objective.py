import unittest
from dataclasses import replace
import torch
from research_v3.contracts import AlphabetSpec, MatrixState, Gate
from research_v3.data.exact_small import build_exact_small
from research_v3.data.replay import Replay
from research_v3.features.registry import FeatureRegistry, FeaturePolicy
from research_v3.model.field import FusionDistanceField
from research_v3.train.objective import FullGraphObjective
from research_v3.words import apply


class ObjectiveTests(unittest.TestCase):
    def test_mixed_objective_runner_checkpoint_restores_exposures(self):
        import tempfile
        from pathlib import Path
        from research_v3.train.runner import TrainingConfig, train_reference
        objective = self.make()
        optimizer = torch.optim.Adam(self.model.parameters(), lr=.001)
        config = TrainingConfig(2, 2, 19, 1, 'full_graph_reference_v1', {'fixture':'verified_gl2_gl3'})
        with tempfile.TemporaryDirectory() as tmp:
            first = train_reference(self.model, optimizer, self.records, objective, config, Path(tmp), stop_after=1)
            previous = objective.exposures.seen_by_gradient.copy()
            restored = self.make()
            result = train_reference(self.model, optimizer, self.records, restored, config, Path(tmp), resume=first['checkpoint'])
            self.assertEqual(result['progress']['accepted'], 2)
            self.assertTrue(previous <= restored.exposures.seen_by_gradient)
            self.assertTrue(restored.audit()['strict_unseen'])

    def setUp(self):
        self.threads = torch.get_num_threads()
        torch.set_num_threads(1)
        self.addCleanup(torch.set_num_threads, self.threads)
        self.registry = FeatureRegistry()
        self.policy = FeaturePolicy(('A01', 'B01'))
        self.alphabets = {n:AlphabetSpec.all_to_all(n) for n in (2, 3)}
        self.catalogs = {a.id:build_exact_small(n, a) for n, a in self.alphabets.items()}
        self.records = []
        for a in self.alphabets.values():
            replay = Replay(a)
            replay.ingest_exact(self.catalogs[a.id])
            self.records.append(replace(next(r for r in replay.records.values() if r.exact_distance == 2), split='train'))
        self.model = FusionDistanceField([self.registry.specs[k] for k in self.policy.enabled_ids],
                                        d=8, pair_d=4, blocks=1, heads=2, ffn=16, fusion_blocks=1).double()

    def make(self, forbidden=()):
        return FullGraphObjective(tuple(self.alphabets.values()), self.registry, self.policy,
                                  forbidden_keys=forbidden, exact_catalogs=self.catalogs)

    def test_mixed_sizes_full_gradient_and_exposures(self):
        objective = self.make()
        loss = objective(self.model, self.records)
        loss.backward()
        self.assertTrue(torch.isfinite(loss))
        self.assertGreater(sum(float(p.grad.abs().sum()) for p in self.model.parameters() if p.grad is not None), 0)
        self.assertEqual(objective.last_diagnostics['examples'], 2)
        self.assertEqual(objective.last_diagnostics['primitive_candidates'], 8)
        self.assertEqual(len(objective.exposures.seen_as_label), 2)
        self.assertTrue(objective.audit()['strict_unseen'])
        saved = objective.state_dict()
        restored = self.make()
        restored.load_state_dict(saved)
        self.assertEqual(restored.exposures.seen_by_forward, objective.exposures.seen_by_forward)

    def test_bellman_pass_reuses_exact_qhat_targets(self):
        from research_v3.objectives.bellman import select_backup
        from research_v3.objectives.auxiliary import build_qhat_targets
        record = self.records[1]
        alphabet = self.alphabets[3]
        selection = select_backup(self.model, (record.state,), self.registry, self.policy,
                                  alphabet, chunk_size=2)
        branch = selection.branches[0]
        old, allowed = build_qhat_targets(self.model, (record.state,), self.registry,
                                          self.policy, alphabet, chunk_size=2)
        self.assertEqual(len(branch.primitive_totals), len(alphabet.allowed))
        for gate, total in zip(alphabet.allowed, branch.primitive_totals):
            self.assertTrue(allowed[0, gate.control, gate.target])
            self.assertAlmostEqual(total, float(old[0, gate.control, gate.target]), places=6)

    def test_verified_upper_bound_teaches_proposal_without_exact_claim(self):
        from research_v3.data.generators import record_from_word
        alphabet = self.alphabets[3]
        record = replace(record_from_word(alphabet, (Gate(0, 1), Gate(1, 2)),
                                          'own_teacher_fixture', 31), split='train')
        objective = FullGraphObjective((alphabet,), self.registry, self.policy,
                                       qhat_weight=0, teacher_weight=.1)
        loss = objective(self.model, (record,))
        loss.backward()
        self.assertEqual(objective.last_diagnostics['teacher_examples'], 1)
        self.assertEqual(objective.last_diagnostics['exact_examples'], 0)
        gradient = sum(float(parameter.grad.abs().sum()) for parameter in
                       self.model.auxiliary.proposal.parameters() if parameter.grad is not None)
        self.assertGreater(gradient, 0)

    def test_forbidden_neighbor_rejects_whole_batch_before_forward(self):
        record = self.records[1]
        a = self.alphabets[3]
        neighbor = apply(record.state, Gate(0, 1), a)
        objective = self.make((neighbor.key,))
        calls = []
        hook = self.model.register_forward_pre_hook(lambda *args: calls.append(1))
        with self.assertRaisesRegex(ValueError, 'forbidden'):
            objective(self.model, self.records)
        hook.remove()
        self.assertEqual(calls, [])
        self.assertEqual(objective.exposures.seen_as_label, set())

    def test_unverified_label_rejected_before_forward(self):
        bad = replace(self.records[0], exact_distance=99)
        calls = []
        hook = self.model.register_forward_pre_hook(lambda *args: calls.append(1))
        with self.assertRaises(ValueError):
            self.make()(self.model, (bad,))
        hook.remove()
        self.assertEqual(calls, [])


if __name__ == '__main__':
    unittest.main()
