import unittest
from fractions import Fraction
from research_v3.train.schedule import selection_key,selection_key_json,selection_key_from_json

class ProtocolSelectionTests(unittest.TestCase):
 def test_failure_uses_cap_plus_one_and_exact_rational(self):
  k=selection_key({'a':None,'b':1},{'a':3,'b':7},{'a':6,'b':14},5.0,640,'a'*64)
  self.assertEqual(k[:2],(-1,Fraction(7,3)+Fraction(1,7)))
  self.assertEqual(selection_key_from_json(selection_key_json(k)),k)
 def test_over_cap_is_failed_even_with_word(self):
  args=({'a':3},{'a':2},{'a':2},1.,640,'a'*64)
  self.assertEqual(selection_key(*args)[:2],(-0,Fraction(3,2)))
 def test_transitive_ties_use_time_update_sha(self):
  base=({'a':1},{'a':3},{'a':6})
  self.assertLess(selection_key(*base,4.,640,'b'*64),selection_key(*base,5.,1,'a'*64))
  self.assertLess(selection_key(*base,4.,640,'a'*64),selection_key(*base,4.,640,'b'*64))
 def test_rejects_incomplete_panel_and_float_cost(self):
  with self.assertRaises(ValueError):selection_key({'a':1},{'a':3,'b':4},{'a':6,'b':8},1.,1,'a'*64)
  with self.assertRaises(ValueError):selection_key({'a':1.0},{'a':3},{'a':6},1.,1,'a'*64)

if __name__=='__main__':unittest.main()
