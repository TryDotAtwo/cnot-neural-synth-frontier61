import copy
import tempfile
import unittest
from pathlib import Path
import random
import numpy as np
import torch
from research_v3.train.checkpoint import save_checkpoint, load_checkpoint
from research_v3.train.runner import guarded_step
from research_v3.train.schedule import Sampler, Progress, selection_key


class ResumeTests(unittest.TestCase):
    def test_runner_fixed_attempts_resume_and_run_lock(self):
        from dataclasses import dataclass
        from research_v3.train.runner import TrainingConfig, train_reference
        @dataclass
        class Record:
            lineage_id: str
            target: float
            split: str = 'train'
        data = (Record('one', 1.), Record('two', 2.))
        def init():
            torch.manual_seed(33)
            model = torch.nn.Linear(1, 1).double()
            return model, torch.optim.Adam(model.parameters())
        def objective(model, batch):
            output = model(torch.ones(len(batch), 1, dtype=torch.float64)).flatten()
            return (output - output.new_tensor([r.target for r in batch])).square().mean()
        config = TrainingConfig(8, 1, 33, 4, 'test_mse', {'fixture':'v1'})
        with tempfile.TemporaryDirectory() as tmp:
            a, ao = init()
            train_reference(a, ao, data, objective, config, Path(tmp)/'a')
            b, bo = init()
            first = train_reference(b, bo, data, objective, config, Path(tmp)/'b', stop_after=4)
            c, co = init()
            final = train_reference(c, co, data, objective, config, Path(tmp)/'b', resume=first['checkpoint'])
            self.assertEqual(final['progress'], {'attempted':8, 'accepted':8, 'rejected':0})
            for x, y in zip(a.parameters(), c.parameters()):
                self.assertTrue(torch.equal(x, y))
            lock = Path(tmp)/'b'/'training.lock'
            lock.write_text('fixture')
            with self.assertRaises(FileExistsError):
                train_reference(c, co, data, objective, config, Path(tmp)/'b', resume=final['checkpoint'])
            self.assertEqual(lock.read_text(), 'fixture')

    def test_full_field_bellman_resume(self):
        from research_v3.contracts import AlphabetSpec, MatrixState
        from research_v3.features.registry import FeatureRegistry, FeaturePolicy
        from research_v3.model.field import FusionDistanceField
        from research_v3.objectives.bellman import select_backup, recompute_backup
        old_threads = torch.get_num_threads()
        torch.set_num_threads(1)
        self.addCleanup(torch.set_num_threads, old_threads)
        alphabet = AlphabetSpec.all_to_all(3)
        states = (MatrixState(3, (1, 3, 7), alphabet.id), MatrixState(3, (3, 2, 4), alphabet.id))
        registry, policy = FeatureRegistry(), FeaturePolicy(('A01', 'B01'))
        def init():
            torch.manual_seed(17)
            model = FusionDistanceField([registry.specs[k] for k in policy.enabled_ids],
                                        d=8, pair_d=4, blocks=1, heads=2, ffn=16, fusion_blocks=1).double()
            return model, torch.optim.Adam(model.parameters(), lr=.001), Sampler(2, 17), Progress()
        def run(model, optimizer, sampler, progress, count):
            for _ in range(count):
                batch = tuple(states[i] for i in sampler.next(1))
                selection = select_backup(model, batch, registry, policy, alphabet)
                report = recompute_backup(model, selection)
                self.assertTrue(guarded_step(model, optimizer, report.loss, progress))
        a, ao, sa, pa = init()
        run(a, ao, sa, pa, 8)
        b, bo, sb, pb = init()
        run(b, bo, sb, pb, 4)
        config = {'schema':b.config, 'data':'two-own-gl3', 'policy':policy.id}
        with tempfile.TemporaryDirectory() as tmp:
            path = save_checkpoint(Path(tmp), b, bo, sb, pb, config)
            c, co, sc, pc = init()
            load_checkpoint(path, c, co, sc, pc, config)
            run(c, co, sc, pc, 4)
            for x, y in zip(a.parameters(), c.parameters()):
                self.assertTrue(torch.equal(x, y))
            for key, value in ao.state_dict()['state'].items():
                for field, tensor in value.items():
                    self.assertTrue(torch.equal(tensor, co.state_dict()['state'][key][field]))
            self.assertEqual(sa.next(5), sc.next(5))

    def test_eight_equals_four_plus_four(self):
        def init():
            random.seed(19); np.random.seed(19); torch.manual_seed(19)
            model = torch.nn.Linear(3, 1).double()
            return model, torch.optim.Adam(model.parameters(), lr=.01), Sampler(7, 19), Progress()
        def run(model, opt, sampler, progress, count):
            batches = []
            for _ in range(count):
                indices = sampler.next(3)
                batches.append(indices)
                x = torch.randn(3, 3, dtype=torch.float64) + random.random() + np.random.random()
                target = torch.tensor(indices, dtype=torch.float64)
                loss = (model(x).flatten() - target).square().mean()
                guarded_step(model, opt, loss, progress)
            return batches
        config = {'schema':'test', 'features':['A01'], 'data_sha':'fixture'}
        a, ao, sa, pa = init()
        batches = run(a, ao, sa, pa, 8)
        b, bo, sb, pb = init()
        run(b, bo, sb, pb, 4)
        with tempfile.TemporaryDirectory() as tmp:
            path = save_checkpoint(Path(tmp), b, bo, sb, pb, config)
            c, co, sc, pc = init()
            load_checkpoint(path, c, co, sc, pc, config)
            self.assertEqual(run(c, co, sc, pc, 4), batches[4:])
            for x, y in zip(a.parameters(), c.parameters()):
                self.assertTrue(torch.equal(x, y))
            self.assertEqual(sa.next(9), sc.next(9))
            self.assertEqual(pa, pc)
            for key, value in ao.state_dict()['state'].items():
                for field, tensor in value.items():
                    self.assertTrue(torch.equal(tensor, co.state_dict()['state'][key][field]))

    def test_reject_nonfinite_without_optimizer_mutation(self):
        model = torch.nn.Linear(2, 1).double()
        opt = torch.optim.Adam(model.parameters())
        progress = Progress()
        guarded_step(model, opt, model(torch.ones(1, 2, dtype=torch.float64)).square().sum(), progress)
        before = copy.deepcopy(opt.state_dict())
        weights = [p.clone() for p in model.parameters()]
        for gradient_only in (False, True):
            loss = model(torch.ones(1, 2, dtype=torch.float64)).sum()
            if gradient_only:
                hook = model.weight.register_hook(lambda grad: grad * float('nan'))
            else:
                loss = loss * float('nan')
            self.assertFalse(guarded_step(model, opt, loss, progress))
            if gradient_only:
                hook.remove()
        self.assertEqual((progress.attempted, progress.accepted, progress.rejected), (3, 1, 2))
        for p, w in zip(model.parameters(), weights):
            self.assertTrue(torch.equal(p, w))
        for key, value in before['state'].items():
            for field, tensor in value.items():
                self.assertTrue(torch.equal(tensor, opt.state_dict()['state'][key][field]))

    def test_schema_and_hash_guard_and_immutable_save(self):
        model = torch.nn.Linear(2, 1)
        opt = torch.optim.Adam(model.parameters())
        sampler, progress = Sampler(3, 5), Progress()
        with tempfile.TemporaryDirectory() as tmp:
            path = save_checkpoint(Path(tmp), model, opt, sampler, progress, {'schema':'a'})
            with self.assertRaises(FileExistsError):
                save_checkpoint(Path(tmp), model, opt, sampler, progress, {'schema':'a'})
            with self.assertRaises(ValueError):
                load_checkpoint(path, model, opt, sampler, progress, {'schema':'b'})
            path.write_bytes(path.read_bytes() + b'bad')
            with self.assertRaises(ValueError):
                load_checkpoint(path, model, opt, sampler, progress, {'schema':'a'})

    def test_selection_uses_complete_fixed_panel(self):
        reference = {'a':10, 'b':20}
        self.assertLess(selection_key({'a':9, 'b':19}, reference, {'a':20,'b':40}, 100., 1, 'a'*64),
                        selection_key({'a':1, 'b':None}, reference, {'a':20,'b':40}, 10., 2, 'b'*64))
        with self.assertRaises(ValueError):
            selection_key({'a':1}, reference, {'a':20,'b':40}, 10., 2, 'b'*64)


if __name__ == '__main__':
    unittest.main()
