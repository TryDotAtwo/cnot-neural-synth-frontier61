import math
import unittest
import numpy as np
from scipy.linalg import expm
from research_v3.diffusion.column import column_chain, column_profile
from research_v3.diffusion.pair import pair_chain, pair_profile
from research_v3.contracts import AlphabetSpec, MatrixState
from research_v3.data.exact_small import build_exact_small
from research_v3.words import apply


class DiffusionTests(unittest.TestCase):
    def test_shared_word_preserves_covariance_independent_control_loses(self):
        from research_v3.diffusion.probes import joint_probes
        state = MatrixState.identity(AlphabetSpec.all_to_all(3))
        joint = joint_probes(state,time=3.,samples=4096,seed=71,columns=(0,0))
        np.testing.assert_array_equal(joint['raw_samples'][:,0],joint['raw_samples'][:,1])
        variance = joint['covariance_column_weight'][0,0]
        self.assertGreater(variance,.2)
        self.assertEqual(joint['covariance_column_weight'][0,1],variance)
        independent = joint_probes(state,time=3.,samples=4096,seed=99,columns=(0,))
        wrong_covariance = np.cov(joint['raw_samples'][:,0],independent['raw_samples'][:,0])[0,1]
        self.assertLess(abs(wrong_covariance),.05)

    def test_rates_sizes_and_detailed_balance(self):
        for n in range(2,7):
            for chain,total in ((column_chain(n),2**n-1),(pair_chain(n),(2**n-1)*(2**n-2))):
                np.testing.assert_array_equal(np.asarray(chain.counts.sum(axis=1)).ravel(),n*(n-1))
                self.assertTrue((chain.counts.data >= 0).all())
                self.assertEqual(sum(chain.class_sizes),total)
                flux = chain.stationary[:,None]*chain.generator.toarray()
                np.testing.assert_allclose(flux,flux.T,atol=1e-15)
            self.assertEqual(len(pair_chain(n).states),math.comb(n+3,3)-1-3*n)

    def test_projection_against_full_gl3(self):
        a = AlphabetSpec.all_to_all(3)
        states = tuple(build_exact_small(3,a).distances)
        index = {s:i for i,s in enumerate(states)}
        q = -np.eye(len(states))
        for i,s in enumerate(states):
            for gate in a.allowed:
                q[i,index[apply(s,gate,a)]] += 1/6
        full = expm(.7*q)[index[MatrixState.identity(a)]]
        col = column_profile(3,(.7,))
        pair = pair_profile(3,(1,1,1,0),(.7,))
        cp,pp = np.zeros(len(col['states'])),np.zeros(len(pair['states']))
        for state,mass in zip(states,full):
            bits = tuple(row&1 for row in state.packed_rows)
            cp[col['states'].index((bits[0],sum(bits[1:])))]+=mass
            h = tuple(sum((row&3)==kind for row in state.packed_rows) for kind in range(4))
            pp[pair['states'].index(h)]+=mass
        np.testing.assert_allclose(cp,col['raw_class_mass'][0],atol=1e-13)
        np.testing.assert_allclose(pp,pair['raw_class_mass'][0],atol=1e-13)

    def test_boundary_and_density_scope(self):
        packet = column_profile(1,(0.,1.))
        np.testing.assert_array_equal(packet['raw_class_mass'],[[1.],[1.]])
        packet = pair_profile(3,(1,1,1,0),(0.,1.))
        self.assertIsNone(packet['endpoint_log_probability'])
        self.assertEqual(int(packet['exact_zero'][1].sum()),0)
        self.assertLess(packet['mass_error'].max(),1e-12)
        with self.assertRaises(MemoryError):
            pair_chain(144,max_states=10)


if __name__ == '__main__':
    unittest.main()
