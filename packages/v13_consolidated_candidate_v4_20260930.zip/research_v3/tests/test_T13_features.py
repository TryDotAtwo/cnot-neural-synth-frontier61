import unittest
import numpy as np
from research_v3.contracts import AlphabetSpec, MatrixState
from research_v3.features.registry import FeatureRegistry, FeaturePolicy
from research_v3.features.diffusion import register_diffusion
from research_v3.symmetry import map_problem


class DiffusionFeatureTests(unittest.TestCase):
    def test_relabel_and_raw_mass_masks(self):
        a = AlphabetSpec.all_to_all(3)
        state = MatrixState(3,(1,3,7),a.id)
        registry = FeatureRegistry()
        register_diffusion(registry,taus=(0.,.25,1.,4.))
        policy = FeaturePolicy(('G01','G02','G03','G04','G05','G06'))
        p = (2,0,1)
        mapped = map_problem(state,a,p).state
        before,after = registry.build((state,),policy),registry.build((mapped,),policy)
        for key in policy.enabled_ids:
            x,y = before.features[key].values[0],after.features[key].values[0]
            if key in ('G05','G06'):
                np.testing.assert_allclose(y[np.ix_(p,p)],x)
                if key == 'G05':
                    np.testing.assert_array_equal(x.sum(axis=-1),3)
            else:
                np.testing.assert_allclose(y[list(p)],x,atol=1e-6)
            self.assertTrue(after.features[key].available.all())
        raw = before.features['G01'].values[0].reshape(3,4,7)[:,:,0]
        flags = before.features['G03'].values[0].reshape(3,4,4)
        np.testing.assert_array_equal(flags[:,0,1],raw[:,0]==0)
        self.assertTrue(np.isfinite(flags).all())
        self.assertTrue((flags[:,0,3] == (raw[:,0]==0)).all())

    def test_full_bellman_reaches_diffusion_stem_and_fusion(self):
        import torch
        from dataclasses import replace
        from research_v3.data.generators import record_from_word
        from research_v3.model.field import FusionDistanceField
        from research_v3.train.objective import FullGraphObjective
        old_threads = torch.get_num_threads()
        torch.set_num_threads(1)
        self.addCleanup(torch.set_num_threads,old_threads)
        alphabet = AlphabetSpec.all_to_all(3)
        record = replace(record_from_word(alphabet,(alphabet.allowed[0],alphabet.allowed[2]),'own_t13_path',31),split='train')
        registry = FeatureRegistry()
        register_diffusion(registry)
        policy = FeaturePolicy(('A01','G01','G05','G06','G07','G08','G09','G10'),symmetry_contract='augmentation_only')
        model = FusionDistanceField([registry.specs[k] for k in policy.enabled_ids],
                                    d=8,pair_d=4,blocks=1,heads=2,ffn=16,fusion_blocks=1)
        objective = FullGraphObjective((alphabet,),registry,policy,qhat_weight=0,neighbor_chunk_size=2)
        loss = objective(model,(record,))
        self.assertTrue(torch.isfinite(loss))
        loss.backward()
        for name in ('stem.projections.G01.weight','stem.projections.G05.weight','stem.projections.G06.weight','stem.projections.G07.weight',
                     'stem.projections.G08.weight','stem.projections.G09.weight','stem.projections.G10.weight',
                     'stem.blocks.0.qkv.weight','fusion.blocks.0.qkv.weight'):
            gradients = dict(model.named_parameters())[name].grad
            self.assertIsNotNone(gradients,name)
            self.assertTrue(torch.isfinite(gradients).all(),name)
            self.assertGreater(float(gradients.abs().sum()),0,name)
        self.assertEqual(objective.last_diagnostics['primitive_candidates'],6)
        self.assertTrue(objective.audit()['strict_unseen'])

    def test_pair_heat_class_mass_and_explicit_unavailability(self):
        a = AlphabetSpec.all_to_all(3)
        state = MatrixState.identity(a)
        registry = FeatureRegistry()
        register_diffusion(registry,taus=(0.,1.))
        packet = registry.build((state,),FeaturePolicy(('G06',)))
        pair = packet.features['G06']
        self.assertTrue(pair.available[0])
        self.assertEqual(float(pair.values[0,0,1,0]),1.)
        self.assertEqual(float(pair.values[0,0,1,4]),0.)
        self.assertEqual(float(pair.values[0,0,0].sum()),0.)
        limited = FeatureRegistry()
        register_diffusion(limited,taus=(0.,1.),max_pair_states=1)
        unavailable = limited.build((state,),FeaturePolicy(('G06',))).features['G06']
        self.assertFalse(unavailable.available[0])
        self.assertEqual(unavailable.status,'resource_limit')
        singleton = MatrixState.identity(AlphabetSpec.all_to_all(1))
        unsupported = registry.build((singleton,),FeaturePolicy(('G06',))).features['G06']
        self.assertFalse(unsupported.available[0])
        self.assertEqual(unsupported.status,'unsupported')

    def test_g07_shared_word_mean_and_scope(self):
        from research_v3.diffusion.probes import joint_probes
        a = AlphabetSpec.all_to_all(3)
        state = MatrixState(3,(1,3,7),a.id)
        registry = FeatureRegistry()
        register_diffusion(registry,mc_samples=128,mc_tau=1.)
        policy = FeaturePolicy(('G07',),seed=91,symmetry_contract='augmentation_only')
        feature = registry.build((state,),policy).features['G07']
        expected = joint_probes(state,time=3.,samples=128,seed=91)['mean_column_weight']
        np.testing.assert_allclose(feature.values[0,:,0],expected,rtol=1e-7,atol=1e-7)
        self.assertEqual(feature.exactness,'monte_carlo')
        self.assertEqual(feature.role,'node')
        self.assertTrue(feature.available[0])
        with self.assertRaisesRegex(ValueError,'symmetry contract'):
            registry.build((state,),FeaturePolicy(('G07',),seed=91))

    def test_grid_configuration_changes_producer_identity(self):
        first,second = FeatureRegistry(),FeatureRegistry()
        register_diffusion(first,taus=(.25,1.))
        register_diffusion(second,taus=(.25,4.))
        self.assertNotEqual(first.specs['G01'].producer_version,second.specs['G01'].producer_version)

    def test_joint_moments_and_empirical_uncertainty(self):
        from research_v3.diffusion.probes import joint_probes
        a=AlphabetSpec.all_to_all(3)
        state=MatrixState(3,(1,3,7),a.id)
        registry=FeatureRegistry()
        register_diffusion(registry,mc_samples=128,mc_tau=1.)
        policy=FeaturePolicy(('G07','G08','G09','G10'),seed=91,symmetry_contract='augmentation_only')
        packet=registry.build((state,),policy)
        probe=joint_probes(state,time=3.,samples=128,seed=91)
        pair=packet.features['G08'].values[0]
        np.testing.assert_allclose(pair[:,:,0],probe['covariance_column_weight'],atol=1e-6)
        np.testing.assert_allclose(pair[:,:,1],probe['mean_intersection'],atol=1e-6)
        np.testing.assert_allclose(pair[:,:,2],probe['mean_xor_weight'],atol=1e-6)
        np.testing.assert_allclose(packet.features['G09'].values[0,:,:,0],probe['character_pair_mean'],atol=1e-6)
        uncertainty=packet.features['G10'].values[0]
        np.testing.assert_allclose(uncertainty[:,:,0],probe['intersection_standard_error'],atol=1e-6)
        stationary=np.full((3,3),-1./7.)
        np.fill_diagonal(stationary,1.)
        np.testing.assert_allclose(uncertainty[:,:,3],np.abs(probe['character_pair_mean']-stationary),atol=1e-6)
        self.assertTrue((uncertainty[:,:,4]==128).all())
        self.assertTrue(np.isfinite(uncertainty).all())
        for key in policy.enabled_ids:
            self.assertTrue(packet.features[key].available.all())
            self.assertEqual(packet.features[key].exactness,'monte_carlo')
        with self.assertRaisesRegex(ValueError,'symmetry contract'):
            registry.build((state,),FeaturePolicy(('G08',),seed=91))

    def test_vector_pair_features_match_independent_scalar_reference(self):
        from research_v3.diffusion.pair import pair_profile
        from research_v3.words import apply
        a=AlphabetSpec.all_to_all(4)
        state=MatrixState.identity(a)
        for gate in (a.allowed[2],a.allowed[7],a.allowed[11]):state=apply(state,gate,a)
        registry=FeatureRegistry();register_diffusion(registry,taus=(0.,1.),floor=1e-30)
        p=registry.build((state,),FeaturePolicy(('G05','G06')))
        pair=pair_profile(4,(2,1,1,0),(0.,4.),max_states=10000)
        lookup={h:i for i,h in enumerate(pair['states'])}
        for c in range(4):
            for d in range(4):
                h=[0,0,0,0]
                for row in state.packed_rows:
                    h[((row>>c)&1)+2*((row>>d)&1)]+=1
                np.testing.assert_array_equal(p.features['G05'].values[0,c,d],h)
                if c==d:
                    np.testing.assert_array_equal(p.features['G06'].values[0,c,d],0)
                    continue
                j=lookup[tuple(h)]
                raw=pair['raw_class_mass'][:,j]
                stationary=pair['stationary_class_mass'][j]
                expected=np.stack((raw,np.full(2,pair['log_class_size'][j]),
                                   np.full(2,stationary),
                                   np.log(np.maximum(raw,1e-30))-np.log(max(stationary,1e-30)),
                                   pair['exact_zero'][:,j],pair['underflow'][:,j] | ((raw.astype(np.float32)==0)&(raw>0)),
                                   raw<1e-30),axis=-1).reshape(-1).astype(np.float32)
                np.testing.assert_array_equal(p.features['G06'].values[0,c,d],expected)


if __name__ == '__main__':
    unittest.main()
