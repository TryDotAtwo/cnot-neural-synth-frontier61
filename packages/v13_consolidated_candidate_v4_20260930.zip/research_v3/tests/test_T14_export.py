import tempfile
from pathlib import Path
import unittest
import torch
from research_v3.contracts import AlphabetSpec,MatrixState,MatrixBatch
from research_v3.features.registry import FeatureRegistry,FeaturePolicy
from research_v3.model.field import FusionDistanceField
from research_v3.native.export import export_model, pack
from research_v3.native.parity import compare


class ExportTests(unittest.TestCase):
    def test_group_counts_and_unavailable_masks_survive_export(self):
        import numpy as np
        from research_v3.features.packet import FeatureSpec
        old = torch.get_num_threads(); torch.set_num_threads(1)
        self.addCleanup(torch.set_num_threads,old)
        registry = FeatureRegistry()
        def producer(state,policy):
            k = state.n-1
            values = np.ones((k,2),dtype=np.float32)
            incidence = np.zeros((k,state.n,2),dtype=np.float32)
            for i in range(k):
                incidence[i,i,0]=1; incidence[i,i+1,1]=1
            return values,incidence
        registry.register(FeatureSpec('D01','group',2,producer_version='test_groups'),producer,
                          symmetry_contract='augmentation_only')
        policy = FeaturePolicy(('A01','D01'),symmetry_contract='augmentation_only')
        model = FusionDistanceField([registry.specs[k] for k in policy.enabled_ids],d=8,pair_d=4,
                                    blocks=1,heads=2,ffn=16,fusion_blocks=1).eval()
        states = (MatrixState.identity(AlphabetSpec.all_to_all(3)),)
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'group.pt'
            export_model(model,MatrixBatch.from_states(states),registry.build(states,policy),path,{'fixture':'groups'})
            exported = torch.jit.load(str(path))
            for n in (1,3,4):
                states = (MatrixState.identity(AlphabetSpec.all_to_all(n)),)
                for budget in (None,0):
                    probe_policy = FeaturePolicy(policy.enabled_ids,symmetry_contract='augmentation_only',evaluations=budget)
                    compare(model,exported,MatrixBatch.from_states(states),registry.build(states,probe_policy))

    def test_export_reload_dynamic_wire_batch_and_padding(self):
        old = torch.get_num_threads(); torch.set_num_threads(1)
        self.addCleanup(torch.set_num_threads,old)
        registry,policy = FeatureRegistry(),FeaturePolicy(('A01','A05','B01','F01'))
        model = FusionDistanceField([registry.specs[k] for k in policy.enabled_ids],d=8,pair_d=4,
                                    blocks=1,heads=2,ffn=16,fusion_blocks=1).eval()
        a = AlphabetSpec.all_to_all(3)
        root = MatrixState(3,(1,3,7),a.id)
        batch,packet = MatrixBatch.from_states((root,)),registry.build((root,),policy)
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'field.pt'
            export_model(model,batch,packet,path,{'test':'own random model'})
            exported = torch.jit.load(str(path))
            # Full parameter-gradient check with the same fixed batch/objective.
            model.zero_grad(set_to_none=True); exported.zero_grad(set_to_none=True)
            ref = model(batch,packet)
            v,p,q,allowed = exported(*pack(model,batch,packet))
            (ref.value.sum()+.1*ref.qhat[allowed].mean()+.1*ref.proposal[allowed].mean()).backward()
            (v.sum()+.1*q[allowed].mean()+.1*p[allowed].mean()).backward()
            traced_parameters = dict(exported.named_parameters())
            for name,parameter in model.named_parameters():
                actual = traced_parameters['model.'+name].grad
                if parameter.grad is None:
                    self.assertIsNone(actual)
                else:
                    torch.testing.assert_close(parameter.grad,actual,atol=2e-5,rtol=2e-5)
            for n in (1,3,4,13):
                alphabet = AlphabetSpec.all_to_all(n)
                state = MatrixState.identity(alphabet)
                if n > 1:
                    state = MatrixState(n,tuple((1<<i)^(1 if i==1 else 0) for i in range(n)),alphabet.id)
                states = (state,MatrixState.identity(AlphabetSpec.all_to_all(1)))
                compare(model,exported,MatrixBatch.from_states(states),registry.build(states,policy))


if __name__ == '__main__':
    unittest.main()
