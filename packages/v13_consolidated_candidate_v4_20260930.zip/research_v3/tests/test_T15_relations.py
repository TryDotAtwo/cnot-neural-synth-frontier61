import unittest
from itertools import product
from research_v3.response.types import (LabeledPorts,AffineRelation,CostDegree,WeightedTerm,
                                         WeightedResponse,ScalarResponse,RelationTerm,RelationResponse,
                                         SignedAffineTerm,SignedAffineResponse,SymbolicBudget,ResponseBudget)
from research_v3.response.relations import (compose_response,compose_affine_relations,
                                            compose_symbolic,protected_initial_projection)


class ResponseTypeTests(unittest.TestCase):
    def test_same_rank_different_relation_and_subset_not_equality(self):
        ports=LabeledPorts(('x','y'))
        x0=AffineRelation(ports,1,((1,0),))
        y0=AffineRelation(ports,1,((2,0),))
        all_values=AffineRelation(ports,1,())
        self.assertEqual(x0.rank,y0.rank)
        self.assertNotEqual(x0.assignments(4),y0.assignments(4))
        self.assertTrue(x0.is_subset(all_values,4))
        self.assertFalse(all_values.is_subset(x0,4))
        kernel=AffineRelation(ports,1,((3,0),))
        strict=AffineRelation(ports,1,((1,0),(2,0)))
        self.assertTrue(strict.is_subset(kernel,4))
        self.assertFalse(kernel.is_subset(strict,4))

    def test_cross_interface_and_protected_initial(self):
        left_relation=AffineRelation(LabeledPorts(('initial','middle'),('initial',)),2,((3,0),))
        right_relation=AffineRelation(LabeledPorts(('middle','output')),2,((3,0),))
        degree=CostDegree('physical_cnot',1,'full_all_to_all')
        left=WeightedResponse.from_relation(left_relation,degree,count_kind='words',witness=('left_gate',),max_assignments=16)
        right=WeightedResponse.from_relation(right_relation,degree,count_kind='words',witness=('right_gate',),max_assignments=16)
        result=compose_response(left,right,('middle',),ResponseBudget(256,16))
        self.assertEqual(result.status,'exact')
        self.assertEqual(result.response.ports,LabeledPorts(('initial','output'),('initial',)))
        for initial,output in product(range(4),repeat=2):
            self.assertEqual(result.response.coefficient((initial,output),2),int(initial==output))
        self.assertEqual(result.response.terms[0].witness,('left_gate','right_gate'))
        blocked=compose_response(left,right,('initial',),ResponseBudget(256,16))
        self.assertEqual(blocked.status,'unsupported')

    def test_equal_endpoint_different_multiplicity_is_added(self):
        p=LabeledPorts(('x','m'))
        degree=CostDegree('physical_cnot',1,'full')
        left=WeightedResponse(p,1,'physical_cnot','full','words',(
            WeightedTerm((0,0),degree,2,('a',)),WeightedTerm((0,0),degree,3,('b',))))
        right=WeightedResponse(LabeledPorts(('m','z')),1,'physical_cnot','full','words',(
            WeightedTerm((0,1),degree,1,('c',)),))
        result=compose_response(left,right,('m',),ResponseBudget(3,2))
        self.assertEqual(result.status,'exact')
        self.assertEqual(result.response.coefficient((0,1),2),5)
        self.assertEqual(result.response.terms[0].witness,('a','c'))

    def test_units_scope_semantics_and_signed_weights_do_not_mix(self):
        p=LabeledPorts(('x',))
        relation=AffineRelation(p,1,())
        base=WeightedResponse.from_relation(relation,CostDegree('physical_cnot',1,'full'),max_assignments=2)
        for degree,kind in ((CostDegree('cell',1,'full'),'assignments'),
                            (CostDegree('physical_cnot',1,'restricted'),'assignments'),
                            (CostDegree('physical_cnot',1,'full'),'words')):
            other=WeightedResponse.from_relation(relation,degree,count_kind=kind,max_assignments=2)
            self.assertEqual(compose_response(base,other,(),ResponseBudget(4,4)).status,'unsupported')
        with self.assertRaisesRegex(ValueError,'signed'):
            WeightedResponse.from_relation(relation,CostDegree('physical_cnot',1,'full'),coefficient=-1,max_assignments=2)
        with self.assertRaisesRegex(ValueError,'budget'):
            relation.assignments(1)

    def test_limit_is_unknown_not_zero(self):
        p=LabeledPorts(('x',))
        relation=AffineRelation(p,1,())
        response=WeightedResponse.from_relation(relation,CostDegree('assignment',0,'tiny'),max_assignments=2)
        limited=compose_response(response,response,(),ResponseBudget(1,4))
        self.assertEqual(limited.status,'resource_limit')
        self.assertIsNone(limited.response)

    def test_closed_response_has_distinct_scalar_type(self):
        p=LabeledPorts(('middle',))
        degree=CostDegree('physical_cnot',1,'full')
        relation=AffineRelation(p,1,())
        left=WeightedResponse.from_relation(relation,degree,coefficient=2,max_assignments=2)
        right=WeightedResponse.from_relation(relation,degree,coefficient=3,max_assignments=2)
        result=compose_response(left,right,('middle',),ResponseBudget(4,1))
        self.assertEqual(result.status,'exact')
        self.assertIsInstance(result.response,ScalarResponse)
        self.assertEqual(result.response.coefficient(2),12)

    def test_explicit_composition_matches_independent_tiny_enumeration(self):
        degree=CostDegree('physical_cnot',1,'full')
        left=WeightedResponse.from_relation(AffineRelation(LabeledPorts(('a','b')),1,((3,0),)),degree,
                                            coefficient=2,max_assignments=4)
        right=WeightedResponse.from_relation(AffineRelation(LabeledPorts(('b','c')),1,()),degree,
                                             coefficient=3,max_assignments=4)
        result=compose_response(left,right,('b',),ResponseBudget(16,4))
        self.assertEqual(result.status,'exact')
        for a,c in product(range(2),repeat=2):
            expected=sum(2*3 for b in range(2) if a^b==0)
            self.assertEqual(result.response.coefficient((a,c),2),expected)

    def test_stage40_restricted_distance_four_is_not_full_distance(self):
        from collections import deque
        from research_v3.contracts import AlphabetSpec,Gate,MatrixState
        from research_v3.words import apply
        full=AlphabetSpec.all_to_all(3)
        restricted=AlphabetSpec(3,(Gate(0,1),Gate(1,2)),(1,1),'stage40_two_generators')
        target=apply(MatrixState.identity(full),Gate(0,2),full).packed_rows
        def distance(alphabet):
            root=MatrixState.identity(alphabet)
            queue=deque([(root,0)]);seen={root.packed_rows}
            while queue:
                state,depth=queue.popleft()
                if state.packed_rows==target:return depth
                for gate in alphabet.allowed:
                    child=apply(state,gate,alphabet)
                    if child.packed_rows not in seen:
                        seen.add(child.packed_rows);queue.append((child,depth+1))
            return None
        self.assertEqual(distance(restricted),4)
        self.assertEqual(distance(full),1)
        narrow=WeightedResponse.from_relation(AffineRelation(LabeledPorts(('x',)),1,()),
            CostDegree('physical_cnot',4,restricted.id),max_assignments=2)
        broad=WeightedResponse.from_relation(AffineRelation(LabeledPorts(('x',)),1,()),
            CostDegree('physical_cnot',1,full.id),max_assignments=2)
        self.assertEqual(compose_response(narrow,broad,(),ResponseBudget(4,2)).status,'unsupported')

    def test_symbolic_free_fiber_and_constraint_left_from_stage58(self):
        # x+y+z=0, eliminate y,z: Q choices for every x.
        all_three=AffineRelation(LabeledPorts(('x','y','z')),2,((7,0),))
        scalar=AffineRelation(LabeledPorts(('y','z')),2,())
        result=compose_affine_relations(all_three,scalar,('y','z'))
        self.assertTrue(result.compatible)
        self.assertEqual(result.relation.ports.labels,('x',))
        self.assertEqual(result.free_port_dimension,1)
        self.assertEqual(result.fiber_multiplicity,4)
        self.assertEqual(result.relation.assignments(4),((0,),(1,),(2,),(3,)))
        # x+y=0, y=0 leaves x=0 and one eliminated y.
        equal=AffineRelation(LabeledPorts(('x','y')),2,((3,0),))
        zero=AffineRelation(LabeledPorts(('y',)),2,((1,0),))
        constrained=compose_affine_relations(equal,zero,('y',))
        self.assertEqual(constrained.free_port_dimension,0)
        self.assertEqual(constrained.relation.assignments(4),((0,),))

    def test_symbolic_affine_composition_matches_exhaustive_tiny(self):
        from random import Random
        rng=Random(1558)
        for width in (1,2):
            left_ports=LabeledPorts(('initial','shared'),('initial',))
            right_ports=LabeledPorts(('shared','output'))
            q=1<<width
            for _ in range(80):
                left=AffineRelation(left_ports,width,tuple((rng.randrange(4),rng.randrange(q)) for i in range(rng.randrange(4))))
                right=AffineRelation(right_ports,width,tuple((rng.randrange(4),rng.randrange(q)) for i in range(rng.randrange(4))))
                result=compose_affine_relations(left,right,('shared',))
                for initial,output in product(range(q),repeat=2):
                    brute=sum(left.contains((initial,shared)) and right.contains((shared,output)) for shared in range(q))
                    symbolic=result.fiber_multiplicity if result.relation.contains((initial,output)) else 0
                    self.assertEqual(symbolic,brute)

    def test_positive_symbolic_weighted_composition_matches_tiny_enumeration(self):
        from random import Random
        rng=Random(1559)
        for width in (1,2):
            q=1<<width
            lp=LabeledPorts(('initial','middle'),('initial',))
            rp=LabeledPorts(('middle','output'))
            degree=CostDegree('physical_cnot',1,'full')
            for _ in range(60):
                la=AffineRelation(lp,width,tuple((rng.randrange(4),rng.randrange(q)) for j in range(rng.randrange(3))))
                lb=AffineRelation(lp,width,tuple((rng.randrange(4),rng.randrange(q)) for j in range(rng.randrange(3))))
                ra=AffineRelation(rp,width,tuple((rng.randrange(4),rng.randrange(q)) for j in range(rng.randrange(3))))
                left=RelationResponse(lp,width,'physical_cnot','full','words',
                                      (RelationTerm(la,degree,2,('a',)),RelationTerm(lb,degree,3,('b',))))
                right=RelationResponse(rp,width,'physical_cnot','full','words',
                                       (RelationTerm(ra,degree,5,('c',)),))
                got=compose_symbolic(left,right,('middle',),SymbolicBudget(2,2))
                self.assertEqual(got.status,'exact')
                for initial,output in product(range(q),repeat=2):
                    brute=sum((2*la.contains((initial,middle))+3*lb.contains((initial,middle)))*
                              5*ra.contains((middle,output)) for middle in range(q))
                    self.assertEqual(got.response.coefficient((initial,output),2),brute)
                self.assertEqual(got.response.ports.protected_initial,('initial',))

    def test_symbolic_budget_does_not_report_false_zero(self):
        p=LabeledPorts(('x','middle'))
        relation=AffineRelation(p,1,())
        degree=CostDegree('physical_cnot',1,'full')
        response=RelationResponse(p,1,'physical_cnot','full','words',
            (RelationTerm(relation,degree,1),RelationTerm(relation,degree,2)))
        result=compose_symbolic(response,response,('middle',),SymbolicBudget(1,4))
        self.assertEqual(result.status,'resource_limit')
        self.assertIsNone(result.response)

    def test_protected_initial_uses_row_space_intersection_not_mask_truncation(self):
        ports=LabeledPorts(('initial','middle'),('initial',))
        linked=AffineRelation(ports,1,((3,0),))
        self.assertEqual(protected_initial_projection(linked).equations,())
        forbidden=AffineRelation(ports,1,((3,0),(2,0)))
        self.assertEqual(protected_initial_projection(forbidden).equations,((1,0),))
        aff=AffineRelation(ports,1,((3,1),(2,0)))
        self.assertEqual(protected_initial_projection(aff).equations,((1,1),))

    def test_stage52_ordered_cross_term_da_prime(self):
        # r=w=m=1 instance of N(a,d,c)N(a',d',c') with central da'.
        def N(a,d,c):return (1,2|a,4|(d<<1)|c)
        def multiply(left,right):
            return tuple((right[0] if row&1 else 0)^(right[1] if row&2 else 0)^
                         (right[2] if row&4 else 0) for row in left)
        delivery=N(0,1,0);preparation=N(1,0,0)
        self.assertEqual(multiply(delivery,preparation),N(1,1,1))
        self.assertEqual(multiply(preparation,delivery),N(1,1,0))
        self.assertNotEqual(multiply(delivery,preparation),multiply(preparation,delivery))

    def test_signed_affine_input_cannot_be_minimized_as_positive_count(self):
        ports=LabeledPorts(('x',))
        relation=AffineRelation(ports,1,())
        signed=SignedAffineResponse(ports,1,(SignedAffineTerm(relation,-1,1),))
        degree=CostDegree('physical_cnot',1,'full')
        positive=WeightedResponse.from_relation(relation,degree,max_assignments=2)
        symbolic=RelationResponse(ports,1,'physical_cnot','full','words',(RelationTerm(relation,degree,1),))
        self.assertEqual(compose_response(signed,positive,(),ResponseBudget(2,2)).status,'unsupported')
        self.assertEqual(compose_symbolic(signed,symbolic,(),SymbolicBudget(2,2)).status,'unsupported')


if __name__=='__main__':unittest.main()
