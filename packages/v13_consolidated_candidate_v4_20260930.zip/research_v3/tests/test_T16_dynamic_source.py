"""Independent full-endpoint checks of the stage51 finite positive adapter."""
import json
import unittest
from collections import defaultdict
from fractions import Fraction
from itertools import product
from pathlib import Path

from research_v3.response.local import (LabeledPorts, LocalBudget, ResponseQuery,
                                        RestrictedProblem, local_response)
from research_v3.response.dynamic_source import _CORE_GATES, _core
from research_v3.response.source_channels import (from_channel, pushed_frequency_bits,
                                                  source_channel_maps, to_channel)


class DynamicSourceResponse(unittest.TestCase):
    def test_all_fifteen_source_charts_sew_to_physical_operator(self):
        frames, index, permutations, _ = _core()
        charts = source_channel_maps()
        self.assertEqual(charts.channel_sizes, (1344,) * 15)
        self.assertEqual(len(set(zip(charts.sector, charts.local_index))), 20160)
        for i, frame in enumerate(frames):
            source, fixed = to_channel(frame)
            self.assertEqual(from_channel(source, fixed), frame)
            moved = list(frame)
            moved[0] ^= frame[1]
            self.assertEqual(frames[charts.source_update[i]], tuple(moved))
            self.assertEqual(charts.source_update[i], permutations[7][i])
            for control, receiver in _CORE_GATES[:7]:
                chart_step = list(fixed)
                chart_step[receiver] ^= fixed[control]
                direct_step = list(frame)
                direct_step[receiver] ^= frame[control]
                self.assertEqual(from_channel(source, tuple(chart_step)), tuple(direct_step))
            for frequency in range(16):
                changed = pushed_frequency_bits(source, frequency)
                for carrier in (1, 2):
                    self.assertEqual((frame[carrier] & frequency).bit_count() & 1,
                                     (fixed[carrier] & changed).bit_count() & 1)

    @staticmethod
    def problem(core, additions, *, kernel="stage51_dynamic_source"):
        n = 4 + len(additions)
        alphabet = ((0, 1), (0, 2), (1, 2), (2, 1),
                    (1, 3), (2, 3), (3, 1), (1, 0)) + tuple(
                        (carrier, receiver) for receiver in range(4, n)
                        for carrier in (1, 2))
        rows = tuple(core) + tuple((1 << (4 + j)) ^ value
                                   for j, value in enumerate(additions))
        return RestrictedProblem(rows, alphabet, LabeledPorts(()), (3,), (), (),
                                 "exact_full_endpoint", (0, 1, 2, 3), kernel)

    def test_one_receiver_matches_full_matrix_word_dp(self):
        words = (((3, 1), (1, 4)), ((1, 0), (0, 2)),
                 ((0, 1), (1, 4), (1, 0)))
        alphabet = self.problem((1, 2, 4, 8), (0,)).alphabet
        for word in words:
            rows = [1, 2, 4, 8, 16]
            for control, target in word:
                rows[target] ^= rows[control]
            args = (tuple(rows), alphabet, LabeledPorts(()), (3,), (), (),
                    "exact_full_endpoint", (0, 1, 2, 3))
            analytic = local_response(RestrictedProblem(*args, kernel="stage51_dynamic_source"),
                                      ResponseQuery(4), LocalBudget(400000, 20_000_000))
            literal = local_response(RestrictedProblem(*args), ResponseQuery(4),
                                     LocalBudget(10000, 1_000_000))
            self.assertEqual((analytic.status, literal.status), ("exact", "exact"))
            self.assertEqual([analytic.response.coefficient(i) for i in range(5)],
                             [literal.response.coefficient(i) for i in range(5)])

    def test_two_receivers_match_primary_saved_coefficients(self):
        root = Path(__file__).resolve().parents[1]
        saved = root / "artifacts/frontier61_source_v1/stage51_dynamic_source/results/coefficients.json"
        stored = json.loads(saved.read_text(encoding="utf-8"))
        expected = stored["full"]
        problem = self.problem((1, 2, 4, 15), (3, 3))
        answer = local_response(problem, ResponseQuery(14),
                                LocalBudget(3_000_000, 500_000_000))
        self.assertEqual(answer.status, "exact")
        self.assertEqual([answer.response.coefficient(i) for i in range(15)], expected)
        private_free = local_response(problem, ResponseQuery(14, source_private_uses=0),
                                      LocalBudget(3_000_000, 500_000_000))
        self.assertEqual(private_free.status, "exact")
        self.assertEqual([private_free.response.coefficient(i) for i in range(15)],
                         stored["no_source_private"])
        no_source = local_response(problem, ResponseQuery(14, source_uses=0),
                                   LocalBudget(3_000_000, 500_000_000))
        self.assertEqual(no_source.status, "exact")
        self.assertEqual([no_source.response.coefficient(i) for i in range(15)],
                         stored["no_source"])
        no_feedback = local_response(problem, ResponseQuery(14, feedback_control=3,
                                                             feedback_uses=0),
                                     LocalBudget(3_000_000, 500_000_000))
        self.assertEqual(no_feedback.status, "exact")
        self.assertEqual([no_feedback.response.coefficient(i) for i in range(15)],
                         stored["no_output_feedback"])
        self.assertEqual(local_response(problem, ResponseQuery(14),
                                        LocalBudget(1000, 1000)).status,
                         "resource_limit")

    def test_own_all_order_interval_contains_stage51_saved_interval(self):
        root = Path(__file__).resolve().parents[1]
        saved = root / "artifacts/frontier61_source_v1/stage51_dynamic_source/results/certified_values.json"
        item = json.loads(saved.read_text(encoding="utf-8"))["results"]["results/cheb_d312_k24_eta1.tsv"]
        certified_lower = Fraction(*map(int, item["lower"]))
        certified_upper = Fraction(*map(int, item["upper"]))
        problem = self.problem((1, 2, 4, 15), (3, 3))
        answer = local_response(problem, ResponseQuery(18, fugacity=Fraction(1, 312)),
                                LocalBudget(3_000_000, 600_000_000))
        self.assertEqual(answer.status, "certified_interval")
        self.assertEqual((answer.response.modes_total,
                          answer.response.modes_independently_replayed), (136, 136))
        self.assertLessEqual(answer.response.lower, certified_lower)
        self.assertGreaterEqual(answer.response.upper, certified_upper)
        self.assertEqual(local_response(problem, ResponseQuery(0, fugacity=Fraction(1, 12)),
                                        LocalBudget(3_000_000, 600_000_000)).status,
                         "unsupported")

    def test_exact_private_source_transfer_count_matches_literal_words(self):
        alphabet = self.problem((1, 2, 4, 8), ()).alphabet
        for target in ((1, 2, 4, 8), (11, 10, 4, 8)):
            problem = self.problem(target, ())
            for marked in range(3):
                answer = local_response(problem, ResponseQuery(4, source_private_uses=marked),
                                        LocalBudget(100000, 5_000_000))
                self.assertEqual(answer.status, "exact")
                for degree in range(5):
                    expected = 0
                    for word in product(alphabet, repeat=degree):
                        rows = [1, 2, 4, 8]
                        charged = 0
                        for control, receiver in word:
                            if (control, receiver) == (1, 0) and rows[1] & 8:
                                charged += 1
                            rows[receiver] ^= rows[control]
                        expected += int(tuple(rows) == target and charged == marked)
                    self.assertEqual(answer.response.coefficient(degree), expected)
        self.assertEqual(local_response(self.problem((1, 2, 4, 8), ()),
                                        ResponseQuery(4, source_private_uses=1),
                                        LocalBudget(100000, 5_000_000)).response.terms, ())

    def test_joint_feedback_source_and_private_marking_matches_full_matrix_dp(self):
        alphabet = self.problem((1, 2, 4, 8), ()).alphabet
        layer = {((1, 2, 4, 8), 0, 0, 0): 1}
        layers = [layer]
        for _ in range(6):
            following = defaultdict(int)
            for (rows, feedback, source, private), count in layer.items():
                for control, receiver in alphabet:
                    nf = feedback + int((control, receiver) == (3, 1))
                    ns = source + int((control, receiver) == (1, 0))
                    np = private + int((control, receiver) == (1, 0) and rows[1] & 8 != 0)
                    if max(nf, ns, np) > 2:
                        continue
                    moved = list(rows)
                    moved[receiver] ^= rows[control]
                    following[(tuple(moved), nf, ns, np)] += count
            layer = following
            layers.append(layer)
        for target in ((1, 2, 4, 8), (11, 10, 4, 8)):
            problem = self.problem(target, ())
            for feedback, source, private in ((0, 0, 0), (1, 1, 1),
                                              (2, 2, 2), (2, 1, 1)):
                query = ResponseQuery(6, feedback_control=3, feedback_uses=feedback,
                                      source_uses=source, source_private_uses=private)
                answer = local_response(problem, query, LocalBudget(600000, 30_000_000))
                self.assertEqual(answer.status, "exact")
                self.assertEqual([answer.response.coefficient(i) for i in range(7)],
                                 [layer.get((target, feedback, source, private), 0)
                                  for layer in layers])
        self.assertEqual(layers[2].get(((11, 10, 4, 8), 1, 1, 1), 0), 1)

    def test_restored_source_and_private_column_single_use_rules(self):
        identity = self.problem((1, 2, 4, 8), ())
        for query in (ResponseQuery(8, source_uses=1),
                      ResponseQuery(8, feedback_control=3, feedback_uses=1),
                      ResponseQuery(8, source_private_uses=1)):
            result = local_response(identity, query, LocalBudget(50000, 5_000_000))
            self.assertEqual(result.status, "exact")
            self.assertEqual(result.response.terms, ())
        changed = self.problem((11, 10, 4, 8), ())
        result = local_response(changed, ResponseQuery(2, source_uses=1),
                                LocalBudget(50000, 5_000_000))
        self.assertEqual(result.response.coefficient(2), 1)
        all_order_zero = local_response(identity,
                                        ResponseQuery(0, source_private_uses=3,
                                                      fugacity=Fraction(1, 13)),
                                        LocalBudget(0, 0))
        self.assertEqual(all_order_zero.status, "certified_interval")
        self.assertEqual((all_order_zero.response.lower,
                          all_order_zero.response.upper), (Fraction(0), Fraction(0)))
        self.assertEqual(local_response(changed, ResponseQuery(2, source_private_uses=1),
                                        LocalBudget(50000, 5_000_000)).response.coefficient(2), 1)


if __name__ == "__main__":
    unittest.main()
