"""First guarded T16 slice: independent stage-36 cost and scope checks."""
import unittest

from itertools import product
from collections import deque
from random import Random
from pathlib import Path
import json
from fractions import Fraction

from research_v3.response.local import (
    LocalBudget, ResponseQuery, RestrictedProblem, local_response, pair_geodesic,
    private_column_restored, three_row_cost, three_row_program,
)
from research_v3.response.types import (
    ExactRationalFunctionIdentity, ExactRationalPointValue, ExactTemporalProfileValue,
    LabeledPorts, OracleResult,
    RationalIntervalCertificate,
)
from research_v3.response.records import stage51_saved_intervals
from research_v3.response.pair_spectral import _character_histograms
from research_v3.response.joint_spectral import joint_histograms
from research_v3.response.joint_channels import joint_channels
from research_v3.response.joint_carriers import CarrierTimeSlice, profiled_joint_carrier_response
from research_v3.response.carrier_schur import carrier_schur_mode
from research_v3.response.influence import (WireInfluence, wire_influence, sew_wire_influences,
                                            TwoCarrierInfluence, two_carrier_influence)
from research_v3.gf2 import inverse
from research_v3.contracts import AlphabetSpec, MatrixBatch, MatrixState
from research_v3.features.registry import FeaturePolicy, FeatureRegistry
from research_v3.features.response import leading_full_response, register_tiny_i10
from research_v3.model.field import FusionDistanceField
from research_v3.symmetry import map_problem


def target(core, columns):
    n = 3 + len(columns)
    rows = list(core) + [1 << i for i in range(3, n)]
    for column, bits in enumerate(columns, 3):
        for i in range(3):
            rows[i] |= ((bits >> i) & 1) << column
    return tuple(rows)


def pair_target(core, columns):
    n = 2 + len(columns)
    rows = list(core) + [1 << i for i in range(2, n)]
    for column, bits in enumerate(columns, 2):
        for i in range(2):
            rows[i] |= ((bits >> i) & 1) << column
    return tuple(rows)


def matrix_of(gates, n):
    rows = [1 << i for i in range(n)]
    for control, target_row in gates:
        rows[target_row] ^= rows[control]
    return tuple(rows)


class LocalStage36(unittest.TestCase):
    def test_five_formula_branches(self):
        cases = (
            ((), 0, "none"),
            ((3, 3, 3), 5, "pair"),
            ((7, 7, 7), 7, "square"),
            ((3, 3, 5, 5, 6, 6), 11, "pentagon"),
            ((3, 3, 3, 5, 5, 5, 6, 6, 6, 7, 7), 17, "complete"),
        )
        for columns, expected, branch in cases:
            with self.subTest(branch=branch):
                rows = target((1, 2, 4), columns)
                result = three_row_cost(rows, (0, 1, 2))
                self.assertEqual((result.cost, result.branch), (expected, branch))
                self.assertEqual(result.scope, "three_target_alphabet")
                program = three_row_program(rows, (0, 1, 2))
                self.assertEqual(program.proven_distance, expected)
                self.assertEqual(program.branch, branch)
                self.assertEqual(matrix_of(program.gates, len(rows)), rows)

    def test_outside_row_excursion_is_shorter(self):
        rows = target((1, 2, 4), (7, 7))
        restricted = three_row_cost(rows, (0, 1, 2))
        full_word = ((3, 4), (4, 0), (4, 1), (4, 2), (3, 4))
        self.assertEqual(restricted.cost, 6)
        self.assertEqual(restricted.scope, "three_target_alphabet")
        self.assertEqual(matrix_of(full_word, len(rows)), rows)
        self.assertLess(len(full_word), restricted.cost)

    def test_special_global_frame_and_permutation(self):
        rows = target((6, 5, 7), range(1, 8))
        result = three_row_cost(rows, (0, 1, 2))
        self.assertEqual((result.cost, result.scope), (11, "full_cnot_alphabet"))
        perm = (5, 1, 3, 7, 0, 6, 2, 4, 9, 8)
        relocated = [0] * len(rows)
        for i, row in enumerate(rows):
            relocated[perm[i]] = sum(((row >> j) & 1) << perm[j] for j in range(len(rows)))
        result = three_row_cost(relocated, perm[:3])
        self.assertEqual((result.cost, result.scope), (11, "full_cnot_alphabet"))
        program = three_row_program(relocated, perm[:3])
        self.assertEqual(program.proven_distance, 11)
        self.assertEqual(matrix_of(program.gates, len(rows)), tuple(relocated))

    def test_reject_outside_hypotheses(self):
        for rows, active in (
            ((2, 4, 1), (0, 1, 2)),
            ((1, 2, 4, 9), (0, 1, 2)),
            ((1, 2, 4), (0, 0, 1)),
        ):
            with self.subTest(rows=rows, active=active):
                with self.assertRaises(ValueError):
                    three_row_cost(rows, active)

    def test_constructed_words_preserve_proved_scope(self):
        cases = (
            (target((1, 2, 4), (7, 7)), 6, "three_target_alphabet"),
            (target((6, 5, 7), range(1, 8)), 11, "full_cnot_alphabet"),
            (target((1, 2, 4), (3, 3, 5, 5, 6, 6)), 11, "three_target_alphabet"),
        )
        for rows, expected, scope in cases:
            with self.subTest(rows=rows):
                result = three_row_program(rows, (0, 1, 2))
                self.assertEqual(result.proven_distance, expected)
                self.assertEqual(result.scope, scope)
                self.assertEqual(matrix_of(result.gates, len(rows)), rows)
                if scope == "full_cnot_alphabet":
                    self.assertEqual(result.global_lower_bound, expected)

    def test_all_two_external_column_instances_against_restricted_bfs(self):
        n = 5
        initial = tuple(1 << i for i in range(n))
        distance = {initial: 0}
        queue = deque((initial,))
        while queue:
            rows = queue.popleft()
            for control in range(n):
                for target_row in range(3):
                    if control == target_row:
                        continue
                    moved = list(rows)
                    moved[target_row] ^= moved[control]
                    moved = tuple(moved)
                    if moved not in distance:
                        distance[moved] = distance[rows] + 1
                        queue.append(moved)
        self.assertEqual(len(distance), 168 * 8 * 8)
        for core in ((1, 2, 4), (6, 5, 7)):
            for columns in product(range(8), repeat=2):
                rows = target(core, columns)
                answer = three_row_program(rows, (0, 1, 2))
                self.assertEqual(answer.proven_distance, distance[rows])
                self.assertEqual(matrix_of(answer.gates, n), rows)
                if core == (6, 5, 7):
                    self.assertEqual(answer.global_lower_bound, answer.proven_distance)


class GlobalPairGeodesic(unittest.TestCase):
    def test_examples_and_rejection(self):
        for rows, length in (
            ((1, 2, 4, 8), 0),
            ((2, 1, 4, 8), 3),
            ((46, 53, 4, 8, 16, 32), 7),
            ((31, 2, 4, 8, 16), 4),
        ):
            with self.subTest(rows=rows):
                answer = pair_geodesic(rows)
                self.assertEqual(answer.lower_bound, length)
                self.assertEqual(len(answer.gates), length)
                self.assertEqual(answer.scope, "full_cnot_alphabet")
                self.assertEqual(matrix_of(answer.gates, len(rows)), rows)
        for rows in ((3, 6, 4, 9), (2, 2, 4)):
            with self.assertRaises(ValueError):
                pair_geodesic(rows)

    def test_all_small_supported_operators_against_full_alphabet_bfs(self):
        # BFS is independent of the analytic frame construction and lower bound.
        for n in (2, 3, 4):
            initial = tuple(1 << i for i in range(n))
            distance = {initial: 0}
            queue = deque((initial,))
            while queue:
                rows = queue.popleft()
                for control in range(n):
                    for target in range(n):
                        if control == target:
                            continue
                        moved = list(rows)
                        moved[target] ^= moved[control]
                        moved = tuple(moved)
                        if moved not in distance:
                            distance[moved] = distance[rows] + 1
                            queue.append(moved)
            supported = 0
            for rows, exact_distance in distance.items():
                if sum(row != 1 << i for i, row in enumerate(rows)) <= 2:
                    answer = pair_geodesic(rows)
                    self.assertEqual(len(answer.gates), exact_distance)
                    self.assertEqual(answer.lower_bound, exact_distance)
                    self.assertEqual(matrix_of(answer.gates, n), rows)
                    supported += 1
            self.assertEqual((len(distance), supported), {2: (6, 6), 3: (168, 61), 4: (20160, 515)}[n])

    def test_labeled_large_two_row_targets(self):
        random = Random(35161)
        for n in (5, 6, 13, 31, 64, 128):
            for _ in range(10):
                a, b = random.sample(range(n), 2)
                source_word = tuple((random.choice(tuple(i for i in range(n) if i != target)), target)
                                    for target in (random.choice((a, b)) for _ in range(2*n)))
                rows = matrix_of(source_word, n)
                answer = pair_geodesic(rows)
                self.assertEqual(matrix_of(answer.gates, n), rows)
                self.assertEqual(len(answer.gates), answer.lower_bound)
                self.assertLessEqual(len(answer.gates), len(source_word))


class PairSpectralKernel(unittest.TestCase):
    def test_all_n4_pair_endpoints_match_full_matrix_reference(self):
        n = 4
        active = (0, 1)
        alphabet = tuple((c, t) for t in active for c in range(n) if c != t)
        frames = ((1, 2), (1, 3), (3, 2), (2, 3), (3, 1), (2, 1))
        for core in frames:
            for columns in product(range(4), repeat=2):
                rows = pair_target(core, columns)
                args = (rows, alphabet, LabeledPorts(()), (), (2, 3), (), "exact_full_endpoint")
                spectral = RestrictedProblem(*args, active_wires=active, kernel="stage29_pair_spectral")
                direct = RestrictedProblem(*args)
                spectral_result = local_response(spectral, ResponseQuery(5), LocalBudget(1000, 200000))
                direct_result = local_response(direct, ResponseQuery(5), LocalBudget(1000, 200000))
                self.assertEqual((spectral_result.status, direct_result.status), ("exact", "exact"))
                self.assertEqual([spectral_result.response.coefficient(i) for i in range(6)],
                                 [direct_result.response.coefficient(i) for i in range(6)])

    def test_signed_modes_normalize_and_budgets_do_not_create_false_zero(self):
        coefficients, _ = _character_histograms((1, 2, 3), 1000)
        self.assertTrue(any(value < 0 for value in coefficients.values()))
        rows = pair_target((1, 2), (3, 3, 3))
        alphabet = tuple((c, t) for t in (0, 1) for c in range(5) if c != t)
        problem = RestrictedProblem(rows, alphabet, LabeledPorts(()), (), (2, 3, 4), (),
                                    "exact_full_endpoint", (0, 1), "stage29_pair_spectral")
        exact = local_response(problem, ResponseQuery(6), LocalBudget(1000, 200000))
        self.assertEqual(exact.status, "exact")
        self.assertEqual(exact.response.coefficient(4), 0)
        self.assertGreater(exact.response.coefficient(5), 0)
        limited = local_response(problem, ResponseQuery(6), LocalBudget(1, 100))
        self.assertEqual(limited.status, "resource_limit")
        self.assertIsNone(limited.response)

    def test_wrong_pair_alphabet_is_rejected(self):
        problem = RestrictedProblem((3, 2, 4), ((1, 0),), LabeledPorts(()), (), (2,), (),
                                    "exact_full_endpoint", (0, 1), "stage29_pair_spectral")
        result = local_response(problem, ResponseQuery(4), LocalBudget(1000, 10000))
        self.assertEqual(result.status, "unsupported")

    def test_all_order_rational_values_match_source_and_positive_tail(self):
        import importlib.util
        root = Path(__file__).resolve().parents[1]
        source = root / "artifacts/frontier61_source_v1/cnot_research_journal/stage29_pair_field/code/pair_field.py"
        spec = importlib.util.spec_from_file_location("frontier29_pair_formula", source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        z = Fraction(1, 9)
        alphabet = tuple((c, t) for t in (0, 1) for c in range(3) if c != t)
        frames = ((1, 2), (1, 3), (3, 2), (2, 3), (3, 1), (2, 1))
        for core in frames:
            for column in range(4):
                rows = pair_target(core, (column,))
                args = (rows, alphabet, LabeledPorts(()), (), (2,), (), "exact_full_endpoint")
                problem = RestrictedProblem(*args, active_wires=(0, 1), kernel="stage29_pair_spectral")
                result = local_response(problem, ResponseQuery(0, fugacity=z), LocalBudget(1000, 100000))
                self.assertEqual(result.status, "exact_rational_point")
                self.assertIsInstance(result.response, ExactRationalPointValue)
                self.assertEqual(result.response.value, module.resolvent(core, (column,), z))
                direct = local_response(RestrictedProblem(*args), ResponseQuery(8),
                                        LocalBudget(1000, 100000))
                partial = sum(direct.response.coefficient(i) * z**i for i in range(9))
                tail = (4*z)**9 / (1 - 4*z)
                self.assertLessEqual(partial, result.response.value)
                self.assertLessEqual(result.response.value, partial + tail)
        with self.assertRaises(ValueError):
            local_response(problem, ResponseQuery(0, fugacity=Fraction(1, 4)),
                           LocalBudget(1000, 100000))

    def test_wider_pair_leading_degree_matches_constructive_global_geodesic(self):
        columns = (1, 2, 3, 0, 3, 2, 1, 3, 1, 2)
        rows = pair_target((2, 1), columns)
        exact_word = pair_geodesic(rows)
        n = len(rows)
        alphabet = tuple((c, t) for t in (0, 1) for c in range(n) if c != t)
        problem = RestrictedProblem(rows, alphabet, LabeledPorts(()), (), tuple(range(2, n)), (),
                                    "exact_full_endpoint", (0, 1), "stage29_pair_spectral")
        result = local_response(problem, ResponseQuery(exact_word.lower_bound),
                                LocalBudget(1000, 300000))
        self.assertEqual(result.status, "exact")
        self.assertEqual([result.response.coefficient(i) for i in range(exact_word.lower_bound)],
                         [0] * exact_word.lower_bound)
        self.assertGreater(result.response.coefficient(exact_word.lower_bound), 0)


class JointSpectralKernel(unittest.TestCase):
    def test_exact_recoupling_matches_primary_integer_operator(self):
        import importlib.util
        import numpy as np
        root = Path(__file__).resolve().parents[1]
        source = root / "artifacts/frontier61_source_v1/cnot_research_journal/stage30_joint_boundary/code/joint_boundary.py"
        spec = importlib.util.spec_from_file_location("frontier30_channel_integer", source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        own = joint_channels()
        primary = module.TripletFusion()
        np.testing.assert_array_equal(own.recoupling_numerator,
                                      primary.recoupling_numerator)
        for histogram in ((0,) * 8, (1, 0, 0, 0, 0, 1, 0, 0),
                          (0, 1, 2, 0, 1, 0, 0, 1)):
            direct = primary.full_matrix(histogram)
            own_pair, own_single = own.microscopic_parts(histogram)
            np.testing.assert_array_equal(own_pair + own_single, direct)
            expected = 16 * primary.pair_blocks(histogram) + (
                primary.recoupling_numerator * primary.single_eigenvalues(histogram)
            ) @ primary.recoupling_numerator.T
            np.testing.assert_array_equal(own.coupled_operator_numerator(histogram), expected)

    def test_selected_endpoints_match_primary_stage30_formula(self):
        import importlib.util
        root = Path(__file__).resolve().parents[1]
        source = root / "artifacts/frontier61_source_v1/cnot_research_journal/stage30_joint_boundary/code/joint_boundary.py"
        spec = importlib.util.spec_from_file_location("frontier30_joint_formula", source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        formula = module.TripletFusion()
        n = 5
        active = (0, 1, 2)
        alphabet = tuple((c, t) for t in active for c in range(n) if c != t)
        frames = ((1, 2, 4), (3, 2, 4), (6, 5, 7), (4, 1, 2))
        for core in frames:
            core_inverse = inverse(core)
            for columns in ((0, 0), (1, 2), (3, 5), (7, 7)):
                rows = target(core, columns)
                currents = tuple(sum(((core_inverse[k] & column).bit_count() & 1) << k
                                     for k in range(3)) for column in columns)
                problem = RestrictedProblem(rows, alphabet, LabeledPorts(()), (), (), (),
                                            "exact_full_endpoint", active, "stage30_joint_spectral")
                result = local_response(problem, ResponseQuery(5), LocalBudget(10000, 1000000))
                self.assertEqual(result.status, "exact")
                self.assertEqual([result.response.coefficient(i) for i in range(6)],
                                 formula.endpoint_coefficients(core, currents, 5))

    def test_full_joint_modes_match_independent_small_matrix_walks(self):
        random = Random(30168)
        for n, degree, trials in ((4, 5, 24), (5, 4, 12)):
            active = (0, 1, 2)
            alphabet = tuple((c, t) for t in active for c in range(n) if c != t)
            for _ in range(trials):
                word = tuple(random.choice(alphabet) for _ in range(random.randrange(6)))
                rows = matrix_of(word, n)
                args = (rows, alphabet, LabeledPorts(()), (), (), (), "exact_full_endpoint")
                spectral = RestrictedProblem(*args, active_wires=active, kernel="stage30_joint_spectral")
                direct = RestrictedProblem(*args)
                analytic_result = local_response(spectral, ResponseQuery(degree),
                                                 LocalBudget(10000, 1000000))
                direct_result = local_response(direct, ResponseQuery(degree),
                                               LocalBudget(100000, 1000000))
                self.assertEqual((analytic_result.status, direct_result.status), ("exact", "exact"))
                self.assertEqual([analytic_result.response.coefficient(i) for i in range(degree + 1)],
                                 [direct_result.response.coefficient(i) for i in range(degree + 1)])

    def test_joint_histogram_keeps_same_marginal_different_correlation(self):
        h = (1, 0, 0, 0, 0, 1, 0, 0)
        k = (0, 1, 0, 0, 1, 0, 0, 0)
        self.assertEqual(tuple(sum(h[a + 4*b] for b in range(2)) for a in range(4)),
                         tuple(sum(k[a + 4*b] for b in range(2)) for a in range(4)))
        self.assertEqual(tuple(sum(h[a + 4*b] for a in range(4)) for b in range(2)),
                         tuple(sum(k[a + 4*b] for a in range(4)) for b in range(2)))
        import numpy as np
        self.assertFalse(np.array_equal(joint_channels().coupled_operator_numerator(h),
                                        joint_channels().coupled_operator_numerator(k)))
        first, _ = joint_histograms((0, 5), 1000)
        second, _ = joint_histograms((1, 4), 1000)
        self.assertNotEqual(first, second)
        self.assertTrue(any(value < 0 for value in first.values()))
        self.assertEqual(joint_histograms((0, 5), 0)[0], None)

    def test_budget_and_alphabet_guards(self):
        n = 5
        active = (0, 1, 2)
        alphabet = tuple((c, t) for t in active for c in range(n) if c != t)
        rows = target((1, 2, 4), (7, 5))
        args = (rows, alphabet, LabeledPorts(()), (), (), (), "exact_full_endpoint")
        problem = RestrictedProblem(*args, active_wires=active, kernel="stage30_joint_spectral")
        result = local_response(problem, ResponseQuery(5), LocalBudget(1, 100))
        self.assertEqual(result.status, "resource_limit")
        self.assertIsNone(result.response)
        wrong = RestrictedProblem(rows, alphabet[:-1], LabeledPorts(()), (), (), (),
                                  "exact_full_endpoint", active, "stage30_joint_spectral")
        self.assertEqual(local_response(wrong, ResponseQuery(4),
                                        LocalBudget(1000, 100000)).status, "unsupported")
        self.assertEqual(local_response(problem, ResponseQuery(0, fugacity=Fraction(1, 20)),
                                        LocalBudget(1000, 100000)).status, "resource_limit")

    def test_all_order_joint_value_matches_primary_formula_on_zero_spectators(self):
        import importlib.util
        root = Path(__file__).resolve().parents[1]
        source = root / "artifacts/frontier61_source_v1/cnot_research_journal/stage30_joint_boundary/code/joint_boundary.py"
        spec = importlib.util.spec_from_file_location("frontier30_joint_rational", source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        z = Fraction(1, 12)
        alphabet = tuple((c, t) for t in range(3) for c in range(3) if c != t)
        for core in ((1, 2, 4), (3, 2, 4)):
            problem = RestrictedProblem(core, alphabet, LabeledPorts(()), (), (), (),
                                        "exact_full_endpoint", (0, 1, 2), "stage30_joint_spectral")
            result = local_response(problem, ResponseQuery(0, fugacity=z),
                                    LocalBudget(1000, 5_000_000))
            self.assertEqual(result.status, "exact_rational_point")
            self.assertEqual(result.response.value,
                             module.TripletFusion().endpoint_resolvent(core, (), z))


class Stage47Influence(unittest.TestCase):
    def test_two_bit_currents_match_primary_source(self):
        import importlib.util
        root = Path(__file__).resolve().parents[1]
        source = root / "artifacts/frontier61_source_v1/stage47_influence_vertex/influence_vertex.py"
        spec = importlib.util.spec_from_file_location("frontier47_influence", source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        random = Random(47001)
        for _ in range(100):
            incoming = tuple(random.randrange(4) for _ in range(4))
            outgoing = tuple(random.randrange(4) for _ in range(4))
            for start, end in product(range(4), repeat=2):
                got = wire_influence(WireInfluence(2, start, end, incoming, outgoing))
                self.assertEqual(got.value,
                                 module.influence_value(start, end, incoming, outgoing, 2))

    def test_exhaustive_one_bit_path_sum(self):
        for length in range(5):
            for incoming in product(range(2), repeat=length):
                for outgoing in product(range(2), repeat=length):
                    for start, end in product(range(2), repeat=2):
                        answer = wire_influence(WireInfluence(1, start, end, incoming, outgoing))
                        expected = 0
                        for middle in product(range(2), repeat=max(0, length - 1)):
                            rows = (start,) + middle + (end,)
                            if length == 0:
                                expected = int(start == end)
                            elif all(rows[i + 1] == (rows[i] ^ incoming[i]) for i in range(length)):
                                sign = sum((outgoing[i] & rows[i]).bit_count()
                                           for i in range(length)) & 1
                                expected += -1 if sign else 1
                        self.assertEqual(answer.value, expected)

    def test_memory_order_and_open_boundary_sewing(self):
        self.assertEqual(wire_influence(WireInfluence(1, 0, 1, (1, 0), (0, 1))).value, -1)
        self.assertEqual(wire_influence(WireInfluence(1, 0, 1, (0, 1), (1, 0))).value, 1)
        random = Random(47002)
        for _ in range(100):
            incoming = tuple(random.randrange(8) for _ in range(7))
            outgoing = tuple(random.randrange(8) for _ in range(7))
            start, end = random.randrange(8), random.randrange(8)
            middle = start ^ incoming[0] ^ incoming[1] ^ incoming[2]
            left = WireInfluence(3, start, middle, incoming[:3], outgoing[:3])
            right = WireInfluence(3, middle, end, incoming[3:], outgoing[3:])
            joined = sew_wire_influences(left, right)
            self.assertEqual(joined.value,
                             wire_influence(WireInfluence(3, start, end, incoming, outgoing)).value)
            self.assertEqual(joined.value,
                             sum(wire_influence(WireInfluence(3, start, x, incoming[:3], outgoing[:3])).value *
                                 wire_influence(WireInfluence(3, x, end, incoming[3:], outgoing[3:])).value
                                 for x in range(8)))

    def test_reject_invalid_currents_and_mismatched_sewing(self):
        with self.assertRaises(ValueError):
            WireInfluence(2, 0, 0, (1,), ())
        with self.assertRaises(ValueError):
            WireInfluence(2, 0, 0, (4,), (0,))
        with self.assertRaises(ValueError):
            sew_wire_influences(WireInfluence(2, 0, 0, (), ()),
                                 WireInfluence(2, 1, 1, (), ()))


class Stage47CarrierStar(unittest.TestCase):
    @staticmethod
    def make_problem(m, parity, mask0, mask1):
        n = m + 2
        rows = [1 << i for i in range(n)]
        rows[1] ^= parity
        for k in range(m):
            if (mask0 >> k) & 1:
                rows[k + 2] ^= 2
            if (mask1 >> k) & 1:
                rows[k + 2] ^= 3
        alphabet = ((0, 1),) + tuple((1, i) for i in range(2, n))
        args = (tuple(rows), alphabet, LabeledPorts(()), (), (), (), "exact_full_endpoint")
        return RestrictedProblem(*args, active_wires=(0, 1), kernel="stage47_carrier_star"), RestrictedProblem(*args)

    def test_all_small_star_endpoints_match_full_matrix_word_dp(self):
        for m in (1, 2, 3):
            for parity in (0, 1):
                for mask0, mask1 in product(range(1 << m), repeat=2):
                    star, direct = self.make_problem(m, parity, mask0, mask1)
                    exact = local_response(star, ResponseQuery(6), LocalBudget(1000, 100000))
                    walked = local_response(direct, ResponseQuery(6), LocalBudget(10000, 100000))
                    self.assertEqual((exact.status, walked.status), ("exact", "exact"))
                    self.assertEqual([exact.response.coefficient(i) for i in range(7)],
                                     [walked.response.coefficient(i) for i in range(7)])

    def test_all_order_star_point_and_known_three_receiver_endpoint(self):
        import importlib.util
        root = Path(__file__).resolve().parents[1]
        source = root / "artifacts/frontier61_source_v1/stage47_influence_vertex/influence_vertex.py"
        spec = importlib.util.spec_from_file_location("frontier47_star", source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        problem, _ = self.make_problem(3, 0, 0, 7)
        exact = local_response(problem, ResponseQuery(11), LocalBudget(1000, 100000))
        self.assertEqual([exact.response.coefficient(i) for i in range(12)],
                         [0, 0, 0, 0, 0, 6, 0, 138, 0, 2568, 0, 45408])
        for z in (Fraction(1, 20), Fraction(1, 10)):
            value = local_response(problem, ResponseQuery(0, fugacity=z),
                                   LocalBudget(1000, 100000))
            self.assertEqual(value.status, "exact_rational_point")
            self.assertEqual(value.response.value, module.star_value(3, 0, 0, 7, z))

    def test_star_scope_and_budget(self):
        problem, _ = self.make_problem(3, 0, 0, 7)
        self.assertEqual(local_response(problem, ResponseQuery(8),
                                        LocalBudget(1, 100)).status, "resource_limit")
        wrong = RestrictedProblem(problem.target_rows, problem.alphabet[:-1], LabeledPorts(()),
                                  (), (), (), "exact_full_endpoint", (0, 1), "stage47_carrier_star")
        self.assertEqual(local_response(wrong, ResponseQuery(8),
                                        LocalBudget(1000, 100000)).status, "unsupported")

    def test_wide_star_leading_coefficient_keeps_restricted_scope(self):
        from math import factorial
        m = 32
        problem, _ = self.make_problem(m, 0, 0, (1 << m) - 1)
        answer = local_response(problem, ResponseQuery(m + 2),
                                LocalBudget(2000, 100000))
        self.assertEqual(answer.status, "exact")
        self.assertEqual([answer.response.coefficient(i) for i in range(m + 2)],
                         [0] * (m + 2))
        self.assertEqual(answer.response.coefficient(m + 2), factorial(m))
        self.assertIn("carrier_star_alphabet", answer.scope_id)


class Stage48JointCarriers(unittest.TestCase):
    def test_all_order_exact_mutual_use_coefficients_against_full_24_state_solve(self):
        from research_v3.response.joint_carriers import _INDEX, _ORIGIN, _mode_data
        z = Fraction(1, 12)
        diagonal, outgoing = _mode_data((0,) * 8)

        def direct_solve(rhs):
            matrix = [[Fraction(int(i == j)) for j in range(24)] + [rhs[i]]
                      for i in range(24)]
            for origin in range(24):
                matrix[origin][origin] -= z * diagonal[origin]
                for destination in outgoing[origin][:2]:
                    matrix[destination][origin] -= z
            for column in range(24):
                pivot = next(i for i in range(column, 24) if matrix[i][column])
                matrix[column], matrix[pivot] = matrix[pivot], matrix[column]
                scale = matrix[column][column]
                matrix[column] = [value / scale for value in matrix[column]]
                for i in range(24):
                    if i == column or not matrix[i][column]:
                        continue
                    factor = matrix[i][column]
                    matrix[i] = [a - factor * b for a, b in zip(matrix[i], matrix[column])]
            return tuple(row[-1] for row in matrix)

        expected = direct_solve(tuple(Fraction(int(i == _ORIGIN)) for i in range(24)))
        problem, _ = self.make_problem((3, 7), ())
        for uses in range(3):
            result = local_response(problem, ResponseQuery(0, mutual_uses=uses, fugacity=z),
                                    LocalBudget(1000, 100000))
            self.assertEqual(result.status, "exact_rational_point")
            self.assertEqual(result.response.value, expected[_INDEX[(3, 7)]])
            rhs = [Fraction(0)] * 24
            for i, value in enumerate(expected):
                for destination in outgoing[i][2:]:
                    rhs[destination] += z * value
            expected = direct_solve(tuple(rhs))

        with_receiver, _ = self.make_problem((3, 7), (7,))
        point = local_response(with_receiver, ResponseQuery(0, mutual_uses=1,
                                                            fugacity=Fraction(1, 20)),
                               LocalBudget(1000, 500000))
        finite = local_response(with_receiver, ResponseQuery(10, mutual_uses=1),
                                LocalBudget(1000, 100000))
        self.assertEqual((point.status, finite.status), ("exact_rational_point", "exact"))
        partial = sum(term.multiplicity * Fraction(1, 20) ** term.degree.value
                      for term in finite.response.terms)
        tail = Fraction(6, 20) ** 11 / (1 - Fraction(6, 20))
        self.assertLessEqual(partial, point.response.value)
        self.assertLessEqual(point.response.value, partial + tail)

    def test_six_four_state_schur_blocks_match_all_24_mode_values(self):
        import importlib.util
        from research_v3.response.joint_carriers import _mode_data, _ORIGIN
        root = Path(__file__).resolve().parents[1]
        source = root / "artifacts/frontier61_source_v1/stage48_joint_influence/joint_influence.py"
        spec = importlib.util.spec_from_file_location("frontier48_schur", source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        cases = (((0,) * 8, Fraction(1, 40)),
                 ((2, 0, 1, 0, 0, 0, 0, 0), Fraction(1, 30)),
                 ((0, 1, 0, 1, 0, 1, 0, 0), Fraction(1, 40)))
        for histogram, z in cases:
            diagonal, outgoing = _mode_data(histogram)
            for coupled in (False, True):
                values = carrier_schur_mode(histogram, z, coupled=coupled)
                self.assertEqual(len(values), 24)
                self.assertEqual(values,
                                 tuple(module.dressed_mode_vector(histogram, z, int(coupled))))
                for i in range(24):
                    incoming = sum(values[j] for j in outgoing[i][:4 if coupled else 2])
                    self.assertEqual(values[i] - z*(diagonal[i]*values[i] + incoming),
                                     int(i == _ORIGIN))

    def test_ordered_time_profile_matches_primary_and_full_matrix_product(self):
        import importlib.util
        root = Path(__file__).resolve().parents[1]
        source = root / "artifacts/frontier61_source_v1/stage48_joint_influence/joint_influence.py"
        spec = importlib.util.spec_from_file_location("frontier48_profile", source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        random = Random(48048)
        alphabet = ((0, 1), (0, 2), (1, 2), (2, 1), (1, 3), (2, 3))
        frames = tuple((u, v) for u in range(2, 8) for v in range(2, 8)
                       if (u >> 1) != (v >> 1))
        for _ in range(5):
            slices = tuple(CarrierTimeSlice(Fraction(1, 7),
                                           tuple(Fraction(random.randrange(3)) for _ in range(6)))
                           for _ in range(7))
            profile = tuple((item.epsilon, item.weights) for item in slices)
            states = {(1, 2, 4, 8): Fraction(1)}
            for item in slices:
                following = dict(states)
                for rows, value in states.items():
                    for (control, target_row), weight in zip(alphabet, item.weights):
                        moved = list(rows)
                        moved[target_row] ^= moved[control]
                        key = tuple(moved)
                        following[key] = following.get(key, Fraction(0)) + item.epsilon * weight * value
                states = following
            for _ in range(10):
                core = random.choice(frames)
                translations = (random.randrange(8),)
                problem, _ = self.make_problem(core, translations)
                result = profiled_joint_carrier_response(problem, slices,
                                                         LocalBudget(1000, 100000))
                self.assertEqual(result.status, "exact_profiled_point")
                self.assertIsInstance(result.response, ExactTemporalProfileValue)
                self.assertEqual(result.response.profile, profile)
                self.assertEqual(result.response.value,
                                 module.profiled_value(translations, core, profile))
                self.assertEqual(result.response.value, states.get(problem.target_rows, Fraction(0)))

    def test_profile_distinguishes_the_two_mutual_gate_directions(self):
        forward, _ = self.make_problem((3, 7), ())
        source_to_h = CarrierTimeSlice(Fraction(1, 3),
                                       (Fraction(1), Fraction(0), Fraction(0),
                                        Fraction(0), Fraction(0), Fraction(0)))
        h_to_k = CarrierTimeSlice(Fraction(1, 5),
                                  (Fraction(0), Fraction(0), Fraction(1),
                                   Fraction(0), Fraction(0), Fraction(0)))
        k_to_h = CarrierTimeSlice(Fraction(1, 5),
                                  (Fraction(0), Fraction(0), Fraction(0),
                                   Fraction(1), Fraction(0), Fraction(0)))
        budget = LocalBudget(100, 10000)
        self.assertEqual(profiled_joint_carrier_response(forward, (source_to_h, h_to_k), budget).response.value,
                         Fraction(1, 15))
        self.assertEqual(profiled_joint_carrier_response(forward, (source_to_h, k_to_h), budget).response.value,
                         Fraction(0))

    def test_fixed_two_carrier_open_influence_against_direct_sums(self):
        import importlib.util
        root = Path(__file__).resolve().parents[1]
        source = root / "artifacts/frontier61_source_v1/stage48_joint_influence/joint_influence.py"
        spec = importlib.util.spec_from_file_location("frontier48_influence", source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        random = Random(48001)
        frames = ((1, 2), (1, 3), (2, 1), (2, 3), (3, 1), (3, 2))
        for _ in range(100):
            initial = (random.randrange(4), random.randrange(4))
            final = (random.randrange(4), random.randrange(4))
            maps = tuple(random.choice(frames) for _ in range(3))
            incoming = tuple((random.randrange(4), random.randrange(4)) for _ in range(3))
            outgoing = tuple((random.randrange(4), random.randrange(4)) for _ in range(3))
            problem = TwoCarrierInfluence(2, initial, final, maps, incoming, outgoing)
            result = two_carrier_influence(problem)
            self.assertEqual(result.value,
                             module.conditional_influence(initial, final, maps, incoming, outgoing))
            expected = 0
            for middle in product(tuple(product(range(4), repeat=2)), repeat=2):
                states = (initial,) + middle + (final,)
                value = 1
                for i, matrix in enumerate(maps):
                    x = states[i]
                    updated = tuple((x[0] if row & 1 else 0) ^ (x[1] if row & 2 else 0) ^ shift
                                    for row, shift in zip(matrix, incoming[i]))
                    if updated != states[i + 1]:
                        value = 0
                        break
                    if sum((bit & charge).bit_count() for bit, charge in zip(x, outgoing[i])) & 1:
                        value = -value
                expected += value
            self.assertEqual(result.value, expected)

    @staticmethod
    def make_problem(core, translations, coupled=True):
        n = 3 + len(translations)
        rows = (1,) + tuple(core) + tuple((1 << (3 + i)) ^ bits
                                              for i, bits in enumerate(translations))
        alphabet = ((0, 1), (0, 2)) + (((1, 2), (2, 1)) if coupled else ()) + tuple(
            (control, receiver) for receiver in range(3, n) for control in (1, 2))
        args = (rows, alphabet, LabeledPorts(()), (), (), (), "exact_full_endpoint")
        kernel = "stage48_joint_carriers" if coupled else "stage48_uncoupled_carriers"
        return RestrictedProblem(*args, active_wires=(0, 1, 2), kernel=kernel), RestrictedProblem(*args)

    def test_all_zero_one_receiver_endpoints_match_full_matrix_dp(self):
        frames = tuple((u, v) for u in range(2, 8) for v in range(2, 8)
                       if (u >> 1) != (v >> 1))
        for translations in ((),) + tuple((x,) for x in range(8)):
            for core in frames:
                spectral, direct = self.make_problem(core, translations)
                analytic = local_response(spectral, ResponseQuery(6),
                                          LocalBudget(1000, 100000))
                walked = local_response(direct, ResponseQuery(6),
                                        LocalBudget(10000, 100000))
                self.assertEqual((analytic.status, walked.status), ("exact", "exact"))
                self.assertEqual([analytic.response.coefficient(i) for i in range(7)],
                                 [walked.response.coefficient(i) for i in range(7)])

    def test_rational_values_match_primary_two_carrier_source(self):
        import importlib.util
        root = Path(__file__).resolve().parents[1]
        source = root / "artifacts/frontier61_source_v1/stage48_joint_influence/joint_influence.py"
        spec = importlib.util.spec_from_file_location("frontier48_joint", source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        for translations, core, z in (((7,), (2, 4), Fraction(1, 40)),
                                      ((3, 5), (3, 7), Fraction(1, 40))):
            problem, _ = self.make_problem(core, translations)
            result = local_response(problem, ResponseQuery(0, fugacity=z),
                                    LocalBudget(10000, 1000000))
            self.assertEqual(result.status, "exact_rational_point")
            self.assertEqual(result.response.value,
                             module.rational_value(translations, core, z))
        uncoupled, _ = self.make_problem((2, 4), (7, 3), coupled=False)
        result = local_response(uncoupled, ResponseQuery(0, fugacity=Fraction(1, 40)),
                                LocalBudget(10000, 1000000))
        self.assertEqual(result.status, "exact_rational_point")
        self.assertEqual(result.response.value,
                         module.rational_value((7, 3), (2, 4), Fraction(1, 40), coupling=0))

    def test_two_carrier_scope_guards(self):
        problem, _ = self.make_problem((2, 4), (7, 3))
        self.assertEqual(local_response(problem, ResponseQuery(8),
                                        LocalBudget(1, 100)).status, "resource_limit")
        wrong = RestrictedProblem(problem.target_rows, problem.alphabet[:-1], LabeledPorts(()),
                                  (), (), (), "exact_full_endpoint", (0, 1, 2),
                                  "stage48_joint_carriers")
        self.assertEqual(local_response(wrong, ResponseQuery(8),
                                        LocalBudget(1000, 100000)).status, "unsupported")

    def test_marked_mutual_gate_count_matches_source_and_independent_words(self):
        import importlib.util
        from collections import defaultdict
        root = Path(__file__).resolve().parents[1]
        source = root / "artifacts/frontier61_source_v1/stage48_joint_influence/joint_influence.py"
        spec = importlib.util.spec_from_file_location("frontier48_marked", source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        translations = (7,)
        core = (3, 7)
        problem, _ = self.make_problem(core, translations)
        primary = module.bivariate_coefficients(translations, core, order=7)
        layer = {(tuple(1 << i for i in range(4)), 0): 1}
        physical = []
        for degree in range(8):
            physical.append(tuple(layer.get((problem.target_rows, uses), 0)
                                  for uses in range(4)))
            following = defaultdict(int)
            for (rows, uses), multiplicity in layer.items():
                for control, target_row in problem.alphabet:
                    next_uses = uses + int((control, target_row) in ((1, 2), (2, 1)))
                    if next_uses > 3:
                        continue
                    moved = list(rows)
                    moved[target_row] ^= moved[control]
                    following[(tuple(moved), next_uses)] += multiplicity
            layer = following
        for uses in range(4):
            result = local_response(problem, ResponseQuery(7, mutual_uses=uses),
                                    LocalBudget(1000, 100000))
            self.assertEqual(result.status, "exact")
            self.assertIn(f"mutual_uses{uses}", result.scope_id)
            for degree in range(8):
                self.assertEqual(result.response.coefficient(degree), primary[degree][uses]
                                 if uses <= degree else 0)
                self.assertEqual(result.response.coefficient(degree), physical[degree][uses])
        with self.assertRaises(ValueError):
            ResponseQuery(3, mutual_uses=-1)
        self.assertEqual(local_response(problem, ResponseQuery(0, fugacity=Fraction(1, 40),
                                                                mutual_uses=2),
                                        LocalBudget(1000, 100000)).status, "unsupported")

    def test_same_full_target_coupled_vs_uncoupled_and_verified_words(self):
        from math import factorial
        translations = (7, 7, 7)
        joined, _ = self.make_problem((2, 4), translations, coupled=True)
        separate, _ = self.make_problem((2, 4), translations, coupled=False)
        bound = LocalBudget(10000, 1000000)
        with_link = local_response(joined, ResponseQuery(8), bound)
        without_link = local_response(separate, ResponseQuery(8), bound)
        self.assertEqual((with_link.status, without_link.status), ("exact", "exact"))
        self.assertEqual([with_link.response.coefficient(i) for i in range(7)], [0] * 7)
        self.assertEqual(with_link.response.coefficient(7), 10 * factorial(3))
        self.assertEqual([without_link.response.coefficient(i) for i in range(8)], [0] * 8)
        self.assertGreater(without_link.response.coefficient(8), 0)
        linked_word = ((0, 1), (2, 1), (1, 3), (1, 4), (1, 5), (2, 1), (0, 1))
        separate_word = ((0, 1), (1, 3), (2, 3), (1, 4), (2, 4),
                         (1, 5), (2, 5), (0, 1))
        self.assertEqual(matrix_of(linked_word, 6), joined.target_rows)
        self.assertEqual(matrix_of(separate_word, 6), separate.target_rows)
        self.assertTrue(set(linked_word) <= set(joined.alphabet))
        self.assertTrue(set(separate_word) <= set(separate.alphabet))


class Stage49FeedbackSpectral(unittest.TestCase):
    def test_all_order_point_value_matches_verified_source_identity(self):
        root = Path(__file__).resolve().parents[1]
        saved = root / "artifacts/frontier61_source_v1/stage49_feedback_influence/results/computed.json"
        primary = json.loads(saved.read_text(encoding="utf-8"))
        self.assertEqual((primary["target"]["frame"], primary["target"]["source_column"],
                         primary["z"], primary["gamma"]), ([1, 2, 7], 4, "1/312", 1))
        problem, _ = self.problems((1, 2, 4, 15))
        z = Fraction(1, 312)
        result = local_response(problem, ResponseQuery(0, fugacity=z),
                                LocalBudget(168, 8 * 168**3))
        self.assertEqual(result.status, "exact_rational_point")
        self.assertEqual(result.response.value,
                         Fraction(int(primary["numerator"]), int(primary["denominator"])))
        self.assertEqual(local_response(problem, ResponseQuery(0, fugacity=z),
                                        LocalBudget(167, 8 * 168**3)).status, "resource_limit")
        with self.assertRaises(ValueError):
            local_response(problem, ResponseQuery(0, fugacity=Fraction(1, 7)),
                           LocalBudget(168, 8 * 168**3))

    @staticmethod
    def problems(rows):
        alphabet = ((0, 1), (0, 2), (1, 2), (2, 1),
                    (1, 3), (2, 3), (3, 1))
        args = (rows, alphabet, LabeledPorts(()), (3,), (), (), "exact_full_endpoint")
        return RestrictedProblem(*args, active_wires=(0, 1, 2, 3),
                                 kernel="stage49_feedback_spectral"), RestrictedProblem(*args)

    def test_all_feedback_use_counts_against_source_and_full_matrix_dp(self):
        import importlib.util
        root = Path(__file__).resolve().parents[1]
        source = root / "artifacts/frontier61_source_v1/stage49_feedback_influence/feedback_influence.py"
        spec = importlib.util.spec_from_file_location("frontier49_feedback", source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        target_rows = (1, 2, 4, 15)
        spectral, direct = self.problems(target_rows)
        self.assertTrue(private_column_restored(target_rows, 3))
        source_counts = module.open_coefficients((1, 2, 7), 4, 7)
        for uses in range(4):
            query = ResponseQuery(7, feedback_control=3, feedback_uses=uses)
            analytic = local_response(spectral, query, LocalBudget(1000, 1000000))
            walked = local_response(direct, query, LocalBudget(10000, 1000000))
            self.assertEqual((analytic.status, walked.status), ("exact", "exact"))
            for degree in range(8):
                self.assertEqual(analytic.response.coefficient(degree), source_counts[degree][uses]
                                 if uses <= degree else 0)
                self.assertEqual(analytic.response.coefficient(degree),
                                 walked.response.coefficient(degree))
        self.assertEqual(sum(source_counts[7][3:4]), 10)

    def test_single_feedback_survives_without_full_private_column_restore(self):
        rows = matrix_of(((3, 1),), 4)
        self.assertFalse(private_column_restored(rows, 3))
        spectral, direct = self.problems(rows)
        query = ResponseQuery(1, feedback_control=3, feedback_uses=1)
        got = local_response(spectral, query, LocalBudget(1000, 100000))
        self.assertEqual(got.status, "exact")
        self.assertEqual(got.response.coefficient(1), 1)
        self.assertEqual(got.response.coefficient(1),
                         local_response(direct, query, LocalBudget(1000, 10000)).response.coefficient(1))

    def test_unmarked_feedback_and_relabelled_full_matrix(self):
        import importlib.util
        root = Path(__file__).resolve().parents[1]
        source = root / "artifacts/frontier61_source_v1/stage49_feedback_influence/feedback_influence.py"
        spec = importlib.util.spec_from_file_location("frontier49_unmarked", source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        small, _ = self.problems((1, 2, 4, 15))
        reference = local_response(small, ResponseQuery(8), LocalBudget(1000, 1000000))
        self.assertEqual(reference.status, "exact")
        self.assertEqual([reference.response.coefficient(i) for i in range(9)],
                         module.scalar_coefficients((1, 2, 7), 4, 8))
        wires = (5, 1, 8, 11)
        n = 13
        relocated = [1 << i for i in range(n)]
        for old, wire in enumerate(wires):
            relocated[wire] = sum(((small.target_rows[old] >> j) & 1) << wires[j]
                                  for j in range(4))
        alphabet = tuple((wires[c], wires[t]) for c, t in small.alphabet)
        wide = RestrictedProblem(tuple(relocated), alphabet, LabeledPorts(()), (wires[3],),
                                 (), (), "exact_full_endpoint", wires, "stage49_feedback_spectral")
        result = local_response(wide, ResponseQuery(8), LocalBudget(1000, 1000000))
        self.assertEqual(result.status, "exact")
        self.assertEqual([result.response.coefficient(i) for i in range(9)],
                         [reference.response.coefficient(i) for i in range(9)])

    def test_feedback_sector_guards(self):
        spectral, _ = self.problems((1, 2, 4, 15))
        self.assertEqual(local_response(spectral, ResponseQuery(7),
                                        LocalBudget(1, 100)).status, "resource_limit")
        wrong = RestrictedProblem(spectral.target_rows, spectral.alphabet[:-1], LabeledPorts(()),
                                  (3,), (), (), "exact_full_endpoint", (0, 1, 2, 3),
                                  "stage49_feedback_spectral")
        self.assertEqual(local_response(wrong, ResponseQuery(7),
                                        LocalBudget(1000, 1000000)).status, "unsupported")


class Stage50SharedFeedback(unittest.TestCase):
    def test_all_136_mode_certificate_residuals_and_tamper(self):
        from research_v3.response.shared_feedback import (stage50_saved_interval,
                                                          verify_stage50_certificate)
        root = Path(__file__).resolve().parents[1]
        path = root / "artifacts/frontier61_source_v1/stage50_shared_feedback/results/certified_gamma1_eta1.json"
        budget = LocalBudget(2000, 2000000)
        result = stage50_saved_interval(path, budget)
        self.assertEqual(result.status, "certified_interval")
        self.assertEqual((result.response.modes_total,
                          result.response.modes_independently_replayed), (136, 136))
        self.assertLessEqual(result.response.lower, result.response.upper)
        data = json.loads(path.read_text(encoding="utf-8"))
        data["modes"][0]["numerators_hex"][0] = hex(
            int(data["modes"][0]["numerators_hex"][0], 16) + 1)
        with self.assertRaisesRegex(ValueError, "residual"):
            verify_stage50_certificate(data, budget, certificate_sha="tampered")
        self.assertEqual(stage50_saved_interval(path, LocalBudget(100, 100)).status,
                         "resource_limit")

    @staticmethod
    def problems(core, additions):
        n = 4 + len(additions)
        rows = (1,) + tuple(core) + tuple((1 << (4+i)) ^ value
                                              for i, value in enumerate(additions))
        alphabet = ((0, 1), (0, 2), (1, 2), (2, 1), (1, 3), (2, 3), (3, 1)) + tuple(
            (control, passive) for passive in range(4, n) for control in (1, 2))
        args = (rows, alphabet, LabeledPorts(()), (3,), (), (), "exact_full_endpoint")
        return RestrictedProblem(*args, active_wires=(0, 1, 2, 3),
                                 kernel="stage50_shared_feedback"), RestrictedProblem(*args)

    def test_zero_passive_outputs_reproduce_stage49_marked_coefficients(self):
        shared, _ = self.problems((2, 4, 15), ())
        old, _ = Stage49FeedbackSpectral.problems((1, 2, 4, 15))
        for uses in range(4):
            query = ResponseQuery(7, feedback_control=3, feedback_uses=uses)
            a = local_response(shared, query, LocalBudget(10000, 1000000))
            b = local_response(old, query, LocalBudget(10000, 1000000))
            self.assertEqual((a.status, b.status), ("exact", "exact"))
            self.assertEqual([a.response.coefficient(i) for i in range(8)],
                             [b.response.coefficient(i) for i in range(8)])

    def test_one_passive_output_against_full_matrix_dp(self):
        random = Random(50001)
        alphabet = self.problems((2, 4, 8), (0,))[0].alphabet
        for _ in range(12):
            word = tuple(random.choice(alphabet) for _ in range(random.randrange(5)))
            rows = matrix_of(word, 5)
            shared = RestrictedProblem(rows, alphabet, LabeledPorts(()), (3,), (), (),
                                       "exact_full_endpoint", (0, 1, 2, 3), "stage50_shared_feedback")
            direct = RestrictedProblem(rows, alphabet, LabeledPorts(()), (3,), (), (),
                                       "exact_full_endpoint")
            for uses in (None, 0, 1, 2):
                query = (ResponseQuery(5) if uses is None else
                         ResponseQuery(5, feedback_control=3, feedback_uses=uses))
                a = local_response(shared, query, LocalBudget(10000, 5000000))
                b = local_response(direct, query, LocalBudget(10000, 2000000))
                self.assertEqual((a.status, b.status), ("exact", "exact"))
                self.assertEqual([a.response.coefficient(i) for i in range(6)],
                                 [b.response.coefficient(i) for i in range(6)])

    def test_two_passive_outputs_preserve_full_private_column(self):
        import importlib.util
        root = Path(__file__).resolve().parents[1]
        source = root / "artifacts/frontier61_source_v1/stage50_shared_feedback/shared_feedback.py"
        spec = importlib.util.spec_from_file_location("frontier50_shared", source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        shared, _ = self.problems((2, 4, 15), (3, 3))
        self.assertTrue(private_column_restored(shared.target_rows, 3))
        source_counts = module.coefficients((3, 3), (2, 4, 15), 7)
        for uses in (0, 1, 2, 3):
            query = ResponseQuery(7, feedback_control=3, feedback_uses=uses)
            result = local_response(shared, query, LocalBudget(100000, 100000000))
            self.assertEqual(result.status, "exact")
            self.assertEqual([result.response.coefficient(i) for i in range(8)],
                             [row[uses] if uses < len(row) else 0 for row in source_counts])
        self.assertEqual([row[1] if len(row)>1 else 0 for row in source_counts], [0]*8)

    def test_charged_feedback_joint_counts_against_source(self):
        import importlib.util
        root = Path(__file__).resolve().parents[1]
        source = root / "artifacts/frontier61_source_v1/stage50_shared_feedback/shared_feedback.py"
        spec = importlib.util.spec_from_file_location("frontier50_tagged", source)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        shared, _ = self.problems((2, 4, 15), (3, 3))
        reference = module.tagged_coefficients((3, 3), (2, 4, 15), 6, 2, 2)
        for feedback in range(3):
            for charged in range(3):
                query = ResponseQuery(6, feedback_control=3, feedback_uses=feedback,
                                      charged_uses=charged)
                result = local_response(shared, query, LocalBudget(100000, 500000000))
                self.assertEqual(result.status, "exact")
                self.assertEqual([result.response.coefficient(i) for i in range(7)],
                                 [layer[feedback][charged] for layer in reference])
        self.assertEqual([layer[0][1] for layer in reference], [0]*7)

    def test_charged_private_bit_can_reach_passive_output(self):
        word = ((3, 1), (1, 4))
        shared, _ = self.problems((10, 4, 8), (10,))
        self.assertEqual(shared.target_rows, matrix_of(word, 5))
        answer = local_response(shared, ResponseQuery(2, charged_uses=1),
                                LocalBudget(10000, 5000000))
        self.assertEqual(answer.status, "exact")
        self.assertEqual(answer.response.coefficient(2), 1)

    def test_own_all_order_point_interval_contains_saved_stage50_interval(self):
        from research_v3.response.shared_feedback import stage50_saved_interval
        root = Path(__file__).resolve().parents[1]
        saved = root / "artifacts/frontier61_source_v1/stage50_shared_feedback/results/certified_gamma1_eta1.json"
        certified = stage50_saved_interval(saved, LocalBudget(1344, 2_000_000))
        self.assertEqual(certified.status, "certified_interval")
        shared, _ = self.problems((2, 4, 15), (3, 3))
        z = Fraction(1, 312)
        answer = local_response(shared, ResponseQuery(18, fugacity=z),
                                LocalBudget(1344, 100_000_000))
        self.assertEqual(answer.status, "certified_interval")
        self.assertLessEqual(answer.response.lower, certified.response.lower)
        self.assertGreaterEqual(answer.response.upper, certified.response.upper)
        self.assertEqual((answer.response.modes_total,
                          answer.response.modes_independently_replayed), (136, 136))
        self.assertEqual(local_response(shared, ResponseQuery(18, fugacity=z),
                                        LocalBudget(100, 100)).status, "resource_limit")
        self.assertEqual(local_response(shared, ResponseQuery(0, fugacity=Fraction(1, 11)),
                                        LocalBudget(1344, 100_000_000)).status, "unsupported")


class TinyEndpointResponse(unittest.TestCase):
    def problem(self, target_rows, alphabet, *, ports=(), frequencies=(), restored=()):
        return RestrictedProblem(
            tuple(target_rows), tuple(alphabet), LabeledPorts(tuple(ports)),
            (), tuple(restored), tuple(frequencies), "exact_full_endpoint",
        )

    def test_complete_word_coefficients_against_independent_enumeration(self):
        n = 3
        alphabet = ((0, 1), (1, 0), (2, 1))
        target_rows = matrix_of(((0, 1), (2, 1)), n)
        problem = self.problem(target_rows, alphabet, restored=(0, 2))
        answer = local_response(problem, ResponseQuery(4), LocalBudget(1000, 10000))
        self.assertEqual(answer.status, "exact")
        self.assertEqual(answer.response.count_kind, "words")
        self.assertIn("restricted_cnot_alphabet", answer.scope_id)
        for degree in range(5):
            expected = sum(matrix_of(word, n) == target_rows for word in product(alphabet, repeat=degree))
            self.assertEqual(answer.response.coefficient(degree), expected)

    def test_full_alphabet_and_empty_zero_are_distinct_from_limit(self):
        alphabet = tuple((c, t) for c in range(3) for t in range(3) if c != t)
        target_rows = matrix_of(((0, 2),), 3)
        problem = self.problem(target_rows, alphabet)
        exact = local_response(problem, ResponseQuery(2), LocalBudget(1000, 10000))
        self.assertEqual(exact.status, "exact")
        self.assertEqual(exact.response.coefficient(0), 0)
        self.assertEqual(exact.response.coefficient(1), 1)
        self.assertEqual(exact.scope_id, "full_cnot_alphabet:n3")
        limited = local_response(problem, ResponseQuery(2), LocalBudget(1, 0))
        self.assertEqual(limited.status, "resource_limit")
        self.assertIsNone(limited.response)

    def test_exposed_boundary_and_frequency_cannot_be_erased(self):
        identity = (1, 2, 4)
        alphabet = ((0, 1),)
        for kwargs in ({"ports": ("initial",)}, {"frequencies": (1,)}):
            with self.subTest(kwargs=kwargs):
                result = local_response(self.problem(identity, alphabet, **kwargs),
                                        ResponseQuery(2), LocalBudget(100, 100))
                self.assertEqual(result.status, "unsupported")
                self.assertIsNone(result.response)

    def test_declared_restoration_and_singular_input_rejected(self):
        with self.assertRaises(ValueError):
            self.problem((1, 3, 4), ((0, 1),), restored=(1,))
        with self.assertRaises(ValueError):
            self.problem((1, 1, 4), ((0, 1),))

    def test_stage29_ordered_pair_boundary(self):
        # Both chronological orders have two gates, but different full C.
        alphabet = tuple((c, t) for c in range(3) for t in (0, 1) if c != t)
        forward = matrix_of(((1, 0), (2, 1)), 3)
        reverse = matrix_of(((2, 1), (1, 0)), 3)
        self.assertNotEqual(forward, reverse)
        for rows in (forward, reverse):
            result = local_response(self.problem(rows, alphabet, restored=(2,)),
                                    ResponseQuery(2), LocalBudget(1000, 10000))
            self.assertEqual(result.status, "exact")
            self.assertEqual(result.response.coefficient(2), 1)
            self.assertEqual(result.response.coefficient(1), 0)

    def test_stage30_same_marginals_do_not_erase_joint_histogram(self):
        h = (1, 0, 0, 0, 0, 1, 0, 0)
        k = (0, 1, 0, 0, 1, 0, 0, 0)
        self.assertEqual(tuple(sum(h[a + 4*b] for b in range(2)) for a in range(4)),
                         tuple(sum(k[a + 4*b] for b in range(2)) for a in range(4)))
        self.assertEqual(tuple(sum(h[a + 4*b] for a in range(4)) for b in range(2)),
                         tuple(sum(k[a + 4*b] for a in range(4)) for b in range(2)))
        self.assertNotEqual(h, k)
        for hist in (h, k):
            result = local_response(self.problem((1, 2, 4), ((0, 1),), frequencies=hist),
                                    ResponseQuery(2), LocalBudget(1000, 10000))
            self.assertEqual(result.status, "unsupported")

    def test_stage49_single_feedback_zero_does_not_remove_gamma_cubed(self):
        # s,h,k,y = 0,1,2,3. Gamma counts every use of y as control.
        alphabet = ((0, 1), (0, 2), (1, 2), (2, 1), (1, 3), (2, 3), (3, 1))
        target_rows = (1, 2, 4, 15)
        self.assertTrue(private_column_restored(target_rows, 3))
        problem = RestrictedProblem(target_rows, alphabet, LabeledPorts(()),
                                    (3,), (), (), "exact_full_endpoint")
        one = local_response(problem, ResponseQuery(7, 3, 1), LocalBudget(50000, 1000000))
        self.assertEqual(one.status, "exact")
        self.assertEqual(one.evaluations, 0)
        self.assertEqual(tuple(one.response.terms), ())
        three = local_response(problem, ResponseQuery(7, 3, 3), LocalBudget(50000, 1000000))
        self.assertEqual(three.status, "exact")
        self.assertEqual(three.response.coefficient(7), 10)
        witness = ((2, 3), (3, 1), (1, 3), (0, 1), (3, 1), (1, 3), (3, 1))
        self.assertEqual(sum(c == 3 for c, _ in witness), 3)
        self.assertEqual(matrix_of(witness, 4), target_rows)
        not_restored = matrix_of(((3, 1),), 4)
        self.assertFalse(private_column_restored(not_restored, 3))
        problem = RestrictedProblem(not_restored, alphabet, LabeledPorts(()),
                                    (3,), (), (), "exact_full_endpoint")
        unrestricted_by_theorem = local_response(problem, ResponseQuery(1, 3, 1),
                                                 LocalBudget(100, 1000))
        self.assertEqual(unrestricted_by_theorem.response.coefficient(1), 1)

    def test_stage50_core_return_does_not_restore_passive_private_column(self):
        gates = ((3, 1), (1, 4), (3, 1), (0, 1),
                 (3, 1), (1, 4), (3, 1), (0, 1))
        partial = matrix_of(gates[:3], 5)
        self.assertEqual(partial[:4], (1, 2, 4, 8))
        self.assertFalse(private_column_restored(partial, 3))
        self.assertEqual(matrix_of(gates, 5), (1, 2, 4, 8, 17))

    def test_stage49_single_use_zero_against_independent_full_alphabet_words(self):
        n = 3
        private = 2
        alphabet = tuple((c, t) for c in range(n) for t in range(n) if c != t)
        for degree in range(6):
            for word in product(alphabet, repeat=degree):
                if sum(c == private for c, _ in word) != 1:
                    continue
                rows = matrix_of(word, n)
                self.assertFalse(private_column_restored(rows, private))

    def test_feedback_query_requires_both_fields(self):
        with self.assertRaises(ValueError):
            ResponseQuery(3, feedback_control=0)
        with self.assertRaises(ValueError):
            ResponseQuery(3, feedback_uses=1)


class ResponseFeatureRoute(unittest.TestCase):
    def test_exact_i10_reaches_both_transformers_and_is_relabel_invariant(self):
        import torch
        torch.set_num_threads(1)
        torch.manual_seed(1610)
        alphabet = AlphabetSpec.all_to_all(3)
        rows = matrix_of(((0, 1), (1, 2)), 3)
        state = MatrixState(3, rows, alphabet.id)
        budget = LocalBudget(500, 10000)
        result, degree, coefficient = leading_full_response(
            state, max_n=3, max_degree=5, budget=budget)
        self.assertEqual(result.status, "exact")
        self.assertEqual((degree, coefficient), (2, 1))
        registry = FeatureRegistry()
        register_tiny_i10(registry, max_n=3, max_degree=5, budget=budget)
        policy = FeaturePolicy(("A01", "I10"), evaluations=2, solver_assisted=True)
        relabeled = map_problem(state, alphabet, (2, 0, 1)).state
        packet = registry.build((state, relabeled), policy)
        self.assertEqual(packet.features["I10"].available.tolist(), [True, True])
        self.assertGreater(packet.audit["per_feature"]["I10"]["oracle_evaluations_reported"], 0)
        self.assertTrue(packet.audit["per_feature"]["I10"]["requires_solver_assisted"])
        self.assertIn("complete_positive_full_endpoint_dp",
                      packet.audit["per_feature"]["I10"]["oracle_provenance"][0])
        self.assertEqual(packet.features["I10"].values[0].tolist(),
                         packet.features["I10"].values[1].tolist())
        model = FusionDistanceField([registry.specs[key] for key in policy.enabled_ids],
                                    d=24, pair_d=8, blocks=1, heads=4, ffn=48,
                                    fusion_blocks=1).double()
        values = model(MatrixBatch.from_states((state, relabeled)), packet).value
        torch.testing.assert_close(values[0], values[1], atol=1e-9, rtol=1e-9)
        values.sum().backward()
        for prefix in ("stem.projections.I10", "stem.blocks", "fusion.blocks"):
            magnitude = sum(parameter.grad.abs().sum().item()
                            for name, parameter in model.named_parameters()
                            if name.startswith(prefix) and parameter.grad is not None)
            self.assertGreater(magnitude, 0, prefix)

    def test_i10_no_hit_and_large_matrix_are_unavailable(self):
        a3, a4 = AlphabetSpec.all_to_all(3), AlphabetSpec.all_to_all(4)
        near = MatrixState(3, matrix_of(((0, 1), (1, 2)), 3), a3.id)
        large = MatrixState(4, matrix_of(((0, 1),), 4), a4.id)
        registry = FeatureRegistry()
        register_tiny_i10(registry, max_n=3, max_degree=1,
                          budget=LocalBudget(500, 10000))
        packet = registry.build((near, large), FeaturePolicy(("I10",), evaluations=2,
                                                              solver_assisted=True))
        self.assertEqual(packet.features["I10"].available.tolist(), [False, False])
        self.assertEqual(packet.features["I10"].status, "unsupported")
        self.assertEqual(packet.audit["omitted_ids"], ["I10"])

    def test_full_target_i10_rejects_raw_policy_before_any_feature_work(self):
        from unittest.mock import patch
        alphabet = AlphabetSpec.all_to_all(3)
        state = MatrixState(3, matrix_of(((0, 1),), 3), alphabet.id)
        registry = FeatureRegistry()
        register_tiny_i10(registry, max_n=3, max_degree=3,
                          budget=LocalBudget(500, 10000))
        with patch("research_v3.features.response.leading_full_response",
                   side_effect=AssertionError("exact oracle must not run")):
            with self.assertRaisesRegex(ValueError, "solver-assisted"):
                registry.build((state,), FeaturePolicy(("I10",)))
        self.assertEqual(registry.cache.calls, 0)


class RationalResultKinds(unittest.TestCase):
    def test_stage51_four_pointwise_intervals_keep_14_of_544_scope(self):
        root = Path(__file__).resolve().parents[1]
        source = root / "artifacts/frontier61_source_v1/stage51_dynamic_source/results/certified_values.json"
        replay = root / "artifacts/evidence/2026-09-27-stage51-selected-replay.json"
        values = stage51_saved_intervals(source, replay)
        self.assertEqual(len(values), 4)
        for result in values.values():
            self.assertEqual(result.status, "certified_interval")
            self.assertIsInstance(result.response, RationalIntervalCertificate)
            self.assertEqual((result.response.modes_independently_replayed,
                              result.response.modes_total), (14, 544))
            self.assertLess(result.response.lower, result.response.upper)
            with self.assertRaises(ValueError):
                OracleResult("exact_rational_identity", result.response, 0, "", result.scope_id)

    def test_exact_function_identity_has_separate_result_type(self):
        root = Path(__file__).resolve().parents[1]
        source = root / "artifacts/frontier61_source_v1/stage49_feedback_influence/results/exact_rational_kernel.json"
        data = json.loads(source.read_text(encoding="utf-8"))
        identity = ExactRationalFunctionIdentity(tuple(data["P"]), tuple(data["Q"]),
                                                 "stage49_source_all_order_rational_identity",
                                                 "stage49_source_verifier_replayed_12_tests")
        result = OracleResult("exact_rational_identity", identity, 0,
                              "stage49 source all-order identity; no global encoder claim", "stage49_restricted_feedback")
        self.assertEqual((len(result.response.numerator), len(result.response.denominator)), (90, 91))
        with self.assertRaises(ValueError):
            OracleResult("certified_interval", identity, 0, "", result.scope_id)


if __name__ == "__main__":
    unittest.main()
