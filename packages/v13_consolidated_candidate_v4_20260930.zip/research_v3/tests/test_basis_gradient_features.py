import unittest
import numpy as np
import torch

from research_v3.basis.objective import evaluate_J
from research_v3.basis.templates import BasisChoice, BasisTemplate
from research_v3.contracts import AlphabetSpec, MatrixBatch, MatrixState
from research_v3.features.basis_gradient import register_basis_gradient
from research_v3.features.registry import FeaturePolicy, FeatureRegistry
from research_v3.model.field import FusionDistanceField
from research_v3.symmetry import map_problem


class BasisGradientFeatureTests(unittest.TestCase):
    def test_exact_paid_gradient_and_model_route(self):
        torch.set_num_threads(1)
        block = np.array([[1, 1, 0], [1, 0, 1], [0, 1, 1]], dtype=np.uint8)
        alphabet = AlphabetSpec.all_to_all(6)
        rows = [1 << i for i in range(6)]
        for t in range(3):
            for c in range(3):
                rows[t+3] ^= int(block[t, c]) << c
        state = MatrixState(6, tuple(rows), alphabet.id)
        registry = FeatureRegistry()
        register_basis_gradient(registry)
        ids = ('A01', 'E01', 'E04', 'E05')
        self.assertEqual(registry.providers['E01'][1], 'augmentation_only')
        with self.assertRaisesRegex(ValueError, 'symmetry contract mismatch'):
            registry.build((state,), FeaturePolicy(ids, symmetry_contract='exact_relabel'))
        relabeled = map_problem(state, alphabet, (3, 1, 2, 0, 4, 5)).state
        relabeled_packet = registry.build((relabeled,), FeaturePolicy(ids, symmetry_contract='augmentation_only'))
        self.assertTrue(relabeled_packet.features['E01'].available[0])
        self.assertNotEqual(relabeled_packet.features['E01'].values[0, 0], int(block.sum()))
        packet = registry.build((state, MatrixState.identity(alphabet)),
                                FeaturePolicy(ids, symmetry_contract='augmentation_only'))
        self.assertTrue(all(packet.features[key].available[0] for key in ids))
        self.assertTrue(all(not packet.features[key].available[1] for key in ids[1:]))
        self.assertEqual(packet.features['E05'].exactness, 'float32_rounded_from_exact_counts')
        self.assertEqual(packet.features['E01'].values[0, 0], int(block.sum()))
        for c in range(3):
            for t in range(3):
                if c == t:
                    continue
                template = BasisTemplate(6, (0, 1, 2), (3, 4, 5), 'source',
                                         (BasisChoice('add', c, t),))
                value, gradient = evaluate_J(template, block, np.array([0.]))
                self.assertEqual(packet.features['E01'].values[0, 0], value)
                self.assertEqual(packet.features['E04'].values[0, c, t, 0], gradient[0])
        self.assertEqual(packet.features['E04'].values[0, 0, 1, 1], 1)
        self.assertEqual(packet.features['E04'].values[0, 4, 1, 1], 0)
        expected = [packet.features['E04'].values[0, c, t, 0]
                    for c in range(3) for t in range(3) if c != t]
        np.testing.assert_allclose(packet.features['E05'].values[0],
                                   [min(expected), np.mean(expected), max(expected),
                                    np.mean(np.array(expected) < 0)])
        torch.manual_seed(512)
        model = FusionDistanceField([registry.specs[key] for key in ids], d=24, pair_d=8,
                                    blocks=2, heads=4, ffn=48, fusion_blocks=2).double()
        model(MatrixBatch.from_states((state, MatrixState.identity(alphabet))), packet).value.sum().backward()
        for key in ids:
            self.assertGreater(model.stem.projections[key].weight.grad.abs().sum().item(), 0, key)
        for prefix in ('stem.blocks', 'fusion.blocks'):
            self.assertGreater(sum(p.grad.abs().sum().item() for name, p in model.named_parameters()
                                   if name.startswith(prefix) and p.grad is not None), 0, prefix)


if __name__ == '__main__':
    unittest.main()
