import json
from pathlib import Path
import tempfile
import unittest
from research_v3.train.cuda_stream_v13 import publish_dev
from research_v3.train.schedule import selection_key, selection_key_json


class BestPointerRecoveryTests(unittest.TestCase):
    def test_equal_committed_report_repairs_stale_checkpoint_pointer(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = root/'step-000000640.pt'
            manifest = {'file': path.name, 'sha256': 'a'*64}
            path.with_suffix('.json').write_text(json.dumps(manifest))
            report = {'selection_key': selection_key_json(selection_key(
                {'root': 1}, {'root': 2}, {'root': 4}, 10., 640, 'a'*64))}
            # Simulate crash after best_dev commit, before best pointer commit.
            (root/'best_dev.json').write_text(json.dumps(report))
            (root/'best.json').write_text(json.dumps({'file': 'old.pt'}))
            publish_dev(root, path, report)
            self.assertEqual(json.loads((root/'best.json').read_text()), manifest)


if __name__ == '__main__':
    unittest.main()
