import tempfile
from pathlib import Path
from unittest.mock import patch
import unittest
import torch
from research_v3.train.checkpoint import save_checkpoint, load_checkpoint
from research_v3.train.schedule import Sampler, Progress


class CheckpointFaultTests(unittest.TestCase):
    def test_incomplete_payload_and_unpublished_manifest_preserved_on_retry(self):
        for boundary in ('payload', 'pointer'):
            with self.subTest(boundary=boundary), tempfile.TemporaryDirectory() as directory:
                root = Path(directory)
                model = torch.nn.Linear(1, 1)
                optimizer = torch.optim.AdamW(model.parameters())
                sampler, progress = Sampler(1, 7), Progress()
                config = {'fixture': 'own-fault-checkpoint-v13'}
                target = ('research_v3.train.checkpoint.torch.save' if boundary == 'payload'
                          else 'research_v3.train.checkpoint.atomic_json')
                with patch(target, side_effect=RuntimeError('injected write failure')):
                    with self.assertRaisesRegex(RuntimeError, 'injected'):
                        save_checkpoint(root, model, optimizer, sampler, progress, config)
                old = {path.name: path.read_bytes() for path in root.iterdir()}
                self.assertFalse((root/'last.json').exists())
                retry = save_checkpoint(root, model, optimizer, sampler, progress, config)
                self.assertIn('-retry-', retry.name)
                for name, content in old.items(): self.assertEqual((root/name).read_bytes(), content)
                load_checkpoint(retry, model, optimizer, sampler, progress, config)
                with self.assertRaises(FileExistsError):
                    save_checkpoint(root, model, optimizer, sampler, progress, config)


if __name__ == '__main__': unittest.main()
