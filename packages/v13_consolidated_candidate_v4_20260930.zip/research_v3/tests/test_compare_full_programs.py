import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import torch

from research_v3.cli.compare_full_programs import compare_case, own_cases, verified_summary
from research_v3.contracts import AlphabetSpec, MatrixState, WordCertificate, Gate
from research_v3.features.registry import FeaturePolicy, FeatureRegistry
from research_v3.model.field import FusionDistanceField
from research_v3.basis.learning import BasisField
from research_v3.postprocess import WindowBudget
from research_v3.cli.summarize_full_programs import markdown_table, summarize


class FullProgramComparisonTests(unittest.TestCase):
    def test_own_reference_word_is_replayed_not_trusted(self):
        alphabet = AlphabetSpec.all_to_all(3)
        root = MatrixState(3, (1, 3, 4), alphabet.id)
        canonical = [3, alphabet.id, list(root.packed_rows)]
        digest = hashlib.sha256(json.dumps(canonical, separators=(',', ':')).encode('ascii')).hexdigest()
        with tempfile.TemporaryDirectory() as directory:
            baseline_path = Path(directory) / 'baseline.json'
            manifest_path = Path(directory) / 'manifest.json'
            baseline = {'cases': [{'case': 'own', 'matrix_sha256': 'legacy',
                                   'best': {'source': 'own_source', 'count': 1, 'gates': [[1, 0]]}}]}
            baseline_path.write_text(json.dumps(baseline), encoding='utf-8')
            case = {'case': 'own', 'canonical_key': canonical, 'canonical_sha256': digest,
                    'word_validity': 'verified', 'certificate_ref': str(baseline_path),
                    'certificate_source': 'own_source', 'upper_bound': 1,
                    'legacy_matrix_sha256': 'legacy'}
            manifest_path.write_text(json.dumps({'cases': [case],
                'baseline_sha256': hashlib.sha256(baseline_path.read_bytes()).hexdigest()}), encoding='utf-8')
            with self.assertRaisesRegex(ValueError, 'encoder endpoint mismatch'):
                list(own_cases(manifest_path))
            baseline['cases'][0]['best']['gates'] = [[0, 1]]
            baseline_path.write_text(json.dumps(baseline), encoding='utf-8')
            manifest_path.write_text(json.dumps({'cases': [case],
                'baseline_sha256': hashlib.sha256(baseline_path.read_bytes()).hexdigest()}), encoding='utf-8')
            self.assertEqual(len(list(own_cases(manifest_path))), 1)

    def test_compiler_assisted_has_separate_word_cost_and_audit(self):
        torch.set_num_threads(1)
        alphabet = AlphabetSpec.all_to_all(4)
        root = MatrixState(4, (1, 2, 5, 10), alphabet.id)
        registry = FeatureRegistry()
        policy = FeaturePolicy(('A01',))
        field = FusionDistanceField([registry.specs['A01']], d=24, pair_d=8,
                                    blocks=2, heads=4, ffn=48, fusion_blocks=2)
        model = BasisField(field, hidden=8).eval()
        canonical = [4, alphabet.id, list(root.packed_rows)]
        digest = hashlib.sha256(json.dumps(canonical, separators=(',', ':')).encode('ascii')).hexdigest()
        case = {'case': 'tiny_shear', 'canonical_sha256': digest, 'upper_bound': 2}
        config = {'beam_width': 8, 'max_expansions': 32,
                  'max_cost_multiplier': 2, 'inference_batch_size': 16}
        basis = {'max_calls': 1, 'updates': 1, 'samples': 2, 'evaluations': 16,
                 'max_bytes': 268435456, 'choices': 1, 'seed': 1}
        report = compare_case(case, root, alphabet, model, registry, policy,
                              'test-checkpoint', config, None, basis)
        assisted = report['compiler_assisted']
        self.assertIsNotNone(assisted)
        self.assertIsNotNone(assisted['word'])
        self.assertGreaterEqual(assisted['basis_calls'], 1)
        self.assertGreaterEqual(assisted['basis_evaluations'], 1)
        self.assertEqual(assisted['budget']['beam_width'], report['raw_neural']['budget']['beam_width'])
        self.assertEqual(assisted['budget']['max_expansions'], report['hamming']['budget']['max_expansions'])
        with tempfile.TemporaryDirectory() as directory:
            manifest = Path(directory) / 'manifest.json'
            journal = Path(directory) / 'comparison.jsonl'
            manifest.write_text(json.dumps({'cases': [{**case, 'canonical_key': canonical,
                                                       'word_validity': 'verified'}]}), encoding='utf-8')
            header = {'header': {'checkpoint_sha256': 'test-checkpoint',
                                 'own_manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest()}}
            journal.write_text(json.dumps(header)+'\n'+json.dumps(report)+'\n', encoding='utf-8')
            _, cases, results = summarize(journal, manifest)
            self.assertIn('NN + basis', markdown_table(header['header'], cases, results))
            tampered = json.loads(json.dumps(report))
            tampered['hamming']['budget']['beam_width'] += 1
            journal.write_text(json.dumps(header)+'\n'+json.dumps(tampered)+'\n', encoding='utf-8')
            with self.assertRaisesRegex(ValueError, 'search budgets differ'):
                summarize(journal, manifest)
            tampered = json.loads(json.dumps(report))
            tampered['portfolio'] = None
            journal.write_text(json.dumps(header)+'\n'+json.dumps(tampered)+'\n', encoding='utf-8')
            with self.assertRaisesRegex(ValueError, 'portfolio omits'):
                summarize(journal, manifest)

    def test_independent_replay_rejects_wrong_word_even_if_primary_verifier_is_bypassed(self):
        alphabet = AlphabetSpec.all_to_all(3)
        root = MatrixState(3, (1, 3, 7), alphabet.id)
        forged = WordCertificate(root, MatrixState.identity(alphabet), (Gate(0, 1),),
                                 1, 'forged', 'test')
        with patch('research_v3.cli.compare_full_programs.verify_word', return_value=None):
            with self.assertRaisesRegex(ValueError, 'independent packed-row replay'):
                verified_summary(forged, root, alphabet)

    def test_own_manifest_hash_and_identical_budget_search(self):
        torch.set_num_threads(1)
        alphabet = AlphabetSpec.all_to_all(3)
        root = MatrixState(3, (1, 3, 7), alphabet.id)
        rows = list(root.packed_rows)
        digest = hashlib.sha256(json.dumps([3, alphabet.id, rows], separators=(',', ':')).encode('ascii')).hexdigest()
        case = {'case': 'own_tiny_fixture', 'canonical_sha256': digest, 'upper_bound': 3}
        fixture = {**case, 'canonical_key': [3, alphabet.id, rows], 'word_validity': 'verified'}
        with tempfile.TemporaryDirectory() as directory:
            manifest = Path(directory) / 'manifest.json'
            manifest.write_text(json.dumps({'cases': [fixture]}), encoding='utf-8')
            self.assertEqual(len(list(own_cases(manifest))), 1)
            with self.assertRaises(ValueError):
                list(own_cases(manifest, ('not_a_case',)))
        historical = (Path(__file__).resolve().parents[1] /
                      'artifacts/evidence/2026-09-26-T00-initial/manifest.json')
        if historical.exists():
            cases = list(own_cases(historical))
            self.assertEqual(len(cases), 9)
            self.assertEqual(len({entry['canonical_sha256'] for entry, _, _ in cases}), 9)
        registry = FeatureRegistry()
        policy = FeaturePolicy(('A01',))
        torch.manual_seed(10)
        model = FusionDistanceField([registry.specs['A01']], d=24, pair_d=8,
                                    blocks=2, heads=4, ffn=48, fusion_blocks=2).eval()
        report = compare_case(case, root, alphabet, model, registry, policy, 'test-checkpoint',
                              {'beam_width': 16, 'max_expansions': 80,
                               'max_cost_multiplier': 2, 'inference_batch_size': 16},
                              WindowBudget(1, 2, 2000, 2000, support_restricted=True))
        self.assertIsNotNone(report['raw_neural']['word'])
        self.assertIsNotNone(report['qhat_neural']['word'])
        self.assertIsNotNone(report['hamming']['word'])
        self.assertEqual(report['qhat_neural']['budget'], report['hamming']['budget'])
        self.assertEqual(report['raw_neural']['budget'], report['hamming']['budget'])
        self.assertIsNotNone(report['postprocess']['word'])
        self.assertIsNotNone(report['portfolio']['word'])
        self.assertIsNone(report['external_same_matrix_reference'])
        with tempfile.TemporaryDirectory() as directory:
            manifest = Path(directory) / 'manifest.json'
            journal = Path(directory) / 'comparison.jsonl'
            manifest.write_text(json.dumps({'cases': [fixture]}), encoding='utf-8')
            header = {'header': {'checkpoint_sha256': 'test-checkpoint',
                                 'own_manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest()}}
            journal.write_text(json.dumps(header)+'\n'+json.dumps(report)+'\n', encoding='utf-8')
            _, cases, results = summarize(journal, manifest)
            table = markdown_table(header['header'], cases, results)
            self.assertIn('own_tiny_fixture', table)
            self.assertIn('Raw V', table)
            self.assertIn('Neural Qhat', table)
            self.assertIn('Winner', table)
            attributed = json.loads(json.dumps(report))
            attributed['portfolio'] = {'source': 'hamming', 'word': attributed['hamming']['word']}
            table = markdown_table(header['header'], cases, {'own_tiny_fixture': attributed})
            self.assertIn('| Hamming |', next(line for line in table.splitlines()
                                              if line.startswith('| own_tiny_fixture')))
            tampered = json.loads(json.dumps(report))
            tampered['raw_neural']['word']['gates'][0] = [0, 0]
            journal.write_text(json.dumps(header)+'\n'+json.dumps(tampered)+'\n', encoding='utf-8')
            with self.assertRaisesRegex(ValueError, 'invalid serialized gate'):
                summarize(journal, manifest)


if __name__ == '__main__':
    unittest.main()
