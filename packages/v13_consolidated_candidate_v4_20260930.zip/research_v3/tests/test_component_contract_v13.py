import hashlib
from pathlib import Path
import unittest
from research_v3.train.component_contract_v13 import component_contract


class OwnComponent:
    def __init__(self, expected):
        self.expected = expected
    def immutable_contract(self):
        return dict(schema='own_reference_test_v1', config={'seed': 7000},
                    source_sha256={str(Path(__file__).resolve()): self.expected})


class IntegrationContractTests(unittest.TestCase):
    def test_approved_actual_implementation_is_bound_to_config(self):
        source = str(Path(__file__).resolve())
        sha = hashlib.sha256(Path(source).read_bytes()).hexdigest()
        contract = component_contract(OwnComponent(sha), {source: sha})
        self.assertEqual(contract['config'], {'seed': 7000})
        self.assertEqual(contract['source_sha256'], {source: sha})

    def test_unapproved_or_changed_source_is_rejected(self):
        source = str(Path(__file__).resolve())
        with self.assertRaisesRegex(ValueError, 'not approved'):
            component_contract(OwnComponent('0'*64), {})
        with self.assertRaisesRegex(ValueError, 'implementation drift'):
            component_contract(OwnComponent('0'*64), {source: '0'*64})

    def test_missing_immutable_contract_is_rejected(self):
        with self.assertRaisesRegex(ValueError, 'immutable'):
            component_contract(object(), {})


if __name__ == '__main__':
    unittest.main()
