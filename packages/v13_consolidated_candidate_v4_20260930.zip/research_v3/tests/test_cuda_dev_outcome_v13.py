import copy
from dataclasses import asdict, replace
from fractions import Fraction
import unittest
from research_v3.data.stream_solver_dataset_v13 import make_root
from research_v3.train.schedule import selection_key
from research_v3.train.verify_cuda_dev_v13 import dev_outcome_cost


class DevOutcomeTests(unittest.TestCase):
    def fixture(self):
        record, _ = make_root('train', 0, 126, 0, 7000)
        record = replace(record, split='dev')
        search = dict(beam_width=4, shortlist=16, inference_batch=8, max_expanded=1000)
        field = dict(mc_samples=8, mc_seed=17, max_pair_states=10000, head='qhat')
        word = replace(record.verified_words[0], producer='own_raw_neural_dev_v13',
                       lineage_id=record.lineage_id)
        result = dict(raw_search_word=asdict(word), status='solved', physical_cap=20,
                      search_config=search, field_config=field,
                      counts=dict(expanded=3, generated=10, value_evaluations=10))
        return record, result, dict(physical_cap=20, search_config=search, field_config=field)

    def test_full_raw_word_budget_compliance_and_penalties(self):
        record, result, config = self.fixture()
        self.assertEqual(dev_outcome_cost(result, record, **config), record.upper_bound)
        failures = [None]
        for status in ('resource_limit', 'numerical_error', 'interrupted', 'invalid_certificate'):
            bad = copy.deepcopy(result); bad['status'] = status; failures.append(bad)
        bad = copy.deepcopy(result); bad['counts']['expanded'] = 1001; failures.append(bad)
        bad = copy.deepcopy(result); bad['raw_search_word']['producer'] = 'compiler'; failures.append(bad)
        bad = copy.deepcopy(result); bad['raw_search_word']['gates'][0]['target'] = 7; failures.append(bad)
        for bad in failures:
            cost = dev_outcome_cost(bad, record, **config)
            self.assertIsNone(cost)
            key = selection_key({'root': cost}, {'root': record.upper_bound},
                                {'root': 20}, 1., 640, 'a' * 64)
            self.assertEqual(key[:2], (0, Fraction(21, record.upper_bound)))

    def test_changed_decoder_or_cap_invalidates_report_conditions(self):
        record, result, config = self.fixture()
        for field, value in (('physical_cap', 21), ('search_config', {}), ('field_config', {})):
            bad = copy.deepcopy(result); bad[field] = value
            with self.assertRaises(ValueError): dev_outcome_cost(bad, record, **config)


if __name__ == '__main__': unittest.main()
