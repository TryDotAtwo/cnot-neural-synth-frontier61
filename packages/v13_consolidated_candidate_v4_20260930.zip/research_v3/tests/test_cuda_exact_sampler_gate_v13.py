from types import SimpleNamespace
import unittest
from research_v3.data.exact_stream import ExactStreamSampler
from research_v3.data.exact_anchor_sampler_v13 import ExactAnchorSampler, exact_sampler_source_hashes
from research_v3.train.cuda_stream_v13 import require_exact_sampler


class CudaSamplerGateTests(unittest.TestCase):
    def test_missing_sampler_or_gl3_only_diagnostic_cannot_launch_full_schedule(self):
        config = SimpleNamespace(unique_roots_per_epoch=10000, exact_every_roots=100)
        with self.assertRaisesRegex(ValueError, 'complete pinned GL3/GL4'):
            require_exact_sampler(config, None, {}, {})
        small = ExactAnchorSampler(ExactStreamSampler((3,)),
                                   source_sha256=exact_sampler_source_hashes())
        with self.assertRaisesRegex(ValueError, 'complete pinned GL3/GL4'):
            require_exact_sampler(config, small, {}, {})


if __name__ == '__main__': unittest.main()
