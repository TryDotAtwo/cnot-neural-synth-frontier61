import unittest
from research_v3.train.cuda_stream_v13 import checkpoint_events


class CudaScheduleTests(unittest.TestCase):
    def test_dev640_independent_of_snapshot10000_and_final(self):
        target = 10000000
        self.assertEqual(checkpoint_events(639, 639, target, 10000), (False, False))
        self.assertEqual(checkpoint_events(640, 640, target, 10000), (True, True))
        self.assertEqual(checkpoint_events(10000, 10000, target, 10000), (True, False))
        self.assertEqual(checkpoint_events(10240, 10240, target, 10000), (True, True))
        self.assertEqual(checkpoint_events(target, target, target, 10000), (True, True))
        for value in (0, -1, True, 1.5):
            with self.assertRaises(ValueError): checkpoint_events(value, 640, target, 10000)


if __name__ == '__main__': unittest.main()
