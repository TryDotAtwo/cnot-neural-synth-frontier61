from pathlib import Path
import sqlite3
import tempfile
import unittest
from contextlib import closing
from research_v3.train.dev_journal_v13 import DevOutcomeJournal


class DevJournalTests(unittest.TestCase):
    identity = dict(checkpoint_sha='a' * 64, panel_sha='b' * 64,
                    update=640, ordered_keys=('c' * 64, 'd' * 64))

    def test_reopen_preserves_completed_cases_and_measured_retry_cost(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'dev.sqlite'
            journal = DevOutcomeJournal(path, **self.identity)
            first = journal.begin(0)
            journal.finish(first, seconds=2., case={'key': 'c' * 64, 'result': None})
            interrupted = journal.begin(1)
            journal.finish(interrupted, seconds=3.)
            journal.close()
            journal = DevOutcomeJournal(path, **self.identity)
            self.assertEqual(len(journal.cases()), 1)
            second = journal.begin(1)
            journal.finish(second, seconds=5., case={'key': 'd' * 64, 'result': None})
            self.assertEqual(journal.measured_attempt_seconds(), 10.)
            self.assertEqual(len(journal.cases()), 2)
            with self.assertRaises(ValueError): journal.begin(0)
            journal.close()

    def test_open_attempt_is_not_treated_as_dead_or_free(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'dev.sqlite'
            journal = DevOutcomeJournal(path, **self.identity)
            journal.begin(0); journal.close()
            journal = DevOutcomeJournal(path, **self.identity)
            with self.assertRaises(RuntimeError): journal.begin(0)
            with self.assertRaises(RuntimeError): journal.measured_attempt_seconds()
            journal.close()

    def test_identity_drift_and_corrupt_outcome_are_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'dev.sqlite'
            journal = DevOutcomeJournal(path, **self.identity)
            attempt = journal.begin(0)
            with self.assertRaises(ValueError):
                journal.finish(attempt, seconds=2., case={'key': 'd' * 64})
            journal.finish(attempt, seconds=2., case={'key': 'c' * 64})
            journal.close()
            with self.assertRaises(ValueError):
                DevOutcomeJournal(path, **{**self.identity, 'checkpoint_sha': 'e' * 64})
            with closing(sqlite3.connect(path)) as connection:
                with connection:
                    connection.execute("UPDATE outcomes SET raw='{}'")
            with self.assertRaises(ValueError): DevOutcomeJournal(path, **self.identity)

    def test_altered_retry_seconds_and_deleted_history_are_rejected(self):
        for statement in ("UPDATE attempts SET seconds=0", "DELETE FROM attempts"):
            with tempfile.TemporaryDirectory() as temp:
                path = Path(temp) / 'dev.sqlite'
                journal = DevOutcomeJournal(path, **self.identity)
                attempt = journal.begin(0)
                journal.finish(attempt, seconds=3.)
                journal.close()
                with closing(sqlite3.connect(path)) as connection:
                    with connection: connection.execute(statement)
                with self.assertRaises(ValueError): DevOutcomeJournal(path, **self.identity)

    def test_deleted_completed_outcome_is_not_retried(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'dev.sqlite'
            journal = DevOutcomeJournal(path, **self.identity)
            attempt = journal.begin(0)
            journal.finish(attempt, seconds=2., case={'key': 'c' * 64})
            journal.close()
            with closing(sqlite3.connect(path)) as connection:
                with connection: connection.execute('DELETE FROM outcomes')
            with self.assertRaises(ValueError): DevOutcomeJournal(path, **self.identity)


if __name__ == '__main__': unittest.main()
