import tempfile
from pathlib import Path
from dataclasses import replace
import unittest
from research_v3.tests.test_replay_refresh_v13 import OwnSolver, ReplayRefreshTests
from research_v3.train.disk_replay_refresh_v13 import DiskReplayRefresh


class DiskRefreshTests(unittest.TestCase):
    def test_improvement_resume_and_whole_batch_failure_rollback(self):
        record = ReplayRefreshTests().fixture()
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'journal.sqlite'
            refresh = DiskReplayRefresh(OwnSolver(), journal_path=path,
                                       every_updates=2, source_sha256={})
            self.assertEqual(refresh((record,), 2)[0].upper_bound, 1)
            checkpoint = refresh.state_dict()
            self.assertNotIn('records', checkpoint)
            self.assertEqual(refresh.replays, {})
            self.assertEqual(refresh.events, [])
            with self.assertRaises(ValueError):
                refresh((replace(record, lineage_id='train:new'),
                         replace(record, split='test')), 4)
            self.assertEqual(refresh.state_dict(), checkpoint)
            refresh.close()
            restored = DiskReplayRefresh(OwnSolver(), journal_path=path,
                                        every_updates=2, source_sha256={})
            restored.load_state_dict(checkpoint)
            self.assertEqual(restored((record,), 3)[0].upper_bound, 1)
            self.assertEqual(restored.solver.calls, 1)
            restored.close()


if __name__ == '__main__': unittest.main()
