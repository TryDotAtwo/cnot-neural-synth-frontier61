import os
import unittest
import torch
from research_v3.gpu.holdout import GpuExactHoldout, admit_complete_neighborhood
from research_v3.gpu.packed_walk import identity_rows


class ProjectionContractTests(unittest.TestCase):
    def test_invalid_width_or_cpu_bank_cannot_disable_cuda_admission(self):
        for n in (1, 257, True, 3.5):
            with self.assertRaises(ValueError): GpuExactHoldout.empty_projection(n)
        with self.assertRaises(ValueError): GpuExactHoldout.empty_projection(3, device='cpu')


@unittest.skipUnless(os.environ.get('MOLAB_TEST_CUDA') == '1' and torch.cuda.is_available(),
                     'explicit Molab CUDA gate')
class ProjectionCudaTests(unittest.TestCase):
    def test_empty_projection_keeps_complete_neighbor_and_dimension_checks(self):
        for n in (3, 4):
            bank = GpuExactHoldout.empty_projection(n)
            rows = identity_rows(1, n, device='cuda')
            self.assertFalse(bank.matches(rows).any().item())
            self.assertEqual(admit_complete_neighborhood(bank, rows, chunk_size=6),
                             1 + n * (n - 1))
            with self.assertRaises(ValueError):
                bank.matches(identity_rows(1, n + 1, device='cuda'))


if __name__ == '__main__': unittest.main()
