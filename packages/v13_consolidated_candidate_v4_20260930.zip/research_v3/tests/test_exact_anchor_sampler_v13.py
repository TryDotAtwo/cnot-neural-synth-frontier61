from dataclasses import FrozenInstanceError
import unittest
from research_v3.data.exact_stream import ExactStreamSampler
from research_v3.data.exact_anchor_sampler_v13 import ExactAnchorSampler, exact_sampler_source_hashes


class ExactSamplerTests(unittest.TestCase):
    def test_runner_component_contract_checks_actual_implementation_source(self):
        from research_v3.train.component_contract_v13 import component_contract
        sources = exact_sampler_source_hashes()
        adapter = ExactAnchorSampler(ExactStreamSampler((3,)), source_sha256=sources)
        contract = component_contract(adapter, sources)
        self.assertEqual(contract['config']['position_stride'], 10000)
        self.assertEqual(contract['source_sha256'], sources)
        with self.assertRaisesRegex(ValueError, 'not approved'):
            component_contract(adapter, {})

    def test_reference_schedule_and_resume_identity(self):
        reference = ExactStreamSampler((3,))
        sources = exact_sampler_source_hashes()
        adapter = ExactAnchorSampler(reference, source_sha256=sources)
        for epoch, position in ((0, 99), (0, 9999), (1, 99), (999, 9999)):
            self.assertEqual(adapter.record(epoch, position), reference.record(epoch, position))
        state = adapter.state_dict()
        restored = ExactAnchorSampler(reference, source_sha256=sources)
        restored.load_state_dict(state)
        self.assertEqual(restored.record(1, 99), adapter.record(1, 99))
        changed = {**state, 'contract_sha256': 'b' * 64}
        with self.assertRaises(ValueError): restored.load_state_dict(changed)
        with self.assertRaises(FrozenInstanceError): adapter.sizes = (4,)
        with self.assertRaises(TypeError): adapter.catalog_hashes[3] = 'forged'

    def test_bad_cursor_and_source_manifest(self):
        reference = ExactStreamSampler((3,))
        with self.assertRaises(ValueError): ExactAnchorSampler(reference, source_sha256={})
        sources = exact_sampler_source_hashes()
        for path in sources:
            with self.assertRaisesRegex(ValueError, 'source closure'):
                ExactAnchorSampler(reference, source_sha256={k: v for k, v in sources.items() if k != path})
            with self.assertRaisesRegex(ValueError, 'source closure'):
                ExactAnchorSampler(reference, source_sha256={**sources, path: '0' * 64})
        adapter = ExactAnchorSampler(reference, source_sha256=sources)
        for epoch, position in ((True, 1), (0, True), (-1, 1), (0, -1), (0, 10000)):
            with self.assertRaises(ValueError): adapter.record(epoch, position)


if __name__ == '__main__': unittest.main()
