import unittest
import torch
from research_v3.gpu.joint_records_v13 import exact_root_loss


class ExactRootLossTests(unittest.TestCase):
    def test_unknown_upper_bound_is_not_exact_supervision(self):
        values = torch.tensor([4., 99., 2.], requires_grad=True)
        loss = exact_root_loss(values, (3, None, 2))
        self.assertAlmostEqual(loss.item(), 1 / 6)
        loss.backward()
        torch.testing.assert_close(values.grad, torch.tensor([1 / 3, 0., 0.]))

    def test_matches_per_record_reference_with_sparse_exact_labels(self):
        labels = (3, None, 2, None)
        values = torch.tensor([4., 99., 0., -9.], requires_grad=True)
        actual = exact_root_loss(values, labels)
        reference = torch.stack([
            value * 0 if label is None else torch.nn.functional.smooth_l1_loss(
                value, value.new_tensor(label))
            for value, label in zip(values, labels)]).mean()
        torch.testing.assert_close(actual, reference)
        torch.testing.assert_close(torch.autograd.grad(actual, values)[0],
                                   torch.autograd.grad(reference, values)[0])

    def test_no_exact_roots_preserves_graph_with_zero_gradient(self):
        values = torch.tensor([19., 3.], requires_grad=True)
        loss = exact_root_loss(values, (None, None))
        loss.backward()
        self.assertEqual(loss.item(), 0.)
        self.assertEqual(values.grad.tolist(), [0., 0.])

    def test_bad_labels_are_rejected(self):
        for label in (-1, True, 1.5):
            with self.assertRaises(ValueError):
                exact_root_loss(torch.tensor([1.]), (label,))


if __name__ == '__main__':
    unittest.main()
