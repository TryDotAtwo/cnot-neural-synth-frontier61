import unittest

from research_v3.data.exact_stream import ExactStreamSampler


class ExactStreamTests(unittest.TestCase):
    def test_complete_catalog_records_remain_exact_anchors(self):
        sampler = ExactStreamSampler()
        self.assertEqual(len(sampler.catalogs['all_to_all_unit_cnot:3'].distances), 168)
        self.assertEqual(len(sampler.catalogs['all_to_all_unit_cnot:4'].distances), 20160)
        first, second = sampler.record(0, 0), sampler.record(0, 1)
        self.assertEqual((first.state.n, second.state.n), (3, 4))
        for record in (first, second):
            self.assertEqual(record.split, 'train')
            self.assertEqual(record.exact_distance, record.upper_bound)
            self.assertTrue(record.exact_evidence.startswith('closed_lipschitz_and_full_words:'))
            self.assertGreater(record.exact_distance, 0)


if __name__ == '__main__':
    unittest.main()
