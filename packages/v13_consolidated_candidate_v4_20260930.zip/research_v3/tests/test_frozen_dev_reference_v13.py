from dataclasses import replace
import unittest
from research_v3.data.stream_solver_dataset_v13 import make_root
from research_v3.train.frozen_dev_panel_v13 import freeze_dev_reference, FrozenDevPanel


class FrozenDevReferenceTests(unittest.TestCase):
    def test_record_and_cap_changes_have_distinct_frozen_identity(self):
        record, _ = make_root('train', 0, 126, 0, 7000)
        dev = replace(record, split='dev')
        first = freeze_dev_reference(dev, 20)
        changed_cap = freeze_dev_reference(dev, 21)
        self.assertNotEqual(first, changed_cap)
        changed_lineage = freeze_dev_reference(replace(dev, lineage_id='other-dev-lineage'), 20)
        self.assertNotEqual(first['record_sha256'], changed_lineage['record_sha256'])
        self.assertEqual(first['reference_UB'], dev.upper_bound)
        with self.assertRaises(ValueError): freeze_dev_reference(record, 20)
        for cap in (0, True, 2.5):
            with self.assertRaises(ValueError): freeze_dev_reference(dev, cap)

    def test_short_panel_cannot_become_full_training_dev_contract(self):
        record, _ = make_root('train', 0, 126, 0, 7000)
        with self.assertRaisesRegex(ValueError, '1792'):
            FrozenDevPanel((replace(record, split='dev'),), search_config={},
                           field_config={}, cap_multiplier=2, holdout_seal_sha256='a' * 64)


if __name__ == '__main__': unittest.main()
