from types import SimpleNamespace

import pytest
import torch

from research_v3.basis.proposal import BasisProposal
from research_v3.basis.templates import BasisChoice, BasisTemplate
from research_v3.gpu.basis_proposer import (batched_basis_proposal,
                                            sample_ordered_source_pairs)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_cuda_choice_sampler_is_replayable_and_without_replacement():
    device = torch.device('cuda')
    first = torch.Generator(device=device).manual_seed(3211)
    second = torch.Generator(device=device).manual_seed(3211)
    pairs = sample_ordered_source_pairs(16, 8, 12,
                                        generator=first, device=device)
    repeat = sample_ordered_source_pairs(16, 8, 12,
                                         generator=second, device=device)
    assert torch.equal(pairs, repeat)
    ids = pairs[:, :, 0] * 7 + pairs[:, :, 1] - \
          (pairs[:, :, 1] > pairs[:, :, 0]).to(torch.int64)
    assert bool((pairs[:, :, 0] != pairs[:, :, 1]).all().item())
    assert bool((torch.sort(ids, dim=1).values[:, 1:] !=
                 torch.sort(ids, dim=1).values[:, :-1]).all().item())


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_cuda_batched_proposer_matches_existing_one_root_template():
    torch.manual_seed(3221)
    model = BasisProposal(16, 32).cuda()
    wire = torch.randn((1, 8, 16), device='cuda', requires_grad=True)
    encoded = SimpleNamespace(wire=wire, valid=torch.ones((1, 8),
                                                           device='cuda', dtype=torch.bool))
    choices = ((0, 1), (2, 0), (1, 3))
    pairs = torch.tensor([choices], device='cuda', dtype=torch.int64)
    template = BasisTemplate(8, tuple(range(4)), tuple(range(4, 8)),
                             'source', tuple(BasisChoice('add', *pair)
                                             for pair in choices))
    expected = model(encoded, template)
    actual = batched_basis_proposal(model, encoded, pairs, source_width=4)[0]
    torch.testing.assert_close(actual, expected, atol=1e-6, rtol=1e-6)
    actual.sum().backward()
    assert wire.grad is not None and bool((wire.grad != 0).any().item())
