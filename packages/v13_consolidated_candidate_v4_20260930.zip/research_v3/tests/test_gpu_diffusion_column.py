import numpy as np
import pytest
import torch

from research_v3.contracts import AlphabetSpec, MatrixState
from research_v3.features.diffusion import register_diffusion
from research_v3.features.registry import FeaturePolicy, FeatureRegistry
from research_v3.gpu.diffusion_column import column_generator, g01_column_heat
from research_v3.gpu.packed_walk import generate_walk_batch, identity_rows


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
@pytest.mark.parametrize('n', (5, 8, 26, 72, 144))
def test_cuda_g01_matches_cpu_semigroup_reference(n):
    walk = generate_walk_batch(n, 2, 15, 3059)
    rows = torch.cat((walk.rows, identity_rows(1, n)), dim=0)
    actual = g01_column_heat(rows)
    registry = FeatureRegistry()
    register_diffusion(registry, mc_samples=8)
    states = []
    for words_by_row in rows.cpu().tolist():
        unpacked = tuple(sum((word & ((1 << 64) - 1)) << (64 * slot)
                             for slot, word in enumerate(words)) for words in words_by_row)
        states.append(MatrixState(n, unpacked, AlphabetSpec.all_to_all(n).id))
    reference = registry.build(states, FeaturePolicy(('G01',)))
    np.testing.assert_allclose(actual.cpu().numpy(),
                               reference.features['G01'].values,
                               rtol=2e-5, atol=1e-5)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_cuda_column_generator_conserves_rate_and_stationary():
    generator, log_size = column_generator(8, torch.device('cuda'))
    assert torch.allclose(generator.sum(dim=1), torch.zeros(15, device='cuda',
                                                           dtype=torch.float64), atol=1e-12)
    stationary = log_size.exp()
    stationary = stationary / stationary.sum()
    assert torch.allclose(generator.T @ stationary,
                          torch.zeros_like(stationary), atol=1e-12)
