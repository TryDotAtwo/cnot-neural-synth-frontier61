import numpy as np
import pytest
import torch

from research_v3.contracts import AlphabetSpec, MatrixState
from research_v3.features.diffusion import register_diffusion
from research_v3.features.registry import FeaturePolicy, FeatureRegistry
from research_v3.gpu.diffusion_exact import g05_pair_histogram
from research_v3.gpu.packed_walk import generate_walk_batch, identity_rows


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
@pytest.mark.parametrize('n', (8, 72, 144))
def test_cuda_g05_matches_registered_cpu_producer(n):
    generated = generate_walk_batch(n, 2, 31, 2999)
    rows = torch.cat((generated.rows, identity_rows(1, n)), dim=0)
    actual = g05_pair_histogram(rows)
    registry = FeatureRegistry()
    register_diffusion(registry, max_pair_states=10000, mc_samples=8)
    states = []
    for words_by_row in rows.cpu().tolist():
        unpacked = tuple(sum((word & ((1 << 64) - 1)) << (64 * slot)
                             for slot, word in enumerate(words)) for words in words_by_row)
        states.append(MatrixState(n, unpacked, AlphabetSpec.all_to_all(n).id))
    expected = registry.build(states, FeaturePolicy(('G05',)))
    np.testing.assert_array_equal(actual.cpu().numpy(), expected.features['G05'].values)
