import numpy as np
import pytest
import torch

from research_v3.gpu.diffusion_mc import (SELECTED_MC_G,
                                          joint_moments_from_samples,
                                          shared_word_mc_features)
from research_v3.gpu.packed_walk import (apply_gates, generate_walk_batch,
                                         identity_rows)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_cuda_shared_word_monte_carlo_replays_every_sample():
    roots = generate_walk_batch(8, 2, 9, 3019).rows
    probes = shared_word_mc_features(roots, samples=8, tau=1.0, seed=3023)
    assert set(probes.features) == set(SELECTED_MC_G)
    starts = roots.repeat_interleave(8, dim=0)
    replay = apply_gates(starts, probes.controls.reshape(16, -1),
                         probes.targets.reshape(16, -1),
                         probes.lengths.reshape(16))
    assert torch.equal(replay.reshape_as(probes.sampled_rows),
                       probes.sampled_rows)
    assert all(torch.isfinite(value).all() for value in probes.features.values())
    repeat = shared_word_mc_features(roots, samples=8, tau=1.0, seed=3023)
    assert torch.equal(probes.sampled_rows, repeat.sampled_rows)
    assert torch.equal(probes.controls[0], probes.controls[1])
    assert torch.equal(probes.targets[0], probes.targets[1])
    assert torch.equal(probes.lengths[0], probes.lengths[1])
    alone = shared_word_mc_features(roots[:1], samples=8, tau=1.0, seed=3023)
    assert torch.equal(probes.sampled_rows[:1], alone.sampled_rows)
    for key in SELECTED_MC_G:
        assert torch.equal(probes.features[key][:1], alone.features[key])


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_cuda_moments_match_independent_numpy_sample_statistics():
    probes = shared_word_mc_features(identity_rows(1, 5), samples=16,
                                     tau=0.8, seed=3037)
    result = joint_moments_from_samples(probes.sampled_rows,
                                        probes.lengths, tau=0.8)
    packed = probes.sampled_rows[0, :, :, 0].cpu().numpy().astype(np.uint64)
    bits = np.stack([((packed >> np.uint64(c)) & 1).astype(np.float64)
                     for c in range(5)], axis=-1)
    weight = bits.sum(axis=1)
    intersections = np.einsum('src,srd->scd', bits, bits)
    xor = weight[:, :, None] + weight[:, None, :] - 2 * intersections
    character = 1 - 2 * (weight % 2)
    cp = character[:, :, None] * character[:, None, :]
    covariance = np.cov(weight, rowvar=False, ddof=1)
    center_weight = weight - weight.mean(axis=0)
    center_intersection = intersections - intersections.mean(axis=0)
    center_xor = xor - xor.mean(axis=0)
    cov_w_intersection = np.einsum('sc,scd->cd', center_weight,
                                   center_intersection) / 15
    cov_w_xor = np.einsum('sc,scd->cd', center_weight, center_xor) / 15
    expected_g08 = np.stack((covariance, intersections.mean(axis=0),
                             xor.mean(axis=0), cov_w_intersection,
                             cov_w_xor), axis=-1)
    expected_g09 = np.stack((cp.mean(axis=0),
                             cp.mean(axis=0) -
                             character.mean(axis=0)[:, None] *
                             character.mean(axis=0)[None, :]), axis=-1)
    np.testing.assert_allclose(result['G07'][0].cpu().numpy(),
                               weight.mean(axis=0)[:, None], atol=1e-6)
    np.testing.assert_allclose(result['G08'][0].cpu().numpy(),
                               expected_g08, atol=1e-6)
    np.testing.assert_allclose(result['G09'][0].cpu().numpy(),
                               expected_g09, atol=1e-6)
    g10 = result['G10'][0].cpu().numpy()
    np.testing.assert_allclose(g10[:, :, 0],
                               intersections.std(axis=0, ddof=1) / 4, atol=1e-6)
    np.testing.assert_allclose(g10[:, :, 1],
                               xor.std(axis=0, ddof=1) / 4, atol=1e-6)
    np.testing.assert_allclose(g10[:, :, 2],
                               cp.std(axis=0, ddof=1) / 4, atol=1e-6)
    assert np.all(g10[:, :, 4] == 16)
    assert np.all(g10[:, :, 5] == float(probes.lengths.sum()) / 16)
    assert np.all(g10[:, :, 6] == np.float32(0.8))
