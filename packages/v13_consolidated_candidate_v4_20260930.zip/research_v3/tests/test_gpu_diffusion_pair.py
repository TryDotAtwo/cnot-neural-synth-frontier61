import numpy as np
import pytest
import torch

from research_v3.contracts import AlphabetSpec, MatrixState
from research_v3.features.diffusion import register_diffusion
from research_v3.features.registry import FeaturePolicy, FeatureRegistry
from research_v3.gpu.diffusion_pair import g06_pair_heat
from research_v3.gpu.packed_walk import generate_walk_batch, identity_rows


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
@pytest.mark.parametrize('n', (3, 8, 26))
def test_cuda_g06_matches_registered_cpu_pair_profile(n):
    walk = generate_walk_batch(n, 1, 17, 3109)
    rows = torch.cat((walk.rows, identity_rows(1, n)), dim=0)
    actual = g06_pair_heat(rows)
    assert bool(actual.available.all().item())
    registry = FeatureRegistry()
    register_diffusion(registry, max_pair_states=10000, mc_samples=8)
    states = []
    for words_by_row in rows.cpu().tolist():
        unpacked = tuple(sum((word & ((1 << 64) - 1)) << (64 * slot)
                             for slot, word in enumerate(words)) for words in words_by_row)
        states.append(MatrixState(n, unpacked, AlphabetSpec.all_to_all(n).id))
    reference = registry.build(states, FeaturePolicy(('G06',)))
    np.testing.assert_allclose(actual.values.cpu().numpy(),
                               reference.features['G06'].values,
                               rtol=3e-5, atol=2e-5)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_cuda_g06_respects_reference_state_cap():
    rows = identity_rows(2, 72)
    result = g06_pair_heat(rows, max_states=10000)
    assert result.class_count > 10000
    assert not bool(result.available.any().item())
    assert not bool(result.values.any().item())
