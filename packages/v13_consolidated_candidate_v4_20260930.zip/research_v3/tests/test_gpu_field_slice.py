import pytest
import torch

from research_v3.features.registry import FeatureRegistry
from research_v3.gpu.field_slice import (complete_bellman_slice,
                                         gpu_field_value, gpu_qhat_loss)
from research_v3.gpu.neighbors import primitive_neighbor_chunks
from research_v3.gpu.packed_walk import apply_gates, generate_walk_batch, identity_rows
from research_v3.gpu.paid_shear import compile_paid_shear, verify_paid_shear
from research_v3.gpu.structural_a import ALL_A, SELECTED_A
from research_v3.gpu.structural_b import SELECTED_BF
from research_v3.gpu.structural_cdh import SELECTED_CDH
from research_v3.gpu.structural_e import SELECTED_E
from research_v3.gpu.diffusion_mc import SELECTED_MC_G
from research_v3.model.field import FusionDistanceField


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_complete_cuda_bellman_slice_backpropagates():
    rows = generate_walk_batch(8, 2, 11, 2749).rows
    registry = FeatureRegistry()
    model = FusionDistanceField([registry.specs[key] for key in SELECTED_A],
                                d=64, pair_d=16, blocks=1, heads=4, ffn=128,
                                fusion_blocks=1).cuda().train()
    loss, audit = complete_bellman_slice(model, rows, action_chunk=7)
    assert audit['candidate_actions_per_root'] == 56
    assert torch.isfinite(loss)
    loss.backward()
    assert any(parameter.grad is not None and
               bool((parameter.grad != 0).any().item())
               for parameter in model.parameters())


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_cuda_paid_basis_to_full_graph_gradient_slice():
    block = torch.zeros((2, 4, 4), device='cuda', dtype=torch.bool)
    block[:, :, 0:2] = True  # Shared parity makes a paid basis step profitable.
    block[:, 0, 2] = True
    source = torch.arange(4, device='cuda')
    target = torch.arange(4, 8, device='cuda')
    word = compile_paid_shear(block, source, target, max_preparation=8)
    assert bool((word.preparation_lengths > 0).all().item())
    assert bool(verify_paid_shear(block, source, target, word, n=8).all().item())
    rows = apply_gates(identity_rows(2, 8), word.controls, word.targets,
                       word.lengths)
    registry = FeatureRegistry()
    model = FusionDistanceField([registry.specs[key] for key in SELECTED_A],
                                d=64, pair_d=16, blocks=1, heads=4, ffn=128,
                                fusion_blocks=1).cuda().train()
    loss, audit = complete_bellman_slice(model, rows, action_chunk=8)
    assert audit['candidate_actions_per_root'] == 56
    loss.backward()
    assert torch.isfinite(loss)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_complete_a_family_enters_field_and_full_bellman_graph():
    rows = generate_walk_batch(8, 1, 9, 2867).rows
    registry = FeatureRegistry()
    model = FusionDistanceField([registry.specs[key] for key in ALL_A],
                                d=64, pair_d=16, blocks=1, heads=4, ffn=128,
                                fusion_blocks=1).cuda().train()
    loss, audit = complete_bellman_slice(model, rows, action_chunk=8)
    assert audit['features'] == ALL_A + SELECTED_BF + SELECTED_CDH + SELECTED_E + ('G05',)
    assert audit['candidate_actions_per_root'] == 56
    loss.backward()
    assert torch.isfinite(loss)
    assert all(model.stem.projections[key].weight.grad is not None
               for key in ALL_A)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_selected_bf_features_enter_field_and_full_bellman_graph():
    rows = generate_walk_batch(8, 1, 11, 2897).rows
    registry = FeatureRegistry()
    specs = [registry.specs[key] for key in ALL_A + SELECTED_BF]
    model = FusionDistanceField(specs, d=64, pair_d=16, blocks=1,
                                heads=4, ffn=128, fusion_blocks=1).cuda().train()
    loss, audit = complete_bellman_slice(model, rows, action_chunk=8)
    assert audit['candidate_actions_per_root'] == 56
    loss.backward()
    assert torch.isfinite(loss)
    assert all(model.stem.projections[key].weight.grad is not None
               for key in ALL_A + SELECTED_BF)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_selected_cdh_features_enter_field_and_full_bellman_graph():
    rows = generate_walk_batch(8, 1, 11, 2917).rows
    registry = FeatureRegistry()
    from research_v3.features.subspace_views import register_subspace_views
    register_subspace_views(registry)
    keys = ALL_A + SELECTED_BF + SELECTED_CDH
    model = FusionDistanceField([registry.specs[key] for key in keys],
                                d=64, pair_d=16, blocks=1, heads=4,
                                ffn=128, fusion_blocks=1).cuda().train()
    loss, audit = complete_bellman_slice(model, rows, action_chunk=8)
    assert audit['candidate_actions_per_root'] == 56
    loss.backward()
    assert torch.isfinite(loss)
    assert all(model.stem.projections[key].weight.grad is not None
               for key in keys)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_selected_e_features_enter_field_and_full_bellman_graph():
    rows = generate_walk_batch(8, 1, 11, 2969).rows
    registry = FeatureRegistry()
    from research_v3.features.subspace_views import register_subspace_views
    from research_v3.features.basis_gradient import register_basis_gradient
    register_subspace_views(registry)
    register_basis_gradient(registry)
    keys = ALL_A + SELECTED_BF + SELECTED_CDH + SELECTED_E
    model = FusionDistanceField([registry.specs[key] for key in keys],
                                d=64, pair_d=16, blocks=1, heads=4,
                                ffn=128, fusion_blocks=1).cuda().train()
    loss, audit = complete_bellman_slice(model, rows, action_chunk=8)
    assert audit['candidate_actions_per_root'] == 56
    loss.backward()
    assert torch.isfinite(loss)
    assert all(model.stem.projections[key].weight.grad is not None
               for key in keys)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_exact_g05_enters_field_and_full_bellman_graph():
    rows = generate_walk_batch(8, 1, 11, 3001).rows
    registry = FeatureRegistry()
    from research_v3.features.diffusion import register_diffusion
    register_diffusion(registry, mc_samples=8)
    model = FusionDistanceField([registry.specs['G05']], d=64, pair_d=16,
                                blocks=1, heads=4, ffn=128, fusion_blocks=1).cuda().train()
    loss, audit = complete_bellman_slice(model, rows, action_chunk=8)
    assert audit['candidate_actions_per_root'] == 56
    loss.backward()
    assert torch.isfinite(loss)
    assert model.stem.projections['G05'].weight.grad is not None


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_shared_word_g_moments_enter_field_and_full_bellman_graph():
    rows = generate_walk_batch(5, 1, 7, 3049).rows
    registry = FeatureRegistry()
    from research_v3.features.diffusion import register_diffusion
    register_diffusion(registry, mc_samples=8)
    model = FusionDistanceField([registry.specs[key] for key in SELECTED_MC_G],
                                d=64, pair_d=16, blocks=1, heads=4,
                                ffn=128, fusion_blocks=1).cuda().train()
    loss, audit = complete_bellman_slice(model, rows, action_chunk=5,
                                         mc_samples=8, mc_seed=3049)
    assert audit['candidate_actions_per_root'] == 20
    assert all(key in audit['features'] for key in SELECTED_MC_G)
    loss.backward()
    assert torch.isfinite(loss)
    assert all(model.stem.projections[key].weight.grad is not None
               for key in SELECTED_MC_G)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_column_heat_g01_enters_field_and_full_bellman_graph():
    rows = generate_walk_batch(5, 1, 7, 3089).rows
    registry = FeatureRegistry()
    from research_v3.features.diffusion import register_diffusion
    register_diffusion(registry, mc_samples=8)
    model = FusionDistanceField([registry.specs['G01']], d=64, pair_d=16,
                                blocks=1, heads=4, ffn=128, fusion_blocks=1).cuda().train()
    loss, audit = complete_bellman_slice(model, rows, action_chunk=5)
    assert audit['candidate_actions_per_root'] == 20
    assert 'G01' in audit['features']
    loss.backward()
    assert torch.isfinite(loss)
    assert model.stem.projections['G01'].weight.grad is not None


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_pair_heat_g06_enters_field_and_full_bellman_graph():
    rows = generate_walk_batch(5, 1, 7, 3121).rows
    registry = FeatureRegistry()
    from research_v3.features.diffusion import register_diffusion
    register_diffusion(registry, mc_samples=8, max_pair_states=10000)
    model = FusionDistanceField([registry.specs['G06']], d=64, pair_d=16,
                                blocks=1, heads=4, ffn=128, fusion_blocks=1).cuda().train()
    loss, audit = complete_bellman_slice(model, rows, action_chunk=5)
    assert audit['candidate_actions_per_root'] == 20
    assert 'G06' in audit['features']
    loss.backward()
    assert torch.isfinite(loss)
    assert model.stem.projections['G06'].weight.grad is not None


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_shared_word_bellman_target_is_chunk_invariant():
    rows = generate_walk_batch(5, 1, 7, 3131).rows
    registry = FeatureRegistry()
    from research_v3.features.diffusion import register_diffusion
    register_diffusion(registry, mc_samples=8)
    model = FusionDistanceField([registry.specs['G07']], d=64, pair_d=16,
                                blocks=1, heads=4, ffn=128, fusion_blocks=1).cuda().eval()
    _, small = complete_bellman_slice(model, rows, action_chunk=1,
                                      mc_samples=8, mc_seed=3131)
    _, large = complete_bellman_slice(model, rows, action_chunk=5,
                                      mc_samples=8, mc_seed=3131)
    torch.testing.assert_close(small['bellman_target'], large['bellman_target'],
                               atol=1e-5, rtol=1e-5)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_gpu_bellman_matches_full_action_oracle_and_selected_child_gradient():
    from torch.nn import functional as F

    identity = identity_rows(1, 4)
    parent = apply_gates(identity,
                         torch.tensor([[0, 1]], device='cuda'),
                         torch.tensor([[1, 2]], device='cuda'),
                         torch.tensor([2], device='cuda'))
    rows = torch.cat((parent, identity), dim=0)
    registry = FeatureRegistry()
    model = FusionDistanceField([registry.specs['A01']], d=32, pair_d=8,
                                blocks=1, heads=4, ffn=64,
                                fusion_blocks=1).cuda().eval()

    actual, audit = complete_bellman_slice(model, rows, action_chunk=3)
    actual.backward()
    actual_grad = {name: parameter.grad.detach().clone()
                   for name, parameter in model.named_parameters()
                   if parameter.grad is not None}
    model.zero_grad(set_to_none=True)

    # Separate all-at-once oracle: selection is frozen, then V is recomputed
    # on the chosen successor with an intact autograd edge.
    full = next(primitive_neighbor_chunks(rows, 12)).rows
    with torch.no_grad():
        totals = 1 + gpu_field_value(model, full.reshape(24, 4, 1)).reshape(2, 12)
        chosen = totals.argmin(dim=1)
    selected_rows = full[torch.arange(2, device='cuda'), chosen]
    parent_value = gpu_field_value(model, rows)
    child_value = gpu_field_value(model, selected_rows)
    residual = torch.stack((parent_value[0] - 1 - child_value[0],
                            parent_value[1]))
    expected = F.smooth_l1_loss(residual, torch.zeros_like(residual))
    expected.backward()

    torch.testing.assert_close(actual.detach(), expected.detach(), atol=1e-6, rtol=1e-6)
    torch.testing.assert_close(audit['primitive_totals'], totals, atol=1e-6, rtol=1e-6)
    assert audit['selected_action_ids'].tolist() == [int(chosen[0].item()), -1]
    assert audit['terminal'].tolist() == [False, True]
    for name, parameter in model.named_parameters():
        if name in actual_grad:
            torch.testing.assert_close(actual_grad[name], parameter.grad,
                                       atol=1e-5, rtol=1e-5)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_gpu_absolute_qhat_uses_every_action_and_identity_successor_target():
    identity = identity_rows(1, 4)
    parent = apply_gates(identity,
                         torch.tensor([[0]], device='cuda'),
                         torch.tensor([[1]], device='cuda'),
                         torch.tensor([1], device='cuda'))
    registry = FeatureRegistry()
    model = FusionDistanceField([registry.specs['A01']], d=32, pair_d=8,
                                blocks=1, heads=4, ffn=64,
                                fusion_blocks=1).cuda().eval()
    _, audit = complete_bellman_slice(model, parent, action_chunk=3)
    assert audit['primitive_totals'].shape == (1, 12)
    # Control 0 / target 1 is first in the CNOT alphabet and undoes the word.
    torch.testing.assert_close(audit['primitive_totals'][0, 0],
                               torch.tensor(1., device='cuda'))
    qloss = gpu_qhat_loss(model, parent, audit['primitive_totals'])
    assert torch.isfinite(qloss)
    qloss.backward()
    assert any(parameter.grad is not None and
               bool((parameter.grad != 0).any().item())
               for parameter in model.auxiliary.qhat.parameters())
