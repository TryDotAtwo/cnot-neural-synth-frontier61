import pytest

from research_v3.gpu.frozen_bank import _historical_hashes_by_input
from research_v3.gpu.frozen_bank import _portable_historical_states
from research_v3.data.frozen import historical_states
from pathlib import Path


def test_historical_source_hashes_are_portable_across_hosts():
    windows = {r'D:\Lean4\TheQuantumProject\synthesis-methods\01_shared_basis_stage17\source_snapshot\inputs\hgp13.json': 'abc'}
    linux = {'/work/01_shared_basis_stage17/source_snapshot/inputs/hgp13.json': 'abc'}
    assert _historical_hashes_by_input(windows) == _historical_hashes_by_input(linux)
    with pytest.raises(ValueError, match='ambiguous'):
        _historical_hashes_by_input({'/tmp/untrusted.json': 'abc'})


def test_portable_historical_loader_preserves_pinned_own_matrices():
    root = Path(__file__).resolve().parents[3]
    portable_states, portable_sources = _portable_historical_states(root)
    original_states, original_sources = historical_states(root)
    assert portable_states == original_states
    assert portable_sources == original_sources
