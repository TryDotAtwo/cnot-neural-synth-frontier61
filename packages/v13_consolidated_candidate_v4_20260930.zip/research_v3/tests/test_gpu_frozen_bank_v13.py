"""CPU admission gates must fail before CUDA tensors are allocated."""
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from research_v3.gpu import frozen_bank_v13 as bank


class FrozenBankVersionGates(unittest.TestCase):
    def rejected_manifest(self, schema, dataset_hashes):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'holdout.sqlite'
            db = sqlite3.connect(path)
            db.execute('CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT)')
            manifest = dict(schema=schema, compiler_source_sha256={'own': 'compiler'},
                            dataset_source_sha256=dataset_hashes,
                            expected_dev_roots=1, expected_test_roots=1)
            seal = dict(dev_roots=1, test_roots=1)
            db.executemany('INSERT INTO metadata VALUES(?,?)',
                           [('manifest', json.dumps(manifest)),
                            ('holdout_seal', json.dumps(seal))])
            db.commit()
            db.close()
            original = path.read_bytes()
            with patch.object(bank.torch.cuda, 'is_available', return_value=True), \
                 patch.object(bank, 'source_hashes', return_value={'own': 'compiler'}), \
                 patch.object(bank, 'data_source_hashes', return_value={'v13': 'source'}), \
                 patch.object(bank, '_pack_states') as allocate:
                with self.assertRaisesRegex(ValueError, 'manifest drift'):
                    bank.load_sealed_own_banks(path, Path(directory),
                                              neighbor_chunk=2,
                                              max_entries_per_width=100)
                allocate.assert_not_called()
            self.assertEqual(path.read_bytes(), original)

    def test_legacy_schema_rejected_before_allocation(self):
        self.rejected_manifest('own_solver_stream_v5', {'v13': 'source'})

    def test_legacy_source_hashes_rejected_before_allocation(self):
        self.rejected_manifest(bank.SCHEMA, {'v5': 'old-source'})

    def test_zero_excess_uses_versioned_exact_reader(self):
        from dataclasses import replace, asdict
        from research_v3.data.stream_solver_dataset_v13 import make_root
        from research_v3.data.stream_reader_v13 import decode_record
        self.assertIs(bank.decode_record, decode_record)
        record, _ = make_root('dev', 0, 126, 0, 7000)
        self.assertEqual(record.source, 'stage37_zero_excess_exact_v1')
        def record_json(value):
            return json.dumps(asdict(value))
        self.assertEqual(bank.decode_record(record_json(record)).exact_distance,
                         record.exact_distance)
        with self.assertRaises(ValueError):
            bank.decode_record(record_json(replace(record,
                                                   exact_distance=record.exact_distance + 1)))
