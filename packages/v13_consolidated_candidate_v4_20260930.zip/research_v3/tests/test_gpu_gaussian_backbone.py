import sys
from pathlib import Path

import pytest
import torch

from research_v3.gpu.gaussian_backbone import gaussian_encoder_words
from research_v3.gpu.packed_walk import apply_gates, generate_walk_batch, identity_rows


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
@pytest.mark.parametrize('n,batch_size', ((8, 5), (72, 2), (144, 1)))
def test_cuda_gaussian_word_matches_own_cpu_backbone_exactly(n, batch_size):
    code = Path(__file__).resolve().parents[2] / 'code'
    sys.path.insert(0, str(code))
    try:
        from general_macro import gaussian_word
    finally:
        sys.path.pop(0)
    roots = generate_walk_batch(n, batch_size, 17, 2801).rows
    words = gaussian_encoder_words(roots)
    encoded = apply_gates(identity_rows(batch_size, n), words.controls,
                          words.targets, words.lengths)
    assert torch.equal(encoded, roots)
    rows = roots.cpu().tolist()
    controls = words.controls.cpu().tolist()
    targets = words.targets.cpu().tolist()
    lengths = words.lengths.cpu().tolist()
    for sample in range(batch_size):
        packed = [sum((word & ((1 << 64) - 1)) << (64 * slot)
                      for slot, word in enumerate(row)) for row in rows[sample]]
        dense = [[(row >> j) & 1 for j in range(n)] for row in packed]
        expected = gaussian_word(dense)
        actual = list(zip(controls[sample][:lengths[sample]],
                          targets[sample][:lengths[sample]]))
        assert actual == expected


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_cuda_gaussian_rejects_singular_full_matrix():
    rows = identity_rows(1, 8)
    rows[:, 1, :] = rows[:, 0, :]
    with pytest.raises(ValueError, match='singular'):
        gaussian_encoder_words(rows)
