import pytest
import torch

from research_v3.gpu.gaussian_backbone import gaussian_encoder_words
from research_v3.gpu.general_paid_macro import (shorten_one_paid_shear_window,
                                                synthesize_general_paid)
from research_v3.gpu.packed_walk import (apply_gates, generate_walk_batch,
                                         identity_rows)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_full_matrix_gpu_gaussian_word_is_shortened_by_paid_basis_macro():
    n = 20
    controls = torch.tensor([[source for target in range(8, 20)
                              for source in (0, 1)]], device='cuda')
    targets = torch.tensor([[target for target in range(8, 20)
                             for source in (0, 1)]], device='cuda')
    lengths = torch.tensor([24], device='cuda')
    matrix = apply_gates(identity_rows(1, n), controls, targets, lengths)
    baseline = gaussian_encoder_words(matrix)
    result = shorten_one_paid_shear_window(matrix, baseline, span=16)
    assert bool(result.improved.item())
    assert int(result.lengths[0]) < int(baseline.lengths[0])
    assert torch.equal(apply_gates(identity_rows(1, n), result.controls,
                                   result.targets, result.lengths), matrix)
    assert int(result.preparation_lengths[0]) > 0


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_full_matrix_gpu_macro_preserves_word_when_no_window():
    matrix = identity_rows(1, 8)
    baseline = gaussian_encoder_words(matrix)
    result = shorten_one_paid_shear_window(matrix, baseline, span=8)
    assert not bool(result.improved.item())
    assert torch.equal(result.lengths, baseline.lengths)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
@pytest.mark.parametrize('n,span', ((8, 8), (144, 16)))
def test_full_matrix_gpu_macro_on_general_walk_endpoint(n, span):
    matrix = generate_walk_batch(n, 1, 17, 2831).rows
    baseline = gaussian_encoder_words(matrix)
    result = shorten_one_paid_shear_window(matrix, baseline, span=span)
    assert bool((result.lengths <= baseline.lengths).all().item())
    assert torch.equal(apply_gates(identity_rows(1, n), result.controls,
                                   result.targets, result.lengths), matrix)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_gpu_macro_rejects_unrelated_input_word():
    matrix = identity_rows(1, 8)
    other = gaussian_encoder_words(generate_walk_batch(8, 1, 7, 2837).rows)
    with pytest.raises(ValueError, match='input word'):
        shorten_one_paid_shear_window(matrix, other, span=8)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_general_gpu_paid_macro_passes_return_complete_verified_program():
    n = 20
    controls = torch.tensor([[source for target in range(8, 20)
                              for source in (0, 1)]], device='cuda')
    targets = torch.tensor([[target for target in range(8, 20)
                             for source in (0, 1)]], device='cuda')
    matrix = apply_gates(identity_rows(1, n), controls, targets,
                         torch.tensor([24], device='cuda'))
    result = synthesize_general_paid(matrix, spans=(8, 16, 32))
    assert int(result.lengths[0]) < 24
    assert result.paid_macro_passes >= 1
    assert torch.equal(apply_gates(identity_rows(1, n), result.controls,
                                   result.targets, result.lengths), matrix)
