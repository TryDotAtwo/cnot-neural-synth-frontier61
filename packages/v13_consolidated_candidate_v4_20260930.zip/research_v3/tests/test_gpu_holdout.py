import pytest
import torch

from research_v3.gpu.holdout import (GpuExactHoldout,
                                     admit_complete_neighborhood,
                                     declared_finite_views)
from research_v3.gpu.packed_walk import (apply_gates, generate_walk_batch,
                                         identity_rows)
from research_v3.contracts import AlphabetSpec, MatrixState
from research_v3.data.frozen import forbidden_views


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_cuda_holdout_hash_collisions_still_use_full_matrix():
    identity = identity_rows(1, 8)
    one = apply_gates(identity, torch.tensor([[0]], device='cuda'),
                      torch.tensor([[1]], device='cuda'),
                      torch.tensor([1], device='cuda'))
    two = apply_gates(identity, torch.tensor([[0, 2]], device='cuda'),
                      torch.tensor([[1, 3]], device='cuda'),
                      torch.tensor([2], device='cuda'))
    bank = GpuExactHoldout.from_matrices(torch.cat((identity, one), dim=0),
                                         hash_weights=torch.zeros((8, 1), device='cuda',
                                                                  dtype=torch.int64))
    assert bank.matches(torch.cat((identity, one, two), dim=0)).tolist() == \
           [True, True, False]


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_cuda_complete_neighborhood_admission_rejects_one_hop_overlap():
    identity = identity_rows(1, 8)
    one = apply_gates(identity, torch.tensor([[0]], device='cuda'),
                      torch.tensor([[1]], device='cuda'),
                      torch.tensor([1], device='cuda'))
    two = apply_gates(identity, torch.tensor([[0, 2]], device='cuda'),
                      torch.tensor([[1, 3]], device='cuda'),
                      torch.tensor([2], device='cuda'))
    distant = GpuExactHoldout.from_matrices(two)
    assert admit_complete_neighborhood(distant, identity, chunk_size=7) == 57
    forbidden = GpuExactHoldout.from_matrices(one)
    with pytest.raises(ValueError, match='neighbor'):
        admit_complete_neighborhood(forbidden, identity, chunk_size=7)
    with pytest.raises(ValueError, match='parent'):
        admit_complete_neighborhood(GpuExactHoldout.from_matrices(identity),
                                    identity, chunk_size=7)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_cuda_frozen_root_closure_contains_every_one_hop_matrix():
    identity = identity_rows(1, 8)
    closure = GpuExactHoldout.from_frozen_roots(identity, neighbor_chunk=9,
                                                max_entries=57)
    with pytest.raises(MemoryError, match='cap'):
        GpuExactHoldout.from_frozen_roots(identity, neighbor_chunk=9,
                                          max_entries=56)
    one = apply_gates(identity, torch.tensor([[3]], device='cuda'),
                      torch.tensor([[6]], device='cuda'),
                      torch.tensor([1], device='cuda'))
    assert bool(closure.matches(one)[0].item())


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
@pytest.mark.parametrize('n', (8, 72))
def test_cuda_declared_finite_views_equal_preserved_cpu_symmetry_set(n):
    root = generate_walk_batch(n, 2, 7, 6191).rows
    views = declared_finite_views(root)
    cpu_rows = root.cpu().tolist()
    expected_roots = []
    for matrix in cpu_rows:
        packed = tuple(sum((word & ((1 << 64) - 1)) << (64 * slot)
                           for slot, word in enumerate(row)) for row in matrix)
        expected_roots.append(MatrixState(n, packed, AlphabetSpec.all_to_all(n).id))
    expected = forbidden_views(expected_roots)
    actual = set()
    for matrix in views.cpu().tolist():
        packed = tuple(sum((word & ((1 << 64) - 1)) << (64 * slot)
                           for slot, word in enumerate(row)) for row in matrix)
        actual.add((n, AlphabetSpec.all_to_all(n).id, packed))
    assert actual == expected


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_cuda_declared_view_closure_rejects_a_neighbor_of_a_view():
    root = generate_walk_batch(8, 1, 7, 6193).rows
    views = declared_finite_views(root)
    required = views.shape[0] * 57
    bank = GpuExactHoldout.from_declared_root_views(
        root, neighbor_chunk=8, max_entries=required)
    neighbor = apply_gates(views[-1:],
                           torch.tensor([[0]], device='cuda'),
                           torch.tensor([[1]], device='cuda'),
                           torch.tensor([1], device='cuda'))
    assert bool(bank.matches(neighbor)[0].item())
    with pytest.raises(MemoryError, match='cap'):
        GpuExactHoldout.from_declared_root_views(
            root, neighbor_chunk=8, max_entries=required - 1)
