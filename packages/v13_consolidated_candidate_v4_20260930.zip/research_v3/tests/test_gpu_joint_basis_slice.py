import itertools

import numpy as np
import pytest
import torch

from research_v3.basis.templates import BasisChoice, BasisTemplate, compile_basis
from research_v3.gpu.joint_basis_slice import (differentiable_gpu_mc_cost,
                                               paid_source_cost,
                                               differentiable_gpu_batched_mc_cost,
                                               complete_joint_basis_slice,
                                               complete_joint_basis_batch)
from research_v3.gpu.holdout import GpuExactHoldout
from research_v3.gpu.packed_walk import (PackedWalkBatch, apply_gates, generate_walk_batch,
                                         identity_rows)
from research_v3.gpu.structural_e import selected_e_features


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
@pytest.mark.parametrize('n', (8, 26))
def test_cuda_paid_source_cost_matches_full_word_cpu_compiler(n):
    walk = generate_walk_batch(n, 1, 17, 3163)
    block = selected_e_features(walk.rows).block
    width = n // 2
    choice_pairs = ((0, 1), (1, 0))
    pairs = torch.tensor(choice_pairs, device='cuda', dtype=torch.int64)
    assignments = torch.tensor(list(itertools.product((0, 1), repeat=2)),
                               device='cuda', dtype=torch.bool)
    actual = paid_source_cost(block.expand(4, -1, -1), assignments, pairs)
    template = BasisTemplate(n, tuple(range(width)), tuple(range(width, n)),
                             'source', tuple(BasisChoice('add', *pair)
                                             for pair in choice_pairs))
    expected = [compile_basis(template, block[0].cpu().numpy(), bits).certificate.physical_cost
                for bits in itertools.product((0, 1), repeat=2)]
    np.testing.assert_array_equal(actual.cpu().numpy(), expected)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_cuda_paired_mc_gradient_matches_conditional_full_word_costs():
    walk = generate_walk_batch(8, 1, 17, 3181)
    block = selected_e_features(walk.rows).block
    theta = torch.tensor([0.2, 0.8], device='cuda', requires_grad=True)
    pairs = torch.tensor([[0, 1], [1, 0]], device='cuda')
    loss, audit = differentiable_gpu_mc_cost(block, theta, pairs, samples=8,
                                             seed=3187, max_evaluations=40,
                                             max_bytes=268435456)
    loss.backward()
    assert audit.evaluations == 40
    assert torch.equal(theta.grad, audit.gradient)
    template = BasisTemplate(8, tuple(range(4)), tuple(range(4, 8)), 'source',
                             (BasisChoice('add', 0, 1), BasisChoice('add', 1, 0)))
    cpu_block = block[0].cpu().numpy()
    independent = []
    for bits in audit.bits.cpu().tolist():
        differences = []
        for index in range(2):
            zero, one = list(bits), list(bits)
            zero[index], one[index] = False, True
            differences.append(compile_basis(template, cpu_block, one).certificate.physical_cost -
                               compile_basis(template, cpu_block, zero).certificate.physical_cost)
        independent.append(differences)
    np.testing.assert_array_equal(audit.gradient.detach().cpu().numpy(),
                                  np.asarray(independent).mean(axis=0))


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_cuda_joint_slice_reaches_field_and_basis_proposer():
    from research_v3.basis.learning import BasisField
    from research_v3.features.basis_gradient import register_basis_gradient
    from research_v3.features.registry import FeatureRegistry
    from research_v3.model.field import FusionDistanceField
    block = torch.zeros((1, 4, 4), device='cuda', dtype=torch.bool)
    block[:, :, :2] = True
    block[:, 0, 2] = True
    controls = torch.tensor([[c for target in range(4) for c in range(4)
                              if block[0, target, c]]], device='cuda')
    targets = torch.tensor([[target + 4 for target in range(4) for c in range(4)
                             if block[0, target, c]]], device='cuda')
    rows = apply_gates(identity_rows(1, 8), controls, targets,
                       torch.tensor([controls.shape[1]], device='cuda'))
    registry = FeatureRegistry()
    register_basis_gradient(registry)
    keys = ('A01', 'E01', 'E04', 'E05')
    model = BasisField(FusionDistanceField([registry.specs[key] for key in keys],
                                           d=64, pair_d=16, blocks=1, heads=4,
                                           ffn=128, fusion_blocks=1), 32).cuda().train()
    loss, audit = complete_joint_basis_slice(model, rows,
                                             pairs=((0, 1), (1, 0)),
                                             action_chunk=8, samples=2,
                                             seed=3197, max_evaluations=32,
                                             max_bytes=268435456, weight=0.1)
    assert audit['basis_status'] == 'evaluated'
    assert audit['basis_evaluations'] == 10
    assert bool((audit['basis_gradient'] != 0).any().item())
    loss.backward()
    assert torch.isfinite(loss)
    assert any(parameter.grad is not None and
               bool((parameter.grad != 0).any().item())
               for parameter in model.proposer.parameters())
    assert model.field.stem.projections['A01'].weight.grad is not None


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_cuda_batched_paid_cost_and_conditional_gradient_match_cpu_words():
    roots = generate_walk_batch(8, 2, 17, 3241).rows
    blocks = selected_e_features(roots).block
    pairs = torch.tensor([[[0, 1], [1, 2]], [[2, 0], [3, 1]]],
                         device='cuda', dtype=torch.int64)
    bits = torch.tensor([[True, False], [False, True]], device='cuda')
    costs = paid_source_cost(blocks, bits, pairs)
    for root in range(2):
        template = BasisTemplate(8, tuple(range(4)), tuple(range(4, 8)),
                                 'source', tuple(BasisChoice('add', *pair)
                                                 for pair in pairs[root].cpu().tolist()))
        expected = compile_basis(template, blocks[root].cpu().numpy(),
                                 bits[root].to(torch.int64).cpu().tolist()).certificate.physical_cost
        assert int(costs[root]) == expected
    theta = torch.tensor([[0.25, 0.75], [0.65, 0.4]], device='cuda',
                         requires_grad=True)
    generator = torch.Generator(device='cuda').manual_seed(3247)
    loss, audit = differentiable_gpu_batched_mc_cost(
        blocks, theta, pairs, samples=2, generator=generator,
        available=torch.ones(2, device='cuda', dtype=torch.bool),
        max_evaluations=32, max_bytes=268435456)
    assert audit.evaluations == 20
    loss.backward()
    torch.testing.assert_close(theta.grad, audit.gradient / 2, atol=0, rtol=0)
    for root in range(2):
        template = BasisTemplate(8, tuple(range(4)), tuple(range(4, 8)),
                                 'source', tuple(BasisChoice('add', *pair)
                                                 for pair in pairs[root].cpu().tolist()))
        independent = []
        for sampled in audit.bits[root].cpu().tolist():
            differences = []
            for index in range(2):
                zero, one = list(sampled), list(sampled)
                zero[index], one[index] = False, True
                differences.append(compile_basis(template, blocks[root].cpu().numpy(), one).certificate.physical_cost -
                                   compile_basis(template, blocks[root].cpu().numpy(), zero).certificate.physical_cost)
            independent.append(differences)
        np.testing.assert_array_equal(audit.gradient[root].cpu().numpy(),
                                      np.asarray(independent).mean(axis=0))


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_cuda_batched_joint_objective_admits_before_field_and_trains_proposer():
    from research_v3.basis.learning import BasisField
    from research_v3.features.basis_gradient import register_basis_gradient
    from research_v3.features.registry import FeatureRegistry
    from research_v3.model.field import FusionDistanceField
    block = torch.zeros((4, 4), device='cuda', dtype=torch.bool)
    block[:, :2] = True
    block[0, 2] = True
    target, control = torch.nonzero(block, as_tuple=True)
    controls = control[None].expand(2, -1)
    targets = (target + 4)[None].expand(2, -1)
    lengths = torch.full((2,), len(control), device='cuda', dtype=torch.int64)
    roots = apply_gates(identity_rows(2, 8), controls, targets, lengths)
    verified_walk = PackedWalkBatch(roots, controls, targets, lengths)
    registry = FeatureRegistry()
    register_basis_gradient(registry)
    keys = ('A01', 'E01', 'E04', 'E05')
    model = BasisField(FusionDistanceField([registry.specs[key] for key in keys],
                                           d=64, pair_d=16, blocks=1, heads=4,
                                           ffn=128, fusion_blocks=1), 32).cuda().train()
    holdout = GpuExactHoldout.from_frozen_roots(identity_rows(1, 8),
                                                neighbor_chunk=8, max_entries=57)
    generator = torch.Generator(device='cuda').manual_seed(3257)
    loss, audit = complete_joint_basis_batch(
        model, roots, generator=generator, choice_count=2, action_chunk=8,
        samples=2, max_evaluations=32, max_bytes=268435456,
        weight=0.1, holdout=holdout, training_walk=verified_walk,
        mc_samples=8, mc_seed=3257)
    assert audit['basis_status'] == 'evaluated'
    assert audit['admitted_parent_and_neighbors'] == 114
    assert audit['basis_active_count'] == 2
    assert audit['basis_evaluations'] == 20
    assert audit['verified_interval']
    assert torch.isfinite(audit['interval_loss'])
    assert torch.isfinite(audit['teacher_loss'])
    loss.backward()
    assert torch.isfinite(loss)
    assert any(parameter.grad is not None and
               bool((parameter.grad != 0).any().item())
               for parameter in model.proposer.parameters())
    assert model.field.stem.projections['A01'].weight.grad is not None
    assert any(parameter.grad is not None and
               bool((parameter.grad != 0).any().item())
               for parameter in model.field.auxiliary.proposal.parameters())
    with pytest.raises(ValueError, match='holdout closure'):
        complete_joint_basis_batch(
            model, identity_rows(1, 8), generator=generator, choice_count=2,
            action_chunk=8, samples=2, max_evaluations=32,
            max_bytes=268435456, weight=0.1, holdout=holdout)
