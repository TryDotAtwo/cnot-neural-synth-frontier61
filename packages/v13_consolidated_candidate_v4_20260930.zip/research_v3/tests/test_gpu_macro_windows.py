import pytest
import torch

from research_v3.gpu.gaussian_backbone import gaussian_encoder_words
from research_v3.gpu.macro_windows import shear_window_mask
from research_v3.gpu.packed_walk import generate_walk_batch


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
@pytest.mark.parametrize('n,batch_size,span', ((8, 5, 4), (72, 2, 8), (144, 1, 16)))
def test_gpu_shear_window_admission_matches_independent_scan(n, batch_size, span):
    words = gaussian_encoder_words(generate_walk_batch(n, batch_size, 17, 2821).rows)
    got = shear_window_mask(words, span).cpu().tolist()
    controls = words.controls.cpu().tolist()
    targets = words.targets.cpu().tolist()
    lengths = words.lengths.cpu().tolist()
    for sample in range(batch_size):
        for start, accepted in enumerate(got[sample]):
            subset = list(zip(controls[sample][start:start + span],
                              targets[sample][start:start + span]))
            valid = (start + span <= lengths[sample] and
                     len({c for c, _ in subset}) >= 2 and
                     len({t for _, t in subset}) >= 2 and
                     {c for c, _ in subset}.isdisjoint({t for _, t in subset}))
            assert accepted == valid
