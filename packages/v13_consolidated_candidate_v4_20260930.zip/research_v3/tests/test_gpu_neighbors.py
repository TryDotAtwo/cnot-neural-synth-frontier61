import pytest
import torch

from research_v3.gpu.neighbors import primitive_neighbor_chunks
from research_v3.gpu.packed_walk import generate_walk_batch


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
@pytest.mark.parametrize('n,chunk_size', ((8, 9), (144, 257)))
def test_all_cuda_neighbors_have_stable_ids_and_exact_row_xor(n, chunk_size):
    parents = generate_walk_batch(n, 2, 7, 2741).rows
    seen = 0
    for chunk in primitive_neighbor_chunks(parents, chunk_size):
        count = chunk.action_ids.numel()
        assert torch.equal(chunk.action_ids,
                           torch.arange(seen, seen + count, device='cuda'))
        assert bool((chunk.controls != chunk.targets).all().item())
        for slot in (0, count - 1):
            control, target = int(chunk.controls[slot]), int(chunk.targets[slot])
            expected = parents.clone()
            expected[:, target, :] ^= parents[:, control, :]
            assert torch.equal(chunk.rows[:, slot], expected)
        seen += count
    assert seen == n * (n - 1)
