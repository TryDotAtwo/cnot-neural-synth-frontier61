"""Full-word search mechanics with deterministic scorer stand-ins on CPU."""

import torch

from research_v3.gpu.neighbors import all_action_pairs
from research_v3.gpu.neural_beam import (_cpu_identity, beam_search,
                                          matrix_hamming_callbacks)


def test_two_gate_program_is_replayed_and_depth_cap_is_honest():
    root = _cpu_identity(3)
    root[1] ^= root[0]
    root[2] ^= root[1]
    wanted_first = root.clone()
    wanted_first[2] ^= wanted_first[1]
    controls, targets = all_action_pairs(3, 'cpu')
    pairs = list(zip(controls.tolist(), targets.tolist()))

    def action_scores(rows):
        scores = torch.full((len(rows), len(pairs)), 100.0)
        for index, state in enumerate(rows):
            gate = (1, 2) if torch.equal(state, root) else (0, 1)
            scores[index, pairs.index(gate)] = 1.0
        return scores

    def state_values(rows):
        return torch.zeros(len(rows))

    short = beam_search(root[None], action_scores, state_values,
                        beam_width=1, shortlist=1, max_depth=1)
    assert short.status == 'depth_limit' and short.word is None
    solved = beam_search(root[None], action_scores, state_values,
                         beam_width=1, shortlist=1, max_depth=2)
    assert solved.status == 'solved' and solved.verified
    assert solved.word == ((1, 2), (0, 1))
    assert solved.expanded == 2 and solved.generated == 1


def test_invalid_action_head_is_rejected_before_search():
    root = _cpu_identity(3)
    root[1] ^= root[0]
    root[2] ^= root[1]
    def incomplete(rows):
        return torch.zeros((len(rows), 2))
    def unused(rows):
        raise AssertionError('child scorer must not run')
    try:
        beam_search(root[None], incomplete, unused,
                    beam_width=1, shortlist=1, max_depth=2)
    except ValueError as error:
        assert 'complete finite alphabet' in str(error)
    else:
        raise AssertionError('incomplete action head was accepted')


def test_batched_successors_preserve_multi_parent_complete_search():
    root = _cpu_identity(4)
    root[1] ^= root[0]
    root[2] ^= root[1]
    root[3] ^= root[2]
    action_count = 4 * 3

    def equal_actions(rows):
        return torch.zeros((len(rows), action_count))

    def reversed_actions(rows):
        return (-torch.arange(action_count, dtype=torch.float32))[None].expand(
            len(rows), -1)

    def equal_values(rows):
        return torch.zeros(len(rows))

    result = beam_search(root[None], equal_actions, equal_values,
                         beam_width=144, shortlist=action_count, max_depth=3)
    direct = beam_search(root[None], None, equal_values,
                         beam_width=144, shortlist=action_count, max_depth=3)
    all_shortlist = beam_search(root[None], reversed_actions, equal_values,
                                beam_width=144, shortlist=action_count, max_depth=3)
    assert result.status == 'solved'
    assert result.verified
    assert len(result.word) == 3
    assert result.expanded > 1
    assert direct.word == result.word
    assert direct.generated == result.generated
    assert all_shortlist.word == direct.word


def test_goal_probe_precedes_action_shortlist():
    root = _cpu_identity(4)
    root[3] ^= root[1]

    def wrong_action_scores(rows):
        scores = torch.arange(12, dtype=torch.float32)[None].expand(len(rows), -1)
        return scores

    def unused_values(rows):
        raise AssertionError('one-step goal must be detected before value ranking')

    result = beam_search(root[None], wrong_action_scores, unused_values,
                         beam_width=1, shortlist=1, max_depth=1)
    assert result.status == 'solved'
    assert result.word == ((1, 3),)
    assert result.verified
    assert result.generated == 0


def test_matrix_hamming_control_uses_same_complete_beam():
    root = _cpu_identity(4)
    root[1] ^= root[0]
    root[2] ^= root[1]
    root[3] ^= root[2]
    actions, states = matrix_hamming_callbacks()
    assert actions is None
    result = beam_search(root[None], actions, states,
                         beam_width=144, shortlist=12, max_depth=3)
    assert result.status == 'solved'
    assert result.verified and len(result.word) == 3
