import pytest
import torch

from research_v3.gpu.packed_walk import generate_walk_batch, verify_inverse


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
@pytest.mark.parametrize('n', (8, 64, 72, 144))
@pytest.mark.parametrize('family', ('ordinary_walk', 'poisson_walk'))
def test_gpu_walk_matches_independent_row_replay(n, family):
    batch = generate_walk_batch(n, 7, 19, 2707, family=family)
    assert bool(verify_inverse(batch).all().item())
    rows = batch.rows.cpu().tolist()
    controls = batch.controls.cpu().tolist()
    targets = batch.targets.cpu().tolist()
    lengths = batch.lengths.cpu().tolist()
    for sample in range(7):
        reference = [1 << wire for wire in range(n)]
        for control, target in zip(controls[sample][:lengths[sample]],
                                   targets[sample][:lengths[sample]]):
            assert control != target
            reference[target] ^= reference[control]
        packed = []
        for row in rows[sample]:
            packed.append(sum((word & ((1 << 64) - 1)) << (64 * index)
                              for index, word in enumerate(row)))
        assert packed == reference
