import pytest
import torch

from research_v3.gpu.paid_shear import (compile_paid_shear,
                                        compile_gradient_source_shear,
                                        compile_paid_shear_portfolio,
                                        select_weighted_source_group,
                                        verify_paid_shear)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
@pytest.mark.parametrize('n,sources,targets', (
    (8, (0, 1, 2, 3), (4, 5, 6, 7)),
    (16, tuple(range(8)), tuple(range(8, 16))),
    (144, (0, 63, 64, 70), (71, 72, 127, 143)),
))
def test_gpu_paid_basis_full_matrix_and_physical_cost(n, sources, targets):
    generator = torch.Generator(device='cuda').manual_seed(2717)
    block = torch.randint(0, 2, (16, len(targets), len(sources)),
                          device='cuda', generator=generator).bool()
    source_wires = torch.tensor(sources, device='cuda')
    target_wires = torch.tensor(targets, device='cuda')
    result = compile_paid_shear(block, source_wires, target_wires,
                                max_preparation=16)
    assert bool(verify_paid_shear(block, source_wires, target_wires,
                                  result, n=n).all().item())
    assert bool((result.lengths <= block.sum((1, 2))).all().item())
    assert bool((result.lengths == 2 * result.preparation_lengths +
                 result.core_lengths).all().item())
    assert bool(result.converged.all().item())


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_wide_gradient_source_basis_emits_paid_verified_word():
    generator = torch.Generator(device='cuda').manual_seed(2771)
    block = (torch.rand((8, 12, 8), device='cuda', generator=generator) < .45)
    block[:, :, 0:2] = True
    source = torch.arange(8, device='cuda')
    target = torch.arange(8, 20, device='cuda')
    result = compile_gradient_source_shear(block, source, target,
                                           group=torch.arange(8, device='cuda'),
                                           gradient_steps=12, learning_rate=.03)
    assert bool(verify_paid_shear(block, source, target, result, n=20).all().item())
    assert bool((result.lengths <= block.sum((1, 2))).all().item())
    assert bool((result.lengths == 2 * result.preparation_lengths +
                 result.core_lengths).all().item())
    assert bool((result.preparation_lengths > 0).any().item())


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_gpu_paid_portfolio_selects_shortest_verified_physical_word():
    generator = torch.Generator(device='cuda').manual_seed(2783)
    block = torch.rand((24, 12, 8), device='cuda', generator=generator) < .45
    source = torch.arange(8, device='cuda')
    target = torch.arange(8, 20, device='cuda')
    greedy = compile_paid_shear(block, source, target, max_preparation=16)
    gradient = compile_gradient_source_shear(block, source, target,
                                             group=source, gradient_steps=12,
                                             learning_rate=.03)
    selected = compile_paid_shear_portfolio(block, source, target,
                                            max_preparation=16,
                                            gradient_group=source,
                                            gradient_steps=12,
                                            learning_rate=.03)
    assert torch.equal(selected.lengths, torch.minimum(greedy.lengths,
                                                       gradient.lengths))
    assert bool(verify_paid_shear(block, source, target, selected, n=20).all().item())


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_n144_gpu_gradient_uses_per_matrix_selected_source_groups():
    generator = torch.Generator(device='cuda').manual_seed(2791)
    block = torch.rand((4, 72, 72), device='cuda', generator=generator) < .16
    block[0, :24, 0:2] = True
    block[1, 24:48, 20:22] = True
    source = torch.arange(72, device='cuda')
    target = torch.arange(72, 144, device='cuda')
    groups = select_weighted_source_group(block, width=8)
    assert groups.shape == (4, 8)
    assert int(groups[0, 0]) != int(groups[1, 0])
    result = compile_gradient_source_shear(block, source, target,
                                           group=groups, gradient_steps=8,
                                           learning_rate=.03)
    assert bool(verify_paid_shear(block, source, target, result, n=144).all().item())
    assert bool((result.lengths <= block.sum((1, 2))).all().item())
