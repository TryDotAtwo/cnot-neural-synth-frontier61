from dataclasses import replace

import pytest
import torch

from research_v3.contracts import AlphabetSpec, Gate
from research_v3.data.generators import record_from_word
from research_v3.gpu.packed_walk import verify_inverse
from research_v3.gpu.record_batch import own_records_to_cuda


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
@pytest.mark.parametrize('n', (8, 72))
def test_own_certificates_transfer_and_replay_complete_gpu_words(n):
    alphabet = AlphabetSpec.all_to_all(n)
    words = ((Gate(0, n - 1), Gate(n - 1, 1)),
             (Gate(1, n - 1), Gate(n - 1, 0), Gate(0, 2)))
    records = tuple(replace(record_from_word(alphabet, word,
                                            f'ordinary_walk:11:{n}:{index}',
                                            11, 'ordinary_walk_v1'),
                            split='train')
                    for index, word in enumerate(words))
    batch = own_records_to_cuda(records)
    assert batch.walk.lengths.tolist() == [2, 3]
    assert batch.walk.controls[0, :2].tolist() == [0, n - 1]
    assert batch.sources == ('ordinary_walk_v1', 'ordinary_walk_v1')
    assert bool(verify_inverse(batch.walk).all().item())


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_own_record_transfer_rejects_external_source_and_bad_word():
    alphabet = AlphabetSpec.all_to_all(8)
    record = replace(record_from_word(alphabet, (Gate(0, 1), Gate(1, 2)),
                                      'ordinary_walk:21:8:0', 21,
                                      'ordinary_walk_v1'), split='train')
    with pytest.raises(ValueError, match='untrusted'):
        own_records_to_cuda((replace(record, source='external_method'),))
    with pytest.raises(ValueError, match='duplicate'):
        own_records_to_cuda((record, record))
    chosen = record.verified_words[0]
    with pytest.raises(ValueError, match='invalid complete'):
        own_records_to_cuda((replace(record, verified_words=(
            replace(chosen, producer='external_method'),)),))
    broken = replace(chosen, gates=(Gate(0, 2),) + chosen.gates[1:])
    with pytest.raises(ValueError, match='replay rejected'):
        own_records_to_cuda((replace(record, verified_words=(broken,)),))
