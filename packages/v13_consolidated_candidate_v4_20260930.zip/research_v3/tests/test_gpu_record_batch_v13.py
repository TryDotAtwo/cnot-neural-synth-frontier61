import unittest
import torch

from research_v3.data.stream_solver_dataset_v13 import make_root
from research_v3.gpu.record_batch_v13 import own_records_to_cuda


@unittest.skipUnless(torch.cuda.is_available(), 'Molab CUDA gate')
class RootLabelTransferTests(unittest.TestCase):
    def test_exact_root_labels_survive_independent_cuda_replay(self):
        for index in (0, 14, 70, 126):
            record, _ = make_root('train', 0, index, 0, 7000)
            batch = own_records_to_cuda((record,))
            self.assertEqual(batch.exact_distances, (record.exact_distance,))
            self.assertEqual(batch.exact_evidence, (record.exact_evidence,))
            self.assertEqual(batch.lineages, (record.lineage_id,))
            self.assertEqual(batch.sources, (record.source,))
            self.assertEqual(batch.walk.lengths.tolist(), [record.upper_bound])


if __name__ == '__main__':
    unittest.main()
