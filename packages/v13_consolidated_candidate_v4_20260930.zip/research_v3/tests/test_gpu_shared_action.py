import sys
from pathlib import Path

import numpy as np
import pytest
import torch

from research_v3.gpu.shared_action import GpuSharedAction


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
@pytest.mark.parametrize('side', ('source', 'target'))
def test_cuda_local_action_value_gradient_and_rounding_match_stage17(side):
    code = Path(__file__).resolve().parents[2] / 'code'
    sys.path.insert(0, str(code))
    try:
        from shared_synth import SharedAction
    finally:
        sys.path.pop(0)
    ops = (('add', 0, 1), ('add', 2, 3), ('swap', 0, 2), ('add', 3, 1))
    generator = torch.Generator(device='cuda').manual_seed(2759)
    vectors = torch.randint(0, 2, (3, 20, 4), generator=generator,
                            device='cuda').bool()
    theta = torch.rand((3, len(ops)), generator=generator, device='cuda',
                       dtype=torch.float64).requires_grad_()
    action = GpuSharedAction(vectors, ops, side=side)
    values = action.value(theta)
    gradient, = torch.autograd.grad(values.sum(), theta)
    rounded = action.conditional_round(theta.detach())
    for index in range(3):
        reference = SharedAction(vectors[index].cpu().numpy().astype(np.uint8),
                                 ops, side=side)
        expected_value, expected_gradient = reference.value_gradient(
            theta[index].detach().cpu().numpy())
        np.testing.assert_allclose(values[index].item(), expected_value,
                                   rtol=0, atol=1e-10)
        np.testing.assert_allclose(gradient[index].cpu().numpy(), expected_gradient,
                                   rtol=0, atol=1e-10)
        assert rounded[index].cpu().tolist() == reference.round(
            theta[index].detach().cpu().numpy())
