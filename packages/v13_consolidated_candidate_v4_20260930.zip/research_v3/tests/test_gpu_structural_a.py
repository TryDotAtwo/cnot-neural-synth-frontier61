import numpy as np
import pytest
import torch

from research_v3.contracts import AlphabetSpec, MatrixState
from research_v3.features.structural import compute
from research_v3.gpu.packed_walk import generate_walk_batch
from research_v3.gpu.structural_a import ALL_A, SELECTED_A, all_a_features, selected_a_features


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
@pytest.mark.parametrize('n', (8, 72, 144))
def test_cuda_a_features_match_reference(n):
    batch = generate_walk_batch(n, 2, 17, 2731)
    actual = selected_a_features(batch.rows)
    assert set(actual) == set(SELECTED_A)
    rows = batch.rows.cpu().tolist()
    for index, words_by_row in enumerate(rows):
        unpacked = tuple(sum((word & ((1 << 64) - 1)) << (64 * slot)
                             for slot, word in enumerate(words)) for words in words_by_row)
        reference = compute(MatrixState(n, unpacked, AlphabetSpec.all_to_all(n).id))
        for key in SELECTED_A:
            np.testing.assert_array_equal(actual[key][index].cpu().numpy(), reference[key])


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
@pytest.mark.parametrize('n', (8, 72, 144))
def test_cuda_complete_a_family_matches_reference(n):
    batch = generate_walk_batch(n, 2, 31, 2833)
    actual = all_a_features(batch.rows)
    assert set(actual) == set(ALL_A)
    for index, words_by_row in enumerate(batch.rows.cpu().tolist()):
        unpacked = tuple(sum((word & ((1 << 64) - 1)) << (64 * slot)
                             for slot, word in enumerate(words)) for words in words_by_row)
        reference = compute(MatrixState(n, unpacked, AlphabetSpec.all_to_all(n).id))
        for key in ALL_A:
            np.testing.assert_array_equal(actual[key][index].cpu().numpy(), reference[key],
                                          err_msg=f'n={n}, root={index}, feature={key}')
