import numpy as np
import pytest
import torch

from research_v3.contracts import AlphabetSpec, MatrixState
from research_v3.features.structural import compute
from research_v3.gpu.packed_walk import generate_walk_batch, identity_rows
from research_v3.gpu.structural_b import SELECTED_BF, selected_bf_features


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
@pytest.mark.parametrize('n', (8, 72, 144))
def test_cuda_selected_bf_matches_cpu_reference(n):
    generated = generate_walk_batch(n, 2, 31, 2879)
    rows = torch.cat((generated.rows, identity_rows(1, n)), dim=0)
    actual = selected_bf_features(rows)
    assert set(actual) == set(SELECTED_BF)
    for index, words_by_row in enumerate(rows.cpu().tolist()):
        unpacked = tuple(sum((word & ((1 << 64) - 1)) << (64 * slot)
                             for slot, word in enumerate(words)) for words in words_by_row)
        reference = compute(MatrixState(n, unpacked, AlphabetSpec.all_to_all(n).id))
        for key in SELECTED_BF:
            np.testing.assert_array_equal(actual[key][index].cpu().numpy(), reference[key],
                                          err_msg=f'n={n}, root={index}, feature={key}')
