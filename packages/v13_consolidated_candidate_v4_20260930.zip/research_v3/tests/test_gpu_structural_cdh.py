import numpy as np
import pytest
import torch

from research_v3.contracts import AlphabetSpec, MatrixState
from research_v3.features.registry import FeaturePolicy, FeatureRegistry
from research_v3.features.subspace_views import register_subspace_views
from research_v3.gpu.packed_walk import generate_walk_batch, identity_rows
from research_v3.gpu.structural_cdh import (SELECTED_CDH, gf2_inverse_dense,
                                            gf2_rank_dense, selected_cdh_features)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
@pytest.mark.parametrize('n', (8, 72, 144))
def test_cuda_cdh_views_match_registered_cpu_producers(n):
    generated = generate_walk_batch(n, 2, 31, 2909)
    rows = torch.cat((generated.rows, identity_rows(1, n)), dim=0)
    actual = selected_cdh_features(rows)
    registry = FeatureRegistry()
    register_subspace_views(registry)
    states = []
    for words_by_row in rows.cpu().tolist():
        unpacked = tuple(sum((word & ((1 << 64) - 1)) << (64 * slot)
                             for slot, word in enumerate(words)) for words in words_by_row)
        states.append(MatrixState(n, unpacked, AlphabetSpec.all_to_all(n).id))
    reference = registry.build(states, FeaturePolicy(SELECTED_CDH))
    assert set(actual) == set(SELECTED_CDH)
    for key in SELECTED_CDH:
        np.testing.assert_array_equal(actual[key].cpu().numpy(),
                                      reference.features[key].values,
                                      err_msg=f'n={n}, feature={key}')


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_cuda_gf2_rank_and_inverse_singular_contract():
    singular = torch.tensor([[[1, 1], [1, 1]], [[0, 0], [0, 0]]],
                            device='cuda', dtype=torch.bool)
    assert gf2_rank_dense(singular).tolist() == [1, 0]
    with pytest.raises(ValueError, match='singular'):
        gf2_inverse_dense(singular)
