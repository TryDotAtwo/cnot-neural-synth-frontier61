import numpy as np
import pytest
import torch

from research_v3.contracts import AlphabetSpec, MatrixState
from research_v3.features.basis_gradient import register_basis_gradient
from research_v3.features.registry import FeaturePolicy, FeatureRegistry
from research_v3.gpu.packed_walk import generate_walk_batch, identity_rows
from research_v3.gpu.structural_e import SELECTED_E, selected_e_features


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
@pytest.mark.parametrize('n', (8, 26, 72, 144))
def test_cuda_partial_shear_e_features_match_cpu_reference(n):
    generated = generate_walk_batch(n, 2, 29, 2953)
    rows = torch.cat((generated.rows, identity_rows(1, n)), dim=0)
    actual = selected_e_features(rows)
    registry = FeatureRegistry()
    register_basis_gradient(registry)
    states = []
    for words_by_row in rows.cpu().tolist():
        unpacked = tuple(sum((word & ((1 << 64) - 1)) << (64 * slot)
                             for slot, word in enumerate(words)) for words in words_by_row)
        states.append(MatrixState(n, unpacked, AlphabetSpec.all_to_all(n).id))
    reference = registry.build(states, FeaturePolicy(SELECTED_E,
                                      symmetry_contract='augmentation_only'))
    np.testing.assert_array_equal(actual.available.cpu().numpy(),
                                  reference.features['E01'].available)
    for key in SELECTED_E:
        np.testing.assert_allclose(actual.features[key].cpu().numpy(),
                                   reference.features[key].values,
                                   rtol=0, atol=1e-6,
                                   err_msg=f'n={n}, feature={key}')


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_cuda_partial_shear_identity_is_unavailable():
    result = selected_e_features(identity_rows(2, 8))
    assert not bool(result.available.any().item())
    assert all(not bool(value.any().item()) for value in result.features.values())
