import json
from pathlib import Path

import pytest
import torch

from research_v3.cli.probe_gpu_fullwidth_joint import _model
from research_v3.gpu.packed_walk import PackedWalkBatch, generate_walk_batch, identity_rows
from research_v3.gpu.trajectory_objective import (sample_verified_graph_edges,
                                                  verified_trajectory_joint_loss)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='Molab CUDA gate')
def test_sampled_edges_have_full_reduction_words_and_honest_bounds():
    walk = generate_walk_batch(8, 2, 5, 7123)
    generator = torch.Generator(device='cuda')
    generator.manual_seed(801)
    edges = sample_verified_graph_edges(
        walk, generator=generator, samples_per_root=3)
    assert edges.parent_word.rows.shape == (6, 8, 1)
    assert torch.equal(edges.parent_word.rows[::3], walk.rows)
    assert torch.equal(edges.parent_labels.upper,
                       edges.child_labels.upper + 1)
    assert bool((edges.parent_labels.lower <= edges.parent_labels.upper).all())
    assert bool((edges.child_labels.lower <= edges.child_labels.upper).all())


@pytest.mark.skipif(not torch.cuda.is_available(), reason='Molab CUDA gate')
def test_cancelled_word_remains_upper_bound_not_exact_target():
    controls = torch.tensor([[2, 2]], device='cuda', dtype=torch.int64)
    targets = torch.tensor([[5, 5]], device='cuda', dtype=torch.int64)
    lengths = torch.tensor([2], device='cuda', dtype=torch.int64)
    identity = identity_rows(1, 8)
    generator = torch.Generator(device='cuda')
    generator.manual_seed(42)
    edges = sample_verified_graph_edges(
        PackedWalkBatch(identity, controls, targets, lengths),
        generator=generator, samples_per_root=1)
    assert torch.equal(edges.parent_word.rows, identity)
    assert edges.parent_labels.lower.tolist() == [0]
    assert edges.parent_labels.upper.tolist() == [2]
    assert edges.child_labels.upper.tolist() == [1]
    assert edges.child_labels.lower.tolist() == [1]


@pytest.mark.skipif(not torch.cuda.is_available(), reason='Molab CUDA gate')
def test_full29_value_qhat_and_basis_gradients_on_verified_edges():
    config = json.loads((Path(__file__).resolve().parents[1] /
                         'configs/joint_100m_stream_main_2700.json').read_text())
    torch.manual_seed(config['seed'])
    model = _model(config).train()
    walk = generate_walk_batch(8, 1, 3, 27819)
    generator = torch.Generator(device='cuda')
    generator.manual_seed(9104)
    loss, audit = verified_trajectory_joint_loss(
        model, walk, generator=generator, samples_per_root=2,
        holdout=None, admission_chunk=32,
        mc_samples=config['diffusion']['mc_samples'],
        mc_seed=config['feature_seed'],
        max_pair_states=config['diffusion']['max_pair_states'])
    loss.backward()
    assert bool(torch.isfinite(loss).item())
    assert audit['sampled_edges'] == 2
    assert sum(model.field.stem.projections[key].weight.grad is not None
               for key in config['features']) == 29
    assert any(parameter.grad is not None
               for parameter in model.proposer.parameters())
