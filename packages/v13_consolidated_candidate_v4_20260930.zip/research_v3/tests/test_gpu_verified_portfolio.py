import pytest
import torch

from research_v3.gpu.general_paid_macro import synthesize_general_paid
from research_v3.gpu.packed_walk import generate_walk_batch
from research_v3.gpu.verified_portfolio import (GpuProgramCandidate,
                                                 choose_shortest_verified)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_gpu_portfolio_retains_short_verified_walk_incumbent():
    walk = generate_walk_batch(72, 1, 19, 2857)
    own = synthesize_general_paid(walk.rows)
    result = choose_shortest_verified(walk.rows, (
        GpuProgramCandidate(walk.controls, walk.targets, walk.lengths,
                            'own_generated_walk_incumbent'),
        GpuProgramCandidate(own.controls, own.targets, own.lengths,
                            'own_gpu_paid_general'),
    ))
    assert int(result.lengths[0]) == min(int(walk.lengths[0]),
                                         int(own.lengths[0]))
    assert result.candidate_lengths.tolist() == [int(walk.lengths[0]),
                                                  int(own.lengths[0])]


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_gpu_portfolio_rejects_wrong_full_matrix_word():
    walk = generate_walk_batch(8, 1, 7, 2861)
    bad = GpuProgramCandidate(torch.tensor([[0]], device='cuda'),
                              torch.tensor([[1]], device='cuda'),
                              torch.tensor([1], device='cuda'), 'invalid')
    with pytest.raises(ValueError, match='full matrix'):
        choose_shortest_verified(walk.rows, (bad,))
