import pytest
import torch

from research_v3.bounds import cheap_bounds
from research_v3.contracts import AlphabetSpec, MatrixState
from research_v3.gpu.packed_walk import (PackedWalkBatch, apply_gates,
                                         generate_walk_batch, identity_rows)
from research_v3.gpu.structural_a import dense_bits
from research_v3.gpu.verified_supervision import (interval_from_verified_walk,
                                                   interval_hinge_loss,
                                                   verified_walk_teacher_loss)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
@pytest.mark.parametrize('n', (8, 72))
def test_verified_gpu_walk_bounds_match_independent_cpu_certificates(n):
    walk = generate_walk_batch(n, 4, 17, 3149)
    labels = interval_from_verified_walk(walk)
    matrix = dense_bits(walk.rows).to(torch.int64).cpu().tolist()
    alphabet = AlphabetSpec.all_to_all(n)
    for index in range(4):
        state = MatrixState.from_dense(matrix[index], alphabet)
        assert int(labels.lower[index]) == cheap_bounds(state).lower_bound
        assert int(labels.upper[index]) == int(walk.lengths[index])
        assert int(labels.lower[index]) <= int(labels.upper[index])


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_verified_gpu_interval_rejects_wrong_matrix_and_bad_word():
    walk = generate_walk_batch(8, 1, 5, 3151)
    labels = interval_from_verified_walk(walk)
    value = torch.tensor([float(labels.upper[0]) + 1], device='cuda',
                         requires_grad=True)
    loss = interval_hinge_loss(value, walk.rows, labels)
    torch.testing.assert_close(loss, torch.tensor(1., device='cuda'))
    loss.backward()
    assert value.grad is not None and value.grad.item() == 2.
    with pytest.raises(ValueError, match='verified CUDA interval'):
        interval_hinge_loss(value, identity_rows(1, 8), labels)
    altered = apply_gates(walk.rows, torch.tensor([[0]], device='cuda'),
                          torch.tensor([[1]], device='cuda'),
                          torch.tensor([1], device='cuda'))
    bad = PackedWalkBatch(altered, walk.controls,
                          walk.targets, walk.lengths)
    with pytest.raises(ValueError, match='replay failed'):
        interval_from_verified_walk(bad)


@pytest.mark.skipif(not torch.cuda.is_available(), reason='CUDA required')
def test_verified_teacher_uses_first_inverse_gate_and_masks_diagonal():
    controls = torch.tensor([[0, 1]], device='cuda')
    targets = torch.tensor([[1, 2]], device='cuda')
    lengths = torch.tensor([2], device='cuda')
    rows = apply_gates(identity_rows(1, 4), controls, targets, lengths)
    walk = PackedWalkBatch(rows, controls, targets, lengths)
    proposal = torch.zeros((1, 4, 4), device='cuda', requires_grad=True)
    loss = verified_walk_teacher_loss(proposal, walk)
    torch.testing.assert_close(loss, torch.log(torch.tensor(12., device='cuda')))
    loss.backward()
    assert proposal.grad[0, 1, 2] < 0  # Last generated gate acts first in reverse.
    assert proposal.grad[0, 0, 1] > 0
    assert bool((proposal.grad.diagonal(dim1=1, dim2=2) == 0).all().item())
    bad = PackedWalkBatch(identity_rows(1, 4), controls, targets, lengths)
    with pytest.raises(ValueError, match='replay failed'):
        verified_walk_teacher_loss(proposal.detach(), bad)
    with pytest.raises(ValueError, match='do not match'):
        verified_walk_teacher_loss(proposal.detach(), bad,
                                   interval_from_verified_walk(walk))
