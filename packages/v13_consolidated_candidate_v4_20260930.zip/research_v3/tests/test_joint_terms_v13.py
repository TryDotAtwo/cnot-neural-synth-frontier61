import unittest
import torch
from research_v3.gpu.joint_terms_v13 import JointTerms, merge_joint_terms


class JointTermsTests(unittest.TestCase):
    def test_mixed_width_denominators_match_reference_gradients(self):
        main = torch.tensor([1., 3., 5.], requires_grad=True)
        basis = torch.tensor([2., 8.], requires_grad=True)
        groups = (JointTerms(main[:2].mean(), 2, basis[0], 1),
                  JointTerms(main[2], 1, basis[1], 1))
        actual = merge_joint_terms(groups, weight=.1)
        expected = main.mean() + .1 * basis.mean()
        torch.testing.assert_close(actual, expected)
        for a, b in zip(torch.autograd.grad(actual, (main, basis)),
                        torch.autograd.grad(expected, (main, basis))):
            torch.testing.assert_close(a, b)

    def test_ineligible_small_group_does_not_dilute_basis(self):
        a, b, c = (torch.tensor(v, requires_grad=True) for v in (2., 5., 7.))
        actual = merge_joint_terms((JointTerms(a, 2, b, 1),
                                    JointTerms(c, 1, c * 0, 0)), weight=.1)
        torch.testing.assert_close(actual, (a * 2 + c) / 3 + .1 * b)

    def test_no_templates_and_invalid_counts(self):
        a = torch.tensor(3., requires_grad=True)
        torch.testing.assert_close(merge_joint_terms((JointTerms(a, 2, a * 0, 0),),
                                                     weight=.1), a)
        for count in (-1, True, 3):
            with self.assertRaises(ValueError):
                merge_joint_terms((JointTerms(a, 2, a, count),), weight=.1)


if __name__ == '__main__': unittest.main()
