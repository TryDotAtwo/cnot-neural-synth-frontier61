import unittest
from unittest.mock import patch
from dataclasses import replace
from research_v3.data.stream_solver_dataset_v13 import make_root
from research_v3.gpu.mixed_joint_records_v13 import RecordGroup, complete_mixed_joint_records


class MixedPreflightTests(unittest.TestCase):
    config = dict(choice_count=2, action_chunk=6, samples=2,
                  max_evaluations=5000, max_bytes=268435456, weight=.1)
    def test_late_bad_label_rejected_before_any_cuda_transfer_or_forward(self):
        first, _ = make_root('train', 0, 126, 0, 7000)
        bad = replace(first, split='test')
        groups = (RecordGroup((first,), object()), RecordGroup((bad,), object()))
        with patch('research_v3.gpu.mixed_joint_records_v13.own_records_to_cuda') as transfer:
            with patch('research_v3.gpu.mixed_joint_records_v13.complete_joint_basis_records') as forward:
                with self.assertRaisesRegex(ValueError, 'untrusted'):
                    complete_mixed_joint_records(None, groups, generator=None, **self.config)
                transfer.assert_not_called()
                forward.assert_not_called()

    def test_missing_bank_is_not_silently_disabled(self):
        first, _ = make_root('train', 0, 126, 0, 7000)
        with self.assertRaisesRegex(ValueError, 'sealed holdout'):
            complete_mixed_joint_records(None, (RecordGroup((first,), None),),
                                         generator=None, **self.config)

    def test_nonfinite_weight_and_hidden_bool_budget_rejected_before_transfer(self):
        first, _ = make_root('train', 0, 126, 0, 7000)
        for name, value in (('weight', float('nan')), ('qhat_weight', float('inf')),
                            ('max_evaluations', True), ('samples', 0)):
            with patch('research_v3.gpu.mixed_joint_records_v13.own_records_to_cuda') as transfer:
                with self.assertRaises(ValueError):
                    complete_mixed_joint_records(None, (RecordGroup((first,), object()),),
                                                 generator=None, **{**self.config, name: value})
                transfer.assert_not_called()


if __name__ == '__main__': unittest.main()
