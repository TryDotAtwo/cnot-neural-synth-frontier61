from dataclasses import replace
import unittest
from research_v3.data.stream_solver_dataset_v13 import make_root
from research_v3.gpu.record_batch_v13 import validate_own_records, validate_own_dev_records
from research_v3.train.neural_dev_search_v13 import search_dev_record, validate_dev_search_config


class DevSearchPreflightTests(unittest.TestCase):
    search = dict(beam_width=4, shortlist=16, inference_batch=8, max_expanded=1000)
    field = dict(mc_samples=8, mc_seed=17, max_pair_states=10000, head='qhat')

    def test_dev_reference_validation_does_not_expand_train_transfer_admission(self):
        train, _ = make_root('train', 0, 126, 0, 7000)
        dev = replace(train, split='dev')
        validate_own_dev_records((dev,))
        with self.assertRaises(ValueError): validate_own_records((dev,))
        with self.assertRaises(ValueError): validate_own_dev_records((train,))
        with self.assertRaises(ValueError):
            search_dev_record(None, train, search_config=self.search,
                              field_config=self.field, physical_cap=20)
        with self.assertRaises(ValueError): validate_own_dev_records((replace(dev, split='test'),))

    def test_work_budgets_are_explicit_and_integer(self):
        validate_dev_search_config(self.search, self.field, 20)
        for cap in (0, True, 1.5):
            with self.assertRaises(ValueError): validate_dev_search_config(self.search, self.field, cap)
        for name in self.search:
            with self.assertRaises(ValueError):
                validate_dev_search_config({**self.search, name: True}, self.field, 20)
        with self.assertRaises(ValueError): validate_dev_search_config({}, self.field, 20)


if __name__ == '__main__': unittest.main()
