"""Trusted primitive expansion must agree with the validating public operation."""
import random

from research_v3.contracts import AlphabetSpec, MatrixState
from research_v3.data.exact_small import build_exact_small
from research_v3.search.reference import _successor_known_gate
from research_v3.words import apply


def test_trusted_successor_exhaustive_gl3():
    alphabet = AlphabetSpec.all_to_all(3)
    catalog = build_exact_small(3, alphabet)
    assert catalog.status == 'complete' and len(catalog.distances) == 168
    for state in catalog.distances:
        for gate in alphabet.allowed:
            assert _successor_known_gate(state, gate) == apply(state, gate, alphabet)


def test_trusted_successor_random_wide():
    rng = random.Random(27403)
    for n in (8, 34, 72, 144):
        alphabet = AlphabetSpec.all_to_all(n)
        state = MatrixState.identity(alphabet)
        for _ in range(24):
            gate = rng.choice(alphabet.allowed)
            state = apply(state, gate, alphabet)
            probe = rng.choice(alphabet.allowed)
            assert _successor_known_gate(state, probe) == apply(state, probe, alphabet)
