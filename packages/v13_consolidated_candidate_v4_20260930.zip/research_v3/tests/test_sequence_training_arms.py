import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from research_v3.cli.sequence_training_arms import check_pilot, verify_snapshot


class SequenceTrainingArmsTests(unittest.TestCase):
    def test_snapshot_hash_and_pilot_completion_gate(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            snapshot = root / 'snapshot'
            source = snapshot / 'research_v3'
            (source / 'configs').mkdir(parents=True)
            (source / 'module.py').write_text('value = 1\n', encoding='utf-8')
            (source / 'configs/train.json').write_text('{}', encoding='utf-8')
            digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
            (snapshot / 'source_manifest.json').write_text(json.dumps({
                'snapshot_root': str(source), 'source_files': {'module.py': digest(source / 'module.py')},
                'config': 'configs/train.json',
                'config_sha256': digest(source / 'configs/train.json')}), encoding='utf-8')
            verify_snapshot(snapshot, 'train.json')
            (source / 'module.py').write_text('value = 2\n', encoding='utf-8')
            with self.assertRaisesRegex(ValueError, 'source drift'):
                verify_snapshot(snapshot, 'train.json')

            run = root / 'pilot'
            run.mkdir()
            self.assertFalse(check_pilot(run))
            checkpoint = run / 'step-000000640.pt'
            checkpoint.write_bytes(b'checkpoint')
            (run / 'last.json').write_text(json.dumps({
                'progress': {'attempted': 640}, 'file': checkpoint.name,
                'sha256': digest(checkpoint)}), encoding='utf-8')
            (run / 'completion.json').write_text(json.dumps({
                'status': 'completed', 'progress': {'attempted': 639}}), encoding='utf-8')
            with self.assertRaisesRegex(ValueError, '640 updates'):
                check_pilot(run)
            (run / 'completion.json').write_text(json.dumps({
                'status': 'completed', 'progress': {'attempted': 640}}), encoding='utf-8')
            self.assertTrue(check_pilot(run))
            checkpoint.write_bytes(b'corrupted')
            with self.assertRaisesRegex(ValueError, 'hash/progress mismatch'):
                check_pilot(run)


if __name__ == '__main__':
    unittest.main()
