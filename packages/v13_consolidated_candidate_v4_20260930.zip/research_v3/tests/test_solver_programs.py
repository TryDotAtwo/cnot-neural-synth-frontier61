import unittest
from unittest.mock import patch

from research_v3.contracts import AlphabetSpec, MatrixState
from research_v3.data.solver_programs import walk_with_solver, basis_program, solution_suffixes
from research_v3.words import verify_word


class SolverProgramTests(unittest.TestCase):
    def test_walk_is_solved_and_best_checked_candidate_is_used(self):
        record, audit = walk_with_solver('ordinary_walk', 27004, 4, 7, split='train')
        self.assertTrue(audit['solver_called'])
        self.assertEqual(len(record.verified_words), 2)
        self.assertLessEqual(record.upper_bound, audit['walk_length'])
        alphabet = AlphabetSpec.all_to_all(4)
        for word in record.verified_words:
            verify_word(word, alphabet)
            self.assertEqual(word.start, record.state)
            self.assertEqual(word.end, MatrixState.identity(alphabet))
        suffixes = solution_suffixes(record)
        self.assertTrue(suffixes)
        self.assertEqual(suffixes[0].state, record.state)
        for suffix in suffixes:
            verify_word(suffix.verified_words[0], alphabet)
            self.assertEqual(suffix.split, 'train')
            self.assertEqual(suffix.seed, record.seed)

    def test_failed_solver_keeps_verified_inverse_walk(self):
        with patch('research_v3.data.solver_programs.solve_matrix_with_own_synth',
                   side_effect=RuntimeError('injected')):
            record, audit = walk_with_solver('poisson_walk', 27005, 4, 7, split='train')
        self.assertEqual(len(record.verified_words), 1)
        self.assertEqual(audit['synthesizer']['status'], 'failed_or_invalid')
        self.assertEqual(audit['selected_length'], record.upper_bound)

    def test_basis_program_and_split_guard(self):
        record, audit = basis_program(27006, 8, split='train')
        self.assertEqual(record.upper_bound, min(audit['candidate_lengths'].values()))
        self.assertTrue(solution_suffixes(record))
        with self.assertRaisesRegex(ValueError, 'train parent'):
            solution_suffixes(record.__class__(record.state, record.verified_words,
                                               record.lineage_id, record.seed, record.source, 'dev'))


if __name__ == '__main__':
    unittest.main()
