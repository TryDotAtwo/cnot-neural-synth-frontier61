import unittest
from research_v3.train.stream_runner_v13 import StreamTrainingConfig, StreamCursor


class StreamCursorV13Tests(unittest.TestCase):
    def test_resume_across_final_accepted_epoch_boundary(self):
        config = StreamTrainingConfig(1000, 10000, 1, 640, 7000)
        cursor = StreamCursor(config)
        state = dict(epoch=999, position=9998, roots_seen=9999998,
                     presentations=9999998, chain='1' * 64)
        cursor.load_state_dict(state)
        cursor.advance('2' * 64, 1)
        restored = StreamCursor(config)
        restored.load_state_dict(cursor.state_dict())
        cursor.advance('3' * 64, 2)
        restored.advance('3' * 64, 2)
        self.assertEqual(restored.state_dict(), cursor.state_dict())
        self.assertEqual(cursor.roots_seen, 10000000)
        self.assertEqual((cursor.epoch, cursor.position), (1000, 0))

    def test_routes_to_guarded_v13_sources(self):
        from research_v3.train import stream_runner_v13 as runner
        from research_v3.data import stream_reader_v13, stream_solver_dataset_v13
        self.assertIs(runner.read_position, stream_reader_v13.read_position)
        self.assertIs(runner.build_epoch, stream_solver_dataset_v13.build_epoch)


if __name__ == '__main__':
    unittest.main()
