import tempfile
import unittest
from pathlib import Path

from research_v3.data.stream_reader import admit_complete_neighbors, read_epoch, read_position
from research_v3.data.stream_solver_dataset import build_epoch, open_store, seal_holdout


class StreamReaderTests(unittest.TestCase):
    def test_verified_distinct_roots_and_suffixes(self):
        with tempfile.TemporaryDirectory() as directory:
            connection, _ = open_store(Path(directory) / 'stream.sqlite', seed_base=3700,
                                       expected_dev_roots=1, expected_test_roots=1)
            try:
                build_epoch(connection, split='dev', epoch=0, count=1, seed_base=3700)
                build_epoch(connection, split='test', epoch=0, count=1, seed_base=3700)
                seal_holdout(connection)
                build_epoch(connection, split='train', epoch=0, count=2, seed_base=3700)
                records = list(read_epoch(connection, 0, suffixes_per_root=2))
                self.assertEqual(len(records), 6)
                self.assertEqual(len({record.state.key for record in records}), 6)
                self.assertTrue(all(record.split == 'train' for record in records))
                first, digest = read_position(connection, 0, 0, suffixes_per_root=2)
                self.assertEqual(tuple(records[:3]), first)
                self.assertEqual(len(digest), 64)
                self.assertEqual(admit_complete_neighbors(connection, first), 3 * (1 + 8 * 7))
                augmented, same_digest = read_position(connection, 0, 0,
                                                        suffixes_per_root=1, augment_suffix=True)
                self.assertEqual(same_digest, digest)
                self.assertEqual(augmented[0], first[0])
                self.assertEqual(augmented[1].upper_bound, first[1].upper_bound)
                self.assertIn(':symmetry:', augmented[1].lineage_id)
                admit_complete_neighbors(connection, augmented)
            finally:
                connection.close()


if __name__ == '__main__':
    unittest.main()
