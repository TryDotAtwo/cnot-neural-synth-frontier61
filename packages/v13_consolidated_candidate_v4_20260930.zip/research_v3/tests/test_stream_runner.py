import sqlite3
import tempfile
import unittest
from pathlib import Path

from research_v3.train.stream_runner import (StreamCursor, StreamTrainingConfig,
                                            exclusive_run_lock, reconcile_journal,
                                            verify_cursor)


class StreamRunnerTests(unittest.TestCase):
    def test_crashed_journal_tail_is_archived_and_lock_can_reopen(self):
        config = StreamTrainingConfig(2, 2, 1, 1, 3700)
        cursor = StreamCursor(config)
        cursor.advance('a' * 64, 2)
        row = ('{"root_number":1,"epoch":0,"position":0,"root_digest":"' +
               'a' * 64 + '"}\n').encode('ascii')
        uncommitted = b'{"root_number":2,"partial":'
        with tempfile.TemporaryDirectory() as directory:
            run_dir = Path(directory)
            journal = run_dir / 'updates.jsonl'
            journal.write_bytes(row + uncommitted)
            with exclusive_run_lock(run_dir):
                with self.assertRaisesRegex(RuntimeError, 'active'):
                    with exclusive_run_lock(run_dir):
                        pass
                archive = reconcile_journal(run_dir, cursor)
            self.assertEqual(journal.read_bytes(), row)
            self.assertEqual(archive.read_bytes(), uncommitted)
            self.assertTrue((run_dir / 'training.lock').exists())
            with exclusive_run_lock(run_dir):
                self.assertIsNone(reconcile_journal(run_dir, cursor))

    def test_hash_linked_cursor_matches_ordered_rows(self):
        config = StreamTrainingConfig(2, 2, 1, 1, 3700)
        cursor = StreamCursor(config)
        connection = sqlite3.connect(':memory:')
        try:
            connection.execute('CREATE TABLE roots(split TEXT,epoch INTEGER,position INTEGER,root_digest TEXT)')
            for epoch, position, digest in ((0, 0, 'a' * 64), (0, 1, 'b' * 64),
                                            (1, 0, 'c' * 64)):
                connection.execute('INSERT INTO roots VALUES(?,?,?,?)',
                                   ('train', epoch, position, digest))
            cursor.advance('a' * 64, 2)
            cursor.advance('b' * 64, 2)
            cursor.advance('c' * 64, 2)
            self.assertEqual((cursor.epoch, cursor.position, cursor.roots_seen,
                              cursor.presentations), (1, 1, 3, 6))
            verify_cursor(connection, cursor)
            restored = StreamCursor(config)
            restored.load_state_dict(cursor.state_dict())
            verify_cursor(connection, restored)
            connection.execute("UPDATE roots SET root_digest=? WHERE epoch=0 AND position=1",
                               ('d' * 64,))
            with self.assertRaisesRegex(ValueError, 'chain mismatch'):
                verify_cursor(connection, restored)
        finally:
            connection.close()


if __name__ == '__main__':
    unittest.main()
