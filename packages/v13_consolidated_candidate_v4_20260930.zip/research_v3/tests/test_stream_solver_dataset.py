import sqlite3
import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch

from research_v3.data.stream_solver_dataset import build_epoch, epoch_seed, open_store, seal_holdout


class SolverDatasetStreamTests(unittest.TestCase):
    def test_own_solver_roots_split_before_suffix_and_resume(self):
        with tempfile.TemporaryDirectory() as directory:
            db = Path(directory) / 'roots.sqlite'
            connection, manifest = open_store(db, seed_base=3700,
                                              expected_dev_roots=1, expected_test_roots=1)
            try:
                with self.assertRaisesRegex(ValueError, 'holdout must be sealed'):
                    build_epoch(connection, split='train', epoch=0, count=1, seed_base=3700)
                dev = build_epoch(connection, split='dev', epoch=0, count=1, seed_base=3700)
                test = build_epoch(connection, split='test', epoch=0, count=1, seed_base=3700)
                seal = seal_holdout(connection)
                train = build_epoch(connection, split='train', epoch=0, count=1, seed_base=3700)
                resumed = build_epoch(connection, split='train', epoch=0, count=1, seed_base=3700)
                self.assertEqual(train['new_roots'], 1)
                self.assertGreater(train['suffix_states'], 0)
                self.assertEqual(dev['new_roots'], 1)
                self.assertEqual(test['new_roots'], 1)
                self.assertEqual(dev['suffix_states'], 0)
                self.assertGreater(seal['forbidden_or_onehop_hashes'], 0)
                self.assertEqual(resumed['new_roots'], 0)
                self.assertEqual(connection.execute('SELECT COUNT(*) FROM roots').fetchone()[0], 3)
                self.assertEqual(connection.execute('SELECT COUNT(DISTINCT matrix_json) FROM roots').fetchone()[0], 3)
                self.assertEqual(train['solver_attempts'], 1)
                self.assertIn('dataset_source_sha256', manifest)
                self.assertIn('data/solver_programs.py', manifest['dataset_source_sha256'])
                with self.assertRaisesRegex(sqlite3.IntegrityError, 'immutable'):
                    connection.execute("UPDATE roots SET seed=0 WHERE split='train'")
                self.assertEqual(dev['solver_attempts'], 1)
                self.assertGreaterEqual(train['verified_certificates'], 1)
                self.assertGreater(train['suffix_states'], train['verified_certificates'])
                self.assertNotEqual(epoch_seed('train', 0, 0, 0, 3700),
                                    epoch_seed('dev', 0, 0, 0, 3700))
                self.assertNotEqual(epoch_seed('train', 0, 0, 0, 3700),
                                    epoch_seed('train', 1, 0, 0, 3700))
            finally:
                connection.close()
            with self.assertRaisesRegex(ValueError, 'source drift'):
                open_store(db, seed_base=3701)

    def test_hash_collision_does_not_merge_distinct_full_matrices(self):
        with tempfile.TemporaryDirectory() as directory:
            connection, _ = open_store(Path(directory) / 'collisions.sqlite', seed_base=3700)
            try:
                with patch('research_v3.data.stream_solver_dataset.root_key', return_value='forced_hash'):
                    report = build_epoch(connection, split='dev', epoch=0, count=2, seed_base=3700)
                self.assertEqual(report['new_roots'], 2)
                rows = connection.execute('SELECT matrix_hash,matrix_json FROM roots').fetchall()
                self.assertEqual(len(rows), 2)
                self.assertEqual({row[0] for row in rows}, {'forced_hash'})
                self.assertEqual(len({row[1] for row in rows}), 2)
            finally:
                connection.close()


if __name__ == '__main__':
    unittest.main()
