import unittest
import torch

from research_v3.contracts import AlphabetSpec, MatrixBatch, MatrixState
from research_v3.features.registry import FeaturePolicy, FeatureRegistry
from research_v3.features.subspace_views import register_subspace_views
from research_v3.gf2 import inverse, transpose
from research_v3.model.field import FusionDistanceField
from research_v3.symmetry import map_problem


class SubspaceViewsTests(unittest.TestCase):
    def test_exact_values_equivariance_and_both_transformer_gradients(self):
        torch.set_num_threads(1)
        torch.manual_seed(929)
        alphabet = AlphabetSpec.all_to_all(4)
        state = MatrixState(4, (1, 3, 6, 12), alphabet.id)
        relabeled = map_problem(state, alphabet, (2, 0, 3, 1)).state
        registry = FeatureRegistry()
        register_subspace_views(registry)
        ids = ('A01', 'C01', 'D03', 'H01', 'H02', 'H03', 'H04')
        packet = registry.build((state, relabeled), FeaturePolicy(ids))
        self.assertTrue(all(packet.features[key].available.all() for key in ids))
        self.assertEqual(packet.features['C01'].values[0, 0], 3)
        self.assertEqual(packet.features['D03'].values[0, 0, 1].tolist(), [0., 1., 1.])
        for key, rows in (('H01', state.packed_rows), ('H02', transpose(state.packed_rows)),
                          ('H03', inverse(state.packed_rows)),
                          ('H04', transpose(inverse(state.packed_rows)))):
            actual = packet.features[key].values[0, :, :, 0]
            self.assertEqual(tuple(sum(int(actual[i, j]) << j for j in range(4)) for i in range(4)), rows)
        model = FusionDistanceField([registry.specs[key] for key in ids], d=24, pair_d=8,
                                    blocks=2, heads=4, ffn=48, fusion_blocks=2).double()
        out = model(MatrixBatch.from_states((state, relabeled)), packet).value
        torch.testing.assert_close(out[0], out[1], rtol=1e-9, atol=1e-9)
        out.sum().backward()
        for key in ids:
            grad = model.stem.projections[key].weight.grad
            self.assertIsNotNone(grad)
            self.assertGreater(grad.abs().sum().item(), 0, key)
        for prefix in ('stem.blocks', 'fusion.blocks'):
            total = sum(p.grad.abs().sum().item() for name, p in model.named_parameters()
                        if name.startswith(prefix) and p.grad is not None)
            self.assertGreater(total, 0, prefix)


if __name__ == '__main__':
    unittest.main()
