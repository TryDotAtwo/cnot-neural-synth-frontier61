import unittest
from dataclasses import replace

from research_v3.contracts import AlphabetSpec, Gate
from research_v3.data.generators import record_from_word
from research_v3.data.symmetry_records import augment_record


class SymmetryRecordTests(unittest.TestCase):
    def test_invert_transpose_relabel_replay_complete_words(self):
        alphabet = AlphabetSpec.all_to_all(5)
        word = (Gate(0, 1), Gate(2, 4), Gate(1, 3), Gate(4, 0), Gate(3, 2))
        original = replace(record_from_word(alphabet, word, 'own_symmetry_fixture', 9),
                           split='train')
        for transform in ('inverse', 'transpose', tuple(reversed(range(5)))):
            with self.subTest(transform=transform):
                mapped = augment_record(original, transform)
                self.assertEqual(mapped.upper_bound, original.upper_bound)
                self.assertEqual(mapped.split, 'train')
                self.assertIsNone(mapped.exact_distance)
                self.assertEqual(mapped.verified_words[0].start, mapped.state)


if __name__ == '__main__':
    unittest.main()
