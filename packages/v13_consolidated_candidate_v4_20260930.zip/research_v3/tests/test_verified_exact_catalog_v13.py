from dataclasses import replace, FrozenInstanceError
import unittest
import json
from pathlib import Path
import torch
from research_v3.contracts import AlphabetSpec, MatrixState
from research_v3.data.exact_small import build_exact_small
from research_v3.data.verified_exact_catalog_v13 import VerifiedExactCatalog
from research_v3.gpu.record_batch_v13 import validate_own_records, own_records_to_cuda


class ExactCatalogContextTests(unittest.TestCase):
    def test_complete_catalog_anchor_and_false_or_incomplete_claims(self):
        alphabet = AlphabetSpec.all_to_all(3)
        context = VerifiedExactCatalog(build_exact_small(3, alphabet))
        self.assertEqual(len(context.records), 168)
        original = next(r for r in context.records.values() if r.exact_distance > 0)
        record = replace(original, split='train', lineage_id='exact_stream:0:99:3')
        self.assertEqual(context.validate(record), record)
        with self.assertRaisesRegex(ValueError, 'verified complete catalog'):
            validate_own_records((record,))
        self.assertEqual(validate_own_records((record,), exact_catalog=context)[0].physical_cost,
                         record.exact_distance)
        for bad in (replace(record, exact_distance=record.exact_distance + 1),
                    replace(record, split='test'), replace(record, exact_evidence='forged')):
            with self.assertRaises(ValueError): context.validate(bad)
        with self.assertRaises(ValueError):
            VerifiedExactCatalog(build_exact_small(3, alphabet, max_states=10))
        with self.assertRaises(TypeError): context.records[record.state.key] = record
        for name, value in (('records', {}), ('evidence', 'forged'),
                            ('alphabet', AlphabetSpec.all_to_all(4))):
            with self.assertRaises(FrozenInstanceError): setattr(context, name, value)


@unittest.skipUnless(torch.cuda.is_available(), 'Molab CUDA gate')
class ExactCatalogCudaTests(unittest.TestCase):
    def test_catalog_full_cuda_replay_and_joint_gradient(self):
        from research_v3.cli.probe_gpu_fullwidth_joint import _model
        from research_v3.gpu.joint_records_v13 import complete_joint_basis_records
        context = VerifiedExactCatalog(build_exact_small(3, AlphabetSpec.all_to_all(3)))
        record = replace(max(context.records.values(), key=lambda r: r.exact_distance),
                         split='train', lineage_id='exact_stream:cuda:3')
        batch = own_records_to_cuda((record,), exact_catalog=context)
        self.assertEqual(batch.exact_distances, (record.exact_distance,))
        config = json.loads((Path(__file__).resolve().parents[2] /
                             'full_training_config.json').read_text())
        model = _model(config).train()
        loss, audit = complete_joint_basis_records(model, batch, (record,),
            exact_catalog=context, generator=torch.Generator(device='cuda').manual_seed(9137),
            choice_count=2, action_chunk=6, samples=2, max_evaluations=5000,
            max_bytes=268435456, weight=.1, qhat_weight=.1, supervision_weight=1.,
            teacher_weight=.1, holdout=None, mc_samples=config['diffusion']['mc_samples'],
            mc_seed=config['feature_seed'], max_pair_states=config['diffusion']['max_pair_states'])
        loss.backward()
        self.assertTrue(torch.isfinite(loss).item())
        self.assertEqual(audit['exact_root_examples'], 1)
        gradients = [p.grad for p in model.parameters() if p.grad is not None]
        self.assertTrue(gradients)
        self.assertTrue(all(torch.isfinite(g).all().item() for g in gradients))
        self.assertGreater(sum(g.abs().sum().item() for g in gradients), 0)


if __name__ == '__main__': unittest.main()
