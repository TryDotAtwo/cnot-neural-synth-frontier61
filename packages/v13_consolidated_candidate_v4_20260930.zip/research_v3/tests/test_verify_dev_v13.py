import copy
from dataclasses import asdict, replace
import hashlib
import unittest
from research_v3.contracts import AlphabetSpec, Gate
from research_v3.data.generators import record_from_word
from research_v3.train.schedule import selection_key, selection_key_json
from research_v3.train.verify_dev_v13 import verify_dev_report


class VerifiedDevTests(unittest.TestCase):
    def fixture(self):
        record = replace(record_from_word(AlphabetSpec.all_to_all(3), (Gate(0, 1),),
                                          'dev:own', 7), split='dev')
        key = hashlib.sha256(repr(record.state.key).encode()).hexdigest()
        report = dict(total=1, solved=1, total_dev_compute_seconds=2.,
                      selection_key=selection_key_json(selection_key(
                          {key: 1}, {key: 1}, {key: 2}, 2., 640, 'a'*64)),
                      cases=[dict(key=key, state=asdict(record.state),
                                  lineage_id=record.lineage_id, reference_UB=1,
                                  result=dict(raw_search_word=asdict(record.verified_words[0])))])
        return record, report
    def test_verified_full_word_reproduces_protocol_key(self):
        record, report = self.fixture()
        self.assertEqual(verify_dev_report(report, (record,), cap_multiplier=2,
                                          checkpoint_sha='a'*64, update=640)[0], -1)
    def test_false_key_and_wrong_full_word_are_rejected(self):
        record, report = self.fixture()
        bad = copy.deepcopy(report); bad['selection_key'][0] = -2
        with self.assertRaises(ValueError):
            verify_dev_report(bad, (record,), cap_multiplier=2, checkpoint_sha='a'*64, update=640)
        bad = copy.deepcopy(report)
        bad['cases'][0]['result']['raw_search_word']['gates'][0]['target'] = 2
        with self.assertRaises(ValueError):
            verify_dev_report(bad, (record,), cap_multiplier=2, checkpoint_sha='a'*64, update=640)


if __name__ == '__main__':
    unittest.main()
