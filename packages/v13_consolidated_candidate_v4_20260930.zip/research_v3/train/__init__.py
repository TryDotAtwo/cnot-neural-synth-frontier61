"""Explicit-update reference training and immutable checkpoints."""
