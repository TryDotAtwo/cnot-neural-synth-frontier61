"""Pin stateful integrations to their approved own-source closure and config."""
import hashlib
import inspect
from pathlib import Path
from .checkpoint import canonical


def component_contract(component, approved_sources):
    provider = getattr(component, 'immutable_contract', None)
    if not callable(provider):
        raise ValueError('stateful integration lacks an immutable implementation contract')
    contract = provider()
    if (not isinstance(contract, dict) or
            set(contract) != {'schema', 'config', 'source_sha256'} or
            not isinstance(contract['schema'], str) or not contract['schema'] or
            not isinstance(contract['config'], dict) or not contract['source_sha256']):
        raise ValueError('invalid integration contract')
    canonical(contract)  # Reject nonserializable configuration and NaN.
    implementation = inspect.getsourcefile(type(component))
    if implementation is None:
        raise ValueError('integration implementation source is unavailable')
    own_root = Path(__file__).resolve().parents[2]
    files = {}
    for source, expected in contract['source_sha256'].items():
        path = Path(source).resolve()
        if not path.is_relative_to(own_root):
            raise ValueError('integration source is outside the own-source closure')
        if approved_sources.get(source) != expected:
            raise ValueError('integration source was not approved')
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            raise ValueError('integration implementation drift')
        files[str(path)] = actual
    if str(Path(implementation).resolve()) not in files:
        raise ValueError('integration class implementation is not pinned')
    return dict(schema=contract['schema'], config=contract['config'], source_sha256=files,
                implementation=type(component).__module__ + '.' + type(component).__qualname__)
