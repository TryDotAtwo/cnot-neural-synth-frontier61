"""Bounded-memory certified replay callback; candidate production integration."""
from dataclasses import replace
import copy
from .replay_refresh_v13 import CertifiedReplayRefresh
from .replay_store_v13 import ReplayJournal


class DiskReplayRefresh(CertifiedReplayRefresh):
    def __init__(self, solver, *, journal_path, every_updates, source_sha256,
                 forbidden_keys=()):
        super().__init__(solver, every_updates=every_updates,
                         source_sha256=source_sha256, forbidden_keys=forbidden_keys)
        self.journal = ReplayJournal(journal_path)

    def immutable_contract(self):
        contract = super().immutable_contract()
        contract['schema'] = 'certified_disk_replay_refresh_v13'
        contract['config']['storage_schema'] = 'own_replay_journal_v13'
        return contract

    def __call__(self, records, update):
        cursor = self.journal.cursor()
        solver_state = copy.deepcopy(self.solver.state_dict())
        output = []
        try:
            for record in records:
                cached = self.journal.get(record)
                if cached is not None:
                    if (cached.state != record.state or cached.source != record.source or
                            cached.lineage_id != record.lineage_id or
                            cached.exact_distance != record.exact_distance or
                            cached.exact_evidence != record.exact_evidence):
                        raise ValueError('disk replay root ownership/exact metadata mismatch')
                    record = replace(record, verified_words=tuple(sorted(set(
                        record.verified_words + cached.verified_words),
                        key=lambda word: (word.physical_cost, word.gates,
                                          word.producer, word.lineage_id))))
                # The reference verifier holds only this root, never the full stream.
                self.replays = {}
                self.events = []
                result = super().__call__((record,), update)[0]
                self.journal.append(result, self.events[-1])
                output.append(result)
            return tuple(output)
        except BaseException:
            self.journal.restore(cursor)
            self.solver.load_state_dict(solver_state)
            raise
        finally:
            self.replays = {}
            self.events = []

    def state_dict(self):
        return dict(schema='certified_disk_replay_refresh_v13',
                    cursor=self.journal.cursor(), solver=self.solver.state_dict())

    def load_state_dict(self, state):
        if state['schema'] != 'certified_disk_replay_refresh_v13':
            raise ValueError('disk replay checkpoint schema mismatch')
        self.journal.restore(state['cursor'])
        self.solver.load_state_dict(state['solver'])

    def close(self):
        self.journal.close()
