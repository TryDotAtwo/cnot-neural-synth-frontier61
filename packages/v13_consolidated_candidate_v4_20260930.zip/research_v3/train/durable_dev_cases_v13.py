"""Full frozen CUDA dev panel -> durable verified raw outcomes.

Caller owns the exclusive run lock and model/RNG isolation. This function
does not publish a selection report: per-case durations omit outer transaction
overhead and cannot stand in for full end-to-end panel compute.
"""
from dataclasses import asdict
from time import perf_counter
import torch

from .dev_journal_v13 import DevOutcomeJournal, canonical
from .frozen_dev_panel_v13 import FrozenDevPanel
from .neural_dev_search_v13 import search_dev_record
from .verify_cuda_dev_v13 import dev_outcome_cost


def evaluate_pending_dev_cases(model, panel, journal, *, checkpoint_sha, update):
    if type(panel) is not FrozenDevPanel or type(journal) is not DevOutcomeJournal:
        raise ValueError('full frozen dev panel and durable journal required')
    frozen = panel.manifest()
    references = frozen['ordered_references']
    expected = canonical({'schema': 'own_dev_outcome_journal_v13',
        'checkpoint_sha': checkpoint_sha, 'panel_sha': panel.sha256,
        'update': update, 'ordered_keys': tuple(r['key'] for r in references)})
    if expected != journal.identity:
        raise ValueError('dev journal belongs to a different checkpoint or full panel')
    device = next(model.parameters()).device
    if device.type != 'cuda':
        raise ValueError('full dev evaluation requires the CUDA neural field')
    # This also refuses an open attempt. A live process audit and separately
    # qualified compute accounting are required after an unclean shutdown.
    journal.measured_attempt_seconds()
    previous = journal.cases()
    for case, record, reference in zip(previous, panel.records, references):
        if (canonical(case['state']) != canonical(asdict(record.state)) or
                case['lineage_id'] != record.lineage_id or
                case['reference_UB'] != record.upper_bound):
            raise ValueError('stored dev input/reference changed')
        dev_outcome_cost(case.get('result'), record,
            physical_cap=reference['physical_cap'],
            search_config=frozen['search_config'], field_config=frozen['field_config'])
    for record, reference in zip(panel.records[len(previous):], references[len(previous):]):
        position, _ = journal.verify()
        attempt = journal.begin(position)
        started = perf_counter()
        try:
            try:
                result = search_dev_record(model, record,
                    physical_cap=reference['physical_cap'],
                    search_config=frozen['search_config'], field_config=frozen['field_config'])
            except torch.OutOfMemoryError:
                result = {'status': 'oom', 'raw_search_word': None,
                    'physical_cap': reference['physical_cap'],
                    'search_config': frozen['search_config'],
                    'field_config': frozen['field_config']}
                torch.cuda.empty_cache()
            except FloatingPointError:
                result = {'status': 'numerical_error', 'raw_search_word': None,
                    'physical_cap': reference['physical_cap'],
                    'search_config': frozen['search_config'],
                    'field_config': frozen['field_config']}
            dev_outcome_cost(result, record, physical_cap=reference['physical_cap'],
                search_config=frozen['search_config'], field_config=frozen['field_config'])
            torch.cuda.synchronize(device)
        except BaseException:
            # Synchronization failure leaves the attempt open with unknown
            # compute. Never mark asynchronous work complete without observing it.
            torch.cuda.synchronize(device)
            journal.finish(attempt, seconds=perf_counter() - started)
            raise
        journal.finish(attempt, seconds=perf_counter() - started,
            case={'key': reference['key'], 'state': asdict(record.state),
                  'lineage_id': record.lineage_id, 'reference_UB': record.upper_bound,
                  'result': result})
    return journal.cases()
