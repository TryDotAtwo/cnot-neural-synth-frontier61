"""Stateful full-panel raw CUDA evaluator candidate for the stream driver.

Clean first evaluations are supported. Recovery is deliberately unqualified
until an outer attempt ledger accounts for all interrupted transaction time.
The driver still owns model/RNG isolation and exclusive process ownership.
"""
import copy
from pathlib import Path
from time import perf_counter

from .checkpoint import digest
from .dev_journal_v13 import DevOutcomeJournal, canonical
from .durable_dev_cases_v13 import evaluate_pending_dev_cases
from .frozen_dev_panel_v13 import FrozenDevPanel
from .schedule import selection_key, selection_key_json
from .verify_cuda_dev_v13 import dev_outcome_cost, verify_cuda_dev_report


class DurableDevEvaluator:
    def __init__(self, panel, journal_dir, *, source_sha256):
        if type(panel) is not FrozenDevPanel:
            raise ValueError('actual frozen full 1792-root dev panel required')
        if not source_sha256:
            raise ValueError('approved own-source closure required')
        self.panel = panel
        self.journal_dir = Path(journal_dir).resolve()
        self._sources = copy.deepcopy(source_sha256)
        self._state = {'schema': 'own_durable_dev_evaluator_v13',
                       'frozen_panel_sha256': panel.sha256, 'last_report': None}

    def immutable_contract(self):
        return {'schema': 'own_durable_dev_evaluator_v13',
                'config': {'frozen_panel_sha256': self.panel.sha256,
                           'journal_dir': str(self.journal_dir),
                           'recovery_policy': 'reject_unaccounted_outer_transaction'},
                'source_sha256': copy.deepcopy(self._sources)}

    def state_dict(self):
        return copy.deepcopy(self._state)

    def load_state_dict(self, state):
        if (set(state) != set(self._state) or
                state['schema'] != self._state['schema'] or
                state['frozen_panel_sha256'] != self.panel.sha256):
            raise ValueError('durable evaluator state/panel changed')
        canonical(state)
        report = state['last_report']
        if report is not None:
            key = report['selection_key']
            verify_cuda_dev_report(report, self.panel, checkpoint_sha=key[4], update=key[3])
        self._state = copy.deepcopy(state)

    def recover(self, model, checkpoint, update):
        raise RuntimeError('full interrupted outer dev compute is not yet qualified; '
                           'audit processes and retain journals before recovery')

    def __call__(self, model, checkpoint, update):
        started = perf_counter()
        sha = digest(Path(checkpoint))
        frozen = self.panel.manifest()
        self.journal_dir.mkdir(parents=True, exist_ok=True)
        path = self.journal_dir / f'{update}_{sha}_{self.panel.sha256}.sqlite'
        if path.exists():
            raise RuntimeError('existing dev journal requires qualified recovery; '
                               'never reset accumulated compute')
        journal = DevOutcomeJournal(path, checkpoint_sha=sha, panel_sha=self.panel.sha256,
            update=update, ordered_keys=tuple(r['key'] for r in frozen['ordered_references']))
        try:
            cases = evaluate_pending_dev_cases(model, self.panel, journal,
                                              checkpoint_sha=sha, update=update)
            costs, upper, caps = {}, {}, {}
            for case, record, reference in zip(cases, self.panel.records,
                                              frozen['ordered_references']):
                key = reference['key']
                costs[key] = dev_outcome_cost(case['result'], record,
                    physical_cap=reference['physical_cap'],
                    search_config=frozen['search_config'], field_config=frozen['field_config'])
                upper[key], caps[key] = reference['reference_UB'], reference['physical_cap']
            journal.measured_attempt_seconds()
        finally:
            journal.close()
        elapsed = perf_counter() - started
        key = selection_key(costs, upper, caps, elapsed, update, sha)
        report = {'total': 1792, 'solved': -key[0], 'cases': list(cases),
                  'frozen_panel_sha256': self.panel.sha256,
                  'selection_protocol': 'EXPERIMENT_PROTOCOL_RU.md 7.4',
                  'total_dev_compute_seconds': elapsed,
                  'selection_key': selection_key_json(key)}
        verify_cuda_dev_report(report, self.panel, checkpoint_sha=sha, update=update)
        self._state['last_report'] = copy.deepcopy(report)
        return report
