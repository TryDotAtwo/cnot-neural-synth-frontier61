"""Complete development-panel evaluation using only verified search words."""
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import torch
from time import perf_counter
from ..contracts import AlphabetSpec, MatrixState
from ..features.registry import FeatureRegistry, FeaturePolicy
from ..model.field import FusionDistanceField
from ..basis.learning import BasisField
from ..features.diffusion import register_diffusion
from ..features.subspace_views import register_subspace_views
from ..features.basis_gradient import register_basis_gradient
from ..search.reference import SearchConfig, solve
from ..words import verify_word
from .schedule import selection_key, selection_key_json


def load_field(path, device='cpu'):
    path = Path(path)
    manifest = json.loads(path.with_suffix('.json').read_text(encoding='utf-8'))
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest != manifest['sha256'] or manifest['file'] != path.name:
        raise ValueError('checkpoint hash/file mismatch')
    payload = torch.load(path, map_location='cpu', weights_only=True)
    if payload['config'] != manifest['config']:
        raise ValueError('checkpoint manifest configuration mismatch')
    root = Path(__file__).resolve().parents[1]
    source_versions = payload['config'].get('source_versions')
    if source_versions is None:
        source_versions = payload['config']['training']['source_versions']
    versions = source_versions['code']
    normalized = {name.replace('\\','/'):value for name,value in versions.items()}
    required = {'model/'+name+'.py' for name in ('field','stem','fusion','family_heads','auxiliary')}
    required |= {'features/'+name+'.py' for name in ('registry','structural','cache','packet')}
    required |= {'contracts.py','gf2.py'}
    if not required <= normalized.keys():
        raise ValueError('missing inference source provenance')
    joint_schema = payload['config']['model_config']['schema']=='basis_fusion_field_v1'
    objective_config = payload['config']['objective_config']
    policy_config = (objective_config['base'] if joint_schema else objective_config)['policy'].copy()
    uses_diffusion = any(key.startswith('G') for key in policy_config['enabled_ids'])
    uses_subspace_views = any(key.startswith(('C', 'D', 'H')) for key in policy_config['enabled_ids'])
    if uses_subspace_views and 'features/subspace_views.py' not in normalized:
        raise ValueError('missing subspace/view inference source provenance')
    uses_basis_gradient = any(key.startswith('E') for key in policy_config['enabled_ids'])
    if uses_basis_gradient and 'features/basis_gradient.py' not in normalized:
        raise ValueError('missing basis-gradient inference source provenance')
    if uses_diffusion:
        diffusion_sources = {'features/diffusion.py'} | {
            'diffusion/'+name+'.py' for name in ('__init__','common','column','pair','probes')}
        if not diffusion_sources <= normalized.keys():
            raise ValueError('missing diffusion inference source provenance')
    for name, expected in normalized.items():
        if (name.startswith(('model/', 'features/')) or name in ('contracts.py', 'gf2.py') or
                (joint_schema and name.startswith('basis/')) or
                (uses_diffusion and name.startswith('diffusion/'))):
            source = (root / name).resolve()
            if not source.is_relative_to(root) or hashlib.sha256(source.read_bytes()).hexdigest() != expected:
                raise ValueError('checkpoint inference source drift: ' + name)
    config = payload['config']['model_config']
    if config['schema'] not in ('fusion_distance_field_v3_2','basis_fusion_field_v1'):
        raise ValueError('unsupported architecture schema')
    joint = config['schema']=='basis_fusion_field_v1'
    if joint:
        required_joint = {'basis/learning.py','basis/proposal.py','features/diffusion.py'}
        if not required_joint <= normalized.keys():
            raise ValueError('missing joint inference source provenance')
    registry = FeatureRegistry()
    if any(k.startswith(('C', 'D', 'H')) for k in policy_config['enabled_ids']):
        register_subspace_views(registry)
    if uses_basis_gradient:
        register_basis_gradient(registry)
    policy_config['enabled_ids'] = tuple(policy_config['enabled_ids'])
    policy = FeaturePolicy(**policy_config)
    if any(k.startswith('G') for k in policy.enabled_ids):
        launch = source_versions['launch_config']
        if 'diffusion' not in launch:
            raise ValueError('missing frozen diffusion producer configuration')
        register_diffusion(registry,**launch['diffusion'])
    field_config = config['field'] if joint else config
    if list(policy.enabled_ids) != field_config['feature_ids']:
        raise ValueError('feature order mismatch')
    field = FusionDistanceField([registry.specs[k] for k in policy.enabled_ids],
                                **{k:field_config[k] for k in ('d','pair_d','blocks','heads','ffn','fusion_blocks')})
    model = BasisField(field,config['basis_hidden']) if joint else field
    model.load_state_dict(payload['model'], strict=True)
    model.to(device).eval()
    return model, registry, policy, digest


def evaluate_panel(model, registry, policy, records, *, checkpoint_id, scoring,
                   beam_width, max_expansions, max_cost_multiplier, update, chunk_size=16, on_case=None, compute_start=None):
    start = perf_counter() if compute_start is None else compute_start
    records = tuple(records)
    if not records or len({r.state.key for r in records}) != len(records):
        raise ValueError('complete nonempty unique dev panel required')
    if any(r.split != 'dev' for r in records):
        raise ValueError('development evaluation refuses train/test records')
    if type(max_cost_multiplier) is not int or max_cost_multiplier < 1:
        raise ValueError('positive integer physical cost multiplier required')
    modes = {name:module.training for name,module in model.named_modules()}
    model.eval()
    cases, costs, references = [], {}, {}
    try:
        for record in records:
            alphabet = AlphabetSpec.all_to_all(record.state.n)
            for word in record.verified_words:
                verify_word(word, alphabet)
                if word.start != record.state or word.end != MatrixState.identity(alphabet):
                    raise ValueError('reference word root mismatch')
            if record.upper_bound == 0:
                raise ValueError('identity excluded from normalized dev selection panel')
            key = hashlib.sha256(repr(record.state.key).encode()).hexdigest()
            search_config = SearchConfig(alphabet, policy, scoring=scoring, beam_width=beam_width,
                                          max_expansions=max_expansions,
                                          max_cost=max_cost_multiplier * record.upper_bound,
                                          inference_batch_size=chunk_size, checkpoint_id=checkpoint_id)
            result = solve(record.state, model, registry, search_config)
            raw = result.raw_search_word
            costs[key] = None if raw is None else raw.physical_cost
            references[key] = record.upper_bound
            cases.append({'key':key, 'lineage_id':record.lineage_id, 'reference_UB':record.upper_bound,
                          'state':asdict(record.state), 'result':asdict(result)})
            if on_case is not None:
                on_case(cases[-1])
    finally:
        for name,module in model.named_modules():
            module.training = modes[name]
    compute_seconds = perf_counter() - start
    caps = {case['key']: max_cost_multiplier * case['reference_UB'] for case in cases}
    work = sum(case['result']['counts']['expanded'] for case in cases)
    return {'checkpoint_id':checkpoint_id, 'scoring':scoring, 'cases':cases,
            'solved':sum(value is not None for value in costs.values()), 'total':len(records),
            'selection_key':selection_key_json(selection_key(costs, references, caps, compute_seconds, update, checkpoint_id)),
            'selection_protocol':'EXPERIMENT_PROTOCOL_RU.md 7.4', 'total_dev_compute_seconds':compute_seconds,
            'expanded_parents':work, 'compute_tie_metric':'end_to_end_dev_seconds', 'update':update,
            'budget':dict(beam_width=beam_width,max_expansions=max_expansions,
                          max_cost_multiplier=max_cost_multiplier,chunk_size=chunk_size),
            'claims':'development comparison; no exact optimality or confirmatory generalization claim'}
