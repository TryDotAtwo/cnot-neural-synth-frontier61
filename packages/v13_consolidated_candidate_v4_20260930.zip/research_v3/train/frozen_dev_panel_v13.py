"""Fixed full-panel references, caps and decoder configuration before training."""
from collections import Counter
from dataclasses import asdict, dataclass
import hashlib
import json
from ..gpu.record_batch_v13 import validate_own_dev_records
from .neural_dev_search_v13 import validate_dev_search_config


def freeze_dev_reference(record, physical_cap):
    if type(physical_cap) is not int or physical_cap < 1:
        raise ValueError('positive frozen integer physical cap required')
    validate_own_dev_records((record,))
    return {'key': hashlib.sha256(repr(record.state.key).encode()).hexdigest(),
            'lineage_id': record.lineage_id, 'reference_UB': record.upper_bound,
            'physical_cap': physical_cap,
            'record_sha256': hashlib.sha256(json.dumps(asdict(record), sort_keys=True,
                separators=(',', ':'), allow_nan=False).encode()).hexdigest()}


@dataclass(frozen=True, init=False)
class FrozenDevPanel:
    records: tuple
    manifest_json: str
    sha256: str

    def __init__(self, records, *, search_config, field_config, cap_multiplier,
                 holdout_seal_sha256):
        records = tuple(records)
        widths = (8, 10, 13, 25, 26, 34, 45, 50, 58, 72, 90, 108, 122, 144)
        if (len(records) != 1792 or Counter(r.state.n for r in records) !=
                Counter({n: 128 for n in widths}) or
                len({r.state.key for r in records}) != len(records)):
            raise ValueError('full fixed unique 1792-root dev panel required')
        if type(cap_multiplier) is not int or cap_multiplier < 1:
            raise ValueError('positive frozen integer cap multiplier required')
        if (type(holdout_seal_sha256) is not str or len(holdout_seal_sha256) != 64 or
                any(c not in '0123456789abcdef' for c in holdout_seal_sha256)):
            raise ValueError('explicit sealed holdout identity required')
        validate_dev_search_config(search_config, field_config, 1)
        references = [freeze_dev_reference(r, cap_multiplier * r.upper_bound) for r in records]
        manifest = {'schema': 'own_frozen_dev_panel_v13', 'total': len(records),
                    'holdout_seal_sha256': holdout_seal_sha256,
                    'ordered_references': references, 'cap_multiplier': cap_multiplier,
                    'search_config': dict(search_config), 'field_config': dict(field_config)}
        raw = json.dumps(manifest, sort_keys=True, separators=(',', ':'), allow_nan=False)
        object.__setattr__(self, 'records', records)
        object.__setattr__(self, 'manifest_json', raw)
        object.__setattr__(self, 'sha256', hashlib.sha256(raw.encode()).hexdigest())

    def manifest(self):
        return json.loads(self.manifest_json)

    def state_dict(self):
        return {'schema': 'own_frozen_dev_panel_v13', 'panel_sha256': self.sha256}

    def load_state_dict(self, state):
        if state != self.state_dict():
            raise ValueError('frozen dev inputs/caps/decoder changed')
