"""Admission-aware full Bellman plus physical basis-cost learning arm."""
import hashlib
import math
import random
from ..basis.templates import BasisTemplate,BasisChoice
from ..contracts import MatrixState
from ..search.basis_macros import recognize_shear,partial_shear


class JointBasisObjective:
    def __init__(self,base,*,weight=.1,choices=3,samples=4,max_evaluations=64,max_bytes=256*1024*1024,seed=0,
                 operator_admission=None,compact_operator_audit=False):
        if not math.isfinite(weight) or weight<=0 or choices<1 or samples<1 or max_evaluations<0 or max_bytes<0:
            raise ValueError('invalid joint objective configuration')
        self.base,self.weight,self.choices,self.samples=base,weight,choices,samples
        self.max_evaluations,self.max_bytes,self.seed=max_evaluations,max_bytes,seed
        self.operator_admission=operator_admission
        if compact_operator_audit and operator_admission is None:
            raise ValueError('compact operator audit requires external admission')
        self.compact_operator_audit=compact_operator_audit
        self.admitted_operator_count=0
        self.calls=0; self.total_evaluations=0; self.operator_labels=set();self.last_diagnostics={}
        self.config={'id':'joint_basis_bellman_v1','base':base.config,'weight':weight,'choices':choices,
                     'samples':samples,'max_evaluations_per_batch':max_evaluations,'max_bytes':max_bytes,'seed':seed,
                     'template_symmetry':'augmentation_only','backend':'independent_conditional_mc',
                     'external_operator_admission':operator_admission is not None,
                     'compact_operator_audit':compact_operator_audit}

    def __call__(self,model,records):
        records=tuple(records); prepared=[]; required=0
        for record in records:
            state=record.state;parsed=recognize_shear(state);binding='full_shear'
            if parsed is None:
                partial=partial_shear(state);parsed=None if partial is None else partial[:3];binding='partial_elimination'
            if parsed is None:continue
            sources,targets,block=parsed
            if len(sources)<2:continue
            key=hashlib.sha256(repr((state.key,self.seed)).encode()).hexdigest()
            rng=random.Random(int(key[:16],16))
            pairs=rng.sample([(c,t) for c in range(len(sources)) for t in range(len(sources)) if c!=t],
                             min(self.choices,len(sources)*(len(sources)-1)))
            template=BasisTemplate(state.n,sources,targets,'source',tuple(BasisChoice('add',c,t) for c,t in pairs))
            rows=[1<<i for i in range(state.n)]
            for t,wire in enumerate(targets):
                for c,source in enumerate(sources):rows[wire]^=int(block[t,c])<<source
            operator=MatrixState(state.n,tuple(rows),state.alphabet_id)
            if operator.key in self.base.split.forbidden_keys:
                raise ValueError('forbidden basis operator label')
            if self.operator_admission is not None:
                self.operator_admission(operator)
            required+=self.samples*(1+2*len(pairs))
            if state.n*state.n*64+self.samples*(len(pairs)+1)*8>self.max_bytes:
                raise MemoryError('resource_limit: basis training workspace')
            prepared.append((state,template,block,binding,operator))
        if required>self.max_evaluations:
            raise RuntimeError('resource_limit: full batch basis gradient budget')
        # Base admission checks every root and full neighbor set before any model forward.
        main=self.base(model,records)
        costs=[];audits=[]
        for state,template,block,binding,operator in prepared:
            cost,audit=model.basis_loss(state,template,block,self.base.registry,self.base.policy,
                                        backend='mc',samples=self.samples,seed=self.seed+self.calls,
                                        max_evaluations=self.max_evaluations,max_bytes=self.max_bytes,binding=binding)
            costs.append(cost);audits.append(audit)
            if self.compact_operator_audit:self.admitted_operator_count+=1
            else:self.operator_labels.add(operator.key)
        self.calls+=1;self.total_evaluations+=required
        self.last_diagnostics={**self.base.last_diagnostics,'basis_templates':len(prepared),
                               'basis_evaluations':required,'basis_audits':audits,'objective_calls':self.calls}
        return main+self.weight*sum(costs)/len(costs) if costs else main

    def audit(self):
        report=self.base.audit()
        if self.compact_operator_audit:
            return {**report,'basis_operator_label_overlap':0,
                    'basis_operator_admission_checks':self.admitted_operator_count,
                    'strict_unseen':report['strict_unseen']}
        overlap=len(self.operator_labels & self.base.split.forbidden_keys)
        return {**report,'basis_operator_label_overlap':overlap,'strict_unseen':report['strict_unseen'] and overlap==0}

    def state_dict(self):
        state={'base':self.base.state_dict(),'calls':self.calls,'total_evaluations':self.total_evaluations}
        if self.compact_operator_audit:state['admitted_operator_count']=self.admitted_operator_count
        else:state['operator_labels']=sorted(self.operator_labels)
        return state

    def load_state_dict(self,state):
        self.base.load_state_dict(state['base'])
        self.calls,self.total_evaluations=state['calls'],state['total_evaluations']
        if self.compact_operator_audit:
            self.admitted_operator_count=state['admitted_operator_count']
        else:self.operator_labels={(n,a,tuple(rows)) for n,a,rows in state['operator_labels']}
        if not self.audit()['strict_unseen']:raise ValueError('forbidden saved basis exposure')
