"""Raw full-matrix CUDA neural search for explicitly budgeted dev records."""
from dataclasses import asdict
from time import perf_counter
import torch
from ..contracts import AlphabetSpec, Gate, MatrixState, WordCertificate
from ..gpu.neural_beam import beam_search, neural_field_callbacks
from ..gpu.record_batch_v13 import validate_own_dev_records
from ..words import verify_word


def validate_dev_search_config(search_config, field_config, physical_cap):
    expected = {'beam_width', 'shortlist', 'inference_batch', 'max_expanded'}
    if (set(search_config) != expected or any(type(v) is not int or v < 1
                                             for v in search_config.values()) or
            type(physical_cap) is not int or physical_cap < 1):
        raise ValueError('explicit positive dev work budgets and physical cap required')
    if (set(field_config) != {'mc_samples', 'mc_seed', 'max_pair_states', 'head'} or
            field_config['head'] not in ('qhat', 'proposal') or
            any(type(field_config[k]) is not int or field_config[k] < 1
                for k in ('mc_samples', 'max_pair_states')) or
            type(field_config['mc_seed']) is not int):
        raise ValueError('complete explicit dev field configuration required')


def search_dev_record(model, record, *, search_config, field_config, physical_cap):
    started = perf_counter()
    validate_dev_search_config(search_config, field_config, physical_cap)
    # Reference labels/words are checked, but never supplied as search incumbents.
    validate_own_dev_records((record,))
    device = next(model.parameters()).device
    if device.type != 'cuda':
        raise ValueError('dev search requires the live full CUDA field')
    n = record.state.n
    packed = [[(row >> (64 * slot)) & ((1 << 64) - 1)
               for slot in range((n + 63) // 64)] for row in record.state.packed_rows]
    signed = [[value - (1 << 64) if value & (1 << 63) else value for value in row]
              for row in packed]
    rows = torch.tensor([signed], device=device, dtype=torch.int64)
    modes = [(module, module.training) for module in model.modules()]
    try:
        model.eval()
        with torch.random.fork_rng(devices=[device.index if device.index is not None
                                            else torch.cuda.current_device()]):
            actions, states = neural_field_callbacks(model, **field_config)
            result = beam_search(rows, actions, states, max_depth=physical_cap, **search_config)
    finally:
        for module, mode in modes:
            module.training = mode
    word = None
    if result.word is not None:
        if not result.verified:
            raise ValueError('uncertified raw dev search word')
        alphabet = AlphabetSpec.all_to_all(n)
        word = WordCertificate(record.state, MatrixState.identity(alphabet),
                               tuple(Gate(c, t) for c, t in result.word), len(result.word),
                               'own_raw_neural_dev_v13', record.lineage_id)
        verify_word(word, alphabet)
        if word.physical_cost > physical_cap or result.expanded > search_config['max_expanded']:
            raise ValueError('raw dev word exceeded its frozen physical/work budget')
    torch.cuda.synchronize(device)
    return {'raw_search_word': None if word is None else asdict(word),
            'status': result.status, 'counts': {'expanded': result.expanded,
                'generated': result.generated, 'value_evaluations': result.value_evaluations},
            'search_result': asdict(result), 'physical_cap': physical_cap,
            'search_config': dict(search_config), 'field_config': dict(field_config),
            'end_to_end_search_seconds': perf_counter() - started}
