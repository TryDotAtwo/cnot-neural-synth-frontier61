"""Mixed-size complete-neighbor Bellman objective over verified own records."""
from dataclasses import asdict, replace
import hashlib
import math
import torch
from ..contracts import MatrixBatch, MatrixState
from ..data.replay import Replay
from ..data.splits import Exposures, SplitPolicy
from ..bounds import cheap_bounds, verify_bounds
from ..data.matching import verify_record
from ..words import apply
from ..objectives.bellman import select_backup, recompute_backup
from ..objectives.auxiliary import build_qhat_targets, absolute_qhat_loss
from .checkpoint import canonical


class FullGraphObjective:
    def __init__(self, alphabets, registry, policy, forbidden_keys=(), exact_catalogs=None,
                 bellman_weight=1., supervision_weight=1., qhat_weight=.1, neighbor_chunk_size=32,
                 external_admission=None, compact_exposures=False,
                 teacher_weight=0., teacher_temperature=4.):
        if type(neighbor_chunk_size) is not int or neighbor_chunk_size < 1:
            raise ValueError('positive neighbor chunk size required')
        self.neighbor_chunk_size = neighbor_chunk_size
        self.alphabets = {a.id:a for a in alphabets}
        if len(self.alphabets) != len(alphabets):
            raise ValueError('duplicate alphabet identity')
        self.registry, self.policy = registry, policy
        self.split = SplitPolicy(forbidden_keys)
        if compact_exposures and external_admission is None:
            raise ValueError('compact exposure audit requires external admission')
        self.external_admission = external_admission
        self.compact_exposures = compact_exposures
        self.compact_counts = {'label': 0, 'forward': 0, 'gradient': 0}
        self.weights = (bellman_weight, supervision_weight, qhat_weight, teacher_weight)
        if any(not math.isfinite(w) or w < 0 for w in self.weights) or sum(self.weights) <= 0:
            raise ValueError('invalid objective weights')
        if not math.isfinite(teacher_temperature) or teacher_temperature <= 0:
            raise ValueError('positive teacher preference temperature required')
        self.teacher_temperature = teacher_temperature
        self.exact = {}
        self.exact_sources = {}
        for key, catalog in (exact_catalogs or {}).items():
            replay = Replay(self.alphabets[key])
            replay.ingest_exact(catalog)
            self.exact.update({k:r.exact_distance for k,r in replay.records.items()})
            self.exact_sources[key] = sorted({r.exact_evidence for r in replay.records.values()})
        self.exposures = Exposures()
        self.last_diagnostics = {}
        self.config = {'id':'full_graph_reference_v1', 'alphabets':[asdict(a) for a in alphabets],
                       'policy':asdict(policy), 'weights':self.weights, 'exact_sources':self.exact_sources,
                       'neighbor_chunk_size':neighbor_chunk_size,
                       'external_admission':external_admission is not None,
                       'compact_exposures':compact_exposures,
                       'teacher_temperature':teacher_temperature,
                       'forbidden_sha256':hashlib.sha256(canonical(sorted(self.split.forbidden_keys)).encode()).hexdigest()}

    def _observe(self, kind, state):
        if self.compact_exposures:
            self.compact_counts[kind] += 1
        else:
            self.exposures.observe(kind, state)

    def __call__(self, model, records):
        records = tuple(records)
        if not records:
            raise ValueError('empty training batch')
        validated = []
        # Validate the entire batch before any label exposure, forward or gradient.
        for record in records:
            if record.split != 'train':
                raise ValueError('non-train record')
            alphabet = self.alphabets[record.state.alphabet_id]
            if self.external_admission is not None:
                self.external_admission(record.state)
                for gate in alphabet.allowed:
                    self.external_admission(apply(record.state, gate, alphabet))
            safe, _ = self.split.filter_full_backup((record,), alphabet)
            if not safe:
                raise ValueError('forbidden state in complete backup; reject whole parent')
            bounds = replace(cheap_bounds(record.state), upper=record.verified_words)
            verify_bounds(record.state, bounds, alphabet)
            if not record.verified_words:
                raise ValueError('missing verified upper bound')
            if record.exact_distance is not None:
                if self.exact.get(record.state.key) != record.exact_distance and not verify_record(record):
                    raise ValueError('unverified exact label')
            validated.append((record, alphabet, bounds))
        terms = []
        counts = {'examples':len(records), 'primitive_candidates':0, 'exact_examples':0,
                  'teacher_examples':0}
        device = next(model.parameters()).device
        for record, alphabet, bounds in validated:
            state = record.state
            if self.weights[1]:
                self._observe('label', state)
            self._observe('forward', state)
            self._observe('gradient', state)
            selection = select_backup(model, (state,), self.registry, self.policy, alphabet, chunk_size=self.neighbor_chunk_size)
            branch = selection.branches[0]
            if branch.successor is not None:
                self._observe('gradient', branch.successor)
                for gate in alphabet.allowed:
                    self._observe('forward', apply(state, gate, alphabet))
            report = recompute_backup(model, selection)
            counts['primitive_candidates'] += branch.primitive_count
            output = model(MatrixBatch.from_states((state,), device), self.registry.build((state,), self.policy))
            value = output.value[0]
            interval = torch.relu(bounds.lower_bound - value).square() + torch.relu(value - record.upper_bound).square()
            exact_loss = value * 0
            if record.exact_distance is not None:
                exact_loss = torch.nn.functional.smooth_l1_loss(value, value.new_tensor(record.exact_distance))
                counts['exact_examples'] += 1
            qloss = value * 0
            if self.weights[2]:
                if branch.successor is None:
                    targets, allowed = build_qhat_targets(model, (state,), self.registry, self.policy,
                                                          alphabet, chunk_size=self.neighbor_chunk_size)
                    for gate in alphabet.allowed:
                        self._observe('forward', apply(state, gate, alphabet))
                else:
                    if len(branch.primitive_totals) != len(alphabet.allowed):
                        raise ValueError('complete Bellman selection did not retain every primitive target')
                    targets = output.qhat.new_zeros(output.qhat.shape)
                    allowed = torch.zeros_like(output.qhat, dtype=torch.bool)
                    for gate, target in zip(alphabet.allowed, branch.primitive_totals):
                        targets[0, gate.control, gate.target] = target
                        allowed[0, gate.control, gate.target] = True
                qloss = absolute_qhat_loss(output.qhat, targets, allowed)
            teacher_loss = value * 0
            if self.weights[3] and record.verified_words:
                first_costs = {}
                for word in record.verified_words:
                    if word.gates:
                        gate = word.gates[0]
                        first_costs[gate] = min(first_costs.get(gate, word.physical_cost),
                                                word.physical_cost)
                if first_costs:
                    best = min(first_costs.values())
                    gates = tuple(first_costs)
                    scores = value.new_tensor([-(first_costs[gate] - best) /
                                               self.teacher_temperature for gate in gates])
                    probabilities = torch.softmax(scores, dim=0)
                    log_probs = torch.log_softmax(output.proposal[0].reshape(-1), dim=0)
                    indices = torch.tensor([gate.control * state.n + gate.target for gate in gates],
                                           dtype=torch.long, device=device)
                    teacher_loss = -(probabilities * log_probs[indices]).sum()
                    counts['teacher_examples'] += 1
            terms.append(self.weights[0] * report.loss + self.weights[1] * (interval + exact_loss) +
                         self.weights[2] * qloss + self.weights[3] * teacher_loss)
        self.last_diagnostics = counts
        return torch.stack(terms).mean()

    def audit(self):
        if self.compact_exposures:
            return {'strict_unseen': True, 'audit_mode': 'external_admission_before_forward',
                    'observation_counts':dict(self.compact_counts),
                    'stored_exposure_keys':0}
        return self.split.audit((), self.exposures)

    def state_dict(self):
        if self.compact_exposures:
            return {'compact_counts':dict(self.compact_counts)}
        return {name:sorted(getattr(self.exposures, name)) for name in
                ('seen_as_label', 'seen_by_forward', 'seen_by_gradient')}

    def load_state_dict(self, state):
        if self.compact_exposures:
            if set(state) != {'compact_counts'} or set(state['compact_counts']) != set(self.compact_counts):
                raise ValueError('compact exposure checkpoint mismatch')
            if any(type(value) is not int or value < 0 for value in state['compact_counts'].values()):
                raise ValueError('invalid compact exposure counts')
            self.compact_counts = dict(state['compact_counts'])
            return
        def key(value):
            return value[0], value[1], tuple(value[2])
        for name in ('seen_as_label', 'seen_by_forward', 'seen_by_gradient'):
            setattr(self.exposures, name, {key(value) for value in state[name]})
        if not self.audit()['strict_unseen']:
            raise ValueError('checkpoint exposures violate frozen split')
