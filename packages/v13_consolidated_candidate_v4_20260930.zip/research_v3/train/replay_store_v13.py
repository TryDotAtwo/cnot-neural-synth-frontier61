"""Disk-backed replay journal with bounded-memory checkpoint/rollback.

Candidate backend. One owner must hold the training run lock. Rewound tails
are retained in an archive; this module never modifies the source dataset.
"""
from dataclasses import asdict
import hashlib
import json
import sqlite3
import uuid
from ..data.stream_reader_v13 import decode_record


class ReplayJournal:
    def __init__(self, path):
        self.connection = sqlite3.connect(str(path))
        self.connection.execute('PRAGMA synchronous=FULL')
        self.connection.executescript('''
          CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY, value TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS entries(seq INTEGER PRIMARY KEY, key TEXT NOT NULL,
            record TEXT NOT NULL, event TEXT NOT NULL, chain TEXT NOT NULL);
          CREATE INDEX IF NOT EXISTS by_key ON entries(key, seq DESC);
          CREATE TABLE IF NOT EXISTS rewound(archive TEXT NOT NULL, seq INTEGER NOT NULL,
            key TEXT NOT NULL, record TEXT NOT NULL, event TEXT NOT NULL, chain TEXT NOT NULL);
        ''')
        with self.connection:
            self.connection.execute('INSERT OR IGNORE INTO metadata VALUES (?, ?)',
                                    ('identity', str(uuid.uuid4())))
        self.identity = self.connection.execute(
            "SELECT value FROM metadata WHERE key='identity'").fetchone()[0]

    @staticmethod
    def key(record):
        # Preserve source/lineage ownership even for identical matrix states.
        return json.dumps([record.state.key, record.source, record.lineage_id],
                          separators=(',', ':'))

    def get(self, record):
        row = self.connection.execute('SELECT seq,key,record,event,chain FROM entries WHERE key=? '
                                      'ORDER BY seq DESC LIMIT 1', (self.key(record),)).fetchone()
        if row is None:
            return None
        previous = self.connection.execute('SELECT chain FROM entries WHERE seq=?',
                                           (row[0] - 1,)).fetchone()
        self.verify_entry(row, previous[0] if previous else '0' * 64)
        decoded = decode_record(row[2])
        if self.key(decoded) != row[1]:
            raise ValueError('replay journal key/content mismatch')
        return decoded

    @staticmethod
    def verify_entry(row, previous_chain):
        seq, key, raw, event, chain = row
        expected = hashlib.sha256(json.dumps([previous_chain, seq, key, raw, event],
                                             separators=(',', ':')).encode()).hexdigest()
        if chain != expected:
            raise ValueError('replay journal content chain mismatch')

    def verify_prefix(self, limit):
        previous, expected_seq = '0' * 64, 1
        for row in self.connection.execute('SELECT seq,key,record,event,chain FROM entries '
                                           'WHERE seq<=? ORDER BY seq', (limit,)):
            if row[0] != expected_seq:
                raise ValueError('replay journal sequence gap')
            self.verify_entry(row, previous)
            previous, expected_seq = row[4], expected_seq + 1
        if expected_seq != limit + 1:
            raise ValueError('replay journal prefix missing')
        return previous

    def cursor(self):
        row = self.connection.execute('SELECT seq,chain FROM entries ORDER BY seq DESC LIMIT 1').fetchone()
        return dict(schema='own_replay_journal_v13', identity=self.identity,
                    seq=row[0] if row else 0, chain=row[1] if row else '0' * 64)

    def append(self, record, event):
        if record.split != 'train':
            raise ValueError('replay journal refuses nontrain records')
        raw = json.dumps(asdict(record), sort_keys=True, separators=(',', ':'), allow_nan=False)
        decode_record(raw)  # Full certificate and exact-claim verification.
        event_raw = json.dumps(event, sort_keys=True, separators=(',', ':'), allow_nan=False)
        with self.connection:
            self.connection.execute('BEGIN IMMEDIATE')
            previous = self.cursor()
            seq = previous['seq'] + 1
            key = self.key(record)
            chain = hashlib.sha256(json.dumps([previous['chain'], seq, key, raw, event_raw],
                                              separators=(',', ':')).encode()).hexdigest()
            self.connection.execute('INSERT INTO entries VALUES (?,?,?,?,?)',
                                    (seq, key, raw, event_raw, chain))
        return self.cursor()

    def restore(self, cursor):
        if (cursor.get('schema') != 'own_replay_journal_v13' or
                cursor.get('identity') != self.identity or
                type(cursor.get('seq')) is not int or cursor['seq'] < 0):
            raise ValueError('replay checkpoint identity/cursor mismatch')
        with self.connection:
            self.connection.execute('BEGIN IMMEDIATE')
            row = self.connection.execute('SELECT chain FROM entries WHERE seq=?',
                                          (cursor['seq'],)).fetchone()
            expected = row[0] if row else ('0' * 64 if cursor['seq'] == 0 else None)
            if expected != cursor['chain']:
                raise ValueError('replay checkpoint chain mismatch')
            if self.verify_prefix(cursor['seq']) != cursor['chain']:
                raise ValueError('replay checkpoint prefix mismatch')
            self.connection.execute('INSERT INTO rewound SELECT ?,seq,key,record,event,chain '
                                    'FROM entries WHERE seq>?', (str(uuid.uuid4()), cursor['seq']))
            self.connection.execute('DELETE FROM entries WHERE seq>?', (cursor['seq'],))

    def close(self):
        self.connection.close()
