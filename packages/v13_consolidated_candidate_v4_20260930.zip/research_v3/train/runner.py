"""Reference update guard. Explicit attempts, never a wall-clock stopper."""
import torch
from dataclasses import asdict, dataclass
from pathlib import Path
import hashlib
import json
import os
from .checkpoint import canonical, save_checkpoint, load_checkpoint
from .schedule import Sampler, Progress


@dataclass(frozen=True)
class TrainingConfig:
    updates: int
    batch_size: int
    seed: int
    checkpoint_every: int
    objective_id: str
    source_versions: dict

    def __post_init__(self):
        if (type(self.updates) is not int or self.updates < 0 or self.batch_size < 1 or
                self.checkpoint_every < 1 or not self.objective_id or not self.source_versions):
            raise ValueError('explicit updates, objective and source versions required')


def train_reference(model, optimizer, data, objective, config, run_dir, resume=None, stop_after=None):
    """Frozen-data runner. Objective returns a scalar over the sampled records.

    stop_after is an explicit interruption boundary for a resume test, not a
    wall-clock budget. No dynamic teacher refresh is silently performed here.
    """
    data = tuple(data)
    if not data:
        raise ValueError('empty training set')
    if any(record.split != 'train' for record in data):
        raise ValueError('all training records need an explicit train split')
    data_json = canonical([asdict(record) for record in data])
    contract = {'training':asdict(config), 'data_sha256':hashlib.sha256(data_json.encode()).hexdigest(),
                'model_config':getattr(model, 'config', None),
                'objective_config':getattr(objective, 'config', None),
                'optimizer':{'type':type(optimizer).__qualname__, 'defaults':optimizer.defaults}}
    # Validate JSON before creating a run or changing any state.
    contract = json.loads(canonical(contract))
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    lock_path = run_dir / 'training.lock'
    with lock_path.open('x', encoding='utf-8') as stream:
        stream.write(str(os.getpid()))
    try:
        sampler, progress = Sampler(len(data), config.seed), Progress()
        if resume is None:
            if (run_dir / 'last.json').exists() or (run_dir / 'updates.jsonl').exists():
                raise FileExistsError('existing run requires explicit resume')
        else:
            resume = Path(resume)
            last = json.loads((run_dir / 'last.json').read_text(encoding='utf-8'))
            if resume.resolve().parent != run_dir.resolve() or last['file'] != resume.name:
                raise ValueError('resume must use the current last snapshot in this run')
            extra = load_checkpoint(resume, model, optimizer, sampler, progress, contract)
            if hasattr(objective, 'load_state_dict'):
                objective.load_state_dict(extra['objective_state'])
            log_path = run_dir / 'updates.jsonl'
            entries = [json.loads(line) for line in log_path.read_text(encoding='utf-8').splitlines()]
            if [row['attempted'] for row in entries] != list(range(1, progress.attempted + 1)):
                raise ValueError('log/checkpoint divergence requires explicit recovery; refusing duplicate updates')
        target = config.updates if stop_after is None else min(config.updates, stop_after)
        if target < progress.attempted:
            raise ValueError('stop boundary precedes saved progress')
        checkpoint = Path(resume) if resume is not None else None
        with (run_dir / 'updates.jsonl').open('a', encoding='utf-8') as log:
            while progress.attempted < target:
                indices = sampler.next(config.batch_size)
                batch = tuple(data[i] for i in indices)
                loss = objective(model, batch)
                accepted = guarded_step(model, optimizer, loss, progress)
                entry = {'attempted':progress.attempted, 'accepted':accepted, 'indices':indices,
                         'lineages':[record.lineage_id for record in batch],
                         'objective_diagnostics':getattr(objective, 'last_diagnostics', {}),
                         'exposure_audit':objective.audit() if hasattr(objective, 'audit') else None,
                         'loss':float(loss.detach()) if torch.isfinite(loss).all() else None}
                log.write(canonical(entry) + '\n')
                log.flush()
                if progress.attempted % config.checkpoint_every == 0 or progress.attempted == target:
                    os.fsync(log.fileno())
                    extra = {'objective_state':objective.state_dict()} if hasattr(objective, 'state_dict') else {}
                    checkpoint = save_checkpoint(run_dir, model, optimizer, sampler, progress, contract, extra=extra)
        if checkpoint is None:
            extra = {'objective_state':objective.state_dict()} if hasattr(objective, 'state_dict') else {}
            checkpoint = save_checkpoint(run_dir, model, optimizer, sampler, progress, contract, extra=extra)
        return {'progress':asdict(progress), 'checkpoint':str(checkpoint),
                'status':'completed' if progress.attempted == config.updates else 'interrupted_at_explicit_update'}
    finally:
        lock_path.unlink()


def guarded_step(model, optimizer, loss, progress):
    progress.attempted += 1
    optimizer.zero_grad(set_to_none=True)
    if loss.numel() != 1 or not torch.isfinite(loss).all():
        progress.rejected += 1
        return False
    loss.backward()
    if any(p.grad is not None and not torch.isfinite(p.grad).all() for p in model.parameters()):
        optimizer.zero_grad(set_to_none=True)
        progress.rejected += 1
        return False
    optimizer.step()
    progress.accepted += 1
    return True
