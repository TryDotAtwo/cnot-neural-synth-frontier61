from dataclasses import dataclass
import math
from fractions import Fraction
import random


@dataclass
class Progress:
    attempted: int = 0
    accepted: int = 0
    rejected: int = 0


class Sampler:
    """Owned RNG and permutation cursor; one visit per item per epoch."""
    def __init__(self, size, seed):
        if type(size) is not int or size < 1:
            raise ValueError('positive dataset size required')
        self.size = size
        self.rng = random.Random(seed)
        self.order = []
        self.cursor = 0
        self.epochs = 0

    def next(self, count):
        if type(count) is not int or count < 1:
            raise ValueError('positive batch size required')
        result = []
        while len(result) < count:
            if self.cursor == len(self.order):
                self.order = list(range(self.size))
                self.rng.shuffle(self.order)
                self.cursor = 0
                self.epochs += 1
            take = min(count - len(result), self.size - self.cursor)
            result.extend(self.order[self.cursor:self.cursor + take])
            self.cursor += take
        return result

    def state_dict(self):
        return dict(size=self.size, order=self.order.copy(), cursor=self.cursor,
                    epochs=self.epochs, rng=self.rng.getstate())

    def load_state_dict(self, state):
        if (state['size'] != self.size or not 0 <= state['cursor'] <= len(state['order']) or
                (state['order'] and sorted(state['order']) != list(range(self.size)))):
            raise ValueError('sampler state mismatch')
        self.order = state['order'].copy()
        self.cursor, self.epochs = state['cursor'], state['epochs']
        self.rng.setstate(state['rng'])


def selection_key(costs, reference, caps, compute_seconds, update, checkpoint_sha):
    """Protocol 7.4: full fixed panel; exact rational cost; lower tuple wins."""
    if (not reference or set(costs)!=set(reference) or set(caps)!=set(reference) or
            type(update) is not int or update < 0 or not isinstance(checkpoint_sha,str) or
            len(checkpoint_sha)!=64 or any(c not in '0123456789abcdef' for c in checkpoint_sha) or
            not isinstance(compute_seconds,(float,int)) or not math.isfinite(compute_seconds) or compute_seconds<0):
        raise ValueError('invalid complete dev panel or checkpoint identity')
    total=Fraction(0)
    solved=0
    for key in sorted(reference):
        upper,cap,cost=reference[key],caps[key],costs[key]
        if (type(upper) is not int or upper<=0 or type(cap) is not int or cap<=0 or
                (cost is not None and (type(cost) is not int or cost<0))):
            raise ValueError('positive integer reference/cap and integer physical cost required')
        if cost is not None and cost<=cap:
            solved+=1
            total+=Fraction(cost,upper)
        else:
            total+=Fraction(cap+1,upper)
    return (-solved,total,float(compute_seconds),update,checkpoint_sha)


def selection_key_json(key):
    """Lossless JSON representation; deserialize the rational before comparing."""
    count,total,seconds,update,sha=key
    if not isinstance(total,Fraction):
        raise ValueError('selection key needs an exact Fraction')
    return [count,{'numerator':total.numerator,'denominator':total.denominator},seconds,update,sha]


def selection_key_from_json(value):
    if len(value)!=5 or set(value[1])!={'numerator','denominator'}:
        raise ValueError('invalid selection key serialization')
    return (value[0],Fraction(value[1]['numerator'],value[1]['denominator']),*value[2:])
