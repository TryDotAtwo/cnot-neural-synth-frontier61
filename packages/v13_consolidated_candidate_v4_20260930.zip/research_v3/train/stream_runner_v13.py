"""Versioned v13 reference stream routing, up to the accepted 1000 epochs.

This retains the CPU objective interface; it is not the production CUDA runner.
"""
from dataclasses import asdict, dataclass
from contextlib import contextmanager
import hashlib
import json
import os
import shutil
import uuid
from pathlib import Path
from time import perf_counter

import torch

from ..data.stream_reader_v13 import read_position
from ..data.stream_solver_dataset_v13 import build_epoch
from .checkpoint import canonical, load_checkpoint, save_checkpoint
from .runner import guarded_step
from .schedule import Progress


@dataclass(frozen=True)
class StreamTrainingConfig:
    epochs: int
    unique_roots_per_epoch: int
    suffixes_per_root: int
    checkpoint_every_roots: int
    seed_base: int
    augment_suffix: bool = False
    exact_every_roots: int = 0

    def __post_init__(self):
        if not 1 <= self.epochs <= 1000 or not 1 <= self.unique_roots_per_epoch <= 10_000 or \
                not 0 <= self.suffixes_per_root or self.checkpoint_every_roots < 1 or \
                self.exact_every_roots < 0:
            raise ValueError('invalid explicit stream training schedule')


class StreamCursor:
    def __init__(self, config):
        self.config = config
        self.epoch = 0
        self.position = 0
        self.roots_seen = 0
        self.presentations = 0
        self.chain = '0' * 64

    def advance(self, root_digest, presentations):
        if len(root_digest) != 64 or presentations < 1:
            raise ValueError('invalid verified root step')
        self.chain = hashlib.sha256(
            f'{self.chain}:{self.epoch}:{self.position}:{root_digest}'.encode('ascii')).hexdigest()
        self.roots_seen += 1
        self.presentations += presentations
        self.position += 1
        if self.position == self.config.unique_roots_per_epoch:
            self.epoch += 1
            self.position = 0

    def state_dict(self):
        return {'epoch': self.epoch, 'position': self.position,
                'roots_seen': self.roots_seen, 'presentations': self.presentations,
                'chain': self.chain}

    def load_state_dict(self, state):
        if set(state) != {'epoch', 'position', 'roots_seen', 'presentations', 'chain'} or \
                state['roots_seen'] != state['epoch'] * self.config.unique_roots_per_epoch + state['position'] or \
                not 0 <= state['epoch'] <= self.config.epochs or \
                not 0 <= state['position'] < self.config.unique_roots_per_epoch or \
                state['presentations'] < state['roots_seen'] or len(state['chain']) != 64:
            raise ValueError('invalid stream cursor checkpoint')
        if state['epoch'] == self.config.epochs and state['position'] != 0:
            raise ValueError('completed cursor has nonzero position')
        for name, value in state.items():
            setattr(self, name, value)


@contextmanager
def exclusive_run_lock(run_dir):
    """An OS lock releases on process death; the small lock file is persistent."""
    path = Path(run_dir) / 'training.lock'
    with path.open('a+b') as stream:
        stream.seek(0)
        if os.name == 'nt':
            import msvcrt
            lock_file = lambda: msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            unlock_file = lambda: msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            lock_file = lambda: fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            unlock_file = lambda: fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
        try:
            lock_file()
        except OSError as error:
            raise RuntimeError('training run is active in another process') from error
        try:
            stream.seek(0)
            stream.truncate()
            stream.write(str(os.getpid()).encode('ascii'))
            stream.flush()
            os.fsync(stream.fileno())
            yield
        finally:
            stream.seek(0)
            unlock_file()


def verify_cursor(connection, cursor):
    chain = '0' * 64
    count = 0
    for epoch, position, digest in connection.execute('''SELECT epoch,position,root_digest
        FROM roots WHERE split='train' AND (epoch<? OR (epoch=? AND position<?))
        ORDER BY epoch,position''', (cursor.epoch, cursor.epoch, cursor.position)):
        if epoch != count // cursor.config.unique_roots_per_epoch or \
                position != count % cursor.config.unique_roots_per_epoch:
            raise ValueError('trained root prefix has a gap')
        chain = hashlib.sha256(f'{chain}:{epoch}:{position}:{digest}'.encode('ascii')).hexdigest()
        count += 1
    if count != cursor.roots_seen or chain != cursor.chain:
        raise ValueError('training cursor/data chain mismatch')


def reconcile_journal(run_dir, cursor):
    """Preserve uncommitted rows after a crash, then restore the checkpoint prefix."""
    journal = Path(run_dir) / 'updates.jsonl'
    chain = '0' * 64
    with journal.open('rb') as stream:
        for index in range(cursor.roots_seen):
            line = stream.readline()
            if not line:
                raise ValueError('journal shorter than committed checkpoint')
            row = json.loads(line)
            epoch, position = divmod(index, cursor.config.unique_roots_per_epoch)
            if (row['root_number'] != index + 1 or row['epoch'] != epoch or
                    row['position'] != position):
                raise ValueError('journal order/cursor mismatch')
            chain = hashlib.sha256(
                f'{chain}:{epoch}:{position}:{row["root_digest"]}'.encode('ascii')).hexdigest()
        prefix_bytes = stream.tell()
        has_tail = bool(stream.read(1))
    if chain != cursor.chain:
        raise ValueError('journal/checkpoint hash mismatch')
    if not has_tail:
        return None
    suffix = uuid.uuid4().hex
    archive = Path(run_dir) / f'updates.uncommitted-after-{cursor.roots_seen:09d}-{suffix}.jsonl'
    with journal.open('rb') as source, archive.open('xb') as output:
        source.seek(prefix_bytes)
        shutil.copyfileobj(source, output)
        output.flush()
        os.fsync(output.fileno())
    temporary = Path(run_dir) / f'updates.committed-{suffix}.tmp'
    with journal.open('rb') as source, temporary.open('xb') as output:
        remaining = prefix_bytes
        while remaining:
            chunk = source.read(min(1 << 20, remaining))
            if not chunk:
                raise ValueError('journal changed during recovery')
            output.write(chunk)
            remaining -= len(chunk)
        output.flush()
        os.fsync(output.fileno())
    os.replace(temporary, journal)
    return archive


def train_stream(model, optimizer, objective, connection, run_dir, config, source_versions,
                 *, resume=None, stop_after_roots=None, exact_sampler=None):
    """One full update per new root, with optional verified solution suffixes."""
    if not objective.base.compact_exposures or not objective.base.config['external_admission'] or \
            not objective.compact_operator_audit or not objective.config['external_operator_admission']:
        raise ValueError('stream requires database admission and compact audits')
    manifest = json.loads(connection.execute("SELECT value FROM metadata WHERE key='manifest'").fetchone()[0])
    seal_row = connection.execute("SELECT value FROM metadata WHERE key='holdout_seal'").fetchone()
    if seal_row is None:
        raise ValueError('sealed holdout required')
    if manifest['seed_base'] != config.seed_base:
        raise ValueError('stream seed mismatch')
    if config.exact_every_roots and exact_sampler is None:
        raise ValueError('exact schedule requires a complete catalog sampler')
    contract = json.loads(canonical({
        'training': asdict(config), 'source_versions': source_versions,
        'dataset_manifest_sha256': hashlib.sha256(canonical(manifest).encode('utf-8')).hexdigest(),
        'holdout_seal_sha256': hashlib.sha256(seal_row[0].encode('utf-8')).hexdigest(),
        'model_config': model.config, 'objective_config': objective.config,
        'optimizer': {'type': type(optimizer).__qualname__, 'defaults': optimizer.defaults}}))
    run_dir = Path(run_dir)
    run_dir.mkdir(parents=True, exist_ok=True)
    with exclusive_run_lock(run_dir):
        cursor, progress = StreamCursor(config), Progress()
        if resume is None:
            if (run_dir / 'last.json').exists() or (run_dir / 'updates.jsonl').exists():
                raise FileExistsError('existing run requires explicit resume')
            with (run_dir / 'experiment_manifest.json').open('x', encoding='utf-8') as stream:
                json.dump(contract, stream, sort_keys=True, indent=2)
        else:
            resume = Path(resume)
            last = json.loads((run_dir / 'last.json').read_text(encoding='utf-8'))
            if resume.resolve().parent != run_dir.resolve() or last['file'] != resume.name:
                raise ValueError('resume must use the current last checkpoint')
            extra = load_checkpoint(resume, model, optimizer, cursor, progress, contract)
            objective.load_state_dict(extra['objective_state'])
            verify_cursor(connection, cursor)
            if progress.attempted != cursor.roots_seen or progress.accepted != cursor.roots_seen or \
                    progress.rejected != 0:
                raise ValueError('checkpoint progress/cursor mismatch')
            archived_tail = reconcile_journal(run_dir, cursor)
            if archived_tail is not None:
                print(canonical({'recovered_from_checkpoint': cursor.roots_seen,
                                 'uncommitted_journal_archive': str(archived_tail)}), flush=True)
        if stop_after_roots is not None and (stop_after_roots < cursor.roots_seen or
                                             stop_after_roots > config.epochs * config.unique_roots_per_epoch):
            raise ValueError('invalid explicit stop boundary')
        target = config.epochs * config.unique_roots_per_epoch
        if stop_after_roots is not None:
            target = stop_after_roots
        checkpoint = Path(resume) if resume else None
        with (run_dir / 'updates.jsonl').open('a', encoding='utf-8') as log:
            while cursor.roots_seen < target:
                epoch, position = cursor.epoch, cursor.position
                root_started = perf_counter()
                present = connection.execute(
                    "SELECT COUNT(*) FROM roots WHERE split='train' AND epoch=?", (epoch,)).fetchone()[0]
                if present <= position:
                    build_epoch(connection, split='train', epoch=epoch, count=position + 1,
                                seed_base=config.seed_base)
                records, digest = read_position(connection, epoch, position,
                                                suffixes_per_root=config.suffixes_per_root,
                                                augment_suffix=config.augment_suffix)
                if config.exact_every_roots and (cursor.roots_seen + 1) % config.exact_every_roots == 0:
                    records += (exact_sampler.record(epoch, position),)
                data_seconds = perf_counter() - root_started
                train_started = perf_counter()
                loss = objective(model, records)
                objective_seconds = perf_counter() - train_started
                step_started = perf_counter()
                if not guarded_step(model, optimizer, loss, progress):
                    raise RuntimeError(f'nonfinite training step at root {epoch}:{position}')
                backward_step_seconds = perf_counter() - step_started
                cursor.advance(digest, len(records))
                log.write(canonical({'root_number': cursor.roots_seen, 'epoch': epoch,
                                     'position': position, 'root_digest': digest,
                                     'presentations': len(records), 'loss': float(loss.detach()),
                                     'data_seconds': data_seconds,
                                     'objective_seconds': objective_seconds,
                                     'backward_step_seconds': backward_step_seconds,
                                     'objective_diagnostics': objective.last_diagnostics}) + '\n')
                log.flush()
                if cursor.roots_seen % config.checkpoint_every_roots == 0 or cursor.roots_seen == target:
                    os.fsync(log.fileno())
                    checkpoint = save_checkpoint(run_dir, model, optimizer, cursor, progress,
                                                 contract, extra={'objective_state': objective.state_dict()})
        if checkpoint is None:
            checkpoint = save_checkpoint(run_dir, model, optimizer, cursor, progress,
                                         contract, extra={'objective_state': objective.state_dict()})
        return {'status': 'completed' if cursor.roots_seen == config.epochs * config.unique_roots_per_epoch
                else 'interrupted_at_explicit_root', 'cursor': cursor.state_dict(),
                'progress': asdict(progress), 'checkpoint': str(checkpoint),
                'audit': objective.audit()}
