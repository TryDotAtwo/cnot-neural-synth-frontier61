"""Protocol raw-word success requires the frozen decoder and work budget."""
import json
from ..contracts import AlphabetSpec, MatrixState
from ..data.stream_reader import _certificate, _state
from ..words import verify_word
from .frozen_dev_panel_v13 import FrozenDevPanel
from .schedule import selection_key, selection_key_json


def _same_json(left, right):
    options = dict(sort_keys=True, separators=(',', ':'), allow_nan=False)
    return json.dumps(left, **options) == json.dumps(right, **options)


def dev_outcome_cost(result, record, *, physical_cap, search_config, field_config):
    """Return a successful raw cost or None; missing/invalid results stay failures."""
    if result is None:
        return None
    if (not _same_json(result.get('search_config'), search_config) or
            not _same_json(result.get('field_config'), field_config) or
            type(result.get('physical_cap')) is not int or result['physical_cap'] != physical_cap):
        raise ValueError('dev decoder or physical cap changed from frozen contract')
    statuses = {'solved', 'resource_limit', 'depth_limit', 'exhausted', 'numerical_error',
                'oom', 'invalid_certificate', 'interrupted', 'missing', 'budget_violation'}
    if result.get('status') not in statuses:
        raise ValueError('unrecognized raw dev outcome status')
    raw = result.get('raw_search_word')
    if raw is None:
        return None
    try:
        word = _certificate(raw)
        alphabet = AlphabetSpec.all_to_all(record.state.n)
        verify_word(word, alphabet)
    except (ValueError, TypeError, KeyError):
        return None
    counts = result.get('counts', {})
    if (word.start != record.state or word.end != MatrixState.identity(alphabet) or
            word.producer != 'own_raw_neural_dev_v13' or word.lineage_id != record.lineage_id or
            word.physical_cost > physical_cap or result['status'] != 'solved' or
            any(type(counts.get(name)) is not int or counts[name] < 0
                for name in ('expanded', 'generated', 'value_evaluations')) or
            counts['expanded'] > search_config['max_expanded']):
        return None
    return word.physical_cost


def verify_cuda_dev_report(report, frozen_panel, *, checkpoint_sha, update):
    if type(frozen_panel) is not FrozenDevPanel:
        raise ValueError('full immutable dev panel required')
    frozen = frozen_panel.manifest()
    if (report.get('frozen_panel_sha256') != frozen_panel.sha256 or
            report.get('total') != 1792 or
            report.get('selection_protocol') != 'EXPERIMENT_PROTOCOL_RU.md 7.4'):
        raise ValueError('full report and frozen panel identity required')
    cases = report['cases']
    references = frozen['ordered_references']
    if len(cases) != len(references) or [case['key'] for case in cases] != [r['key'] for r in references]:
        raise ValueError('dev outcome order or coverage differs from fixed panel')
    costs, upper, caps = {}, {}, {}
    for case, record, reference in zip(cases, frozen_panel.records, references):
        if (_state(case['state']) != record.state or
                case['lineage_id'] != reference['lineage_id'] or
                case['reference_UB'] != reference['reference_UB']):
            raise ValueError('fixed dev input/reference changed')
        key = reference['key']
        costs[key] = dev_outcome_cost(case.get('result'), record,
            physical_cap=reference['physical_cap'], search_config=frozen['search_config'],
            field_config=frozen['field_config'])
        upper[key], caps[key] = reference['reference_UB'], reference['physical_cap']
    key = selection_key(costs, upper, caps, report['total_dev_compute_seconds'], update, checkpoint_sha)
    if report['selection_key'] != selection_key_json(key) or report['solved'] != -key[0]:
        raise ValueError('raw budget-compliant dev selection key is false')
    return key
