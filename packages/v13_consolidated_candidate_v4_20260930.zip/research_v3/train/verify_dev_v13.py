"""Recompute protocol selection from frozen inputs and complete raw words."""
import hashlib
from ..contracts import AlphabetSpec, MatrixState
from ..data.stream_reader import _state, _certificate
from ..words import verify_word
from .schedule import selection_key, selection_key_json


def verify_dev_report(report, panel, *, cap_multiplier, checkpoint_sha, update):
    panel = tuple(panel)
    if not panel or any(r.split != 'dev' for r in panel):
        raise ValueError('fixed dev panel required')
    expected = {hashlib.sha256(repr(r.state.key).encode()).hexdigest(): r for r in panel}
    if len(expected) != len(panel) or report['total'] != len(panel):
        raise ValueError('duplicate or incomplete dev panel')
    cases = report['cases']
    if len(cases) != len(panel) or {c['key'] for c in cases} != set(expected):
        raise ValueError('dev outcomes do not cover the frozen panel')
    costs, references, caps = {}, {}, {}
    for case in cases:
        key = case['key']; record = expected[key]
        if (_state(case['state']) != record.state or
                case['lineage_id'] != record.lineage_id or
                case['reference_UB'] != record.upper_bound):
            raise ValueError('dev input, lineage or reference changed')
        alphabet = AlphabetSpec.all_to_all(record.state.n)
        for reference in record.verified_words:
            verify_word(reference, alphabet)
            if reference.start != record.state or reference.end != MatrixState.identity(alphabet):
                raise ValueError('wrong reference full-matrix endpoints')
        raw = case['result']['raw_search_word']
        word = None if raw is None else _certificate(raw)
        if word is not None:
            verify_word(word, alphabet)
            if word.start != record.state or word.end != MatrixState.identity(alphabet):
                raise ValueError('raw dev word solves another matrix')
        costs[key] = None if word is None else word.physical_cost
        references[key] = record.upper_bound
        caps[key] = cap_multiplier * record.upper_bound
    key = selection_key(costs, references, caps, report['total_dev_compute_seconds'],
                        update, checkpoint_sha)
    if report['selection_key'] != selection_key_json(key) or report['solved'] != -key[0]:
        raise ValueError('dev solved count or exact selection key is false')
    return key
