from .contracts import MatrixState


def apply(state, gate, alphabet):
    if state.n != alphabet.n or state.alphabet_id != alphabet.id:
        raise ValueError('state/alphabet mismatch')
    alphabet.cost(gate)
    rows = list(state.packed_rows)
    rows[gate.target] ^= rows[gate.control]
    return MatrixState(state.n, tuple(rows), state.alphabet_id)


def invert_word(word):
    return tuple(reversed(word))


def verify_word(cert, alphabet):
    if type(cert.physical_cost) is not int or cert.physical_cost < 0:
        raise ValueError('invalid physical cost')
    if cert.start.n != alphabet.n or cert.start.alphabet_id != alphabet.id:
        raise ValueError('state/alphabet mismatch')
    state = cert.start
    cost = 0
    for gate in cert.gates:
        cost += alphabet.cost(gate)
        state = apply(state, gate, alphabet)
    if state != cert.end:
        raise ValueError('word endpoint mismatch')
    if cost != cert.physical_cost:
        raise ValueError('word cost mismatch')
