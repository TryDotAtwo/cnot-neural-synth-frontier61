"""CUDA stream driver; launch requires sealed panels and stateful integrations.

Data production, replay refresh and full dev evaluation are explicit owners.
This driver never falls back to CPU generation or a shortened dev panel.
"""
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
from time import perf_counter

import torch

from ..data.stream_reader_v13 import read_position, _manifest
from ..gpu.record_batch_v13 import own_records_to_cuda
from ..gpu.joint_records_v13 import complete_joint_basis_records
from .checkpoint import canonical, save_checkpoint, load_checkpoint, atomic_json, digest
from .runner import guarded_step
from .schedule import Progress, selection_key_from_json
from .stream_runner_v13 import StreamCursor, exclusive_run_lock, verify_cursor, reconcile_journal


def require_integrations(connection, config, banks, bank_audit, producer, replay, evaluate):
    manifest = _manifest(connection, 0)
    if (manifest['seed_base'] != config.seed_base or
            manifest['epochs'] != config.epochs or
            manifest['new_unique_roots_per_epoch'] != config.unique_roots_per_epoch):
        raise ValueError('stream schedule and sealed dataset differ')
    expected = manifest['expected_dev_roots']
    if (expected != 1792 or manifest['expected_test_roots'] != 1792 or
            bank_audit['dev_roots'] != expected or bank_audit['test_roots'] != 1792):
        raise ValueError('full confirmatory dev/test panels required')
    widths = {8, 10, 13, 25, 26, 34, 45, 50, 58, 72, 90, 108, 122, 144}
    if not widths.issubset(banks):
        raise ValueError('sealed GPU bank missing a width')
    for component in (producer, replay, evaluate):
        if not callable(component) or not all(callable(getattr(component, n, None))
                                             for n in ('state_dict', 'load_state_dict')):
            raise ValueError('stateful producer, replay refresh and dev evaluator required')
    return manifest


def train_cuda_stream(model, optimizer, connection, run_dir, config, *, banks,
                      bank_audit, producer, replay, evaluate, joint_config,
                      source_versions, generator, resume=None):
    manifest = require_integrations(connection, config, banks, bank_audit,
                                    producer, replay, evaluate)
    if generator.device.type != 'cuda' or next(model.parameters()).device.type != 'cuda':
        raise ValueError('CUDA model and durable CUDA basis generator required')
    contract = json.loads(canonical(dict(schema='cuda_stream_v13', training=asdict(config),
                                        dataset_manifest=manifest, sources=source_versions,
                                        joint=joint_config, bank_audit=bank_audit)))
    root = Path(run_dir); root.mkdir(parents=True, exist_ok=True)
    cursor, progress = StreamCursor(config), Progress()
    def extra():
        return dict(basis_rng=generator.get_state(), producer=producer.state_dict(),
                    replay=replay.state_dict(), evaluator=evaluate.state_dict())
    with exclusive_run_lock(root):
        if resume is None:
            if (root/'last.json').exists() or (root/'updates.jsonl').exists():
                raise FileExistsError('existing run requires explicit resume')
            atomic_json(root/'experiment_manifest.json', contract)
        else:
            last = json.loads((root/'last.json').read_text())
            if Path(resume).resolve() != (root/last['file']).resolve():
                raise ValueError('resume requires the committed last snapshot')
            state = load_checkpoint(resume, model, optimizer, cursor, progress, contract)
            generator.set_state(state['basis_rng'])
            for name, component in (('producer', producer), ('replay', replay), ('evaluator', evaluate)):
                component.load_state_dict(state[name])
            verify_cursor(connection, cursor)
            reconcile_journal(root, cursor)
        target = config.epochs * config.unique_roots_per_epoch
        with (root/'updates.jsonl').open('a', encoding='utf-8') as log:
            while cursor.roots_seen < target:
                epoch, position = cursor.epoch, cursor.position
                started = perf_counter()
                # Producer owns its native provenance and complete root transaction.
                producer(connection, epoch, position)
                records, root_digest = read_position(
                    connection, epoch, position, suffixes_per_root=config.suffixes_per_root,
                    augment_suffix=config.augment_suffix)
                records = tuple(replay(records, cursor.roots_seen))
                batch = own_records_to_cuda(records)
                n = records[0].state.n
                optimizer.zero_grad(set_to_none=True)
                loss, audit = complete_joint_basis_records(
                    model, batch, records, generator=generator, holdout=banks[n], **joint_config)
                if not guarded_step(model, optimizer, loss, progress):
                    raise RuntimeError('nonfinite CUDA stream step')
                torch.cuda.synchronize()
                cursor.advance(root_digest, len(records))
                log.write(canonical(dict(root_number=cursor.roots_seen, epoch=epoch,
                                         position=position, root_digest=root_digest,
                                         presentations=len(records), loss=float(loss.detach()),
                                         exact_root_examples=audit['exact_root_examples'],
                                         end_to_end_seconds=perf_counter()-started))+'\n')
                log.flush()
                if cursor.roots_seen % config.checkpoint_every_roots == 0 or cursor.roots_seen == target:
                    os.fsync(log.fileno())
                    path = save_checkpoint(root, model, optimizer, cursor, progress, contract, extra=extra())
                    report = evaluate(model, path, progress.attempted)
                    if (report['total'] != 1792 or report['selection_protocol'] != 'EXPERIMENT_PROTOCOL_RU.md 7.4'):
                        raise ValueError('incomplete or nonnormative dev evaluation')
                    key = selection_key_from_json(report['selection_key'])
                    if key[3:] != (progress.attempted, digest(path)):
                        raise ValueError('dev report checkpoint identity mismatch')
                    atomic_json(root/(path.stem+'.dev.json'), report)
                    previous = root/'best_dev.json'
                    if not previous.exists() or key < selection_key_from_json(json.loads(previous.read_text())['selection_key']):
                        atomic_json(previous, report)
                        atomic_json(root/'best.json', json.loads(path.with_suffix('.json').read_text()))
        return dict(status='completed', cursor=cursor.state_dict(), progress=asdict(progress))
