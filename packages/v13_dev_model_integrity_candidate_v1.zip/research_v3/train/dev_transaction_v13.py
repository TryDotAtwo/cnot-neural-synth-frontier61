"""Durable dev completion and RNG isolation for immutable train snapshots."""
import json
import os
from pathlib import Path
from time import perf_counter
import torch

from .checkpoint import atomic_json, digest, rng_state, restore_rng
from .schedule import selection_key_from_json, selection_key_json
from .neural_refresh_solver_v13 import model_state_sha256


def finish_dev(model, checkpoint, update, evaluator, generator, *, expected_total=1792,
               validator=None):
    checkpoint = Path(checkpoint)
    sha = digest(checkpoint)
    marker = checkpoint.with_suffix('.dev-commit.json')
    pending = checkpoint.with_suffix('.dev-pending.json')
    if marker.exists():
        receipt = json.loads(marker.read_text())
        if receipt['state_file'] != checkpoint.with_suffix('.dev-state.pt').name:
            raise ValueError('dev transaction state file identity mismatch')
        state_path = checkpoint.parent / receipt['state_file']
        if receipt['checkpoint_sha'] != sha or digest(state_path) != receipt['state_sha']:
            raise ValueError('dev transaction state/checkpoint drift')
        evaluator.load_state_dict(torch.load(state_path, map_location='cpu', weights_only=True))
        if validator is not None:
            validator(receipt['report'], sha, update)
        return receipt['report']
    recovering = pending.exists()
    if recovering:
        pending_identity = json.loads(pending.read_text())
        if (pending_identity['checkpoint_sha'] != sha or
                pending_identity['update'] != update):
            raise ValueError('pending dev checkpoint drift')
        if not callable(getattr(evaluator, 'recover', None)):
            raise RuntimeError('interrupted dev requires durable evaluator recovery')
    else:
        atomic_json(pending, dict(checkpoint_sha=sha, update=update))
    training_rng = rng_state()
    basis_rng = generator.get_state()
    modes = {name: module.training for name, module in model.named_modules()}
    versions = tuple(parameter._version for parameter in model.parameters())
    started = perf_counter()
    model_digest = model_state_sha256(model)
    try:
        report = (evaluator.recover(model, checkpoint, update) if recovering
                  else evaluator(model, checkpoint, update))
    finally:
        restore_rng(training_rng)
        generator.set_state(basis_rng)
        for name, module in model.named_modules():
            module.training = modes[name]
    if (versions != tuple(parameter._version for parameter in model.parameters()) or
            model_state_sha256(model) != model_digest):
        raise ValueError('dev evaluator changed model parameters or persistent buffers')
    elapsed = perf_counter() - started
    key = selection_key_from_json(report['selection_key'])
    if (report['total'] != expected_total or
            report['selection_protocol'] != 'EXPERIMENT_PROTOCOL_RU.md 7.4' or
            key[3:] != (update, sha) or
            key[2] != report['total_dev_compute_seconds']):
        raise ValueError('incomplete dev panel, identity or end-to-end compute accounting')
    if recovering and report.get('recovery_compute_accounted') is not True:
        raise ValueError('interrupted dev compute cost is not accounted')
    prior_compute = 0.
    if recovering:
        attempt = report['current_attempt_compute_seconds']
        prior_compute = report['total_dev_compute_seconds'] - attempt
        if attempt < 0 or prior_compute < 0:
            raise ValueError('invalid recovered dev compute breakdown')
    report = dict(report)
    report['total_dev_compute_seconds'] = prior_compute + elapsed
    report['selection_key'] = selection_key_json((key[0], key[1],
                                                  prior_compute + elapsed, key[3], key[4]))
    if validator is not None:
        validator(report, sha, update)
    state_path = checkpoint.with_suffix('.dev-state.pt')
    temporary = state_path.with_suffix('.tmp.pt')
    with temporary.open('wb') as stream:
        torch.save(evaluator.state_dict(), stream)
        stream.flush(); os.fsync(stream.fileno())
    os.replace(temporary, state_path)
    atomic_json(marker, dict(checkpoint_sha=sha, state_file=state_path.name,
                             state_sha=digest(state_path), report=report))
    return report
