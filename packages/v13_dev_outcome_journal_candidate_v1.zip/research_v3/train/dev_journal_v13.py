"""Durable ordered dev outcomes and measured attempts; no guessed crash cost.

The evaluator owns the run lock and validates raw words. An open attempt is
not evidence of a dead process and cannot be retried through this journal.
"""
import hashlib
import json
import math
from pathlib import Path
import sqlite3


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


class DevOutcomeJournal:
    def __init__(self, path, *, checkpoint_sha, panel_sha, update, ordered_keys):
        keys = tuple(ordered_keys)
        if (not keys or len(set(keys)) != len(keys) or
                type(update) is not int or update < 0 or
                any(type(v) is not str or len(v) != 64 or
                    any(c not in '0123456789abcdef' for c in v)
                    for v in (checkpoint_sha, panel_sha, *keys))):
            raise ValueError('explicit dev journal identities and unique ordered keys required')
        self.identity = canonical({'schema': 'own_dev_outcome_journal_v13',
            'checkpoint_sha': checkpoint_sha, 'panel_sha': panel_sha,
            'update': update, 'ordered_keys': keys})
        path = Path(path).resolve()
        # Inspect an existing file read-only before any write-capable connection.
        if path.exists():
            probe = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)
            try:
                row = probe.execute("SELECT value FROM metadata WHERE key='identity'").fetchone()
                if row is None or row[0] != self.identity:
                    raise ValueError('dev journal checkpoint/panel/config identity drift')
            finally:
                probe.close()
        self.connection = sqlite3.connect(str(path))
        self.connection.execute('PRAGMA synchronous=FULL')
        self.connection.executescript('''
          CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS attempts(id INTEGER PRIMARY KEY,position INTEGER NOT NULL,
            status TEXT NOT NULL,seconds REAL,digest TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS outcomes(position INTEGER PRIMARY KEY,
            key TEXT NOT NULL,raw TEXT NOT NULL,attempt INTEGER NOT NULL,chain TEXT NOT NULL);
        ''')
        with self.connection:
            self.connection.execute('INSERT OR IGNORE INTO metadata VALUES (?,?)',
                                    ('identity', self.identity))
            self.connection.execute('INSERT OR IGNORE INTO metadata VALUES (?,?)', ('attempt_count', '0'))
        self.keys = keys
        try:
            self.verify()
        except BaseException:
            self.connection.close()
            raise

    def verify(self):
        expected_count = int(self.connection.execute(
            "SELECT value FROM metadata WHERE key='attempt_count'").fetchone()[0])
        actual_count = 0
        for index, position, status, seconds, digest in self.connection.execute(
                'SELECT id,position,status,seconds,digest FROM attempts ORDER BY id'):
            actual_count += 1
            if (index != actual_count or status not in ('open', 'completed', 'interrupted') or
                    not 0 <= position < len(self.keys) or
                    (status == 'open' and seconds is not None) or
                    (status != 'open' and (seconds is None or not math.isfinite(seconds) or seconds < 0)) or
                    digest != hashlib.sha256(canonical([self.identity, index, position, status, seconds]).encode()).hexdigest()):
                raise ValueError('dev attempt content/cost mismatch')
        if actual_count != expected_count:
            raise ValueError('dev attempt history missing')
        previous, position = '0' * 64, 0
        for index, key, raw, attempt, chain in self.connection.execute(
                'SELECT position,key,raw,attempt,chain FROM outcomes ORDER BY position'):
            if index != position or index >= len(self.keys) or key != self.keys[index]:
                raise ValueError('dev outcome prefix/order mismatch')
            expected = hashlib.sha256(canonical([self.identity, previous, index, key, raw, attempt]).encode()).hexdigest()
            row = self.connection.execute('SELECT position,status,seconds FROM attempts WHERE id=?',
                                          (attempt,)).fetchone()
            if (chain != expected or json.loads(raw).get('key') != key or row is None or
                    row[0] != index or row[1] != 'completed' or row[2] is None or
                    not math.isfinite(row[2]) or row[2] < 0):
                raise ValueError('dev outcome content/attempt mismatch')
            previous, position = chain, position + 1
        return position, previous

    def begin(self, position):
        completed, _ = self.verify()
        if type(position) is not int or position != completed or position >= len(self.keys):
            raise ValueError('next fixed dev case required')
        if self.connection.execute("SELECT 1 FROM attempts WHERE status='open'").fetchone():
            raise RuntimeError('open dev attempt: audit live process before any recovery')
        with self.connection:
            self.connection.execute('BEGIN IMMEDIATE')
            count = int(self.connection.execute(
                "SELECT value FROM metadata WHERE key='attempt_count'").fetchone()[0])
            index = count + 1
            digest = hashlib.sha256(canonical([self.identity, index, position, 'open', None]).encode()).hexdigest()
            self.connection.execute('INSERT INTO attempts VALUES (?,?,?,?,?)',
                                    (index, position, 'open', None, digest))
            self.connection.execute("UPDATE metadata SET value=? WHERE key='attempt_count'", (str(index),))
        return index

    def finish(self, attempt, *, seconds, case=None):
        if (type(seconds) not in (int, float) or not math.isfinite(seconds) or seconds < 0 or
                type(attempt) is not int):
            raise ValueError('measured nonnegative attempt seconds required')
        raw = None if case is None else canonical(case)
        with self.connection:
            self.connection.execute('BEGIN IMMEDIATE')
            row = self.connection.execute('SELECT position,status FROM attempts WHERE id=?',
                                          (attempt,)).fetchone()
            if row is None or row[1] != 'open':
                raise ValueError('one open dev attempt required')
            position = row[0]
            count, previous = self.verify()
            if position != count:
                raise ValueError('attempt does not own next dev case')
            if case is not None:
                key = self.keys[position]
                if case.get('key') != key:
                    raise ValueError('wrong fixed dev case identity')
                chain = hashlib.sha256(canonical([self.identity, previous, position, key, raw, attempt]).encode()).hexdigest()
                self.connection.execute('INSERT INTO outcomes VALUES (?,?,?,?,?)',
                                        (position, key, raw, attempt, chain))
            status = 'completed' if case is not None else 'interrupted'
            digest = hashlib.sha256(canonical([self.identity, attempt, position, status, float(seconds)]).encode()).hexdigest()
            self.connection.execute('UPDATE attempts SET status=?,seconds=?,digest=? WHERE id=?',
                                    (status, float(seconds), digest, attempt))

    def cases(self):
        self.verify()
        return tuple(json.loads(raw) for (raw,) in self.connection.execute(
            'SELECT raw FROM outcomes ORDER BY position'))

    def measured_attempt_seconds(self):
        self.verify()
        if self.connection.execute("SELECT 1 FROM attempts WHERE status='open'").fetchone():
            raise RuntimeError('unfinished attempt has unknown compute; no qualified selection cost')
        return self.connection.execute('SELECT COALESCE(SUM(seconds),0) FROM attempts').fetchone()[0]

    def close(self):
        self.connection.close()
