import tempfile
from pathlib import Path
import unittest
import torch
from research_v3.train.checkpoint import digest
from research_v3.train.schedule import selection_key, selection_key_json
from research_v3.train.dev_transaction_v13 import finish_dev


class Evaluator:
    def __init__(self, fail=False):
        self.calls = 0
        self.fail = fail
    def state_dict(self):
        return {'calls': self.calls}
    def load_state_dict(self, state):
        self.calls = state['calls']
    def __call__(self, model, checkpoint, update):
        self.calls += 1
        torch.rand(10)
        model.eval()
        if self.fail:
            raise RuntimeError('injected dev failure')
        return dict(total=1, selection_protocol='EXPERIMENT_PROTOCOL_RU.md 7.4',
                    total_dev_compute_seconds=0., selection_key=selection_key_json(
                        selection_key({'a': 1}, {'a': 2}, {'a': 4}, 0., update, digest(checkpoint))))


class DevTransactionTests(unittest.TestCase):
    def test_dev_rng_modes_and_state_restore_without_duplicate_evaluation(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/'snapshot.pt'; path.write_bytes(b'own-checkpoint')
            model = torch.nn.Linear(2, 1).train()
            generator = torch.Generator().manual_seed(9)
            before = torch.get_rng_state().clone()
            basis = generator.get_state().clone()
            evaluate = Evaluator()
            report = finish_dev(model, path, 640, evaluate, generator, expected_total=1)
            self.assertTrue(torch.equal(before, torch.get_rng_state()))
            self.assertTrue(torch.equal(basis, generator.get_state()))
            self.assertTrue(model.training)
            self.assertGreater(report['total_dev_compute_seconds'], 0)
            fresh = Evaluator(fail=True)
            self.assertEqual(finish_dev(model, path, 640, fresh, generator,
                                       expected_total=1), report)
            self.assertEqual(fresh.calls, 1)

    def test_failed_dev_preserves_rng_and_requires_durable_recovery(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/'snapshot.pt'; path.write_bytes(b'own-checkpoint')
            model = torch.nn.Linear(2, 1).train()
            generator = torch.Generator()
            before = torch.get_rng_state().clone()
            with self.assertRaisesRegex(RuntimeError, 'injected'):
                finish_dev(model, path, 640, Evaluator(fail=True), generator,
                           expected_total=1)
            self.assertTrue(torch.equal(before, torch.get_rng_state()))
            self.assertFalse(path.with_suffix('.dev-commit.json').exists())
            with self.assertRaisesRegex(RuntimeError, 'durable evaluator recovery'):
                finish_dev(model, path, 640, Evaluator(), generator, expected_total=1)


if __name__ == '__main__':
    unittest.main()
