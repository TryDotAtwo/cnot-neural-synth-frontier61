import tempfile
from pathlib import Path
from dataclasses import replace
import unittest
from research_v3.contracts import AlphabetSpec, Gate
from research_v3.data.generators import record_from_word
from research_v3.train.replay_store_v13 import ReplayJournal


class ReplayJournalTests(unittest.TestCase):
    def test_checkpoint_reopen_rollback_and_tail_preservation(self):
        record = replace(record_from_word(AlphabetSpec.all_to_all(3), (Gate(0, 1),),
                                         'train:journal', 7), split='train')
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'replay.sqlite'
            store = ReplayJournal(path)
            checkpoint = store.append(record, {'update': 1})
            other = replace(record, lineage_id='train:other')
            store.append(other, {'update': 2})
            store.close()
            store = ReplayJournal(path)
            store.restore(checkpoint)
            self.assertEqual(store.get(record), record)
            self.assertIsNone(store.get(other))
            self.assertEqual(store.cursor(), checkpoint)
            self.assertEqual(store.connection.execute('SELECT count(*) FROM rewound').fetchone()[0], 1)
            with self.assertRaises(ValueError):
                store.restore({**checkpoint, 'chain': 'wrong'})
            self.assertEqual(store.cursor(), checkpoint)
            with self.assertRaises(ValueError): store.append(replace(record, split='test'), {})
            store.close()


if __name__ == '__main__': unittest.main()
