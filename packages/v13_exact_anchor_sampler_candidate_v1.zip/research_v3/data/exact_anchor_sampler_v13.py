"""Content-pinned stateless adapter of the original complete-catalog sampler."""
from dataclasses import asdict, dataclass, replace
import hashlib
import json
from types import MappingProxyType
from .exact_stream import ExactStreamSampler
from .verified_exact_catalog_v13 import VerifiedExactCatalog


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


@dataclass(frozen=True, init=False)
class ExactAnchorSampler:
    sizes: tuple
    contexts: object
    states: object
    catalog_hashes: object
    source_hashes: object

    def __init__(self, reference, *, source_sha256):
        if type(reference) is not ExactStreamSampler:
            raise ValueError('original complete exact sampler required')
        sizes = tuple(reference.sizes)
        if not sizes or len(set(sizes)) != len(sizes) or any(n not in (3, 4) for n in sizes):
            raise ValueError('distinct complete small widths required')
        if (not source_sha256 or any(type(key) is not str or type(value) is not str or
                len(value) != 64 or any(c not in '0123456789abcdef' for c in value)
                for key, value in source_sha256.items())):
            raise ValueError('explicit implementation source hashes required')
        contexts, states, hashes = {}, {}, {}
        for n in sizes:
            catalogs = [c for c in reference.catalogs.values() if c.alphabet.n == n]
            if len(catalogs) != 1:
                raise ValueError('ambiguous exact catalog width')
            context = VerifiedExactCatalog(catalogs[0])
            contexts[n] = context
            states[n] = tuple(sorted((r.state for r in context.records.values()
                                      if r.exact_distance > 0), key=lambda s: s.packed_rows))
            proof = [asdict(context.records[state.key]) for state in
                     sorted((r.state for r in context.records.values()), key=lambda s: s.packed_rows)]
            hashes[n] = hashlib.sha256(_canonical(proof).encode()).hexdigest()
        for name, value in (('sizes', sizes), ('contexts', MappingProxyType(contexts)),
                            ('states', MappingProxyType(states)),
                            ('catalog_hashes', MappingProxyType(hashes)),
                            ('source_hashes', MappingProxyType(dict(source_sha256)))):
            object.__setattr__(self, name, value)

    def immutable_contract(self):
        return {'schema': 'verified_exact_anchor_sampler_v13',
                'config': {'sizes': list(self.sizes), 'position_stride': 10000,
                           'selection': 'reference_epoch_position_v1',
                           'catalog_sha256': {str(n): self.catalog_hashes[n] for n in self.sizes}},
                'source_sha256': dict(self.source_hashes)}

    def state_dict(self):
        # Selection is solely a function of the durable stream cursor.
        return {'schema': 'stateless_exact_anchor_sampler_v13',
                'contract_sha256': hashlib.sha256(_canonical(self.immutable_contract()).encode()).hexdigest()}

    def load_state_dict(self, state):
        if state != self.state_dict():
            raise ValueError('exact sampler checkpoint content/source/schedule drift')

    def record(self, epoch, position):
        if (type(epoch) is not int or epoch < 0 or type(position) is not int or
                not 0 <= position < 10000):
            raise ValueError('invalid exact stream cursor')
        index = epoch * 10000 + position
        n = self.sizes[index % len(self.sizes)]
        state = self.states[n][(index // len(self.sizes)) % len(self.states[n])]
        record = replace(self.contexts[n].records[state.key], split='train', seed=index,
                         lineage_id=f'exact_stream:{epoch}:{position}:{n}')
        return self.contexts[n].validate(record)
