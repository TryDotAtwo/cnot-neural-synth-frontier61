"""Molab gate: full-model mixed-width update, not a training quality result."""
from dataclasses import replace
import json
import os
from pathlib import Path
import unittest
import torch
from research_v3.contracts import AlphabetSpec
from research_v3.data.exact_small import build_exact_small
from research_v3.data.verified_exact_catalog_v13 import VerifiedExactCatalog
from research_v3.data.stream_solver_dataset_v13 import make_root
from research_v3.gpu.holdout import GpuExactHoldout
from research_v3.gpu.mixed_joint_records_v13 import RecordGroup, complete_mixed_joint_records


@unittest.skipUnless(os.environ.get('MOLAB_TEST_CUDA') == '1' and torch.cuda.is_available(),
                     'explicit Molab CUDA gate')
class MixedJointCudaTests(unittest.TestCase):
    def test_full_field_and_basis_gradients_in_one_mixed_update(self):
        from research_v3.cli.probe_gpu_fullwidth_joint import _model
        cfg = json.loads((Path(__file__).resolve().parents[2] /
                          'full_training_config.json').read_text())
        torch.set_num_threads(cfg['threads'])
        torch.manual_seed(cfg['seed'])
        model = _model(cfg).train()
        optimizer = torch.optim.AdamW(model.parameters(), lr=1e-5)
        large, _ = make_root('train', 0, 126, 0, 7000)
        self.assertEqual(large.state.n, 8)
        context = VerifiedExactCatalog(build_exact_small(3, AlphabetSpec.all_to_all(3)))
        small = replace(max(context.records.values(), key=lambda r: r.exact_distance),
                        split='train', lineage_id='exact_stream:mixed_cuda:3')
        # Diagnostic empty banks exercise shape and complete-neighbor admission.
        # They are NOT a receipt for the production sealed holdout loader.
        groups = (RecordGroup((large,), GpuExactHoldout.empty_projection(8)),
                  RecordGroup((small,), GpuExactHoldout.empty_projection(3), context))
        generator = torch.Generator(device='cuda').manual_seed(9137)
        loss, audit = complete_mixed_joint_records(
            model, groups, generator=generator, choice_count=2, action_chunk=6,
            samples=2, max_evaluations=5000, max_bytes=268435456, weight=.1,
            qhat_weight=.1, supervision_weight=1., teacher_weight=.1,
            mc_samples=cfg['diffusion']['mc_samples'], mc_seed=cfg['feature_seed'],
            max_pair_states=cfg['diffusion']['max_pair_states'])
        self.assertTrue(torch.isfinite(loss).item())
        self.assertEqual(audit['records'], 2)
        self.assertEqual(audit['exact_root_examples'], 2)
        self.assertEqual(audit['admission_counts'], [57, 7])
        self.assertGreater(audit['basis_templates'], 0)
        loss.backward()
        for module in (model.field, model.proposer):
            grads = [p.grad for p in module.parameters() if p.grad is not None]
            self.assertTrue(grads)
            self.assertTrue(all(torch.isfinite(g).all().item() for g in grads))
            self.assertGreater(sum(g.abs().sum().item() for g in grads), 0)
        optimizer.step()
        steps = {int(state['step'].item()) for state in optimizer.state.values()}
        self.assertEqual(steps, {1})
        self.assertEqual(sum(a['basis_evaluations'] for a in audit['groups']),
                         audit['basis_evaluations'])


if __name__ == '__main__': unittest.main()
