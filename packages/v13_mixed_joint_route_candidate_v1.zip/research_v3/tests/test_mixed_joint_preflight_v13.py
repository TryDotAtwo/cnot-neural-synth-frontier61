import unittest
from unittest.mock import patch
from dataclasses import replace
from research_v3.data.stream_solver_dataset_v13 import make_root
from research_v3.gpu.mixed_joint_records_v13 import RecordGroup, complete_mixed_joint_records


class MixedPreflightTests(unittest.TestCase):
    def test_late_bad_label_rejected_before_any_cuda_transfer_or_forward(self):
        first, _ = make_root('train', 0, 126, 0, 7000)
        bad = replace(first, split='test')
        groups = (RecordGroup((first,), object()), RecordGroup((bad,), object()))
        with patch('research_v3.gpu.mixed_joint_records_v13.own_records_to_cuda') as transfer:
            with patch('research_v3.gpu.mixed_joint_records_v13.complete_joint_basis_records') as forward:
                with self.assertRaises(ValueError):
                    complete_mixed_joint_records(None, groups, generator=None)
                transfer.assert_not_called()
                forward.assert_not_called()

    def test_missing_bank_is_not_silently_disabled(self):
        first, _ = make_root('train', 0, 126, 0, 7000)
        with self.assertRaisesRegex(ValueError, 'sealed holdout'):
            complete_mixed_joint_records(None, (RecordGroup((first,), None),), generator=None)


if __name__ == '__main__': unittest.main()
