import unittest
import torch
from research_v3.train.neural_refresh_solver_v13 import NeuralRefreshSolver


class NeuralRefreshContractTests(unittest.TestCase):
    def test_invalid_explicit_budgets_and_field_config_rejected(self):
        search = dict(beam_width=2, shortlist=2, max_depth=3,
                      inference_batch=2, max_expanded=30)
        field = dict(mc_samples=2, mc_seed=7, max_pair_states=30, head='qhat')
        for key in search:
            for value in (0, -1, True, 1.5):
                with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                    NeuralRefreshSolver(torch.nn.Linear(1, 1),
                        search_config={**search, key: value}, field_config=field,
                        source_sha256={})
        for override in ({'mc_samples': True}, {'max_pair_states': 0},
                         {'mc_seed': 1.5}, {'head': 'hamming'}):
            with self.assertRaises(ValueError):
                NeuralRefreshSolver(torch.nn.Linear(1, 1), search_config=search,
                    field_config={**field, **override}, source_sha256={})


if __name__ == '__main__': unittest.main()
