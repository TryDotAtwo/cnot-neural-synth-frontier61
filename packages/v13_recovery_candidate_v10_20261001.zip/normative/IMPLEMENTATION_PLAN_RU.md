# Базисный синтезатор и полное поле Frontier 17–61: план реализации

> **Для исполнителя:** использовать `superpowers:executing-plans`, последовательно проходя задачи и их проверки. Субагентов не создавать. Этот файл — план; незаполненные пункты не являются выполненной реализацией.

**Цель:** получать короткие проверенные CNOT-программы из полной матрицы собственным базисным методом и полем `V_theta(M)`, сохраняя точный смысл результатов Frontier 17–61 и отдельно измеряя пользу каждого механизма.

**Архитектура:** полная помеченная матрица и типизированный банк A–I поступают в первый структурный трансформер; его связанные с проводами/группами feature heads поступают в объединяющий трансформер с одним выходом V. Собственный оплаченный basis compiler предоставляет допустимые слова, локальные дифференцируемые задачи и макропереходы. Exact/interval certificates, proposal и абсолютный Qhat имеют отдельные интерфейсы и проверяемую семантику.

**Стек:** Python как проверяемый reference, существующие PyTorch/NumPy/SciPy, GF(2) на packed rows; после reference gates — существующие Rust/C++/LibTorch/CUDA адаптеры. Окружение и версии фиксируются из фактического рабочего контейнера/интерпретатора, а не обновляются автоматически.

**Спецификация:** [ARCHITECTURE_AUDIT_RU.md](ARCHITECTURE_AUDIT_RU.md), [FEATURE_BANK_RU.md](FEATURE_BANK_RU.md), [STAGE_COVERAGE_RU.md](STAGE_COVERAGE_RU.md). Проверки и панели результатов: [EXPERIMENT_PROTOCOL_RU.md](EXPERIMENT_PROTOCOL_RU.md).

Дата: 26.09.2026. Основа — восстановленная боковая переписка, исходный архив stage61 и текущие файлы проекта. План не утверждает, что все доказательства архива повторены или что нейросеть уже улучшила девять целей.

## Глобальные ограничения

- Состояние — вся обратимая матрица над F₂ с фиксированным порядком проводов. `CNOT(c,t)` означает `row[t] ^= row[c]`, c≠t.
- Основная метрика — all-to-all CNOT единичной цены без добавочных проводов и без бесплатных SWAP/смен базиса. Ограниченный алфавит задаёт отдельную задачу, а не тот же benchmark.
- Encoder проверяется действием временного списка на I; reduction M→I обращается по порядку для получения encoder. Проверяется каждый бит всех n строк, не один хэш и не действие на одном состоянии.
- Оплата basis prep/core/restore обязательна. Нельзя присвоить макросу цену 1 или сохранить уже исчезнувшую чётность бесплатно.
- Случайная длина и известная программа дают UB. Exact label требует проверенной теоремы в нужном scope либо LB=UB/полного сертификата. Суффикс негеодезического слова не задаёт истинного порядка расстояний.
- `V(I)=0` точно. Полная Bellman-производная проходит через обе стороны выбранной ветви при одинаковых theta и packets. Полное соседство выбранных матриц не означает перечисление всей GL(n,2).
- Никакого кода, цепочек, меток или производных данных из архива Келипая. Допустимые девять целей — собственные stage17 `source_snapshot/inputs`; benchmark не подаётся teacher как готовое решение.
- Не вводить скрытых секундных отсечек. Число updates, template evaluations, ширина, глубина, число состояний и память — явные поля бюджетов. Остановки ресурса не объявляются невозможностью решения.
- Существующие source snapshots, runs, веса, журналы и negative results сохраняются. Новая архитектура получает новый schema/run; она не объявляется точным продолжением старого checkpoint.
- Каждая строка отчёта различает raw neural result, собственный compiler incumbent, postprocessed result и best verified portfolio. Отсутствующее решение не заменяется incumbent в столбце NN.
- Старые девять целей — исторический benchmark, исключённый из training labels; они уже использовались в разработке и не являются новым независимым подтверждающим тестом.

## Что проверено при подготовке этого плана

26.09.2026 read-only checker повторно проверил 36 сохранённых полных слов, обнаружил 5 записанных неудач поиска, `pending=0`, отсутствие ошибок word verification и побайтовое равенство трёх файлов исходных данных пары heat-on/off. Это не повтор обучения и не новый benchmark.

Checker в целом вернул `ok=false`: текущий `report_diffusion_ablation.py` отличается от pinned hash плагина. Происхождение drift удалось проверить: из исходной сессии извлечены два патча от 24.09.2026 (обработка несовпадающих наборов cases/pending и вывод UTF-8). Их обратное применение к текущему тексту **в памяти** восстановило байты с точным pinned SHA-256 `4e3e3aa88561e215a11ae7885c069d12ff126b909836f732c5fd7c80eb6147f6`. Полные патчи, время, строки источника и нынешний SHA сохранены в [REPORT_DRIFT_EVIDENCE.json](REPORT_DRIFT_EVIDENCE.json). Это объяснённое изменение, а не полное совпадение snapshot; исходник и manifest плагина не перезаписывались, checker по-прежнему сообщает drift.

Отдельная текущая SHA-256 проверка архива stage61 и всех 24 `current_project_files` из SOURCE_MANIFEST показала совпадение. Это проверка целостности указанных файлов, не аудит всех текстов архива.

Прочитаны определения текущего structural/action/heat контура, `general_macro`, первичные тексты shared-basis17, README35/60/61 и теорема 2/следствие13 текста55 о bilinear residual. Остальные результаты в этом плане привязаны к coverage и требуют своих source gates. Это граница нынешнего аудита.

## Review Focus

1. **Формально правильная локальная формула в неверном алфавите:** restricted optimum не становится global d; тесты T01/T03/T15/T16 должны сохранять scope и контрпримеры.
2. **Одно M, разные признаки между argmin и backward:** cache/probes/маски и theta должны совпадать; тесты T02/T06.
3. **Скрытая утечка при full-neighbor training:** раздельно учитывать `seen_as_label`, `seen_by_forward`, `seen_by_gradient`; тест T03. Нельзя удалить тестового соседа и продолжать называть backup полным.
4. **Большая матрица с редкой/недоступной feature:** availability, padding, underflow и лимит exact backend не превращаются в физический ноль; тесты T02/T05/T13/T19.
5. **Подмена общего результата удачным компонентом:** source identity, сырая NN-цепочка, физическая цена, compiler/postprocess budgets и внешние столбцы проверяются независимо; тесты T11/T23/T24.

---

## 1. Файлы, владельцы и очередность

Обозначения точных корней:

```text
P = D:/Lean4/TheQuantumProject
S = P/synthesis-methods/01_shared_basis_stage17
R = S/improved/research_v3
D = C:/Users/Иван Литвак/Documents/ChatGPT/TheQuantumProject/docs/superpowers/plans/2026-09-26-frontier61
```

Пути `R/...` ниже — **предлагаемые новые файлы**, не заявление об их наличии. Корень R создаётся только при реализации T00. Legacy modules служат читаемыми источниками/reference adapters; изменение legacy hot path допускается после T14 parity и отдельной проверки отсутствия регрессий. Генераторы не импортируют чужие handoff-пакеты.

| Подсистема | Новые файлы/каталоги R | Ответственность |
|---|---|---|
| Контракты | `contracts.py`, `gf2.py`, `words.py`, `symmetry.py` | State/alphabet/certificates, точная семантика |
| Источники и replay | `evidence.py`, `data/{records,splits,replay,generators,exact_small}.py`, `bounds.py` | Provenance, typed labels, guards |
| Вход модели | `features/{registry,packet,cache,structural,basis,certificates,diffusion,views,response}.py` | A–I, masks, budgets, deterministic producers |
| Модель | `model/{stem,family_heads,fusion,field,auxiliary}.py` | Первый transformer, feature embeddings, второй transformer, V |
| Обучение | `objectives/{bellman,supervision,auxiliary}.py`, `train/{schedule,runner,checkpoint}.py` | Full gradient, diagnostics, воспроизводимость |
| Собственный compiler | `basis/{templates,objective,rounding,proposal,wide,frames,compose}.py`, `postprocess.py` | Оплаченные блоки и postprocessing |
| Полный поиск | `search/{reference,scoring,results}.py` | Direct V/Qhat/shortlist/macros, honest outcomes |
| Диффузия | `diffusion/{column,pair,probes}.py` | Замкнутые проекции, масса/нормировки |
| Поздние этапы | `response/{types,relations,local,compression,bilinear,positive,quadratic,ordering,wick}.py` | Restricted/exact/research backends |
| Native bridge | `native/{export,parity,profile}.py`, новые `native/v3_*` файлы в S/improved | Export/runtime parity, измеряемое ускорение |
| Репродуцируемость | `cli/{verify,train,solve,benchmark,release}.py`, `configs/*.json`, `tests/test_T*.py` | CLI и независимые проверки |

Порядок прохода: T00→T01→T02→T03→T04→T05→T06, затем T07→T08→T09→T10→T11→T12→T13→T14. После рабочего reference последовательно T15→T16→T17→T18→T19→T20→T21→T22, затем итоговые T23→T24. Ранние unit/control панели T23 запускаются при закрытии их зависимостей, но итоговая таблица формируется после фиксации версии. Дорогие T17–T22 могут остаться явно открытым исследованием: это запрещает статус «всё реализовано», но не блокирует честную оценку уже работающего field/compiler.

Сначала берётся checkpoint старого состояния документов/исходников. На переходе между задачами записываются результаты тестов и source hashes. Если каталог под Git, коммит содержит только проверенную задачу; без Git используются неизменяемые именованные manifests. Команды не коммитят весь рабочий каталог автоматически.

## 2. Общие типы и интерфейсы

Все типы ниже определяются в `contracts.py` либо экспортируются оттуда; поля с массивами имеют явно зафиксированные dtype/layout в schema.

```text
Gate(control:int, target:int)
AlphabetSpec(n:int, allowed:tuple[Gate,...], costs:tuple[int,...], id:str)
MatrixState(n:int, packed_rows:tuple[int,...], alphabet_id:str)
MatrixBatch(states:tuple[MatrixState,...], matrix:bool[B,N,N], valid:bool[B,N])
WordCertificate(start:MatrixState, end:MatrixState, gates:tuple[Gate,...],
                physical_cost:int, producer:str, lineage_id:str)
BoundCertificate(kind:lower|upper|exact, value:int, scope_id:str,
                 hypotheses:dict, witness_ref:str, verifier_version:str)
BoundSet(lower:tuple[BoundCertificate,...], upper:tuple[WordCertificate,...],
         exact:BoundCertificate|None)
OracleStatus = exact | certified_no_solution_within_scope | unknown | unsupported
OracleResult(status:OracleStatus, scope_id:str, value:object|None,
             witness:object|None, statistics:dict)
Budget(updates:int|None, max_states:int|None, max_bytes:int|None,
       max_depth:int|None, beam_width:int|None, evaluations:int|None)
FeaturePolicy(schema_id:str, enabled_ids:tuple[str,...], optional_budget:Budget,
              seed:int, solver_assisted:bool, symmetry_contract:str)
FeaturePacket(state_keys, alphabet_id, schema_id, policy_id, node, pair,
              group, group_incidence, global_values, available,
              exactness, scope, uncertainty, producer_versions, audit)
EncodedState(wire, pair, group, global_tokens, valid, availability)
ModelOutput(value:Tensor[B], proposal:Tensor[B,N,N]|None,
            qhat:Tensor[B,N,N]|None)
SampleRecord(state, bounds:BoundSet, lineage_id, split, source, seed,
             verified_words, exposures)
SearchConfig(mode, scoring, feature_policy, alphabet, budget, tie_rule,
             macro_policy, postprocess_policy, checkpoint_id)
SolveResult(status, raw_neural_word, incumbent_word, postprocessed_word,
            best_verified_word, counts, timings, diagnostics, provenance)
```

`MatrixState` хранит little-endian бит j входного провода в строке i; n хранится отдельно. Canonical matrix key — `(n, alphabet_id, packed_rows)`; SHA-256 этого сериализованного объекта применяется для manifest, но равенство в verifier/cache проверяется по полному ключу. Смешивать hash исходного JSON с canonical matrix key запрещено.

Основные API:

```python
verify_word(cert: WordCertificate, alphabet: AlphabetSpec) -> None
verify_bounds(state: MatrixState, bounds: BoundSet, alphabet: AlphabetSpec) -> None
FeatureRegistry.build(batch: MatrixBatch, policy: FeaturePolicy) -> FeaturePacket
FusionDistanceField.encode(batch: MatrixBatch, packet: FeaturePacket) -> EncodedState
FusionDistanceField.value(encoded: EncodedState) -> Tensor
FusionDistanceField.forward(batch: MatrixBatch, packet: FeaturePacket) -> ModelOutput
select_backup(model, batch, packet_provider, config) -> BackupSelection
recompute_backup(model, selection: BackupSelection) -> LossReport
solve(state: MatrixState, model, registry, config: SearchConfig) -> SolveResult
```

`BackupSelection` включает parent/selected successor, gate или полностью раскрытый macro, физическую цену, frozen inputs/masks/probes, tie rule, версию параметров и полноту перебора. Для первого reference все producers фиксированы относительно theta, dropout=0. Learned producer потребует повторного differentiable вычисления при тех же theta/probes, а не detached-cache его выхода.

LossReport — именованные scalar losses, число использованных примеров каждого типа, active fractions, violation magnitudes, gradient norms, approximation flags. Конкретные веса задаются в configs и не подбираются по девяти benchmark.

## 3. Задачи с проверяемыми выходами

### T00. Зафиксировать источники и исходные результаты

**Файлы:** создать `R/evidence.py`, `R/configs/reference.json`, `R/tests/test_T00_evidence.py`, `R/artifacts/evidence/<run-id>/manifest.json`. Читать `D/SOURCE_MANIFEST.json`, `S/source_snapshot/inputs`, `S/improved/research_v2/baselines.json` и manifests конкретных runs.

**Интерфейс:** `audit_sources(source_manifest:Path, allowed_root:Path)->EvidenceReport`; report содержит actual hashes, missing/drift, разрешённое происхождение и отдельный статус проверки слов. Числа baseline извлекаются из проверенных сертификатов, не из этой записки.

- [ ] Зафиксировать интерпретатор/container, исходные paths/SHA, nine matrix canonical keys и все использованные certificate refs. Не запускать старые обучающие команды из документации.
- [ ] Тесты `changed_source_is_drift`, `missing_report_is_missing`, `false_verified_flag_is_rejected`: испортить копию слова/хэш; checker обязан отказать именно соответствующему утверждению.
- [ ] Повторно сверить current hash с REPORT_DRIFT_EVIDENCE и извлечёнными патчами; классифицировать известный drift как explained, новый — как unresolved. Не переписать pinned manifest ради зелёного статуса.
- [ ] Проверить собственные compiler incumbents из файлов и их ориентацию. Исторические 19/41/68/93/149/350/421/572/1057 — ожидаемые ссылки для сверки, не зашитые ответы.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T00_evidence -v`; отчёт различает source drift, word validity, optimality и uncomputed. Сохранить checkpoint задачи.

### T01. Полная матрица, алфавит, слова и симметрии

**Файлы:** `R/contracts.py`, `R/gf2.py`, `R/words.py`, `R/symmetry.py`, `R/tests/test_T01_state.py`.

**Интерфейсы:** `apply(state,gate,alphabet)->MatrixState`, `invert_word(word)->tuple[Gate,...]`, `map_problem(state,alphabet,transform)->MappedProblem`, `map_word_back(cert,mapping)->WordCertificate`. MappedProblem хранит изменённый alphabet и обратную карту.

- [ ] Написать тесты n=1 identity/no moves, n=2 одиночный CNOT, SWAP=3 CNOT, сингулярный/несquare вход, out-of-range/self gate, padded wires. Недопустимый вход отвергается до модели.
- [ ] Проверить encoder/reduction на некоммутирующем двухgate примере: ошибочное сохранение порядка не должно пройти verifier.
- [ ] Реализовать inverse, transpose и simultaneous permutation отдельно. Inverse сохраняет любой фиксированный набор инволютивных CNOT; transpose требует обратных рёбер с теми же ценами; relabel переносит alphabet/costs или проверяет автоморфизм.
- [ ] Для n≤3 проверить карты полных слов на всех достижимых состояниях; отдельно restricted alphabet с одной ориентацией и различными ценами, где transpose не является симметрией прежней задачи.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T01_state -v`; повторно проверить все выходные bits. Snapshot/commit только этих контрактов.

### T02. Полный FeatureRegistry A–I и детерминированные packets

**Файлы:** `R/features/{registry,packet,cache,structural}.py`, `R/tests/test_T02_features.py`.

**Интерфейсы:** `FeatureProducer.spec()->FeatureSpec`, `compute(batch,context)->TypedFeature`; spec фиксирует ID, scope, shape, physical roles, cost tier, exactness и зависимости. Registry реализует общий `build`; `FeatureCache.get_or_compute(full_key,producer)->TypedFeature`.

- [ ] Завести все 103 ID A–I в schema; сначала реализовать дешёвые A/B/F01, остальным вернуть явные unavailable/status, не фиктивные нули. Добавление десятого семейства не меняет формат модели.
- [ ] Определить group incidence по ролям и направленные pair indices. Metadata IDs/файлы/время исполнения не передавать как числовые признаки цели.
- [ ] Тесты `missing_not_zero`, `padding_is_not_wire`, `collision_safe_cache`, `same_state_same_policy_same_packet`, `changed_policy_invalidates_cache`; forced identical hashes для двух разных матриц не объединяют их.
- [ ] Проверить equivariance целого producer/proposer, включая tie handling и sampled cuts. Если выбор не эквивариантен, policy честно помечается augmentation-only; тест не отключается.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T02_features -v`; report по producer содержит время, bytes, calls, hits, omitted IDs. Новый run/schema фиксируется.

### T03. Сертифицированные данные, replay и разделение выборок

**Файлы:** `R/data/{records,splits,replay,generators,exact_small}.py`, `R/tests/test_T03_data.py`.

**Интерфейсы:** `build_exact_small(n,alphabet)->ExactCatalog`, `generate(family,seed,n,budget)->list[SampleRecord]`, `Replay.merge(records)->MergeReport`, `SplitPolicy.audit(records,exposures)->SplitReport`. Теоремный adapter возвращает предпосылки, scope и witness, а не один флаг exact.

- [ ] Ввести независимые источники: exact-small BFS, guarded exact families18/23–25/35–38, собственные paid-basis words, ordinary/Poisson walks. Прочитать первичные гипотезы каждого подключаемого семейства и записать ссылки/проверку применимости до маркировки exact.
- [ ] GL(2,2) должен содержать 6 состояний, GL(3,2) — 168, GL(4,2) — 20 160. BFS не импортируется runtime solver. Отсутствие результата при budget limit не является exact distance.
- [ ] Тесты: `walk_return_has_ub_not_exact`, `nongeodesic_suffix_not_rank_label`, `same_state_minimum_verified_ub`, `restricted_certificate_not_global`, `unsupported_family_not_exact`.
- [ ] Делить целыми lineages/генераторными seeds/семействами; учитывать известные T/inverse/relabel augmentations. Не обещать полную дешёвую canonicalization всех орбит.
- [ ] Раздельно вести множества `seen_as_label`, `seen_by_forward`, `seen_by_gradient`. Full-neighbor Bellman способен увидеть test M даже без метки; для строгой панели отбрасывать **родителя train**, если его полный successor set пересекает запрещённую панель, либо выбирать независимые размеры/семейства. Не удалять отдельного соседа из «полного» backup. Проверять это после каждого replay refresh, включая macro successors.
- [ ] Исторические девять целей исключить из label/replay/teacher; встречи в forward/gradient раскрывать. Новый подтверждающий набор заморозить до выбора v3 и открыть только после dev selection.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T03_data -v`; split report публикует различия label-held-out, transductive и действительно unseen; сохранить хэши наборов.

### T04. Нижние границы и guarded recognizers

**Файлы:** `R/bounds.py`, `R/data/generators.py`, `R/features/certificates.py`, `R/tests/test_T04_bounds.py`.

**Интерфейсы:** `cheap_bounds(state)->BoundSet`, `cut_bound(state,A,B)->BoundCertificate`, `recognize_excess(state,order,budget)->OracleResult`. Суммирование границ требует отдельного capacity certificate; обычное объединение — maximum.

- [ ] Реализовать changed rows/columns, rank(M−I), guarded stage35 `n-components+zero_diagonal`, directional cut rank sum и verifier stage26. Stage26 сначала в reference scope после переноса всех условий исходника.
- [ ] Зафиксировать обозначения: `components=c(M)` — число компонент **неориентированного внедиагонального support** с учётом изолированных проводов; ребро {i,j} существует при i≠j и `(M_ij=1 or M_ji=1)`. `zero_diagonal=z0(M)=#{i:M_ii=0}`. Для P0/P1 `r0(A,B)=#{i:A_i!=B_i}` — исходная рядовая LB из §1 stage37; при редукции A=M, B=I. Это r в первичном тексте и R в таблице coverage, а не rank(M−I) и не максимум всех доступных LB.
- [ ] P0/P1 подключать только после проверки iff/полноты соответствующего алгоритма. `P0 exhaustive reject` исключает r0; `P0,P1 exhaustive reject` исключает r0 и r0+1. Выводы r0+1/r0+2 объединяются максимумом с остальными LB. Timeout/unsupported/heuristic failure не повышает LB.
- [ ] Проверить `LB<=d_exact` на всех GL3 и заданной полной GL4 панели; deliberate sum-over-cuts overcount должен быть отвергнут. Cut bound проверяется также в требуемом направлении CNOT.
- [ ] Тест `action_bound=cost(a)+LB(aM)` на всех допустимых соседях; это граница стоимости пути с **фиксированным первым ходом**, её нельзя без минимума использовать как LB на d(M).
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T04_bounds -v`; точная метка создаётся лишь при verified UB=valid LB либо theorem-certified global value. Зафиксировать verifier versions.

### T05. Реализовать пользовательскую архитектуру

**Файлы:** `R/model/{stem,family_heads,fusion,field,auxiliary}.py`, `R/tests/test_T05_model.py`.

**Интерфейсы:** общий `FusionDistanceField`, `FamilyHeads.forward(encoded,packet)->FamilyEmbeddings`; family embeddings сохраняют wire/group incidence. V не является средним готовых ответов отдельных решателей.

- [ ] Начальный профиль: d=128, pair_d=32, 6 structural blocks, 4 attention heads, FFN=256; 2 fusion blocks d=128/heads=4/FFN=256; dropout=0. Число feature families независимо и не ограничено шестью. Конфигурации d=192/256 — последующие измеряемые варианты.
- [ ] Все доступные node/pair/group/global inputs входят до первого transformer. Group/global cross-attention использует incidence/roles. После structural blocks — специализированные feature embeddings, затем feature/wire fusion и `[DIST]` readout.
- [ ] Основной V: `where(identity,0,softplus(raw_logit))`; не добавлять непроходимый `LB+softplus(excess)` floor для exact saturated examples. Внешнее LB clipping применяется отдельно в search mode, а train diagnostics используют V до clipping.
- [ ] Тесты `all_enabled_families_reach_first_stem`, `value_gradient_reaches_both_transformers`, `relabel_padding_scalar_invariance`, `identity_zero_exact`, `nonterminal_output_finite`, `family_count_above_six`. Availability masks полностью отключают отсутствующие tokens.
- [ ] Повторить diagnostic collision I+A(C10) vs I+A(C5⊔C5) для old/new encoder. Эти матрицы проверяют выразительность; без сертифицированно разных d их различение не считается доказательством улучшения distance model.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T05_model -v`; pooled control получает тот же input bank и сопоставимый param/FLOP budget. Snapshot новой schema.

### T06. Full-gradient Bellman и сильный честный сигнал

**Файлы:** `R/objectives/{bellman,supervision,auxiliary}.py`, `R/tests/test_T06_gradients.py`.

**Интерфейсы:** `select_backup`, `recompute_backup`, `supervised_losses(output,records)->LossReport`; `AuxRouting` задаёт независимые stop-gradient границы.

- [ ] На M≠I выбирать минимум по **всем** допустимым primitive successors с no_grad; при тех же theta/packets пересчитать V(M) и выбранное V(aM) с autograd. На I применять boundary condition, не ненулевой backup.
- [ ] Включить exact Huber, two-sided verified interval hinge, verified path Lipschitz inequality и total-V symmetry loss. Не считать random-walk UB или raw teacher cost истинным d.
- [ ] Для макросов проверить раздельно inequality `V(M)<=c+V(N)` и mixed backup. При V=d macro value не меньше primitive minimum; strict winners могут отсутствовать у идеального V. Логировать margin/ties/active-gradient, не только winners.
- [ ] Proposal CE трактовать как imitation доступного portfolio. Qhat обучать абсолютному detached `cost(a)+V(aM)`, а не только centered targets; diagonal/padding mask, known identity-successor target=1 для unit costs. Proposal logits не сравнивать между разными parents как длины.
- [ ] Тесты: `selected_gradient_equals_all_neighbor_autograd` в float64 при unique minimum; при ties сравнивать с тем же deterministic first-index branch, не усредняющей производной. `changed_packet_rejected`, `changed_theta_rejected`, `terminal_has_no_cost_one_residual`, `parent_offsets_detected_by_absolute_qhat`, `V_equals_d_has_no_strict_macro_win`.
- [ ] Для proposal/Qhat вход V по умолчанию detached; shared encoder gradients остаются видимыми. Отдельно проверить full-shared/detached/last-block-separated routing по dev, сохранив один основной V.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T06_gradients -v`; CPU float64 max abs gradient error≤1e-8, GPU tolerance заранее фиксируется в протоколе. Не менять tolerance после неудачи.

### T07. Собственный stage17 objective и amortized basis proposer

**Файлы:** `R/basis/{templates,objective,rounding,proposal}.py`, `R/tests/test_T07_basis.py`. Reference: `S/source_snapshot/code/shared_synth.py` и первичная формула17.

**Интерфейсы:** `evaluate_J(template,B,theta)->ObjectiveResult(value,gradient,kind)`, `conditional_round(template,B,theta)->BasisCandidate`, `compile_basis(candidate)->WordCertificate`, `BasisProposal(encoded,group)->theta`.

- [ ] Template описывает упорядоченные реальные gate/swap choices, a_j∈{1,3}, физические source/target группы. Для каждого eta сохранить тождество D=TBS⁻¹ и полный оператор B; не штрафовать нарушенный endpoint вместо его построения.
- [ ] Реализовать exact J=2Σa_j theta_j+E|D_local(eta)|₀, exact message contraction, градиент и conditional rounding. Оценка O(K2^w) относится к исходному классу stage17: одна выбранная сторона, w двоичных координат сообщения, K заданных переключателей, остальные параметры зафиксированы. В template хранить `side`, `group_wires`, `frozen_frame`; preprocessing матрицы/гистограммы и материализация выходного слова считаются отдельно. Общий одновременно двусторонний или correlated шаблон из T08 не получает эту сложность автоматически. Для small K сверить с полным 2^K перечислением и конечными разностями.
- [ ] Численная conditional rounding принимает итог только после точной integer-cost и endpoint проверки. В точной арифметике округление не увеличивает J; float evaluation требует погрешности, не безусловной гарантии по округлённым числам.
- [ ] Контрпример `J=61+3p+q−6pq`: проверить нулевую стационарную ловушку constrained descent и `(p,q)=(1,1)` с J=59. Сравнивать zero, midpoint, multistart и learned initialization при одинаковом числе exact objective evaluations.
- [ ] Stage19–20 convex/min-cut variants включать через explicit eligible predicate; forbidden multilevel TV/generic nonconvex J возвращает unsupported. Выпуклость в локальных variables не распространяется на theta-веса transformer.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T07_basis -v`; каждый sampled/rounded candidate реализует тот же B с ценой `2L_S+2L_T+popcount(D)`. Сохранить prep/core/restore attribution.

### T08. Широкие блоки и совместные варианты программы

**Файлы:** `R/basis/wide.py`, `R/basis/templates.py`, `R/tests/test_T08_wide.py`.

**Интерфейсы:** `optimize_wide(block,template,initial_theta,backend,budget)->WideResult`; backend=`exact_messages|exact_response|mc`; result содержит estimator semantics, evaluations, uncertainty, verified candidates и status.

- [ ] Разрешить произвольную физическую ширину w в schema, без скрытого w≤4. Exact backend оценивает memory/time до аллокации; невозможность 2^w contraction не маскируется снижением ширины.
- [ ] Сохранять пару независимых механизмов: точные последовательные координатные группы внутри широкого B и глобальный correlated шаблон с общими choices. Локальный проход по группам не называется глобальным оптимумом широкого блока.
- [ ] Для точного прямого J использовать stage60 response backend после T19; до этого статус unsupported. Для MC независимых Bernoulli choices допустима coordinate estimator `dJ/dtheta_j=2a_j+E_eta[-j][C(eta_j=1)-C(eta_j=0)]` с общими samples; он определён и на theta_j=0/1. Correlated distributions требуют своего score/reparameterization estimator и записанной формулы.
- [ ] На small K сравнить математическое ожидание estimator с exhaustive gradient; статистическая проверка на конечном sample не заменяет равенство ожиданий. Отчёт включает variance/SE/sample budget; biased truncation не называется exact gradient.
- [ ] Все полные branch words должны быть допустимы по построению. Endpoint-penalty-only relaxation хранится только как отрицательный контроль. Для postprocessed reward предусмотреть отдельную auxiliary/control-variate оценку, не присваивать ему derivative J17.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T08_wide -v`; broad B, ограниченная память, resource_limit, correlated coordinated-benefit и verified integer acceptance. Профили w=8/16/32 запускаются как измерение, без обещания exact tractability.

### T09. Сохранение оплаченного базиса между блоками

**Файлы:** `R/basis/{frames,compose}.py`, `R/tests/test_T09_frames.py`.

**Интерфейсы:** `FrameState(physical_matrix,frame_words,pending_restoration)`, `compose_blocks(blocks,frame_policy)->WordCertificate` и `materialize(frame)->WordCertificate`.

- [ ] Frame используется как representation/compiler bookkeeping с точной картой к physical M. Для primitive shortest-path задачи достаточно полной M; скрытые скидки по прошлой истории запрещены.
- [ ] Композировать реальные prep/core/restore words; отменять только доказанно одинаковые соседние inverse операции или корректные commuting transformations. Не считать произвольные GL преобразования бесплатными.
- [ ] Тесты: два блока с одинаковой подготовкой против разных; noncommuting preparation order; три CNOT физического SWAP; произвольные начальные значения target wires; финальное восстановление всех проводов.
- [ ] В macro training/search передавать настоящий endpoint и фактическую раскрытую стоимость. Макрос с незавершённым frame допустим лишь при точном physical endpoint либо явном expanded-state model с отдельным critic, не прежним d(M).
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T09_frames -v`; полный word product равен композиции и стоимость равна реально оставшимся gates.

### T10. Postprocessing и endpoint-preserving окна

**Файлы:** `R/postprocess.py`, `R/tests/test_T10_windows.py`. Reference: `code/stage28_exact.py`, `defect_repair.py`, собственные window routines.

**Интерфейсы:** `shorten(cert,config,budget)->PostprocessResult(before,after,window_records)`; каждое окно хранит входной/выходной полный оператор, scope и новый witness.

- [ ] Реализовать inverse/transpose/relabel перезапуски собственного compiler и mapping back; отдельно реальные window substitutions/commuting expansions/endpoint repair28. Повторное обучение модели не смешивается с этим контролем.
- [ ] Тесты включают off-support wires, noncommuting boundary, несовпадающий endpoint при одинаковом hash и valid replacement только после полного word verification.
- [ ] Применять улучшение лишь при строго меньшей физической длине; equal-length варианты могут участвовать в отдельном diversity mode, без ложного счётчика savings. Сохранить no-improvement outcomes.
- [ ] Проверить отсутствие скрытого `time_limit` у вызываемых legacy helpers; текущий `code/general_macro.py` имеет такой аргумент. Использовать явный evaluations/passes budget и проверенную новую обёртку, не предполагать, что старое значение уже удалено везде.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T10_windows -v`; postprocess attribution сообщает delta отдельно от raw synthesis и от symmetry restart.

### T11. Поиск полной программы и честные результаты

**Файлы:** `R/search/{reference,scoring,results}.py`, `R/cli/solve.py`, `R/tests/test_T11_search.py`.

**Интерфейсы:** общий `solve`; scoring=`direct_v|absolute_qhat|proposal_then_v|hamming_control`; action set=`primitive|primitive_plus_paid_macro`; `SearchConfig` содержит physical depth и distinct macro expansion budget.

- [ ] Reference разворачивает полную M. Проверять identity до pruning/caps, dedup делать по полной матрице, учитывать best g и reopening; closed filtering до top-k, отброшенное состояние не объявлять посещённым навсегда.
- [ ] При разной цене edges сравнивать физическое g+score; «слой макросов» не равен физической длине. Hamming — отдельно именованный baseline, без скрытого prefilter в neural variants.
- [ ] Для proposal topK явно `approximate=true`; при K=all режим должен воспроизводить direct V при одинаковых tie rules. Порог shortlist выбирается по dev recall/regret, не по benchmark рекорду.
- [ ] При нескольких minimizers раздельно считать `best_set_hit` (хотя бы один лучший successor попал в shortlist) и `minimizer_coverage` (доля всего множества лучших). Первый нужен для сохранения значения backup; второй дополнительно описывает потерю разнообразия. Отсутствие остальных равных minima само по себе не ухудшает minimum.
- [ ] Тесты: goal behind bad score, duplicate shortest path, state reopened with better g, macro cost>1, complete failure cannot become neural success via fallback, cross-parent additive-Q bias regression.
- [ ] Encoder/reduction mapping и независимый `verify_word` обязательны перед статусом solved. Для failed result `raw_neural_word=null`; incumbent хранится в другом поле.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T11_search -v`; на exact-small сравнить найденные полные слова с d, не объявляя beam всегда оптимальным. Save full traces/provenance.

### T12. Обучение, refresh, checkpoints и продолжение

**Файлы:** `R/train/{schedule,runner,checkpoint}.py`, `R/cli/train.py`, `R/tests/test_T12_resume.py`.

**Интерфейсы:** `train(config,data,run_dir,resume=None)->TrainingResult`, `save_checkpoint(state)->CheckpointManifest`, `load_checkpoint(path,config)->TrainingState`.

- [ ] Сохранить weights, optimizer, schedule, all RNGs, sampler/replay cursor, feature/cache/probe versions и источник каждого label. Resume на другой schema/family map запрещён; частичный transfer weights — отдельный run с явным migration report и новым optimizer для новых параметров.
- [ ] Расписание exact-small/guarded families/paid-basis/walks и размеров фиксируется до запуска. Wide examples и trace labels не заменяются молча small exact из-за стоимости.
- [ ] Обновлять только train teacher/replay по верифицированным новым словам; журналировать, на каком update данные реально вошли в обучение. Финальные улучшенные teacher words не объявлять обучавшими уже законченный checkpoint.
- [ ] Тест `4+4 resume == 8 uninterrupted` на CPU deterministic reference включает parameters/optimizer/sampler и следующие minibatches. Native допускает только заранее заданный численный tolerance и сравнительный semantic test; неудачный старый resume gate не «исправляется» увеличением tolerance без причины.
- [ ] Сохранять last и dev-selected best отдельно, immutable snapshots + atomic pointer. Не запускать второй training процесс поверх существующего run/output. Число updates явно задано; wall-clock stopper отсутствует.
- [ ] Зафиксировать единый транзитивный selection key на полном dev-наборе: сначала больше solved roots, затем меньше сумма нормированных case-costs с заранее фиксированными penalties неуспеха, затем compute/tie rule. Попарное среднее на common-solved subset публикуется как описательная метрика и не определяет порядок множества checkpoints. Конкретные penalties и Uref согласуются с протоколом до запуска.
- [ ] Fault injection nonfinite loss/gradient проверяет отсутствие изменения parameters и optimizer moments при отклонённом update; rejected step явно учитывается в schedule, а не незаметно считается выполненным успешным обновлением.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T12_resume -v`; все новые checkpoint SHA/manifest читаются и подтверждаются. Training launch — следующий отдельный этап реализации, не действие этого плана.

### T13. Сырая диффузионная масса и совместные признаки

**Файлы:** `R/diffusion/{column,pair,probes}.py`, `R/features/diffusion.py`, `R/tests/test_T13_diffusion.py`.

**Интерфейсы:** `column_profile(n,initial,times)->DiffusionPacket`, `pair_profile(n,h0,times,budget)->OracleResult`, `joint_probes(state,probe_spec,seed)->MomentPacket`. DiffusionPacket разделяет class mass, log class size, stationary mass, relative density, density scope, exact-zero и underflow masks.

- [ ] Контроль: uniform ordered CNOT, Q=P−I, общая интенсивность 1, t=n·tau, tau=(1/4,1,4,16); t=0 и n=1 обрабатываются отдельно. Нельзя удалять обратные шаги из этого процесса.
- [ ] Single-column source-relative states `(b,k)` исключают нулевой вектор; подтвердить lumped rates и равномерность внутри класса именно для начального e_j. Не переносить это доказательство на arbitrary labeled starts.
- [ ] Two-column histogram h=(h00,h10,h01,h11), rank2 orbit: transitions h_a(h_b−delta_ab), target b→b xor a, включая self-loops. Число states C(n+3,3)−1−3n; N_h=n!/prod h_a!, pi_h=N_h/((2^n−1)(2^n−2)). Initial histogram — часть запроса.
- [ ] Тесты n=2..6: total rates n(n−1), nonnegative counts, class sizes и detailed balance; сравнить semigroup проекции с full GL3 на выбранных times. При t=0 histogram mass1 не превращается в вероятность1/N_h конкретного endpoint без exchangeability.
- [ ] MC moments всех колонок используют один W, а не независимые words. Тест выявляет исчезновение ковариации при независимых путях. Floors/log normalization сохраняют отдельный raw_class_mass и не создают exact zero из underflow.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T13_diffusion -v`; exact generator≠exact floating semigroup, погрешность численной экспоненты отражена. Стоимость O(n³) pair state space учитывается до включения в каждый forward.

### T14. Native/export и измерение полной стоимости

**Файлы:** `R/native/{export,parity,profile}.py`, `R/tests/test_T14_export.py`; новые адаптеры `S/improved/native/v3_export.py`, `v3_trainer.cpp`, `v3_adapter.cu` после reference gates. Старые бинарники/weights/manifests не перезаписываются.

**Интерфейсы:** `export_model(checkpoint,schema)->ExportManifest`, `compare_backends(fixtures,python,native)->ParityReport`; ABI фиксирует packed rows, valid/action masks, features и порядок control/target.

- [ ] Сначала parity exact state/gates/masks, затем V/proposal/Qhat на n=1/3/4 и физических n=13/25/34/45/58/72/90/108/144. Invalid entries сравниваются по masks, не вычитанием inf−inf.
- [ ] Full-gradient probe сравнивает selected branch/gradients до применения optimizer; native resume проверяется отдельно от inference parity. New fusion schema не подсовывается старому runtime под тем же ID.
- [ ] Отдельно измерять packing, host-device transfer, feature construction, encoder, fusion, all-neighbor sweep, selection и full-word verification; cold/warm cache режимы различаются.
- [ ] Сначала contiguous packed/SoA arrays и batch/chunk reuse; custom kernels вводить после профиля. Не обещать дешёвый exact update всего transformer из одного row XOR.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T14_export -v`, затем hardware parity по фиксированным tolerances протокола. CPU/source review не отмечает GPU gate выполненным.

### T15. Типы границ, весов и композиции

**Файлы:** `R/response/{types,relations}.py`, `R/tests/test_T15_relations.py`.

**Интерфейсы:** `LabeledPorts`, `AffineRelation`, `WeightedResponse`, `CostDegree(unit:physical_cnot|cell|assignment)`, `compose_response(left,right,interface)->OracleResult`. Scalar response и full port response имеют разные типы.

- [ ] Перенести ordered ports, initial protected relation, multiplicity и noncommuting order; ранги не заменяют relation matrices. Явно различать counts assignments, words, traces и diagram coefficients.
- [ ] Тесты stages39/43/52/53/58: одинаковый rank с разной relation; equal endpoint при разных multiplicities; cross-term da′; protected-initial projection; subset relation R⊂kerX против exact-kernel equality.
- [ ] Signed affine/Gauss representation не допускает min/count semiring до корректной positive projection. Cell-degree τ и physical z никогда не смешиваются без явной карты градуировки.
- [ ] Обязательные отрицательные fixtures: restricted/full alphabet distance4/1 из40, premature port forgetting, product independent histograms, подстановка target в промежуточную границу.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T15_relations -v`; composition сравнивается с exhaustive tiny boundary enumeration.

### T16. Проверенные локальные response kernels

**Файлы:** `R/response/local.py`, `R/features/response.py`, `R/tests/test_T16_local.py`.

**Интерфейс:** `local_response(problem:RestrictedProblem,query:ResponseQuery,budget)->OracleResult`; RestrictedProblem явно задаёт alphabet, ports, private/restored wires, frequencies и observable.

- [ ] Последовательно adapters29–30, pair/global35, restricted3-row36, influence47–48, feedback49–50, dynamic source51. Перед adapter читать полные гипотезы и построить tiny full-alphabet reference fixture.
- [ ] Тест stage36 outside-row excursion5<restricted6 запрещает global optimal label от restricted3-row formula. Separate special exact family требует своего recognizer.
- [ ] Проверить stage49 zero rule только для γ¹ при полном условии восстановления private column; не запрещать все нечётные степени. Stage50 core-return не равен private-column restore; две excursions могут компенсироваться.
- [ ] Rational interval certificate и exact rational-function identity имеют разные result kinds. Для51 сохранить gap: исходная запись 544 values/14 независимых пересчётов не означает проверку всех 544 здесь.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T16_local -v`; only eligible kernel outputs поступают в I-features/auxiliary labels, с scope и measured cost.

### T17. Сжатие поля с явной ошибкой

**Файлы:** `R/response/compression.py`, `R/tests/test_T17_compression.py`.

**Интерфейс:** `compress_response(problem,basis,budget)->CompressedResponse(value,absolute_error,relative_error,scope,status)`; certificate содержат K, residual и условия definiteness/normalization в форме независимой проверки.

- [ ] Galerkin/Krylov31: перенести actual `RᵀK⁻¹R` error expression с гипотезами, стоимость сборки K и решения. Малый reduced rank не скрывает дорогой full operator build.
- [ ] Для signed/Fourier reconstruction relative error допустима только при положительной certified lower bound знаменателя; иначе выдавать absolute/unknown.
- [ ] Fixtures32–34/53: spurious early degrees, insufficient modes, degree-preserving rank requirement R≥d+1 в своём action class, freezing rank и average-resolvent inequality.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T17_compression -v`; интервалы покрывают exact tiny answers. Использование compressed response в learned features не превращает его в certified distance.

### T18. Bilinear/shared interface backends

**Файлы:** `R/response/bilinear.py`, `R/response/relations.py`, `R/tests/test_T18_bilinear.py`.

**Интерфейс:** `eliminate_bilinear(problem,ports,weights,budget)->OracleResult`; response хранит full `(K_X,U_X)`, protected ports, weighted coefficients и cost unit.

- [ ] Adapters52/54/55/56: cross-term composition, visible-rank conditions, полный future-port набор, signed/positive weights, exact forgetting через intersection.
- [ ] Тест `rank(Cbar)>k` даёт exact zero только после проверки всех stage55 affine compatibility hypotheses. Несовместимые ports и unsupported cost model — отдельные причины.
- [ ] Не применять rank-invariant convolution к physical shear cost popcount без доказательства инвариантности. Ωda при всех variables — кубичный член; quadratic eliminator обязан отвергать такой неверно объявленный ввод.
- [ ] Тесты tiny enumeration: одинаковый rank/different relation, noncommuting chain order, counts assignments против words, boundary growth budget limit.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T18_bilinear -v`; generic network, не покрытая source chain/contour assumptions, возвращает unsupported.

### T19. Positive/universal и quadratic reference solver

**Файлы:** `R/response/{positive,quadratic}.py`, `R/tests/test_T19_reference.py`.

**Интерфейсы:** `compile_horizon(state,alphabet,horizon)->BoundaryProblem`, `contract(problem,semiring,budget)->OracleResult`, `extract_witness(result)->WordCertificate`. Semiring=`positive_count|min_count|probability`; exact/signed промежуточные представления явно типизированы.

- [ ] Stage57 replicas используют один и тот же physical gate во всех копиях; n+1 replicas не считаются n+1 маленькими независимыми операторами. Stage58 positive relation projection сохраняет multiplicity и initial boundary.
- [ ] Stage59 exact linear syndrome separator κ определяет конкретный interface; κ=0 selector space не удаляет physical operator space. Stage60 сохраняет полный future response `(alpha,B)` и weighted contributions.
- [ ] Сверить coefficients/минимумы на n=2/3 и горизонтах0–4 с независимым direct enumeration. Для horizon-exhausted distinguish certified_no_solution_within_scope от unknown/resource_limit и от global no-solution.
- [ ] Подключить bridge к широкому J17 T08 только если exact weighted expectation/gradient и endpoint-template bijection сверены на exhaustive small K. Усечённая contraction не имеет статуса exact gradient.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T19_reference -v`; witness полный, labels scoped. Большой compiled HGP13 network не помечается solved только за успешную компиляцию.

### T20. Обучаемый порядок contraction

**Файлы:** `R/response/ordering.py`, `R/tests/test_T20_ordering.py`.

**Интерфейсы:** `choose_order(boundary,policy,budget)->EliminationOrder`, `evaluate_order(problem,order)->CostTrace`. Reward — выполненные операции/peak states/bytes, отдельно от CNOT distance.

- [ ] Policy может выбирать порядок exact eliminations из59–60 и guarded approximations из **задачи T17**. Итог exact contraction при завершении должен быть независим от порядка; стоимость может различаться. Приближённый результат имеет отдельный статус и error certificate; он не проходит exact order-invariance gate по одному сходству чисел. На малом reference проверять покрытие точного ответа каждым сертификатом, а на большом — корректность условий и самого сертификата без заявления exact equality.
- [ ] Gradient через завершённую weighted contraction сравнить с exhaustive reference и finite differences. Discrete order policy имеет свой estimator; её обучение не называется градиентным решением d(M).
- [ ] Проверить maximum boundary width, actual counts/bytes, allocation refusal и status unknown при лимите; memory-limited pruning не может вернуть certified zero без доказательства.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T20_ordering -v`; одинаковый exact result для нескольких orders и отдельная сравнительная cost panel.

### T21. Connected Wick61 как отдельная certificate задача

**Файлы:** `R/response/wick.py`, `R/tests/test_T21_wick.py`.

**Интерфейс:** `connected_coefficients(problem,loop_orders,budget)->OracleResult`, с exact coefficient ledger и полным physical degree mapping.

- [ ] Реализовать topology bookkeeping и grading L−n+c, connected L−n+1 в условиях stage61. Не подавать неизвестную L или loop count, вычисленный из эталонного ответа, в features модели.
- [ ] Тесты tiny states: coefficients, annihilating polynomial, exact integer arithmetic/overflow rejection, consistency с independent words. `UNCOMPUTED_LIMIT` не нулевой коэффициент.
- [ ] HGP13 q≤6 остаётся отдельным открытым вычислением до actual full contraction. Прежний witness19/loop7 не доказывает новые нули и не является новым результатом синтеза.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T21_wick -v`; отчёт перечисляет именно вычисленные orders и scope. Отсутствующие orders явно unknown.

### T22. Независимый аудит специальных сертификатов

**Файлы:** `R/evidence.py`, `R/response/certificate_audit.py`, `R/tests/test_T22_certificates.py`, отдельный `R/artifacts/certificates/<run-id>`.

**Интерфейс:** `audit_certificate(bundle,source_manifest,scope)->CertificateAudit`; состояния=`source_claim|independently_verified|formally_proved|rejected|uncomputed`.

- [ ] Для41–46 перенести исправленный transpose rule, past/current/restore constraints и coverage всех секторов. Наличие phase title «complete» не заменяет exhaustive coverage.
- [ ] Stage44: отдельно проверить witness19, sector inventory (необходимые и избыточные), completion records и reproducibility большого computational certificate. Прежний archive result не объявлять заново доказанным без этих gates.
- [ ] Stage45/46 analytic cases и stage49 single-use conditions включать лишь в доказанном scope; counterexamples помещать в negative fixtures.
- [ ] HGP13 certificate остаётся audit/evaluation asset и не используется как training label/feature; такой источник может закрывать optimality только соответствующей матрицы/hash/alphabet.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T22_certificates -v`; unit tests проверяют verifier и incomplete-sector rejection. Большой повтор и Lean formalization имеют собственные явные статусы, не автоматически «passed» от unit tests.

### T23. Абляции, полные программы и таблица сравнения

**Файлы:** `R/cli/benchmark.py`, `R/search/results.py`, `R/configs/experiments/*.json`, `R/tests/test_T23_reporting.py`; панели задаёт EXPERIMENT_PROTOCOL_RU.md.

**Интерфейс:** `run_panel(panel_config,artifact_root)->PanelManifest`, `build_table(manifests,external_sources)->ComparisonTable`.

- [ ] Лестница: old pooled/fusion fixed bank; A/B/C/D/E/G/H families и leave-one-family-out; UB-only/proposal-only/combined basis data; local J proposer; full/macro search; raw/postprocessing/symmetry. Сохранять одинаковые underlying states/action subsets при проверке именно certificate quality.
- [ ] Две оси затрат: одинаковый algorithmic budget и измеренная end-to-end стоимость. Если для анализа строится equal-time slice, это заранее объявленный аналитический срез полных traces, не скрытая остановка обучения. Показывать total training cost отдельно.
- [ ] Main result: n, canonical matrix key, allowed source, external length/source/matrix-match status, own compiler, raw NN, postprocessed NN, best portfolio, integer delta и percent, solved status, physical length/depth, time и budgets. Метод авторов Ours и наш метод подписываются раздельно.
- [ ] Внешняя дельта допустима только для одной и той же полной M/алфавита/цен. Совпадение [[n,k;c]] не является таким доказательством. EA с неподтверждёнными допустимыми исходниками получает `input_unresolved`, не подставленные числа.
- [ ] Тесты `failure_is_not_incumbent`, `matrix_mismatch_blocks_delta`, `missing_is_not_zero`, `training_cost_not_solve_time`, `sum_only_common_solved_set`; aggregate all-case таблица сохраняет failures/coverage и не скрывает их средним по успехам.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T23_reporting -v`; все solved rows независимо перемножаются, checkpoint выбирается только по dev. Нулевые/отрицательные эффекты сохраняются.

### T24. Интеграция и воспроизводимый итог

**Файлы:** `R/cli/{verify,release}.py`, `R/README_RU.md`, `R/tests/test_T24_release.py`, `R/artifacts/releases/<run-id>`.

**Интерфейс:** `package_release(config,manifests,results)->ReleaseManifest`; пакет включает source hashes, inputs/provenance, complete words, environment, commands и evidence scopes.

- [ ] Проверить все ссылки T00–T24 и source coverage17–61: каждому результату соответствует implementation, data/oracle, verifier, negative test или явно открытое research item. Не выдавать заполненную таблицу планирования за закрытые задачи.
- [ ] Запуск reference `verify` из чистой отдельной run-папки воспроизводит каждую заявленную chain/матрицу. Training/checkpoint restoration проверяется собственным gate, не только загрузкой файла.
- [ ] Сравнить результаты raw field, собственных basis macros и postprocessing; перечислить, какой фактор реально сократил длину. Если NN не выиграла, итог так и формулируется.
- [ ] Gate: `python -B -m unittest research_v3.tests.test_T24_release -v`; отчёт содержит completed/failed/unknown по всем задачам, все обязательные source/contract gates и цену воспроизведения. Только после этого можно заявлять выполненную соответствующую часть плана.

## 4. Минимальный первый сквозной проход

Первый проверяемый increment: T00–T06 + primitive subset T11/T12 на n≤4 и диагностических собственных dev matrices; он проверяет путь **все включённые признаки → первый transformer → feature heads → fusion → V → полная проверенная программа**. Затем подключаются wide basis17, joint diffusion и native execution. Этот порядок не заменяет остальные задачи: он даёт работающий сквозной контроль до вложения вычислений в большие backends.

Ни этот документ, ни нынешний обмен между чатами не запускают обучение и не продолжают прерванные parent processes. Конкретный запуск при реализации фиксируется новым config/run, после чтения актуального состояния машины. Дорогие вычисления и деньги не предполагаются разрешёнными автоматически из существования плана.

## 5. Критерий готовности плана и критерий готовности системы

План готов, когда architecture/feature/coverage/protocol не противоречат друг другу, номера задач разрешаются, ключевые типы согласованы и второй участник проверил существенные математические риски. Система готова только после actual implementation/test/run evidence. Для заявления улучшения нужны полностью проверенные более короткие слова на заранее зафиксированных разрешённых целях и объявленные затраты; уменьшение loss, красивая feature map или успешный small contraction этого не заменяют.
