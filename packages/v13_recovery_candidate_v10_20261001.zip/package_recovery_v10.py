"""Fresh immutable source closure; native data/training remain unaccepted."""
import hashlib,json,re,zipfile
from pathlib import Path,PurePosixPath
from research_v3.data.stream_solver_dataset_v13 import data_source_hashes
root=Path(__file__).resolve().parent
base=root/'v13_recovery_candidate_v9_20261001.zip'
assert hashlib.sha256(base.read_bytes()).hexdigest()=='e16feaef3c0227f8b5ff06b081ebcbbc5776ad95c247b903baf1ce31ca947b30'
with zipfile.ZipFile(base) as archive:
 previous=json.loads(archive.read('source_manifest.json'))
 contents={n:archive.read(n) for n in previous['files']}
 assert all(hashlib.sha256(contents[n]).hexdigest()==sha for n,sha in previous['files'].items())
for tree in ('research_v3','code'):
 for path in (root/tree).rglob('*.py'):
  if 'artifacts' not in path.parts and '__pycache__' not in path.parts:
   contents[path.relative_to(root).as_posix()]=path.read_bytes()
for pattern in ('T03_*2026-10-01.json','NORMATIVE_REQUIREMENT_STATUS_V*_2026-10-01.json'):
 for path in root.glob(pattern):contents[path.name]=path.read_bytes()
contents['package_recovery_v10.py']=Path(__file__).read_bytes()
ledger=json.loads((root/'NORMATIVE_REQUIREMENT_STATUS_V36_2026-10-01.json').read_text(encoding='utf-8'))
for name,expected in ledger['normative_source_sha256'].items():
 data=(root.parents[1]/'docs/superpowers/plans/2026-09-26-frontier61'/(name+'.md')).read_bytes()
 assert hashlib.sha256(data).hexdigest()==expected
 contents['normative/'+name+'.md']=data
for n,data in contents.items():
 path=PurePosixPath(n)
 assert not path.is_absolute() and '..' not in path.parts
 assert not re.search(rb'(?:hf_[A-Za-z0-9]{30,}|gh[pousr]_[A-Za-z0-9]{30,}|sk-[A-Za-z0-9]{30,}|/session/eyJ[A-Za-z0-9_-]{40,})',data),n
manifest={'schema':'own_recovery_candidate_v10','base_archive_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),
 'scope':'eight-family and corrected walk mixture source; teacher/exposure/checkpoint candidate; fresh native source and database required',
 'native_acceptance':False,'production_training_launched':False,
 'dataset_source_sha256':data_source_hashes(),
 'normative_source_sha256':ledger['normative_source_sha256'],
 'files':{n:hashlib.sha256(data).hexdigest() for n,data in sorted(contents.items())}}
contents['source_manifest.json']=json.dumps(manifest,indent=2,sort_keys=True).encode()
target=root/'v13_recovery_candidate_v10_20261001.zip'
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED) as archive:
 for n,data in sorted(contents.items()):archive.writestr(n,data)
with zipfile.ZipFile(target) as archive:
 assert archive.testzip() is None
 assert all(hashlib.sha256(archive.read(n)).hexdigest()==sha for n,sha in manifest['files'].items())
print(json.dumps({'archive':target.name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'files':len(manifest['files']),'bytes':target.stat().st_size,'normative_documents_verified':5}))
