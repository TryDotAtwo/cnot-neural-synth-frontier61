"""Own source recovery closure, preserving previous public candidates."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import zipfile

root = Path(__file__).resolve().parent
workspace = root.parents[1]
base = root/'github_transfer/packages/v13_consolidated_candidate_v4_20260930.zip'
assert hashlib.sha256(base.read_bytes()).hexdigest() == '5cf6f79d9df0724c71400e06bf84f75dc6cf3d0388431e2977bb068a50b01272'
with zipfile.ZipFile(base) as source:
    old = json.loads(source.read('source_manifest.json'))
    contents = {}
    for name, expected in old['files'].items():
        data = source.read(name)
        assert hashlib.sha256(data).hexdigest() == expected
        contents[name] = data
for tree in ('research_v3', 'code'):
    for path in (root/tree).rglob('*.py'):
        if '__pycache__' not in path.parts and 'artifacts' not in path.parts:
            contents[path.relative_to(root).as_posix()] = path.read_bytes()
for name in ('full_training_config.json', 'NORMATIVE_REQUIREMENT_STATUS_V14_2026-10-01.json',
             'T03_REFRESH_FORWARD_ADMISSION_V3_2026-10-01.json',
             'MOLAB_TERMINAL_SESSION_EVIDENCE_2026-10-01.json',
             'MOLAB_RECOVERY_PREFLIGHT_2026-10-01.json', 'package_recovery_v5.py'):
    contents[name] = (root/name).read_bytes()
for name in ('IMPLEMENTATION_PLAN_RU.md', 'ARCHITECTURE_AUDIT_RU.md', 'FEATURE_BANK_RU.md',
             'STAGE_COVERAGE_RU.md', 'EXPERIMENT_PROTOCOL_RU.md'):
    contents['normative/'+name] = (workspace/'docs/superpowers/plans/2026-09-26-frontier61'/name).read_bytes()
for name in ('cnot_research_journal/stage18_exact_boundary/18_complexity_and_exact_family_ru.md',
             'stage35_geodesic_vertex/35_pair_kernel_to_global_geodesic_ru.md',
             'cnot_research_journal/stage37_general_graded_kernel/37_exact_zero_excess_propagator_ru.md'):
    member = 'research_v3/artifacts/frontier61_source_v1/'+name
    contents[member] = (root/member).read_bytes()
for name, data in contents.items():
    parts = PurePosixPath(name)
    assert not parts.is_absolute() and '..' not in parts.parts
    assert not re.search(rb'(?:hf_[A-Za-z0-9]{30,}|gh[pousr]_[A-Za-z0-9]{30,}|sk-[A-Za-z0-9]{30,}|/session/eyJ[A-Za-z0-9_-]{40,})', data)
manifest = dict(schema='own_recovery_candidate_v5', scope='T03 reference/native admission candidate; production and missing source gates OPEN',
                base_sha256=hashlib.sha256(base.read_bytes()).hexdigest(),
                files={name:hashlib.sha256(data).hexdigest() for name,data in sorted(contents.items())})
contents['source_manifest.json'] = json.dumps(manifest,indent=2,sort_keys=True).encode()
archive = root/'v13_recovery_candidate_v5_20261001.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as output:
    for name,data in sorted(contents.items()):
        output.writestr(name,data)
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    for name, expected in manifest['files'].items():
        assert hashlib.sha256(check.read(name)).hexdigest() == expected
print(json.dumps(dict(path=str(archive), bytes=archive.stat().st_size,
                      sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), files=len(manifest['files']))))
