"""Immutable complete v7 source closure, fresh native destination required."""
import hashlib,json,re,zipfile
from pathlib import Path,PurePosixPath
from research_v3.data.stream_solver_dataset_v13 import GUARDED_PRIMARY_SOURCES,data_source_hashes
root=Path(__file__).resolve().parent
base=root/'v13_recovery_candidate_v6_20261001.zip'
assert hashlib.sha256(base.read_bytes()).hexdigest()=='cdf9284b10f83459583c402f34b2836ae11d22a6ef919c8fe3a8d8a2942d20e8'
with zipfile.ZipFile(base) as oldzip:
    old=json.loads(oldzip.read('source_manifest.json'))
    contents={name:oldzip.read(name) for name in old['files']}
    assert all(hashlib.sha256(contents[name]).hexdigest()==sha for name,sha in old['files'].items())
for tree in ('research_v3','code'):
    for path in (root/tree).rglob('*.py'):
        if 'artifacts' not in path.parts and '__pycache__' not in path.parts:
            contents[path.relative_to(root).as_posix()]=path.read_bytes()
for name in GUARDED_PRIMARY_SOURCES:
    contents['research_v3/'+name]=(root/'research_v3'/name).read_bytes()
for name in ('T03_STAGE38_READER_GATE_V2_2026-10-01.json','T03_GUARDED_PRIMARY_CLOSURE_GATE_2026-10-01.json','T03_EIGHT_FAMILY_DISPATCH_GATE_2026-10-01.json','T03_GUARDED_DISPATCH_NEGATIVE_V1_2026-10-01.json','T03_GUARDED_DISPATCH_NEGATIVE_V2_2026-10-01.json','T03_NATIVE_PANEL_DRIVER_NEGATIVE_V1_2026-10-01.json','T03_NATIVE_PANEL_DRIVER_GATE_2026-10-01.json','NORMATIVE_REQUIREMENT_STATUS_V23_2026-10-01.json','package_recovery_v7.py'):
    contents[name]=(root/name).read_bytes()
for name,data in contents.items():
    rel=PurePosixPath(name)
    assert not rel.is_absolute() and '..' not in rel.parts
    assert not re.search(rb'(?:hf_[A-Za-z0-9]{30,}|gh[pousr]_[A-Za-z0-9]{30,}|sk-[A-Za-z0-9]{30,}|/session/eyJ[A-Za-z0-9_-]{40,})',data),name
manifest={'schema':'own_recovery_candidate_v7','base_archive_sha256':hashlib.sha256(base.read_bytes()).hexdigest(),'scope':'eight-family source candidate; T03 native full panels and production open','dataset_source_sha256':data_source_hashes(),'files':{n:hashlib.sha256(d).hexdigest() for n,d in sorted(contents.items())}}
contents['source_manifest.json']=json.dumps(manifest,indent=2,sort_keys=True).encode()
archive=root/'v13_recovery_candidate_v7_20261001.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED) as z:
    for n,d in sorted(contents.items()):z.writestr(n,d)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(hashlib.sha256(z.read(n)).hexdigest()==sha for n,sha in manifest['files'].items())
print(json.dumps({'archive':archive.name,'bytes':archive.stat().st_size,'files':len(manifest['files']),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}))
