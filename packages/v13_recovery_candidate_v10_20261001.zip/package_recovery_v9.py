"""Fresh full source closure; previous native source must remain immutable."""
import hashlib,json,re,zipfile
from pathlib import Path,PurePosixPath
root=Path(__file__).resolve().parent
base=root/'v13_recovery_candidate_v8_20261001.zip'
assert hashlib.sha256(base.read_bytes()).hexdigest()=='41d4375595d1d3a2de071e09e800291487523bd7426eb3642c26a3c134de84a3'
with zipfile.ZipFile(base) as archive:
 manifest=json.loads(archive.read('source_manifest.json'))
 contents={n:archive.read(n) for n in manifest['files']}
 assert all(hashlib.sha256(contents[n]).hexdigest()==sha for n,sha in manifest['files'].items())
for tree in ('research_v3','code'):
 for path in (root/tree).rglob('*.py'):
  if 'artifacts' not in path.parts and '__pycache__' not in path.parts:
   contents[path.relative_to(root).as_posix()]=path.read_bytes()
for n in ('T03_EXPOSURE_SNAPSHOT_REFERENCE_GATE_2026-10-01.json','T03_EXPOSURE_CHECKPOINT_BINDING_GATE_2026-10-01.json','T03_NATIVE_EXPOSURE_RESUME_PREPARED_2026-10-01.json','NORMATIVE_REQUIREMENT_STATUS_V30_2026-10-01.json','package_recovery_v9.py'):
 contents[n]=(root/n).read_bytes()
contents['T03_NATIVE_DIAGNOSTIC_LOCAL_GUARD_2026-10-01.json']=json.dumps({
 'status':'local_preimport_guard_verified_native_open','exit_code':1,
 'error':'this native diagnostic must execute in Molab','report_created':False,
 'native_command':'CUBLAS_WORKSPACE_CONFIG=:4096:8 python -m research_v3.cli.audit_native_exposure_resume --report /marimo/exposure-resume-v9.json'}).encode()
for n,data in contents.items():
 path=PurePosixPath(n)
 assert not path.is_absolute() and '..' not in path.parts
 assert not re.search(rb'(?:hf_[A-Za-z0-9]{30,}|gh[pousr]_[A-Za-z0-9]{30,}|sk-[A-Za-z0-9]{30,}|/session/eyJ[A-Za-z0-9_-]{40,})',data),n
manifest.update(schema='own_recovery_candidate_v9',base_archive_sha256=hashlib.sha256(base.read_bytes()).hexdigest(),
 scope='snapshot/checkpoint binding and prepared native diagnostic; full resume and production remain open',
 files={n:hashlib.sha256(data).hexdigest() for n,data in sorted(contents.items())})
contents['source_manifest.json']=json.dumps(manifest,indent=2,sort_keys=True).encode()
target=root/'v13_recovery_candidate_v9_20261001.zip'
with zipfile.ZipFile(target,'x',zipfile.ZIP_DEFLATED) as archive:
 for n,data in sorted(contents.items()):archive.writestr(n,data)
with zipfile.ZipFile(target) as archive:
 assert archive.testzip() is None
 assert all(hashlib.sha256(archive.read(n)).hexdigest()==sha for n,sha in manifest['files'].items())
print(json.dumps({'archive':target.name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'files':len(manifest['files'])}))
