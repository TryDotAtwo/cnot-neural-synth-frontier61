"""Foreground eight-family native source audit; independent of train/holdout.

Every case keeps its status, matrix/certificate when exact, physical cost,
source evidence and full end-to-end producer plus reader verification time.
No seconds cutoff or fallback. Resource-limit cases do not prove exclusion.
"""
import argparse,json,os,platform
from time import perf_counter
from dataclasses import asdict
from pathlib import Path
from ..data.guarded_family_dispatch_v1 import EXACT_FAMILIES,make_exact_root,GuardedGenerationLimit
from ..data.stream_reader_v13 import decode_record
from ..data.stream_solver_dataset_v13 import SIZES,data_source_hashes

def audit_case(kind,seed,n):
    started=perf_counter()
    try:
        record,audit=make_exact_root(kind,seed,n,'dev')
        decoded=decode_record(json.dumps(asdict(record)))
        if decoded!=record:raise ValueError('native reader changed record')
        result={'kind':kind,'seed':seed,'n':n,'status':'exact',
                'record':asdict(record),'audit':audit,'physical_cost':record.upper_bound}
    except GuardedGenerationLimit as error:
        result={'kind':kind,'seed':seed,'n':n,'status':error.audit['status'],
                'audit':error.audit,'physical_cost':None,'record':None}
    result['end_to_end_seconds']=perf_counter()-started
    return result

def write_report(path,report):
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    os.replace(temporary,path)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--report',type=Path,required=True)
    parser.add_argument('--seed-base',type=int,default=810038)
    parser.add_argument('--sizes',type=int,nargs='+',default=SIZES)
    args=parser.parse_args()
    if any(n<8 for n in args.sizes):raise ValueError('joint source panel requires n>=8')
    if args.report.exists():raise ValueError('preserve existing report; select a fresh audit path')
    args.report.parent.mkdir(parents=True,exist_ok=True)
    report={'schema':'T03_guarded_eight_family_native_panel_v1','python':platform.python_version(),
            'source_sha256':data_source_hashes(),'cases':[],
            'scope':'source admission diagnostics; not production roots or synthesis quality',
            'planned_cases':len(args.sizes)*len(EXACT_FAMILIES),'stage':'running'}
    write_report(args.report,report)
    for kind_index,kind in enumerate(EXACT_FAMILIES):
        for n in args.sizes:
            seed=args.seed_base+kind_index*100000+n
            print(json.dumps({'event':'case_start','kind':kind,'n':n,'seed':seed}),flush=True)
            try:case=audit_case(kind,seed,n)
            except Exception as error:
                report['stage']='failed';report['failure']={'kind':kind,'n':n,'type':type(error).__name__,'message':str(error)}
                write_report(args.report,report)
                raise
            report['cases'].append(case);write_report(args.report,report)
            print(json.dumps({'event':'case_completed','kind':kind,'n':n,'status':case['status'],
                              'physical_cost':case['physical_cost'],'seconds':case['end_to_end_seconds']}),flush=True)
    report['stage']='completed'
    report['exact_cases']=sum(case['status']=='exact' for case in report['cases'])
    report['resource_limit_cases']=sum(case['status']=='resource_limit' for case in report['cases'])
    report['all_admitted']=report['exact_cases']==report['planned_cases']
    write_report(args.report,report)
    print(json.dumps({'event':'panel_completed','all_admitted':report['all_admitted'],
                      'exact_cases':report['exact_cases'],'resource_limit_cases':report['resource_limit_cases']}),flush=True)

if __name__=='__main__':main()
