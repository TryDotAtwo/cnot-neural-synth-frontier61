"""Read-only live process and own dataset inventory; never restarts work."""
import argparse
import hashlib
import json
import re
from pathlib import Path
import sqlite3
import subprocess


def process_inventory(proc=Path('/proc')):
    processes = []
    for path in proc.iterdir():
        if not path.name.isdigit():
            continue
        try:
            args = (path / 'cmdline').read_bytes().split(b'\0')
            executable = Path(args[0].decode(errors='replace')).name
            modules = [arg.decode() for arg in args
                       if re.fullmatch(rb'research_v3(?:\.[A-Za-z_][A-Za-z_0-9]*)+', arg)]
            # Never print arguments, URLs, environment, tokens, or kernel code.
            if executable.startswith(('python', 'marimo')) or modules:
                processes.append({'pid': int(path.name), 'executable': executable,
                                  'own_modules': modules,
                                  'state': (path / 'status').read_text().split('State:', 1)[1].splitlines()[0].strip()})
        except (FileNotFoundError, PermissionError, IndexError, ProcessLookupError):
            continue
    return sorted(processes, key=lambda p: p['pid'])


def inspect_database(path):
    path = Path(path).resolve()
    if not path.is_file():
        return {'path': str(path), 'status': 'missing'}
    connection = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)
    try:
        connection.execute('PRAGMA query_only=ON')
        tables = [r[0] for r in connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
        result = {'path': str(path), 'status': 'read_only',
                  'integrity': [r[0] for r in connection.execute('PRAGMA integrity_check')],
                  'tables': tables}
        if 'metadata' in tables:
            result['metadata_keys'] = [r[0] for r in connection.execute(
                'SELECT key FROM metadata ORDER BY key')]
            for key in ('holdout_seal', 'manifest'):
                row = connection.execute('SELECT value FROM metadata WHERE key=?', (key,)).fetchone()
                if row:
                    result[key + '_sha256'] = hashlib.sha256(row[0].encode()).hexdigest()
        if 'roots' in tables:
            result['split_width_counts'] = [list(r) for r in connection.execute(
                "SELECT split,json_extract(record_json,'$.state.n'),COUNT(*) "
                'FROM roots GROUP BY split,json_extract(record_json,\'$.state.n\') ORDER BY split,2')]
        return result
    finally:
        connection.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--db', action='append', required=True)
    parser.add_argument('--source', action='append', default=[])
    args = parser.parse_args()
    sources = []
    for value in args.source:
        path = Path(value).resolve()
        if path.suffix not in ('.py', '.json', '.md') or path.name.startswith('.'):
            raise ValueError('explicit own source/evidence paths only; no credential files')
        sources.append({'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()
                        if path.is_file() else None})
    gpu = subprocess.run(['nvidia-smi', '--query-compute-apps=pid,process_name,used_gpu_memory',
                          '--format=csv,noheader,nounits'], capture_output=True, text=True)
    print(json.dumps({'schema': 'own_molab_readonly_inventory_v13',
        'processes': process_inventory(), 'gpu_query_exit': gpu.returncode,
        'gpu_processes': gpu.stdout.strip().splitlines(),
        'databases': [inspect_database(p) for p in args.db], 'sources': sources,
        'scope': 'inventory only; no word verification, panel acceptance or process changes'},
        sort_keys=True))


if __name__ == '__main__':
    main()
