"""Foreground Molab-only diagnostic; all failures retained, no timeout."""
import argparse,hashlib,json,os,platform,sys,traceback,unittest
from pathlib import Path
from time import perf_counter

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--report',required=True)
    args=parser.parse_args()
    # Reject before importing torch or initializing any local CUDA runtime.
    if not Path('/marimo').is_dir():
        raise RuntimeError('this native diagnostic must execute in Molab')
    if os.environ.get('CUBLAS_WORKSPACE_CONFIG') not in (':4096:8',':16:8'):
        raise RuntimeError('declare CUBLAS_WORKSPACE_CONFIG before starting Python')
    target=Path(args.report)
    if target.exists():raise FileExistsError(target)
    import torch
    if not torch.cuda.is_available():raise RuntimeError('native CUDA unavailable')
    started=perf_counter()
    suite=unittest.defaultTestLoader.loadTestsFromName('research_v3.tests.test_molab_model_exposure')
    result=unittest.TextTestRunner(stream=sys.stdout,verbosity=2).run(suite)
    synchronization_error=None
    try:torch.cuda.synchronize()
    except Exception:synchronization_error=traceback.format_exc()
    source=Path(__file__).resolve().parents[1]/'tests/test_molab_model_exposure.py'
    report={'schema':'own_native_exposure_resume_diagnostic_v1',
        'scope':'bounded A01/B01 actual CUDA field; full selected Bellman/production not qualified',
        'tests':result.testsRun,'skipped':[(str(test),reason) for test,reason in result.skipped],
        'failures':[(str(test),detail) for test,detail in result.failures],
        'errors':[(str(test),detail) for test,detail in result.errors],
        'synchronization_error':synchronization_error,
        'accepted':result.wasSuccessful() and result.testsRun==2 and not result.skipped and synchronization_error is None,
        'end_to_end_seconds':perf_counter()-started,
        'environment':{'python':platform.python_version(),'torch':torch.__version__,
            'cuda':torch.version.cuda,'gpu':torch.cuda.get_device_name(),
            'cublas_workspace_config':os.environ['CUBLAS_WORKSPACE_CONFIG']},
        'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'own_source_closure_sha256':{
            path.relative_to(source.parents[1]).as_posix():hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted(source.parents[1].rglob('*.py')) if '__pycache__' not in path.parts}}
    with target.open('x',encoding='utf-8') as output:
        json.dump(report,output,indent=2);output.flush();os.fsync(output.fileno())
    print(json.dumps({'report':str(target),'accepted':report['accepted'],'tests':result.testsRun}),flush=True)
    return 0 if report['accepted'] else 1

if __name__=='__main__':sys.exit(main())
