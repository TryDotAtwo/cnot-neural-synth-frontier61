from dataclasses import dataclass, field
import hashlib
import json
from ..words import apply
from ..symmetry import map_problem


def known_symmetry_keys(states, alphabet, permutations=()):
    """Finite declared augmentations only, not full orbit canonicalization."""
    result = set()
    for state in states:
        views = [state, map_problem(state, alphabet, 'inverse').state]
        try:
            views.extend([map_problem(s, alphabet, 'transpose').state for s in tuple(views)])
        except ValueError:
            pass  # Transpose outside this fixed alphabet is not an allowed augmentation.
        for view in views:
            result.add(view.key)
            for permutation in permutations:
                mapped = map_problem(view, alphabet, tuple(permutation))
                if mapped.alphabet == alphabet:
                    result.add(mapped.state.key)
    return result


@dataclass
class Exposures:
    seen_as_label: set = field(default_factory=set)
    seen_by_forward: set = field(default_factory=set)
    seen_by_gradient: set = field(default_factory=set)

    def observe(self, kind, state):
        target = {'label': self.seen_as_label, 'forward': self.seen_by_forward,
                  'gradient': self.seen_by_gradient}[kind]
        target.add(state.key)


class SplitPolicy:
    def __init__(self, forbidden_keys):
        self.forbidden_keys = set(forbidden_keys)

    @staticmethod
    def assign(source_family, seed, salt='split_v1'):
        # Whole family/seed unit: changing trajectory suffix never moves a sample.
        bucket = int(hashlib.sha256(repr((salt, source_family, seed)).encode()).hexdigest(), 16) % 100
        return 'train' if bucket < 80 else 'dev' if bucket < 90 else 'test'

    def filter_full_backup(self, records, alphabet, macro_successors=None):
        accepted, rejected = [], 0
        for record in records:
            keys = {record.state.key}
            keys.update(apply(record.state, gate, alphabet).key for gate in alphabet.allowed)
            if macro_successors is not None:
                keys.update(state.key for state in macro_successors(record.state))
            if keys & self.forbidden_keys:
                rejected += 1
            else:
                accepted.append(record)
        return accepted, {'rejected_parents': rejected, 'neighbors_removed': 0}

    def audit(self, records, exposures):
        labels = {r.state.key for r in records} | exposures.seen_as_label
        label_overlap = labels & self.forbidden_keys
        forward_overlap = exposures.seen_by_forward & self.forbidden_keys
        gradient_overlap = exposures.seen_by_gradient & self.forbidden_keys
        banks={'labels':labels,'forward':exposures.seen_by_forward,
               'gradient':exposures.seen_by_gradient,'forbidden':self.forbidden_keys}
        hashes={name:hashlib.sha256(json.dumps(sorted(keys),separators=(',',':'),
                    ensure_ascii=True,allow_nan=False).encode()).hexdigest() for name,keys in banks.items()}
        return {'schema':'split_exposure_audit_v2',
                'label_overlap': len(label_overlap), 'forward_overlap': len(forward_overlap),
                'gradient_overlap': len(gradient_overlap), 'label_held_out': not label_overlap,
                'transductive':not label_overlap and bool(forward_overlap or gradient_overlap),
                'strict_unseen': not (label_overlap or forward_overlap or gradient_overlap),
                'full_key_set_sha256':hashes,'set_counts':{name:len(keys) for name,keys in banks.items()},
                'orbit_scope':'supplied full keys and declared finite augmentations; no complete orbit claim'}
