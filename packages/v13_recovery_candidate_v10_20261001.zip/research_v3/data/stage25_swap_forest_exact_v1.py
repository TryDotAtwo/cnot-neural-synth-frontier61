"""Own stage25 sections1-2 swap-fed forest global-distance recognizer.

The changed-row bound is strengthened by one: the first core update needs
e_a+e_b, absent from all initial/final rows. Full word length reaches R+1.
"""
from .stage23_forest_exact_v1 import ForestResult
from ..contracts import AlphabetSpec,MatrixState,Gate,WordCertificate
from ..words import verify_word
from dataclasses import replace
import random
from .records import SampleRecord

SOURCE_NOTES_SHA256='ad833a4d2877cfdcc1589e0c8e06e077d004dc2454917e1891199530f054efe2'


def recognize(state,alphabet):
    if state.n!=alphabet.n or state.alphabet_id!=alphabet.id:
        raise ValueError('state/alphabet mismatch')
    def unsupported(reason):
        return ForestResult('unsupported',state,alphabet.id,None,None,{}, {},reason)
    if state.n<2 or alphabet!=AlphabetSpec.all_to_all(state.n):
        return unsupported('requires full unit all-to-all CNOT')
    rows=state.packed_rows
    lookup={row:i for i,row in enumerate(rows)}
    for a in range(state.n):
        if rows[a].bit_count()!=1:
            continue
        b=rows[a].bit_length()-1
        if a>=b or rows[b]!=1<<a:
            continue
        active={i for i,row in enumerate(rows) if row!=1<<i}-{a,b}
        parents={}
        valid=True
        for v in active:
            diff=rows[v]^(1<<v)
            if diff==1<<a:
                parents[v]=a
            elif diff==1<<b:
                parents[v]=b
            else:
                parent=lookup.get(diff)
                if parent not in active or parent==v:
                    valid=False
                    break
                parents[v]=parent
        if not valid:
            continue
        depths={}
        for v in active:
            ancestor_bits,current,seen=1<<v,parents[v],{v}
            while current not in (a,b):
                if current in seen or current not in active:
                    valid=False
                    break
                seen.add(current)
                ancestor_bits^=1<<current
                current=parents[current]
            if not valid or ancestor_bits^(1<<current)!=rows[v]:
                valid=False
                break
            depths[v]=len(seen)
        if not valid:
            continue
        # Guard the exact lower-bound contradiction explicitly.
        needed=(1<<a)^(1<<b)
        if needed in rows or needed.bit_count()==1:
            raise AssertionError('first-core-update lower-bound guard failed')
        order=tuple(sorted(active,key=lambda v:(depths[v],v)))
        construction=(Gate(a,b),Gate(b,a),Gate(a,b))+tuple(
            Gate(b if parents[v]==a else a if parents[v]==b else parents[v],v)
            for v in order)
        changed=sum(row!=1<<i for i,row in enumerate(rows))
        distance=changed+1
        assert len(construction)==distance
        word=WordCertificate(state,MatrixState.identity(alphabet),tuple(reversed(construction)),
            distance,'stage25_swap_forest_exact_v1',f'stage25:{state.n}:{rows}')
        verify_word(word,alphabet)
        return ForestResult('exact',state,alphabet.id,distance,word,
            {'full_unit_all_to_all':True,'full_matrix_reconstructed':True,
             'source_notes_sha256':SOURCE_NOTES_SHA256},
            {'core':(a,b),'parents':tuple(sorted(parents.items())),
             'construction_order':order,'changed_rows':changed,
             'extra_step_lower_bound':1,'missing_initial_final_control':needed})
    return unsupported('matrix outside swap-fed forest family')


def verify_result(result,alphabet):
    if recognize(result.state,alphabet)!=result:
        raise ValueError('stage25 result failed re-recognition')
    return result.status=='exact'


def generate(seed,n,*,split):
    if type(seed) is not int or type(n) is not int or n<2 or split not in ('train','dev','test'):
        raise ValueError('invalid swap-forest input')
    rng=random.Random(seed)
    order=list(range(n));rng.shuffle(order)
    a,b=order[:2]
    rows=[1<<i for i in range(n)]
    rows[a]=1<<b;rows[b]=1<<a
    active=[]
    for v in order[2:]:
        if rng.randrange(4)==0:
            continue
        parent=rng.choice([a,b]+active)
        rows[v]=(1<<v)^((1<<parent) if parent in (a,b) else rows[parent])
        active.append(v)
    alphabet=AlphabetSpec.all_to_all(n)
    result=recognize(MatrixState(n,tuple(rows),alphabet.id),alphabet)
    if not verify_result(result,alphabet):
        raise AssertionError('generated swap forest failed recognition')
    return result


def ingest_exact(replay,result,*,seed,split):
    if type(seed) is not int or split not in ('train','dev','test'):
        raise ValueError('invalid swap-forest lineage')
    if not verify_result(result,replay.alphabet):
        raise ValueError('unsupported swap-forest exact result')
    if result.state.key in replay.forbidden_keys:
        raise ValueError('forbidden holdout label')
    old=replay.records.get(result.state.key)
    if old is not None and old.exact_distance is not None and old.exact_distance!=result.distance:
        raise ValueError('conflicting exact distance')
    record=SampleRecord(result.state,(result.word,),f'stage25:{split}:{seed}:{result.state.n}',
                        seed,'stage25_swap_forest_exact_v1',split)
    replay.merge((record,))
    current=replay.records[result.state.key]
    replay.records[result.state.key]=replace(current,exact_distance=result.distance,
        exact_evidence='stage25_swap_forest_theorem_sha256:'+SOURCE_NOTES_SHA256)
    return replay.records[result.state.key]
