"""Own stage36B globally exact B* family, arbitrary external columns.

Only B* (6,5,7) under physical relabeling is admitted. The four internal
operations cover all seven inverse-frame directions. Every external column
is transferred once; connectivity plus zero diagonal proves optimality.
"""
from itertools import permutations
from .stage23_forest_exact_v1 import ForestResult
from ..contracts import AlphabetSpec,MatrixState,Gate,WordCertificate
from ..gf2 import inverse
from ..words import verify_word
from dataclasses import replace
import random
from .records import SampleRecord

SOURCE_NOTES_SHA256='dd22650b7414b3721c46c80bc80f301160b374077112c798f10ba8dc80e9a29b'
FRAME=(6,5,7)
INTERNAL=((0,1),(1,2),(2,0),(0,1))


def matvec(rows,vector):
    return sum(((row&vector).bit_count()%2)<<i for i,row in enumerate(rows))


def recognize(state,alphabet):
    if state.n!=alphabet.n or state.alphabet_id!=alphabet.id:
        raise ValueError('state/alphabet mismatch')
    def unsupported(reason):
        return ForestResult('unsupported',state,alphabet.id,None,None,{}, {},reason)
    if state.n<3 or alphabet!=AlphabetSpec.all_to_all(state.n):
        return unsupported('requires full unit all-to-all CNOT')
    rows=state.packed_rows
    changed=tuple(i for i,row in enumerate(rows) if row!=1<<i)
    if len(changed)!=3:
        return unsupported('requires exactly three changed core rows')
    active=None
    for candidate in permutations(changed):
        block=tuple(sum(((rows[wire]>>column)&1)<<j for j,column in enumerate(candidate))
                    for wire in candidate)
        if block==FRAME:
            active=candidate
            break
    if active is None:
        return unsupported('internal block is not the globally saturated B* frame')
    # Compute direction availability from exact 3x3 inverse frames, no search.
    frame=[1,2,4]
    available={}
    for step in range(5):
        inv=inverse(frame)
        for target in range(3):
            direction=sum(((inv[i]>>target)&1)<<i for i in range(3))
            available.setdefault(direction,(step,target))
        if step<4:
            control,target=INTERNAL[step]
            frame[target]^=frame[control]
    assert tuple(frame)==FRAME and set(available)==set(range(1,8))
    transfers=[[] for _ in range(5)]
    final_inverse=inverse(FRAME)
    m=0
    for control in range(state.n):
        if control in active:
            continue
        column=sum(((rows[wire]>>control)&1)<<i for i,wire in enumerate(active))
        if column:
            direction=matvec(final_inverse,column)
            step,target=available[direction]
            transfers[step].append(Gate(control,active[target]))
            m+=1
    construction=[]
    for step in range(5):
        construction.extend(transfers[step])
        if step<4:
            control,target=INTERNAL[step]
            construction.append(Gate(active[control],active[target]))
    # Independent whole support graph, retaining all isolated physical wires.
    parents=list(range(state.n))
    def find(i):
        while parents[i]!=i:
            i=parents[i]
        return i
    for i,row in enumerate(rows):
        for j in range(state.n):
            if i!=j and row>>j&1:
                parents[find(i)]=find(j)
    components=len({find(i) for i in range(state.n)})
    zero_diagonal=sum(not(row>>i&1) for i,row in enumerate(rows))
    lower=state.n-components+zero_diagonal
    assert lower==m+4 and len(construction)==lower
    word=WordCertificate(state,MatrixState.identity(alphabet),tuple(reversed(construction)),
        lower,'stage36_saturated_frame_exact_v1',f'stage36:{state.n}:{rows}')
    verify_word(word,alphabet)
    return ForestResult('exact',state,alphabet.id,lower,word,
        {'full_unit_all_to_all':True,'internal_frame':FRAME,
         'source_notes_sha256':SOURCE_NOTES_SHA256},
        {'active_rows':active,'nonzero_external_columns':m,
         'support_components':components,'zero_diagonal':zero_diagonal,
         'global_lower_bound':lower})


def verify_result(result,alphabet):
    if recognize(result.state,alphabet)!=result:
        raise ValueError('stage36 result failed re-recognition')
    return result.status=='exact'


def generate(seed,n,*,split):
    if type(seed) is not int or type(n) is not int or n<3 or split not in ('train','dev','test'):
        raise ValueError('invalid B* family input')
    rng=random.Random(seed)
    active=rng.sample(range(n),3)
    rows=[1<<i for i in range(n)]
    for i,wire in enumerate(active):
        rows[wire]=sum(((FRAME[i]>>j)&1)<<other for j,other in enumerate(active))
    for control in range(n):
        if control in active:
            continue
        column=rng.randrange(8)
        for i,wire in enumerate(active):
            rows[wire]|=((column>>i)&1)<<control
    alphabet=AlphabetSpec.all_to_all(n)
    result=recognize(MatrixState(n,tuple(rows),alphabet.id),alphabet)
    if not verify_result(result,alphabet):
        raise AssertionError('generated B* family failed recognition')
    return result


def ingest_exact(replay,result,*,seed,split):
    if type(seed) is not int or split not in ('train','dev','test'):
        raise ValueError('invalid B* lineage')
    if not verify_result(result,replay.alphabet):
        raise ValueError('unsupported B* exact result')
    if result.state.key in replay.forbidden_keys:
        raise ValueError('forbidden holdout label')
    old=replay.records.get(result.state.key)
    if old is not None and old.exact_distance is not None and old.exact_distance!=result.distance:
        raise ValueError('conflicting exact distance')
    record=SampleRecord(result.state,(result.word,),f'stage36:{split}:{seed}:{result.state.n}',
                        seed,'stage36_saturated_frame_exact_v1',split)
    replay.merge((record,))
    current=replay.records[result.state.key]
    replay.records[result.state.key]=replace(current,exact_distance=result.distance,
        exact_evidence='stage36_saturated_frame_theorem_sha256:'+SOURCE_NOTES_SHA256)
    return replay.records[result.state.key]
