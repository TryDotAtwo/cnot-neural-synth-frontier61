"""Registered basis MC workspace estimate, excluding neural autograd graphs."""


def basis_mc_workspace_bytes(active, targets, sources, samples, choices):
    if (type(active) is not int or active < 0 or
            any(type(v) is not int or v < 1 for v in (targets, sources, samples, choices))):
        raise ValueError('integer basis workspace dimensions required')
    return active * targets * sources * 64 + active * samples * (choices + 1) * 8


def check_mixed_basis_workspace(groups, limit):
    if type(limit) is not int or limit < 0:
        raise ValueError('nonnegative explicit workspace byte limit required')
    total = sum(basis_mc_workspace_bytes(*group) for group in groups)
    if total > limit:
        raise MemoryError('resource_limit: mixed-update basis MC workspace preflight')
    return total
