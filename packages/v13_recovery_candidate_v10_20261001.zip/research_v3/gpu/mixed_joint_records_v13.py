"""One differentiable objective over independently admitted width groups."""
from dataclasses import dataclass
import math
from .record_batch_v13 import validate_own_records, own_records_to_cuda
from .joint_records_v13 import complete_joint_basis_records
from .joint_terms_v13 import merge_joint_terms
from .holdout import admit_complete_neighborhood
from .structural_e import selected_e_features
from .basis_workspace_v13 import check_mixed_basis_workspace


@dataclass(frozen=True)
class RecordGroup:
    records: tuple
    holdout: object
    exact_catalog: object = None


def complete_mixed_joint_records(model, groups, *, generator, **config):
    groups = tuple(groups)
    if not groups or 'retain_components' in config or 'holdout' in config:
        raise ValueError('nonempty explicit width groups required')
    for name in ('choice_count', 'action_chunk', 'samples', 'max_evaluations', 'max_bytes'):
        value = config.get(name)
        if type(value) is not int or value < (0 if name.startswith('max_') else 1):
            raise ValueError('invalid mixed-update resource configuration')
    for name, default in (('weight', None), ('qhat_weight', .1),
                          ('supervision_weight', 1.), ('teacher_weight', .1)):
        value = config.get(name, default)
        if (type(value) not in (int, float) or not math.isfinite(value) or
                value < 0 or (name == 'weight' and value == 0)):
            raise ValueError('invalid mixed-update loss weight')
    # Reject all archival source/word errors before allocation or forward.
    for group in groups:
        if group.holdout is None:
            raise ValueError('each width group requires its sealed holdout bank')
        validate_own_records(group.records, exact_catalog=group.exact_catalog)
    root_keys = [record.state.key for group in groups for record in group.records]
    if len(set(root_keys)) != len(root_keys):
        raise ValueError('repeated root across mixed groups changes objective weighting')
    batches = [own_records_to_cuda(group.records, exact_catalog=group.exact_catalog)
               for group in groups]
    evaluations = 0
    admissions = []
    workspace_groups = []
    # Admit every group before the first train exposure. Apply the MC budget
    # to the whole update, rather than resetting it at each matrix width.
    for group, batch in zip(groups, batches):
        rows = batch.walk.rows
        admissions.append(admit_complete_neighborhood(
            group.holdout, rows, chunk_size=config['action_chunk']))
        width = rows.shape[1] // 2
        if width >= 2:
            if config['choice_count'] > width * (width - 1):
                raise ValueError('basis choices exceed ordered source pairs')
            active = int(selected_e_features(rows).available.sum().item())
            evaluations += active * config['samples'] * (1 + 2 * config['choice_count'])
            workspace_groups.append((active, rows.shape[1] - width, width,
                                     config['samples'], config['choice_count']))
    if evaluations > config['max_evaluations']:
        raise RuntimeError('resource_limit: mixed-update MC gradient exceeds budget')
    workspace_bytes = check_mixed_basis_workspace(workspace_groups, config['max_bytes'])
    terms, audits = [], []
    for group, batch in zip(groups, batches):
        _, audit = complete_joint_basis_records(
            model, batch, group.records, exact_catalog=group.exact_catalog,
            generator=generator, holdout=group.holdout, retain_components=True, **config)
        terms.append(audit.pop('objective_components'))
        audits.append(audit)
    return merge_joint_terms(terms, weight=config['weight']), {
        'groups': audits, 'admission_counts': admissions,
        'records': sum(term.records for term in terms),
        'basis_templates': sum(term.templates for term in terms),
        'basis_evaluations': evaluations,
        'basis_mc_workspace_estimate_bytes': workspace_bytes,
        'exact_root_examples': sum(audit['exact_root_examples'] for audit in audits)}
