"""Reference full-neighbor Bellman derivative with frozen selection provenance."""
from dataclasses import dataclass, fields, is_dataclass, replace
import hashlib
import numpy as np
import torch
from ..contracts import MatrixState, MatrixBatch
from ..words import apply, verify_word


def fingerprint(value):
    digest = hashlib.sha256()
    def feed(item):
        if isinstance(item, torch.Tensor):
            array = item.detach().cpu().contiguous().numpy()
            feed(array)
        elif isinstance(item, np.ndarray):
            digest.update(repr((item.shape, str(item.dtype))).encode())
            digest.update(np.ascontiguousarray(item).tobytes())
        elif is_dataclass(item):
            for field in fields(item):
                if field.name != 'audit':
                    feed(field.name)
                    feed(getattr(item, field.name))
        elif isinstance(item, dict):
            for key in sorted(item):
                feed(key)
                feed(item[key])
        elif isinstance(item, (tuple, list)):
            digest.update(str(len(item)).encode())
            for entry in item:
                feed(entry)
        else:
            digest.update(repr(item).encode())
    feed(value)
    return digest.hexdigest()


def theta_fingerprint(model):
    return fingerprint((tuple(model.state_dict().items()), tuple((name, module.training) for name, module in model.named_modules())))


def slice_packet(packet, index):
    def copy(value):
        return value[index:index + 1].clone() if isinstance(value, torch.Tensor) else value[index:index + 1].copy()
    features = {key: replace(feature, values=copy(feature.values), available=copy(feature.available),
                              token_valid=None if feature.token_valid is None else copy(feature.token_valid))
                for key, feature in packet.features.items()}
    return replace(packet, state_keys=(packet.state_keys[index],), alphabet_ids=(packet.alphabet_ids[index],),
                   valid=copy(packet.valid), features=features,
                   group_incidence={key: copy(value) for key, value in packet.group_incidence.items()})


@dataclass
class BackupBranch:
    parent: MatrixState
    parent_packet: object
    successor: MatrixState | None
    successor_packet: object
    cost: int
    selected_index: int | None
    candidate_count: int
    primitive_count: int
    packet_hash: str
    macro_margin: float | None = None
    primitive_totals: tuple[float, ...] = ()


@dataclass
class BackupSelection:
    branches: tuple[BackupBranch, ...]
    theta_hash: str
    completeness: str = 'full_primitive_neighbors'
    tie_rule: str = 'first_in_alphabet_then_macro_order'


@dataclass
class LossReport:
    loss: object
    losses: dict
    diagnostics: dict


def select_backup(model, states, registry, policy, alphabet, macros=None, chunk_size=None,
                  forbidden_keys=(), admission=None):
    if chunk_size is not None and (type(chunk_size) is not int or chunk_size < 1):
        raise ValueError('positive neighbor chunk size required')
    if not states:
        raise ValueError('empty Bellman batch')
    # Freeze and validate every complete candidate set before any feature/model
    # exposure. A later unsafe parent must not expose earlier batch members.
    forbidden = set(forbidden_keys)
    prepared = []
    for state in states:
        if state.alphabet_id != alphabet.id or state.n != alphabet.n:
            raise ValueError('state/alphabet mismatch')
        successors, costs = [], []
        if state != MatrixState.identity(alphabet):
            successors = [apply(state, gate, alphabet) for gate in alphabet.allowed]
            costs = list(alphabet.costs)
        primitive_count = len(successors)
        if successors and macros is not None:
            for cert in macros(state):
                verify_word(cert, alphabet)
                if cert.start != state or cert.physical_cost <= 0:
                    raise ValueError('invalid paid macro')
                successors.append(cert.end)
                costs.append(cert.physical_cost)
        for candidate in (state, *successors):
            if candidate.key in forbidden:
                raise ValueError('forbidden state in complete backup; reject whole parent')
            if admission is not None:
                admission(candidate)
        prepared.append((state, successors, costs, primitive_count))
    # Dropout changes the function between selection and backward; reject even
    # when currently in eval mode so later mode toggles cannot silently change it.
    if any(isinstance(m, torch.nn.Dropout) and m.p != 0 for m in model.modules()):
        raise ValueError('Bellman reference requires dropout=0')
    if policy.evaluations is not None:
        raise ValueError('finite per-batch feature evaluations could change selected packets; use frozen unlimited deterministic producers')
    before = theta_fingerprint(model)
    branches = []
    device = next(model.parameters()).device
    for state, successors, costs, primitive_count in prepared:
        if state.alphabet_id != alphabet.id or state.n != alphabet.n:
            raise ValueError('state/alphabet mismatch')
        parent_packet = registry.build((state,), policy)
        if state == MatrixState.identity(alphabet):
            branches.append(BackupBranch(state, parent_packet, None, None, 0, None, 0, 0,
                                         fingerprint((parent_packet, None))))
            continue
        if not successors:
            raise ValueError('nonterminal state with empty move alphabet')
        width = chunk_size or len(successors)
        totals = []
        best = float('inf')
        index = None
        selected_packet = None
        with torch.no_grad():
            for start in range(0, len(successors), width):
                chunk = tuple(successors[start:start + width])
                packet = registry.build(chunk, policy)
                values = model(MatrixBatch.from_states(chunk, device), packet).value
                total = values + values.new_tensor(costs[start:start + width])
                if not torch.isfinite(total).all():
                    raise ValueError('nonfinite Bellman candidates')
                totals.extend(total.cpu().tolist())
                local = int(total.argmin().item())
                candidate = float(total[local])
                if candidate < best:
                    best, index = candidate, start + local
                    selected_packet = slice_packet(packet, local)
            margin = None
            if len(successors) > primitive_count and primitive_count:
                margin = min(totals[primitive_count:]) - min(totals[:primitive_count])
        branches.append(BackupBranch(state, parent_packet, successors[index], selected_packet, costs[index], index,
                                     len(successors), primitive_count, fingerprint((parent_packet, selected_packet)),
                                     margin, tuple(totals[:primitive_count])))
    if theta_fingerprint(model) != before:
        raise ValueError('theta or buffers changed during selection')
    return BackupSelection(tuple(branches), before)


def recompute_backup(model, selection):
    if theta_fingerprint(model) != selection.theta_hash:
        raise ValueError('theta changed after Bellman selection')
    device = next(model.parameters()).device
    residuals = []
    terminals = 0
    margins = []
    for branch in selection.branches:
        if fingerprint((branch.parent_packet, branch.successor_packet)) != branch.packet_hash:
            raise ValueError('packet changed after Bellman selection')
        parent = model(MatrixBatch.from_states((branch.parent,), device), branch.parent_packet).value[0]
        if branch.successor is None:
            residuals.append(parent)
            terminals += 1
        else:
            successor = model(MatrixBatch.from_states((branch.successor,), device), branch.successor_packet).value[0]
            residuals.append(parent - branch.cost - successor)
        if branch.macro_margin is not None:
            margins.append(branch.macro_margin)
    residual = torch.stack(residuals)
    loss = torch.nn.functional.smooth_l1_loss(residual, torch.zeros_like(residual))
    if not torch.isfinite(loss):
        raise ValueError('nonfinite Bellman loss')
    return LossReport(loss, {'bellman': loss}, {'terminal_count': terminals, 'examples': len(residuals),
                                              'macro_margins': margins, 'approximate': False,
                                              'candidates': sum(b.candidate_count for b in selection.branches)})
