import unittest
from research_v3.contracts import Gate, AlphabetSpec, MatrixState, WordCertificate
from research_v3.words import apply, verify_word, invert_word
from research_v3.symmetry import map_problem, map_word_back


def catalog(alphabet):
    identity = MatrixState.identity(alphabet)
    found = {identity: ()}
    queue = [identity]
    for state in queue:
        for gate in alphabet.allowed:
            nxt = apply(state, gate, alphabet)
            if nxt not in found:
                found[nxt] = found[state] + (gate,)
                queue.append(nxt)
    return found


class StateTests(unittest.TestCase):
    def test_single_cnot_full_bits(self):
        a = AlphabetSpec.all_to_all(2)
        state = apply(MatrixState.identity(a), Gate(0, 1), a)
        self.assertEqual(state.packed_rows, (1, 3))
        verify_word(WordCertificate(MatrixState.identity(a), state,
                                   (Gate(0, 1),), 1, 'test', 'test'), a)

    def test_padded_batch_rejected_before_model(self):
        import torch
        from research_v3.contracts import MatrixBatch
        states = (MatrixState.identity(AlphabetSpec.all_to_all(1)),
                  MatrixState.identity(AlphabetSpec.all_to_all(2)))
        matrix = torch.tensor([[[1, 0], [0, 0]], [[1, 0], [0, 1]]], dtype=torch.bool)
        valid = torch.tensor([[1, 0], [1, 1]], dtype=torch.bool)
        MatrixBatch(states, matrix, valid)
        wrong = matrix.clone()
        wrong[0, 1, 1] = True
        with self.assertRaises(ValueError):
            MatrixBatch(states, wrong, valid)
        wrong_valid = valid.clone()
        wrong_valid[0, 1] = True
        with self.assertRaises(ValueError):
            MatrixBatch(states, matrix, wrong_valid)

    def test_identity_and_swap(self):
        a = AlphabetSpec.all_to_all(1)
        self.assertEqual(a.allowed, ())
        verify_word(WordCertificate(MatrixState.identity(a), MatrixState.identity(a), (), 0, 'test', 'test'), a)
        a = AlphabetSpec.all_to_all(2)
        word = (Gate(0, 1), Gate(1, 0), Gate(0, 1))
        target = MatrixState(2, (2, 1), a.id)
        verify_word(WordCertificate(MatrixState.identity(a), target, word, 3, 'test', 'test'), a)

    def test_invalid_inputs(self):
        a = AlphabetSpec.all_to_all(2)
        for rows in ((1, 1), (1,), (1, 4), (True, 2)):
            with self.assertRaises(ValueError):
                MatrixState(2, rows, a.id)
        with self.assertRaises(ValueError):
            MatrixState.from_dense([[1, 0], [0]], a)
        for gate in (Gate(0, 0), Gate(2, 0), Gate(-1, 0), Gate(False, 1)):
            with self.assertRaises(ValueError):
                apply(MatrixState.identity(a), gate, a)

    def test_noncommuting_order(self):
        a = AlphabetSpec.all_to_all(3)
        word = (Gate(0, 1), Gate(1, 2))
        state = MatrixState(3, (1, 3, 7), a.id)
        verify_word(WordCertificate(state, MatrixState.identity(a), invert_word(word), 2, 'test', 'test'), a)
        with self.assertRaises(ValueError):
            verify_word(WordCertificate(state, MatrixState.identity(a), word, 2, 'test', 'test'), a)

    def test_all_small_symmetry_words(self):
        for n in (1, 2, 3):
            a = AlphabetSpec.all_to_all(n)
            states = catalog(a)
            self.assertEqual(len(states), {1: 1, 2: 6, 3: 168}[n])
            for state in states:
                for transform in ('inverse', 'transpose', tuple(reversed(range(n)))):
                    mapped = map_problem(state, a, transform)
                    mapped_words = catalog(mapped.alphabet)
                    encoder = mapped_words[mapped.state]
                    reduction = invert_word(encoder)
                    cert = WordCertificate(mapped.state, MatrixState.identity(mapped.alphabet), reduction,
                                           len(reduction), 'test', 'test')
                    original = map_word_back(cert, mapped)
                    verify_word(original, a)
                    self.assertEqual(original.start, state)
                    self.assertEqual(original.end, MatrixState.identity(a))

    def test_restricted_transpose_and_relabel(self):
        a = AlphabetSpec(2, (Gate(0, 1),), (2,), 'directed')
        m = apply(MatrixState.identity(a), Gate(0, 1), a)
        inv = map_problem(m, a, 'inverse')
        cert = WordCertificate(inv.state, MatrixState.identity(a), (Gate(0, 1),), 2, 'test', 'test')
        verify_word(map_word_back(cert, inv), a)
        with self.assertRaises(ValueError):
            map_problem(m, a, 'transpose')
        b = AlphabetSpec(2, (Gate(0, 1), Gate(1, 0)), (2, 3), 'weighted')
        with self.assertRaises(ValueError):
            map_problem(MatrixState.identity(b), b, 'transpose')
        mapped = map_problem(m, a, (1, 0))
        self.assertEqual(mapped.alphabet.allowed, (Gate(1, 0),))
        cert = WordCertificate(mapped.state, MatrixState.identity(mapped.alphabet), (Gate(1, 0),), 2, 'test', 'test')
        verify_word(map_word_back(cert, mapped), a)


if __name__ == '__main__':
    unittest.main()
