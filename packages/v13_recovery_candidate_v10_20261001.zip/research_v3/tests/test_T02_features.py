import unittest
import numpy as np
from research_v3.contracts import AlphabetSpec, MatrixState
from research_v3.features.registry import FeatureRegistry, FeaturePolicy
from research_v3.features.cache import FeatureCache
from research_v3.features.packet import FeatureSpec
from research_v3.symmetry import map_problem


class FeatureTests(unittest.TestCase):
    def test_full_encoder_proposer_relabel_with_transported_ordered_template(self):
        import torch
        from itertools import permutations
        from research_v3.contracts import MatrixBatch
        from research_v3.model.field import FusionDistanceField
        from research_v3.basis.proposal import BasisProposal
        from research_v3.basis.templates import BasisChoice, BasisTemplate
        from research_v3.tests.test_T01_state import catalog
        threads = torch.get_num_threads()
        self.addCleanup(torch.set_num_threads, threads)
        torch.set_num_threads(1)
        with torch.random.fork_rng():
            torch.manual_seed(1702)
            registry = FeatureRegistry()
            policy = FeaturePolicy(('A01', 'A03', 'A05', 'B01', 'F01'))
            field = FusionDistanceField([registry.specs[k] for k in policy.enabled_ids],
                                        d=8, pair_d=4, blocks=1, heads=2,
                                        ffn=16, fusion_blocks=1).double().eval()
            proposer = BasisProposal(8, hidden=16).double().eval()
            states = tuple(catalog(self.alphabet))
            template = BasisTemplate(3, (0, 1), (2,), 'source',
                                     (BasisChoice('add', 0, 1), BasisChoice('add', 1, 0)))
            with torch.no_grad():
                encoding = field.encode(MatrixBatch.from_states(states), registry.build(states, policy))
                expected = torch.stack([proposer(encoding, template, i) for i in range(len(states))])
                for permutation in permutations(range(3)):
                    mapped = tuple(map_problem(s, self.alphabet, permutation).state for s in states)
                    transported = BasisTemplate(3, tuple(permutation[i] for i in template.source_wires),
                                                tuple(permutation[i] for i in template.target_wires),
                                                template.side, template.choices)
                    encoding = field.encode(MatrixBatch.from_states(mapped), registry.build(mapped, policy))
                    actual = torch.stack([proposer(encoding, transported, i) for i in range(len(states))])
                    torch.testing.assert_close(actual, expected, rtol=1e-10, atol=1e-10)

    def test_cheap_producer_all_gl3_relabels_including_ties(self):
        from itertools import permutations
        from research_v3.tests.test_T01_state import catalog
        registry = FeatureRegistry()
        policy = FeaturePolicy(tuple(k for k in registry.specs if k[0] in 'AB') + ('F01',))
        states = tuple(catalog(self.alphabet))
        original = registry.build(states, policy)
        for permutation in permutations(range(3)):
            mapped = tuple(map_problem(s, self.alphabet, permutation).state for s in states)
            packet = registry.build(mapped, policy)
            back = np.argsort(permutation)
            for key, feature in original.features.items():
                expected = feature.values
                if feature.role == 'node':
                    expected = expected[:, back]
                elif feature.role == 'pair':
                    expected = expected[:, back][:, :, back]
                np.testing.assert_allclose(packet.features[key].values, expected, err_msg=key)
                np.testing.assert_array_equal(packet.features[key].available, feature.available)

    def test_packet_bytes_include_group_incidence_and_masks(self):
        registry = FeatureRegistry()
        def producer(state, policy):
            return (np.ones((2, 1), dtype=np.float32),
                    np.ones((2, state.n, 2), dtype=np.float32))
        registry.register(FeatureSpec('J01', 'group', 1, producer_version='bytes_v1'), producer)
        packet = registry.build((self.state,), FeaturePolicy(('A01', 'J01')))
        expected = packet.valid.nbytes
        for key, feature in packet.features.items():
            feature_bytes = feature.values.nbytes + feature.available.nbytes
            if feature.token_valid is not None:
                feature_bytes += feature.token_valid.nbytes
            if key in packet.group_incidence:
                feature_bytes += packet.group_incidence[key].nbytes
            self.assertEqual(packet.audit['per_feature'][key]['bytes'], feature_bytes)
            expected += feature_bytes
        self.assertEqual(packet.audit['bytes'], expected)

    def test_group_provider_preserves_roles_and_padding(self):
        registry = FeatureRegistry()
        spec = FeatureSpec('J01', 'group', 2, producer_version='test_v1')
        def producer(state, policy):
            values = np.array([[state.n, 1]], dtype=np.float32)
            incidence = np.zeros((1, state.n, 2), dtype=np.float32)
            incidence[0, 0, 0] = 1
            incidence[0, state.n - 1, 1] = 1
            return values, incidence
        registry.register(spec, producer, symmetry_contract='augmentation_only')
        a = AlphabetSpec.all_to_all(1)
        policy = FeaturePolicy(('J01',), symmetry_contract='augmentation_only')
        packet = registry.build((MatrixState.identity(a), self.state), policy)
        self.assertEqual(packet.group_incidence['J01'].shape, (2, 1, 3, 2))
        self.assertEqual(packet.group_incidence['J01'][0, :, 1:].sum(), 0)
        np.testing.assert_array_equal(packet.features['J01'].values[:, 0, 0], [1, 3])
        with self.assertRaisesRegex(ValueError, 'symmetry'):
            registry.build((self.state,), FeaturePolicy(('J01',)))

    def test_provider_budget_zero_is_unavailable(self):
        registry = FeatureRegistry()
        def producer(state, policy):
            self.fail('zero-budget producer must not run')
        registry.register(FeatureSpec('J01', 'global', 1, producer_version='test_v1'), producer)
        packet = registry.build((self.state,), FeaturePolicy(('J01',), evaluations=0))
        self.assertEqual(packet.features['J01'].status, 'resource_limit')
        self.assertFalse(packet.features['J01'].available.any())

    def test_graph_motifs_against_hand_count(self):
        alphabet = AlphabetSpec.all_to_all(4)
        square = MatrixState(4, (1, 3, 5, 14), alphabet.id)
        packet = FeatureRegistry().build((square,), FeaturePolicy(('B01', 'B02', 'B03', 'B10')))
        np.testing.assert_array_equal(packet.features['B10'].values[0], [[0, 1]] * 4)
        np.testing.assert_array_equal(packet.features['B02'].values[0], [[4]] * 4)
        np.testing.assert_array_equal(packet.features['B03'].values[0], [[1]] * 4)

    def test_resource_limit_before_compute(self):
        registry = FeatureRegistry()
        with self.assertRaises(MemoryError):
            registry.build((self.state,), FeaturePolicy(('A01',), max_bytes=1))
        self.assertEqual(registry.cache.calls, 0)

    def test_cache_results_cannot_poison_later_packets(self):
        registry = FeatureRegistry()
        policy = FeaturePolicy(('A01',))
        first = registry.build((self.state,), policy)
        first.features['A01'].values.setflags(write=True)
        first.features['A01'].values[:] = 9
        second = registry.build((self.state,), policy)
        self.assertLess(second.features['A01'].values.max(), 2)

    def setUp(self):
        self.alphabet = AlphabetSpec.all_to_all(3)
        self.state = MatrixState(3, (1, 3, 7), self.alphabet.id)

    def test_registry_has_all_103_ids(self):
        self.assertEqual(len(FeatureRegistry().specs), 103)

    def test_missing_not_zero(self):
        packet = FeatureRegistry().build((self.state,), FeaturePolicy(('A01', 'D01')))
        self.assertTrue(packet.features['A01'].available[0])
        self.assertFalse(packet.features['D01'].available[0])
        self.assertEqual(packet.features['D01'].status, 'unsupported')
        self.assertEqual(packet.features['D01'].exactness, 'unknown')

    def test_padding_is_not_wire(self):
        a = AlphabetSpec.all_to_all(1)
        packet = FeatureRegistry().build((MatrixState.identity(a), self.state), FeaturePolicy(('A01', 'A03', 'A05')))
        np.testing.assert_array_equal(packet.valid[0], [True, False, False])
        self.assertEqual(packet.features['A03'].values[0, 1:].sum(), 0)
        self.assertEqual(packet.features['A05'].values[0, 1:].sum(), 0)

    def test_collision_safe_cache(self):
        cache = FeatureCache(hash_fn=lambda key: 0)
        self.assertEqual(cache.get_or_compute((1, 'one'), lambda: 1), 1)
        self.assertEqual(cache.get_or_compute((1, 'two'), lambda: 2), 2)
        self.assertEqual(cache.get_or_compute((1, 'one'), lambda: 999), 1)
        self.assertEqual(cache.hits, 1)

    def test_same_state_same_packet_changed_policy_invalidates(self):
        registry = FeatureRegistry()
        p1 = registry.build((self.state,), FeaturePolicy(('A01',), seed=1))
        p2 = registry.build((self.state,), FeaturePolicy(('A01',), seed=1))
        p3 = registry.build((self.state,), FeaturePolicy(('A01',), seed=2))
        np.testing.assert_array_equal(p1.features['A01'].values, p2.features['A01'].values)
        self.assertEqual(p1.policy_id, p2.policy_id)
        self.assertNotEqual(p1.policy_id, p3.policy_id)
        self.assertEqual(registry.cache.hits, 1)

    def test_relabel_equivariance_all_cheap_features(self):
        registry = FeatureRegistry()
        policy = FeaturePolicy(tuple(k for k in registry.specs if k[0] in 'AB') + ('F01',))
        permutation = (2, 0, 1)
        mapped = map_problem(self.state, self.alphabet, permutation).state
        one = registry.build((self.state,), policy)
        two = registry.build((mapped,), policy)
        back = np.argsort(permutation)
        for key, feature in one.features.items():
            actual = two.features[key].values[0]
            expected = feature.values[0]
            if feature.role == 'node':
                expected = expected[back]
            elif feature.role == 'pair':
                expected = expected[back][:, back]
            np.testing.assert_allclose(actual, expected, err_msg=key)

    def test_values_match_direct_matrix_calculation(self):
        packet = FeatureRegistry().build((self.state,), FeaturePolicy(('A01', 'A05', 'A20', 'F01')))
        np.testing.assert_array_equal(packet.features['A05'].values[0, :, 0], [1, 2, 3])
        np.testing.assert_array_equal(packet.features['F01'].values[0], [2, 2])
        # control=0,target=1 turns [1,1,0] into [0,1,0].
        np.testing.assert_array_equal(packet.features['A20'].values[0, 0, 1], [-1, -1])


if __name__ == '__main__':
    unittest.main()
