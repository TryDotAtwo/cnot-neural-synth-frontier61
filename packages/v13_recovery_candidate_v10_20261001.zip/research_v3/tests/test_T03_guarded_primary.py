"""Portable guards and exact-word checks; no Molab script imports."""
import unittest
from research_v3.contracts import AlphabetSpec, MatrixState, Gate
from research_v3.data.exact_small import build_exact_small
from research_v3.data.stage35_pair_exact_v1 import recognize as pair
from research_v3.data.stage37_zero_excess_exact_v1 import recognize as zero
from research_v3.words import verify_word


class GuardedPrimaryTests(unittest.TestCase):
    def test_pair_and_zero_against_complete_gl3(self):
        alphabet = AlphabetSpec.all_to_all(3)
        catalog = build_exact_small(3, alphabet)
        successes = {'pair': 0, 'zero': 0}
        for state, distance in catalog.distances.items():
            for name, adapter in (('pair', pair), ('zero', zero)):
                result = adapter(state, alphabet)
                if result.status == 'exact':
                    verify_word(result.word, alphabet)
                    self.assertEqual(result.distance, distance)
                    self.assertEqual(result.word.physical_cost, distance)
                    successes[name] += 1
                elif result.status == 'certified_no_solution_within_scope':
                    self.assertGreater(distance, result.witness['excluded_length'])
                else:
                    self.assertEqual(result.status, 'unsupported')
        self.assertGreater(successes['pair'], 1)
        self.assertGreater(successes['zero'], 1)

    def test_restricted_and_weighted_alphabets_rejected(self):
        for alphabet in (AlphabetSpec(2, (Gate(0, 1),), (1,), 'restricted'),
                         AlphabetSpec(2, (Gate(0, 1), Gate(1, 0)), (2, 2), 'weighted')):
            state = MatrixState.identity(alphabet)
            for adapter in (pair, zero):
                result = adapter(state, alphabet)
                self.assertEqual(result.status, 'unsupported')
                self.assertIsNone(result.distance)
                self.assertIsNone(result.word)


if __name__ == '__main__':
    unittest.main()
