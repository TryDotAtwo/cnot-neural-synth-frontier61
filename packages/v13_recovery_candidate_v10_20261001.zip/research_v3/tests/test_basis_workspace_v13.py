import unittest
from research_v3.gpu.basis_workspace_v13 import basis_mc_workspace_bytes, check_mixed_basis_workspace


class WorkspaceTests(unittest.TestCase):
    def test_combined_widths_exceed_individually_valid_budget(self):
        groups = ((1, 4, 4, 2, 2), (1, 2, 2, 2, 2))
        self.assertEqual(basis_mc_workspace_bytes(*groups[0]), 1072)
        self.assertEqual(basis_mc_workspace_bytes(*groups[1]), 304)
        for group in groups:
            self.assertLessEqual(check_mixed_basis_workspace((group,), 1072), 1072)
        with self.assertRaises(MemoryError): check_mixed_basis_workspace(groups, 1072)
        self.assertEqual(check_mixed_basis_workspace(groups, 1376), 1376)

    def test_inactive_template_and_invalid_dimensions(self):
        self.assertEqual(check_mixed_basis_workspace(((0, 4, 4, 2, 2),), 0), 0)
        for group in ((True, 4, 4, 2, 2), (1, 0, 4, 2, 2), (1, 4, 4, 0, 2)):
            with self.assertRaises(ValueError): check_mixed_basis_workspace((group,), 1000)


if __name__ == '__main__': unittest.main()
