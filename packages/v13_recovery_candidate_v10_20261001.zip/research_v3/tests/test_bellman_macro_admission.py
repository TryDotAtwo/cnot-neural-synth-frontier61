import unittest
from unittest.mock import Mock
import torch
from research_v3.contracts import AlphabetSpec, MatrixState, Gate, WordCertificate
from research_v3.words import apply
from research_v3.objectives.bellman import select_backup


class BellmanMacroAdmissionTests(unittest.TestCase):
    def test_forbidden_macro_rejects_entire_batch_before_feature_or_forward(self):
        alphabet = AlphabetSpec.all_to_all(3)
        identity = MatrixState.identity(alphabet)
        parent = apply(identity, Gate(0, 1), alphabet)
        other = apply(parent, Gate(1, 2), alphabet)
        forbidden = apply(other, Gate(2, 0), alphabet)
        # A two-step paid macro reaches a state outside the primitive neighbors.
        end = apply(forbidden, Gate(0, 2), alphabet)
        self.assertNotIn(end, [apply(other, g, alphabet) for g in alphabet.allowed])
        cert = WordCertificate(other, end, (Gate(2, 0), Gate(0, 2)), 2,
                               'own_test_paid_macro', 'macro:admission')
        model = torch.nn.Linear(1, 1)
        registry = Mock()
        policy = Mock()
        with self.assertRaisesRegex(ValueError, 'reject whole parent'):
            select_backup(model, (parent, other), registry, policy, alphabet,
                          macros=lambda state: (cert,) if state == other else (),
                          forbidden_keys={end.key})
        registry.build.assert_not_called()


if __name__ == '__main__':
    unittest.main()
