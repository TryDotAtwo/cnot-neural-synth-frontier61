import tempfile,unittest
from pathlib import Path
from research_v3.train.cuda_stream_v13 import train_cuda_stream
from research_v3.data.model_exposure_journal_v1 import ModelExposureJournal

class CudaStreamExposureAdmissionTests(unittest.TestCase):
    def invoke(self,**kwargs):
        return train_cuda_stream(None,None,None,None,None,banks={},bank_audit={'holdout_seal_sha256':'a'*64},producer=None,replay=None,evaluate=None,joint_config={},source_versions={},generator=None,dev_panel=(),dev_cap_multiplier=1,**kwargs)
    def test_missing_journal_rejected_before_any_cuda_work(self):
        with self.assertRaisesRegex(ValueError,'full-key model exposure journal'):
            self.invoke()
    def test_wrong_seal_rejected_before_any_cuda_work(self):
        with tempfile.TemporaryDirectory() as directory:
            journal=ModelExposureJournal(Path(directory)/'exposures.sqlite',holdout_seal_sha256='b'*64)
            try:
                with self.assertRaisesRegex(ValueError,'different sealed holdout'):
                    self.invoke(exposure_journal=journal)
            finally:journal.close()

if __name__=='__main__':unittest.main()
