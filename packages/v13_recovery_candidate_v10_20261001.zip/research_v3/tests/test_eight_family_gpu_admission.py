from dataclasses import replace
import unittest
from research_v3.data.guarded_family_dispatch_v1 import EXACT_FAMILIES,make_exact_root
from research_v3.gpu.record_batch_v13 import validate_own_records,validate_own_dev_records

class EightFamilyGpuAdmissionTests(unittest.TestCase):
    def test_all_eight_actual_small_sources_pass_pre_cuda_word_and_exact_gate(self):
        for kind in EXACT_FAMILIES:
            with self.subTest(kind=kind):
                n=8 if kind=='stage18_bipartite' else 3
                record,audit=make_exact_root(kind,1738,n,'dev')
                if record.upper_bound==0:
                    record,audit=make_exact_root(kind,1739,n,'dev')
                self.assertGreater(record.upper_bound,0)
                self.assertEqual(validate_own_dev_records((record,))[0].physical_cost,record.exact_distance)
                train=replace(record,split='train')
                self.assertEqual(validate_own_records((train,))[0].physical_cost,record.exact_distance)
                for changed in (replace(train,exact_distance=train.exact_distance+1),replace(train,exact_evidence='wrong')):
                    with self.assertRaises(ValueError):validate_own_records((changed,))
                word=replace(train.verified_words[0],producer='external_untrusted')
                with self.assertRaises(ValueError):validate_own_records((replace(train,verified_words=(word,)),))

if __name__=='__main__':unittest.main()
