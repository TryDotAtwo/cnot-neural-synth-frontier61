import json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from research_v3.data import guarded_family_dispatch_v1 as dispatch
from research_v3.data import stream_solver_dataset_v13 as stream
from research_v3.data.stream_reader_v13 import decode_record
from dataclasses import asdict

class GuardedFamilyDispatchTests(unittest.TestCase):
    def test_all_eight_sources_generate_readable_full_certificates(self):
        for kind in dispatch.EXACT_FAMILIES:
            with self.subTest(kind=kind):
                record,audit=dispatch.make_exact_root(kind,1738,8 if kind=='stage18_bipartite' else 3,'dev')
                self.assertEqual(decode_record(json.dumps(asdict(record))),record)
                self.assertEqual(record.upper_bound,record.exact_distance)
                self.assertFalse(audit['solver_called'])

    def test_all_widths_keep_exact_quarter_and_rotate_eight_families(self):
        counts={family:0 for family in stream.FAMILIES}
        kinds=set()
        for index in range(len(stream.SIZES)*len(stream.FAMILIES)*8):
            family=stream.FAMILIES[index//len(stream.SIZES)%4]
            counts[family]+=1
            if family=='guarded_exact':kinds.add(dispatch.select_family(index,14,4))
        self.assertEqual(len(set(counts.values())),1)
        self.assertEqual(kinds,set(dispatch.EXACT_FAMILIES))
        with patch.object(stream,'make_exact_root',return_value=('record','audit')) as generate:
            for block,kind in enumerate(dispatch.EXACT_FAMILIES):
                stream.make_root('dev',0,14+block*56,0,3700)
                self.assertEqual(generate.call_args.args[0],kind)
                self.assertEqual(generate.call_args.args[2],8)

    def test_nonexact_outcome_stops_before_verification_and_no_fallback(self):
        limited=SimpleNamespace(status='resource_limit',hypotheses={'contraction_max_entries':1},witness={},reason='entries')
        module=SimpleNamespace(generate=lambda *a,**k:limited,verify_result=lambda *a: self.fail('no exact verification'))
        with patch.object(dispatch,'import_module',return_value=module):
            with self.assertRaises(dispatch.GuardedGenerationLimit) as caught:
                dispatch.make_exact_root('stage38_one_excess',42,144,'dev')
        self.assertIsNone(caught.exception.audit['exact_distance'])
        self.assertFalse(caught.exception.audit['fallback_used'])

    def test_generation_limit_is_durable_without_committing_a_root(self):
        limited=SimpleNamespace(status='resource_limit',hypotheses={},witness={},reason='fixture')
        error=dispatch.GuardedGenerationLimit('stage38_one_excess',limited,42,'dev')
        with tempfile.TemporaryDirectory() as directory:
            db=Path(directory)/'roots.sqlite'
            connection,manifest=stream.open_store(db,seed_base=3700,source_sha={})
            try:
                self.assertEqual(tuple(manifest['exact_family_schedule']),dispatch.EXACT_FAMILIES)
                with patch.object(stream,'make_root',side_effect=error), patch.object(stream,'source_hashes',return_value={}):
                    with self.assertRaises(dispatch.GuardedGenerationLimit):
                        stream.build_epoch(connection,split='dev',epoch=0,count=1,seed_base=3700)
                self.assertEqual(connection.execute('SELECT COUNT(*) FROM roots').fetchone()[0],0)
                raw=connection.execute('SELECT audit_json FROM generation_limits').fetchone()[0]
                self.assertEqual(json.loads(raw),error.audit)
            finally:connection.close()

if __name__=='__main__':unittest.main()
