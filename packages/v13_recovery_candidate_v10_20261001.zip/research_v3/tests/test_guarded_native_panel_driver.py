import unittest
from types import SimpleNamespace
from unittest.mock import patch
from research_v3.cli import audit_guarded_native_panel as driver
from research_v3.data.guarded_family_dispatch_v1 import GuardedGenerationLimit

class NativePanelDriverTests(unittest.TestCase):
    def test_actual_small_full_record_and_complete_reader_timing(self):
        with patch.object(driver,'perf_counter',side_effect=[10,17]):
            result=driver.audit_case('stage38_one_excess',1738,3)
        self.assertEqual(result['status'],'exact')
        self.assertEqual(result['end_to_end_seconds'],7)
        self.assertEqual(result['physical_cost'],result['record']['exact_distance'])
        self.assertTrue(result['record']['verified_words'])

    def test_resource_case_preserved_and_never_counted_exact(self):
        limited=SimpleNamespace(status='resource_limit',hypotheses={},witness={},reason='entries')
        error=GuardedGenerationLimit('stage38_one_excess',limited,42,'dev')
        with patch.object(driver,'make_exact_root',side_effect=error), patch.object(driver,'decode_record') as reader:
            result=driver.audit_case('stage38_one_excess',42,144)
        reader.assert_not_called()
        self.assertEqual(result['status'],'resource_limit')
        self.assertIsNone(result['record'])
        self.assertIsNone(result['physical_cost'])
        self.assertFalse(result['audit']['fallback_used'])

if __name__=='__main__':unittest.main()
