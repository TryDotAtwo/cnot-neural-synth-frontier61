import tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from research_v3.data import stream_solver_dataset_v13 as stream

class GuardedPrimaryClosureTests(unittest.TestCase):
    def test_actual_primary_bytes_are_pinned_in_dataset_manifest(self):
        observed=stream.data_source_hashes()
        for name, expected in stream.GUARDED_PRIMARY_SOURCES.items():
            self.assertEqual(observed[name],expected)
        with tempfile.TemporaryDirectory() as directory:
            connection,manifest=stream.open_store(Path(directory)/'new.sqlite',seed_base=3700,source_sha={})
            try:
                for name,expected in stream.GUARDED_PRIMARY_SOURCES.items():
                    self.assertEqual(manifest['dataset_source_sha256'][name],expected)
            finally:connection.close()

    def test_each_primary_drift_rejected_before_store_creation(self):
        original=Path.read_bytes
        for name in stream.GUARDED_PRIMARY_SOURCES:
            with self.subTest(source=name), tempfile.TemporaryDirectory() as directory:
                target=Path(directory)/'not-created.sqlite'
                def altered(path):
                    data=original(path)
                    return data+b'\nDRIFT' if path.as_posix().endswith(name) else data
                with patch.object(Path,'read_bytes',altered):
                    with self.assertRaisesRegex(ValueError,'guarded primary source drift'):
                        stream.open_store(target,seed_base=3700,source_sha={})
                self.assertFalse(target.exists())

if __name__=='__main__':unittest.main()
