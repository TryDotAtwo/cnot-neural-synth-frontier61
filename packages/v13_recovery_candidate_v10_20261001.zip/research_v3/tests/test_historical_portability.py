import unittest
from pathlib import Path
from research_v3.data.frozen import historical_input_relative, historical_states
class HistoricalPortabilityTests(unittest.TestCase):
    def test_windows_source_normalized_to_host_path(self):
        self.assertEqual(historical_input_relative(r'source_snapshot\inputs\matrix.json'), Path('source_snapshot')/'inputs'/'matrix.json')
    def test_traversal_and_other_roots_rejected(self):
        for source in ('../matrix.json','/source_snapshot/inputs/a.json',r'source_snapshot\inputs\..\a.json',r'C:\source_snapshot\inputs\a.json'):
            with self.subTest(source=source), self.assertRaises(ValueError):
                historical_input_relative(source)
    def test_all_own_historical_files_validate(self):
        root=Path(__file__).resolve().parents[2]/'historical_stage17_own_v1'
        states,sources=historical_states(root)
        self.assertEqual(len(states),9)
        self.assertEqual(len(sources),9)
if __name__=='__main__': unittest.main()
