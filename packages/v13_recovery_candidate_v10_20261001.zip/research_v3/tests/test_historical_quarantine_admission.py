import unittest
from research_v3.train.cuda_stream_v13 import require_historical_quarantine

class HistoricalQuarantineAdmissionTests(unittest.TestCase):
    def test_complete_nine_source_contract_is_required(self):
        seal={'historical_roots':9,'historical_source_sha256':{f'own-input-{i}':'a'*64 for i in range(9)}}
        require_historical_quarantine(seal,{'historical_roots':9})
        for count in (None,0,8,10):
            with self.assertRaisesRegex(ValueError,'all nine'):
                require_historical_quarantine(dict(seal,historical_roots=count),{'historical_roots':9})
            with self.assertRaisesRegex(ValueError,'all nine'):
                require_historical_quarantine(seal,{'historical_roots':count})
        for sources in ({},dict(list(seal['historical_source_sha256'].items())[:8]),
                        dict(seal['historical_source_sha256'],**{'own-input-0':'invalid'})):
            with self.assertRaisesRegex(ValueError,'pinned historical'):
                require_historical_quarantine(dict(seal,historical_source_sha256=sources),{'historical_roots':9})

if __name__=='__main__':unittest.main()
