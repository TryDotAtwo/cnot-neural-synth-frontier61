import hashlib
import json
from pathlib import Path
import sqlite3
import tempfile
import unittest
from research_v3.cli.audit_live_molab_v13 import inspect_database, process_inventory


class InventoryTests(unittest.TestCase):
    def test_readonly_inventory_preserves_database_bytes(self):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / 'own.sqlite'
            connection = sqlite3.connect(path)
            connection.executescript('CREATE TABLE metadata(key TEXT,value TEXT); '
                                     'CREATE TABLE roots(split TEXT,record_json TEXT);')
            connection.execute('INSERT INTO metadata VALUES (?,?)', ('holdout_seal', '{"own":true}'))
            connection.execute('INSERT INTO roots VALUES (?,?)', ('dev', '{"state":{"n":8}}'))
            connection.commit(); connection.close()
            before = hashlib.sha256(path.read_bytes()).hexdigest()
            report = inspect_database(path)
            self.assertEqual(report['integrity'], ['ok'])
            self.assertEqual(report['split_width_counts'], [['dev', 8, 1]])
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), before)
            self.assertEqual(sorted(p.name for p in Path(temp).iterdir()), ['own.sqlite'])

    def test_process_arguments_and_tokens_are_not_reported(self):
        with tempfile.TemporaryDirectory() as temp:
            proc = Path(temp); process = proc / '123'; process.mkdir()
            (process / 'cmdline').write_bytes(b'/usr/bin/python\0-m\0research_v3.cli.train\0'
                                            b'--token\0PRIVATE_VALUE\0research_v3.bad?secret\0')
            (process / 'status').write_text('Name: python\nState: R (running)\n')
            report = process_inventory(proc)
            self.assertEqual(report[0]['own_modules'], ['research_v3.cli.train'])
            self.assertNotIn('PRIVATE_VALUE', json.dumps(report))
            self.assertNotIn('secret', json.dumps(report))


if __name__ == '__main__': unittest.main()
