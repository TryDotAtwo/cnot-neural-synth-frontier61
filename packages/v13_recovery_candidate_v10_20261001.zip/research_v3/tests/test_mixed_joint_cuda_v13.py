"""Molab gate: full-model mixed-width update, not a training quality result."""
from dataclasses import replace
import json
import os
from pathlib import Path
import unittest
from time import perf_counter
import torch
from research_v3.contracts import AlphabetSpec
from research_v3.data.exact_small import build_exact_small
from research_v3.data.verified_exact_catalog_v13 import VerifiedExactCatalog
from research_v3.data.stream_solver_dataset_v13 import make_root
from research_v3.gpu.holdout import GpuExactHoldout
from research_v3.gpu.mixed_joint_records_v13 import RecordGroup, complete_mixed_joint_records


@unittest.skipUnless(os.environ.get('MOLAB_TEST_CUDA') == '1' and torch.cuda.is_available(),
                     'explicit Molab CUDA gate')
class MixedJointCudaTests(unittest.TestCase):
    def test_full_field_and_basis_gradients_in_one_mixed_update(self):
        from research_v3.cli.probe_gpu_fullwidth_joint import _model
        cfg = json.loads((Path(__file__).resolve().parents[2] /
                          'full_training_config.json').read_text())
        torch.set_num_threads(cfg['threads'])
        torch.manual_seed(cfg['seed'])
        model = _model(cfg).train()
        optimizer = torch.optim.AdamW(model.parameters(), lr=1e-5)
        large, _ = make_root('train', 0, 126, 0, 7000)
        self.assertEqual(large.state.n, 8)
        # The preserved every-100-root reference schedule selects width 4:
        # epoch*10000 + position is odd at positions 99,199,...,9999.
        context = VerifiedExactCatalog(build_exact_small(4, AlphabetSpec.all_to_all(4)))
        small = replace(max(context.records.values(), key=lambda r: r.exact_distance),
                        split='train', lineage_id='exact_stream:mixed_cuda:4')
        # Diagnostic empty banks exercise shape and complete-neighbor admission.
        # They are NOT a receipt for the production sealed holdout loader.
        groups = (RecordGroup((large,), GpuExactHoldout.empty_projection(8)),
                  RecordGroup((small,), GpuExactHoldout.empty_projection(4), context))
        generator = torch.Generator(device='cuda').manual_seed(9137)
        device = next(model.parameters()).device
        torch.cuda.synchronize(device)
        torch.cuda.reset_peak_memory_stats(device)
        profile = {'schema': 'own_mixed_joint_cuda_phase_profile_v13',
                   'widths': [8, 4], 'gpu': torch.cuda.get_device_name(device),
                   'parameters': sum(p.numel() for p in model.parameters()),
                   'baseline_allocated_bytes': torch.cuda.memory_allocated(device),
                   'baseline_reserved_bytes': torch.cuda.memory_reserved(device)}
        started = perf_counter()
        loss, audit = complete_mixed_joint_records(
            model, groups, generator=generator, choice_count=2, action_chunk=6,
            samples=2, max_evaluations=5000, max_bytes=268435456, weight=.1,
            qhat_weight=.1, supervision_weight=1., teacher_weight=.1,
            mc_samples=cfg['diffusion']['mc_samples'], mc_seed=cfg['feature_seed'],
            max_pair_states=cfg['diffusion']['max_pair_states'])
        torch.cuda.synchronize(device)
        profile['forward_seconds'] = perf_counter() - started
        profile['forward_allocated_bytes'] = torch.cuda.memory_allocated(device)
        profile['forward_peak_allocated_bytes'] = torch.cuda.max_memory_allocated(device)
        profile['basis_mc_workspace_estimate_bytes'] = audit['basis_mc_workspace_estimate_bytes']
        self.assertTrue(torch.isfinite(loss).item())
        self.assertEqual(audit['records'], 2)
        self.assertEqual(audit['exact_root_examples'], 2)
        self.assertEqual(audit['admission_counts'], [57, 13])
        self.assertGreater(audit['basis_templates'], 0)
        started = perf_counter()
        loss.backward()
        torch.cuda.synchronize(device)
        profile['backward_seconds'] = perf_counter() - started
        profile['backward_allocated_bytes'] = torch.cuda.memory_allocated(device)
        profile['through_backward_peak_allocated_bytes'] = torch.cuda.max_memory_allocated(device)
        for module in (model.field, model.proposer):
            grads = [p.grad for p in module.parameters() if p.grad is not None]
            self.assertTrue(grads)
            self.assertTrue(all(torch.isfinite(g).all().item() for g in grads))
            self.assertGreater(sum(g.abs().sum().item() for g in grads), 0)
        started = perf_counter()
        optimizer.step()
        torch.cuda.synchronize(device)
        profile['optimizer_seconds'] = perf_counter() - started
        profile['through_optimizer_peak_allocated_bytes'] = torch.cuda.max_memory_allocated(device)
        profile['through_optimizer_peak_reserved_bytes'] = torch.cuda.max_memory_reserved(device)
        steps = {int(state['step'].item()) for state in optimizer.state.values()}
        self.assertEqual(steps, {1})
        self.assertEqual(sum(a['basis_evaluations'] for a in audit['groups']),
                         audit['basis_evaluations'])
        profile['scope'] = 'one diagnostic mixed n8+n4 update; not a bound for wider groups or production sealed banks'
        print(json.dumps(profile, sort_keys=True), flush=True)


if __name__ == '__main__': unittest.main()
