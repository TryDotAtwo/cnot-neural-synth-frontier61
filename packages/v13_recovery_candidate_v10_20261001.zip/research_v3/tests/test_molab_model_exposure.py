"""Native CUDA integration gate. Skips on CPU are not acceptance."""
import tempfile,unittest,os
from pathlib import Path
import torch
import copy
from types import SimpleNamespace
from research_v3.contracts import AlphabetSpec,MatrixState
from research_v3.features.registry import FeatureRegistry
from research_v3.model.field import FusionDistanceField
from research_v3.gpu.field_slice import gpu_field_value
from research_v3.data.model_exposure_journal_v1 import ModelExposureJournal
from research_v3.train.checkpoint import save_checkpoint,load_checkpoint
from research_v3.train.schedule import Progress

@unittest.skipUnless(Path('/marimo').is_dir() and torch.cuda.is_available(),'Molab native CUDA session required; local CUDA is not authorized for this gate')
class MolabModelExposureTests(unittest.TestCase):
    def test_cuda_optimizer_rng_and_journal_continuous_vs_restored(self):
        # A bounded native instrumentation gate, not full Bellman acceptance.
        self.assertIn(os.environ.get('CUBLAS_WORKSPACE_CONFIG'),(':4096:8',':16:8'),
                      'launch native process with declared deterministic cuBLAS configuration')
        previous=torch.are_deterministic_algorithms_enabled()
        previous_warn=torch.is_deterministic_algorithms_warn_only_enabled()
        torch.use_deterministic_algorithms(True)
        self.addCleanup(torch.use_deterministic_algorithms,previous,warn_only=previous_warn)
        registry=FeatureRegistry()
        model=FusionDistanceField([registry.specs[k] for k in ('A01','B01')],d=8,pair_d=4,blocks=1,heads=2,ffn=16,fusion_blocks=1).cuda()
        model.eval()  # Differentiable field; no stochastic dropout in this gate.
        optimizer=torch.optim.Adam(model.parameters(),lr=1e-4)
        alphabet=AlphabetSpec.all_to_all(3)
        state=MatrixState(3,(1,3,7),alphabet.id)
        rows=torch.tensor(state.packed_rows,device='cuda',dtype=torch.int64).reshape(1,3,1)
        progress=Progress()
        position=[0]
        sampler=SimpleNamespace(state_dict=lambda:{'position':position[0]},
                                load_state_dict=lambda saved:position.__setitem__(0,saved['position']))
        def step(journal):
            sampled=torch.randint(0,100000,(8,),device='cuda')
            optimizer.zero_grad(set_to_none=True)
            with journal.attach_stem(model.stem):
                value=gpu_field_value(model,rows,mc_samples=0)
                (value.square().mean()+value.mean()).backward()
            optimizer.step();torch.cuda.synchronize()
            position[0]+=1;progress.attempted+=1;progress.accepted+=1
            return sampled.clone(),value.detach().clone()
        def equal(left,right):
            if isinstance(left,torch.Tensor):self.assertTrue(torch.equal(left,right))
            elif isinstance(left,dict):
                self.assertEqual(left.keys(),right.keys())
                for key in left:equal(left[key],right[key])
            elif isinstance(left,(tuple,list)):
                self.assertEqual(len(left),len(right))
                for a,b in zip(left,right):equal(a,b)
            else:self.assertEqual(left,right)
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)
            live=ModelExposureJournal(root/'live.sqlite')
            recovered=None
            try:
                step(live)
                snapshot=live.snapshot(root/'exposures-native.sqlite')
                path=save_checkpoint(root,model,optimizer,sampler,progress,{'gate':'native-exposure-reference-v1'},extra={
                    'model_exposures':snapshot['state'],'model_exposure_snapshot':{
                        'file':'exposures-native.sqlite','receipt':snapshot}})
                uninterrupted=[step(live),step(live)]
                expected_model=copy.deepcopy(model.state_dict())
                expected_optimizer=copy.deepcopy(optimizer.state_dict())
                ahead=live.state_dict()
                restored=load_checkpoint(path,model,optimizer,sampler,progress,{'gate':'native-exposure-reference-v1'})
                with self.assertRaisesRegex(ValueError,'differs from checkpoint'):
                    live.load_state_dict(restored['model_exposures'])
                recovered=ModelExposureJournal.recover_copy(root/'exposures-native.sqlite',snapshot,root/'restored.sqlite')
                resumed=[step(recovered),step(recovered)]
                equal(uninterrupted,resumed)
                equal(expected_model,model.state_dict())
                equal(expected_optimizer,optimizer.state_dict())
                self.assertEqual(position[0],3)
                self.assertEqual(progress.attempted,3)
                self.assertEqual(recovered.state_dict(),ahead)
                self.assertEqual(live.state_dict(),ahead)
            finally:
                live.close()
                if recovered is not None:recovered.close()

    def test_actual_cuda_field_forward_backward_is_durable_and_separate(self):
        registry=FeatureRegistry()
        model=FusionDistanceField([registry.specs[k] for k in ('A01','B01')],d=8,pair_d=4,blocks=1,heads=2,ffn=16,fusion_blocks=1).cuda()
        alphabet=AlphabetSpec.all_to_all(3)
        state=MatrixState(3,(1,3,7),alphabet.id)
        rows=torch.tensor(state.packed_rows,device='cuda',dtype=torch.int64).reshape(1,3,1)
        with tempfile.TemporaryDirectory() as directory:
            journal=ModelExposureJournal(Path(directory)/'exposures.sqlite')
            try:
                with journal.attach_stem(model.stem):
                    value=gpu_field_value(model,rows,mc_samples=0)
                    self.assertEqual(journal.keys('forward'),{state.key})
                    self.assertFalse(journal.keys('gradient'))
                    value.sum().backward();torch.cuda.synchronize()
                    self.assertEqual(journal.keys('gradient'),{state.key})
                    self.assertGreater(sum(float(p.grad.abs().sum()) for p in model.parameters() if p.grad is not None),0)
                journal.load_state_dict(journal.state_dict())
            finally:journal.close()

if __name__=='__main__':unittest.main()
