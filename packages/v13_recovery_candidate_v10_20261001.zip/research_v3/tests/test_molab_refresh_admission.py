"""Molab-only nonempty-bank CUDA admission; no synthesis quality claim."""
from dataclasses import replace
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock
import torch
from research_v3.contracts import AlphabetSpec, Gate
from research_v3.data.generators import record_from_word
from research_v3.gpu.holdout import GpuExactHoldout
from research_v3.gpu.neural_beam import neural_field_callbacks
from research_v3.gpu.record_batch_v13 import own_records_to_cuda
from research_v3.train.neural_refresh_solver_v13 import NeuralRefreshSolver


@unittest.skipUnless(sys.platform == 'linux' and Path('/marimo').exists()
                     and torch.cuda.is_available(), 'Molab CUDA gate only')
class MolabRefreshAdmissionTests(unittest.TestCase):
    def test_full_width_collision_and_both_callbacks_reject(self):
        n = 72
        identity = torch.zeros((1, n, 2), device='cuda', dtype=torch.int64)
        for i in range(n):
            identity[0, i, i // 64] = (1 << (i % 64)) if i % 64 != 63 else -(1 << 63)
        forbidden = identity.clone()
        forbidden[:, 71] ^= forbidden[:, 70]
        bank = GpuExactHoldout.from_matrices(forbidden,
            hash_weights=torch.zeros((n, 2), device='cuda', dtype=torch.int64))
        self.assertFalse(bool(bank.matches(identity).any().item()))
        self.assertTrue(bool(bank.matches(forbidden).all().item()))
        def admit(rows):
            if bool(bank.matches(rows).any().item()):
                raise ValueError('forbidden full matrix')
        model = Mock()
        callbacks = neural_field_callbacks(model, mc_samples=1, mc_seed=1,
                                          max_pair_states=1, admission=admit)
        batch = torch.cat((identity, forbidden))
        for callback in callbacks:
            with self.assertRaisesRegex(ValueError, 'forbidden full matrix'):
                callback(batch)
        self.assertEqual(model.mock_calls, [])

    def test_actual_refresh_rejects_nonempty_bank_before_model_forward(self):
        record = replace(record_from_word(AlphabetSpec.all_to_all(8),
                          (Gate(0, 1), Gate(2, 3)), 'train:molab-admission', 31,
                          source='ordinary_walk_v1'), split='train')
        rows = own_records_to_cuda((record,)).walk.rows
        bank = GpuExactHoldout.from_matrices(rows)
        model = torch.nn.Linear(1, 1).cuda().train()
        calls = []
        hook = model.register_forward_hook(lambda *_: calls.append(True))
        self.addCleanup(hook.remove)
        solver = NeuralRefreshSolver(model,
            search_config=dict(beam_width=2, shortlist=2, max_depth=2,
                               inference_batch=2, max_expanded=30),
            field_config=dict(mc_samples=1, mc_seed=1, max_pair_states=1, head='qhat'),
            source_sha256={}, holdout_banks={8: bank})
        with self.assertRaisesRegex(ValueError, 'intersects frozen holdout bank'):
            solver(record, 0)
        self.assertEqual(calls, [])
        self.assertTrue(model.training)


if __name__ == '__main__':
    unittest.main()
