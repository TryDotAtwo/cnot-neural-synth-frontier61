import contextlib,hashlib,io,json,sqlite3,tempfile,unittest
from pathlib import Path
from unittest.mock import patch
from research_v3.data import stream_solver_dataset_v13 as stream

class StreamStatusTests(unittest.TestCase):
    def test_committed_wal_visible_without_data_or_journal_mutation(self):
        with tempfile.TemporaryDirectory() as directory:
            db=Path(directory)/'status.sqlite'
            writer=sqlite3.connect(db)
            try:
                writer.execute('PRAGMA journal_mode=WAL')
                writer.executescript('CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT);CREATE TABLE roots(split TEXT);')
                manifest={'compiler_source_sha256':{},'dataset_source_sha256':{}}
                writer.execute('INSERT INTO metadata VALUES(?,?)',('manifest',json.dumps(manifest)))
                writer.commit();writer.execute('PRAGMA wal_checkpoint(TRUNCATE)')
                writer.execute("INSERT INTO roots VALUES('dev')");writer.commit()
                wal=Path(str(db)+'-wal')
                before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (db,wal)}
                files_before={p.name for p in Path(directory).iterdir()}
                output=io.StringIO()
                with patch('sys.argv',['status','--db',str(db),'--status']),patch.object(stream,'source_hashes',return_value={}),patch.object(stream,'data_source_hashes',return_value={}),contextlib.redirect_stdout(output):
                    stream.main()
                report=json.loads(output.getvalue())
                self.assertEqual(report['root_counts'],{'dev':1})
                self.assertIsNone(report['generation_limit_counts'])
                self.assertEqual({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (db,wal)},before)
                self.assertEqual(writer.execute('PRAGMA journal_mode').fetchone()[0],'wal')
                self.assertEqual({p.name for p in Path(directory).iterdir()},files_before)
            finally:writer.close()

    def test_limit_journal_reported_separately_from_committed_roots(self):
        with tempfile.TemporaryDirectory() as directory:
            db=Path(directory)/'status.sqlite'
            connection,manifest=stream.open_store(db,seed_base=3700,source_sha={})
            try:
                connection.execute('INSERT INTO generation_limits VALUES(?,?,?,?,?)',
                    ('dev',0,406,0,json.dumps({'status':'resource_limit'})))
                connection.commit()
                output=io.StringIO()
                with patch('sys.argv',['status','--db',str(db),'--status']),patch.object(stream,'source_hashes',return_value={}),contextlib.redirect_stdout(output):
                    stream.main()
                report=json.loads(output.getvalue())
                self.assertEqual(report['root_counts'],{})
                self.assertEqual(report['generation_limit_counts'],{'dev':1})
                self.assertTrue(report['current_source_matches_manifest'])
                self.assertEqual(report['read_scope'],'read_only_transaction_including_committed_WAL')
            finally:connection.close()

if __name__=='__main__':unittest.main()
