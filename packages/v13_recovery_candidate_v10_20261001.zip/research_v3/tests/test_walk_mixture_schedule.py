import unittest
from collections import Counter
from research_v3.data import stream_solver_dataset_v13 as stream

class WalkMixtureScheduleTests(unittest.TestCase):
    def test_both_walk_sources_appear_at_every_confirmatory_width(self):
        counts={n:Counter() for n in stream.SIZES}
        for index in range(1792):
            family=stream.FAMILIES[(index//len(stream.SIZES))%len(stream.FAMILIES)]
            if family=='walk_mixture':counts[stream.SIZES[index%len(stream.SIZES)]][stream.select_walk_kind(0,index)]+=1
        for n in stream.SIZES:
            self.assertEqual(counts[n],{'ordinary_walk':16,'poisson_walk':16})

    def test_retry_seed_parity_cannot_select_walk_family(self):
        index=56
        self.assertEqual(stream.select_walk_kind(0,index),'poisson_walk')
        self.assertEqual(stream.select_walk_kind(1,index),'ordinary_walk')
        # The old first-attempt rule was constant across every width/cycle.
        old={stream.epoch_seed('dev',0,i,0,42)%2 for i in range(1792)}
        self.assertEqual(old,{0})
        self.assertEqual({stream.select_walk_kind(0,i) for i in range(0,1792,56)},
                         {'ordinary_walk','poisson_walk'})

if __name__=='__main__':unittest.main()
