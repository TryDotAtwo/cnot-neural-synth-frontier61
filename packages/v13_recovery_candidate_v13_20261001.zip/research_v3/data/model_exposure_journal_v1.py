"""Durable full-key model exposures; stem hooks observe real forward/backward.

This journal is a candidate instrumentation path. Native throughput and the
production stream/checkpoint integration require independent acceptance.
"""
from contextlib import contextmanager
from dataclasses import fields,is_dataclass
import hashlib,json,sqlite3,os,uuid
import threading
from functools import wraps
from pathlib import Path
import torch
from ..contracts import AlphabetSpec

KINDS=('label','forward','gradient')
def serialized(method):
    @wraps(method)
    def call(self,*args,**kwargs):
        with self._lock:return method(self,*args,**kwargs)
    return call
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)

def batch_keys(batch):
    matrix=batch.matrix.detach().cpu()
    valid=batch.valid.detach().cpu()
    if matrix.ndim!=3 or matrix.shape[1]!=matrix.shape[2] or valid.shape!=matrix.shape[:2]:
        raise ValueError('full square matrix and wire mask required')
    result=[]
    for rows,mask in zip(matrix,valid):
        n=int(mask.sum())
        if n<1 or not bool(mask[:n].all()) or bool(mask[n:].any()):
            raise ValueError('exposure wire mask must be a nonempty prefix')
        bits=rows[:n,:n]
        if not bool(((bits==0)|(bits==1)).all()):raise ValueError('binary full matrix exposure required')
        packed=tuple(sum(int(bit)<<j for j,bit in enumerate(row)) for row in bits.tolist())
        result.append((n,AlphabetSpec.all_to_all(n).id,packed))
    return tuple(result)

def output_tensors(value):
    if isinstance(value,torch.Tensor):yield value
    elif is_dataclass(value):
        for field in fields(value):yield from output_tensors(getattr(value,field.name))
    elif isinstance(value,dict):
        for item in value.values():yield from output_tensors(item)
    elif isinstance(value,(tuple,list)):
        for item in value:yield from output_tensors(item)

class ModelExposureJournal:
    def __init__(self,path,*,forbidden_keys=(),holdout_seal_sha256=None):
        if holdout_seal_sha256 is not None and (type(holdout_seal_sha256) is not str or len(holdout_seal_sha256)!=64 or any(c not in '0123456789abcdef' for c in holdout_seal_sha256)):
            raise ValueError('invalid exposure holdout seal identity')
        self.holdout_seal_sha256=holdout_seal_sha256
        self.path=Path(path)
        self._lock=threading.RLock()
        existing=self.path.exists()
        if existing:
            probe=sqlite3.connect(self.path.resolve().as_uri()+'?mode=ro',uri=True)
            try:
                has_metadata=probe.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='metadata'").fetchone()
                identity=probe.execute("SELECT value FROM metadata WHERE key='journal_id'").fetchone() if has_metadata else None
                if identity is None:
                    raise ValueError('legacy journal requires explicit new experiment; no identity migration')
                journal_id=identity[0]
                if str(uuid.UUID(journal_id))!=journal_id:raise ValueError('invalid journal identity')
            finally:probe.close()
        else:journal_id=str(uuid.uuid4())
        self.connection=sqlite3.connect(self.path,check_same_thread=False)
        self.connection.executescript('''
            CREATE TABLE IF NOT EXISTS metadata(key TEXT PRIMARY KEY,value TEXT);
            CREATE TABLE IF NOT EXISTS observed(kind TEXT,key_json TEXT,PRIMARY KEY(kind,key_json));
            CREATE TABLE IF NOT EXISTS forbidden(key_json TEXT PRIMARY KEY);
            CREATE TABLE IF NOT EXISTS events(sequence INTEGER PRIMARY KEY,kind TEXT,batch_json TEXT);
        ''')
        if not existing:
            with self.connection:self.connection.execute('INSERT INTO metadata VALUES(?,?)',('journal_id',journal_id))
        supplied=sorted({canonical(key) for key in forbidden_keys})
        bank_sha=hashlib.sha256(canonical(supplied).encode()).hexdigest()
        stored=self.connection.execute("SELECT value FROM metadata WHERE key='forbidden_sha'").fetchone()
        if stored is not None and stored[0]!=bank_sha:
            self.connection.close();raise ValueError('exposure forbidden bank changed')
        seal=canonical(holdout_seal_sha256)
        stored_seal=self.connection.execute("SELECT value FROM metadata WHERE key='holdout_seal_sha'").fetchone()
        if stored_seal is not None and stored_seal[0]!=seal:
            self.connection.close();raise ValueError('exposure holdout seal changed')
        with self.connection:
            self.connection.execute('INSERT OR IGNORE INTO metadata VALUES(?,?)',('holdout_seal_sha',seal))
            self.connection.execute('INSERT OR IGNORE INTO metadata VALUES(?,?)',('forbidden_sha',bank_sha))
            self.connection.execute('INSERT OR IGNORE INTO metadata VALUES(?,?)',('event_chain_sha',hashlib.sha256(b'').hexdigest()))
            self.connection.executemany('INSERT OR IGNORE INTO forbidden VALUES(?)',[(key,) for key in supplied])
    def immutable_contract(self):
        source=str(Path(__file__).resolve())
        splits_source=str(Path(__file__).with_name('splits.py').resolve())
        return {'schema':'own_model_exposures_v2_logical_identity','config':{
            'journal_id':self.state_dict()['journal_id'],'holdout_seal_sha256':self.holdout_seal_sha256,
            'forbidden_sha256':self.state_dict()['forbidden_sha256'],
            'observation_policy':'structural_stem_forward_and_actual_backward'},
            'source_sha256':{path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
                             for path in (source,splits_source)}}
    def verify_packed_banks(self,banks):
        expected=0
        mask=(1<<64)-1
        for n,bank in sorted(banks.items()):
            tensor=bank.sorted_rows
            if tensor.ndim!=3 or tensor.dtype!=torch.int64 or tensor.shape[1:]!=(n,(n+63)//64):
                raise ValueError('exposure packed holdout shape mismatch')
            alphabet_id=AlphabetSpec.all_to_all(n).id
            # Exact comparison against the actual approved packed bank. This
            # preflight cost is explicit; no complete orbit claim is made.
            for matrix in tensor.detach().cpu().tolist():
                rows=tuple(sum((word&mask)<<(64*slot) for slot,word in enumerate(row)) for row in matrix)
                key=canonical((n,alphabet_id,rows))
                if not self.connection.execute('SELECT 1 FROM forbidden WHERE key_json=?',(key,)).fetchone():
                    raise ValueError('exposure forbidden keys differ from packed holdout bank')
                expected+=1
        actual=self.connection.execute('SELECT COUNT(*) FROM forbidden').fetchone()[0]
        if actual!=expected:raise ValueError('exposure forbidden key count differs from packed holdout banks')

    @serialized
    def observe(self,kind,keys):
        if kind not in KINDS:raise ValueError('unknown exposure kind')
        encoded=tuple(canonical(key) for key in keys)
        # Reject the entire batch before persisting any exposure or model call.
        if any(self.connection.execute('SELECT 1 FROM forbidden WHERE key_json=?',(key,)).fetchone() for key in encoded):
            raise ValueError('forbidden full matrix model exposure')
        with self.connection:
            self.connection.executemany('INSERT OR IGNORE INTO observed VALUES(?,?)',[(kind,key) for key in encoded])
            batch_json=canonical(encoded)
            cursor=self.connection.execute('INSERT INTO events(kind,batch_json) VALUES(?,?)',(kind,batch_json))
            previous=self.connection.execute("SELECT value FROM metadata WHERE key='event_chain_sha'").fetchone()[0]
            chain=hashlib.sha256(bytes.fromhex(previous)+canonical((cursor.lastrowid,kind,batch_json)).encode()).hexdigest()
            self.connection.execute("UPDATE metadata SET value=? WHERE key='event_chain_sha'",(chain,))
    def observe_labels(self,records):self.observe('label',tuple(record.state.key for record in records))
    @serialized
    def keys(self,kind):
        if kind not in KINDS:raise ValueError('unknown exposure kind')
        return {tuple([value[0],value[1],tuple(value[2])]) for (raw,) in self.connection.execute('SELECT key_json FROM observed WHERE kind=?',(kind,)) for value in [json.loads(raw)]}
    @serialized
    def state_dict(self):
        count,last=self.connection.execute('SELECT COUNT(*),COALESCE(MAX(sequence),0) FROM events').fetchone()
        chain=self.connection.execute("SELECT value FROM metadata WHERE key='event_chain_sha'").fetchone()[0]
        bank=self.connection.execute("SELECT value FROM metadata WHERE key='forbidden_sha'").fetchone()[0]
        return {'schema':'own_model_exposures_v2_logical_identity','journal_id':self.connection.execute("SELECT value FROM metadata WHERE key='journal_id'").fetchone()[0],'events':count,'last_sequence':last,
                'event_sha256':chain,'forbidden_sha256':bank}
    @serialized
    def split_audit(self):
        """Actual persisted exposures, not a caller's predicted query set."""
        from .splits import Exposures,SplitPolicy
        forbidden={tuple([value[0],value[1],tuple(value[2])])
                   for (raw,) in self.connection.execute('SELECT key_json FROM forbidden')
                   for value in [json.loads(raw)]}
        exposures=Exposures(self.keys('label'),self.keys('forward'),self.keys('gradient'))
        report=SplitPolicy(forbidden).audit((),exposures)
        report['holdout_seal_sha256']=self.holdout_seal_sha256
        return report
    @serialized
    def verify_events(self):
        chain=hashlib.sha256(b'').hexdigest()
        for row in self.connection.execute('SELECT sequence,kind,batch_json FROM events ORDER BY sequence'):
            chain=hashlib.sha256(bytes.fromhex(chain)+canonical(row).encode()).hexdigest()
        if chain!=self.state_dict()['event_sha256']:
            raise ValueError('exposure event ledger content drift')
        expected="SELECT DISTINCT e.kind AS kind,j.value AS key_json FROM events e,json_each(e.batch_json) j"
        for left,right in ((expected,'SELECT kind,key_json FROM observed'),('SELECT kind,key_json FROM observed',expected)):
            if self.connection.execute('SELECT 1 FROM ('+left+' EXCEPT '+right+') LIMIT 1').fetchone():
                raise ValueError('exposure materialized sets differ from event ledger')
        bank=[row[0] for row in self.connection.execute('SELECT key_json FROM forbidden ORDER BY key_json')]
        if hashlib.sha256(canonical(bank).encode()).hexdigest()!=self.state_dict()['forbidden_sha256']:
            raise ValueError('exposure forbidden bank content drift')
    @serialized
    def load_state_dict(self,state):
        self.verify_events()
        if state!=self.state_dict():raise ValueError('exposure journal differs from checkpoint; preserve and audit before recovery')
    @serialized
    def snapshot(self,path):
        """Exclusive durable SQLite backup; caller binds receipt to checkpoint.

        The live journal remains untouched. Publication/recovery of a training
        run still requires its run lock and checkpoint contract validation.
        """
        target=Path(path)
        if target.resolve()==self.path.resolve():raise ValueError('snapshot must have a separate path')
        self.verify_events()
        state=self.state_dict()
        # Reserve exclusively before SQLite opens; never overwrite old evidence.
        with target.open('xb'):pass
        destination=sqlite3.connect(target)
        try:self.connection.backup(destination)
        finally:destination.close()
        with target.open('r+b') as stream:os.fsync(stream.fileno())
        return {'schema':'own_model_exposure_snapshot_v1',
                'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
                'state':state,'holdout_seal_sha256':self.holdout_seal_sha256,
                'split_audit':self.split_audit()}

    @classmethod
    def validate_snapshot(cls,snapshot,receipt):
        """Read-only full digest, event ledger, materialization and seal audit."""
        source=Path(snapshot)
        if receipt.get('schema')!='own_model_exposure_snapshot_v1':
            raise ValueError('unsupported exposure snapshot receipt')
        if hashlib.sha256(source.read_bytes()).hexdigest()!=receipt['sha256']:
            raise ValueError('exposure snapshot digest mismatch')
        connection=sqlite3.connect(source.resolve().as_uri()+'?mode=ro',uri=True)
        try:
            if connection.execute('PRAGMA quick_check').fetchall()!=[('ok',)]:
                raise ValueError('exposure snapshot SQLite integrity failure')
            keys=[json.loads(row[0]) for row in connection.execute('SELECT key_json FROM forbidden')]
        finally:connection.close()
        # Read-only validation uses the same exact ledger verifier, without
        # constructor writes to the immutable source.
        validator=cls.__new__(cls)
        validator._lock=threading.RLock()
        validator.holdout_seal_sha256=receipt['holdout_seal_sha256']
        validator.connection=sqlite3.connect(source.resolve().as_uri()+'?mode=ro',uri=True)
        try:
            validator.load_state_dict(receipt['state'])
            seal=validator.connection.execute("SELECT value FROM metadata WHERE key='holdout_seal_sha'").fetchone()
            if seal is None or json.loads(seal[0])!=receipt['holdout_seal_sha256']:
                raise ValueError('exposure snapshot holdout seal mismatch')
            if validator.split_audit()!=receipt['split_audit']:
                raise ValueError('exposure snapshot split audit mismatch')
        finally:validator.connection.close()
        return keys

    @classmethod
    def recover_copy(cls,snapshot,receipt,destination):
        """Restore into fresh path; never replace configured live journal."""
        source=Path(snapshot);target=Path(destination)
        keys=cls.validate_snapshot(source,receipt)
        # Preserve byte identity rather than silently migrating SQLite metadata.
        with target.open('xb') as output:
            output.write(source.read_bytes());output.flush();os.fsync(output.fileno())
        journal=cls(target,forbidden_keys=keys,holdout_seal_sha256=receipt['holdout_seal_sha256'])
        try:journal.load_state_dict(receipt['state'])
        except BaseException:
            journal.close();raise
        return journal
    @serialized
    def close(self):self.connection.close()
    @contextmanager
    def attach_stem(self,stem):
        pending=[]
        def before(_module,args):
            keys=batch_keys(args[0]);self.observe('forward',keys);pending.append(keys)
        def after(_module,args,output):
            keys=pending.pop();seen=[False]
            def backward(gradient):
                with self._lock:
                    if not seen[0]:self.observe('gradient',keys);seen[0]=True
                return gradient
            for tensor in output_tensors(output):
                if tensor.requires_grad:tensor.register_hook(backward)
        pre=stem.register_forward_pre_hook(before)
        post=stem.register_forward_hook(after)
        try:yield self
        finally:pre.remove();post.remove()
