"""Load a sealed own holdout into exact per-width CUDA admission banks.

The SQLite connection is read-only and only own stage-17 historical inputs are
used. The GPU bank covers the declared finite views and every CNOT neighbor.
"""

from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sqlite3

import torch

from ..contracts import AlphabetSpec, MatrixState
from ..data.stream_reader_v13 import decode_record
from ..data.stream_solver_dataset_v13 import canonical, data_source_hashes, SCHEMA
from ..data.own_synthesis import source_hashes
from .holdout import GpuExactHoldout, declared_finite_views


def _signed_word(value: int) -> int:
    return value - (1 << 64) if value & (1 << 63) else value


def open_readonly_holdout_snapshot(db):
    """Consistent committed WAL view; caller must close the connection."""
    path=Path(db).resolve()
    if not path.is_file():raise FileNotFoundError(path)
    connection=sqlite3.connect(path.as_uri()+'?mode=ro',uri=True)
    try:connection.execute('BEGIN')
    except BaseException:
        connection.close();raise
    return connection


def _historical_hashes_by_input(sources: dict[str, str]) -> dict[str, str]:
    normalized = {}
    for path, digest in sources.items():
        parts = path.replace('\\', '/').split('/source_snapshot/inputs/', 1)
        if len(parts) != 2 or not parts[1] or parts[1] in normalized:
            raise ValueError('ambiguous historical own input path')
        normalized[parts[1]] = digest
    return normalized


def _portable_historical_states(stage17_root: Path):
    """Read pinned own stage-17 paths under either Windows or POSIX semantics."""
    root = Path(stage17_root).resolve()
    baseline = root / 'improved/research_v2/baselines.json'
    cases = json.loads(baseline.read_text(encoding='utf-8'))['cases']
    states, sources = [], {}
    input_root = (root / 'source_snapshot/inputs').resolve()
    for case in cases:
        relative = case['input_source'].replace('\\', '/')
        path = (root / relative).resolve()
        if not path.is_relative_to(input_root):
            raise ValueError('historical input outside own snapshot')
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        if digest != case['input_file_sha256']:
            raise ValueError('historical own input source drift')
        states.append(MatrixState.from_dense(json.loads(raw)['matrix'],
                                             AlphabetSpec.all_to_all(case['n'])))
        sources[str(path)] = digest
    return tuple(states), sources


def _pack_states(states: list[MatrixState], n: int) -> torch.Tensor:
    if not states or any(state.n != n or
                         state.alphabet_id != AlphabetSpec.all_to_all(n).id
                         for state in states):
        raise ValueError('mixed or empty own holdout width')
    words = (n + 63) // 64
    return torch.tensor([[[ _signed_word((row >> (64 * slot)) & ((1 << 64) - 1))
                           for slot in range(words)]
                          for row in state.packed_rows]
                         for state in states], device='cuda', dtype=torch.int64)


def load_sealed_own_banks(db: Path, stage17_root: Path, *,
                          neighbor_chunk: int, max_entries_per_width: int,
                          additional_widths=()
                          ) -> tuple[dict[int, GpuExactHoldout], dict]:
    """Verify saved provenance/words, then build finite-view one-hop GPU banks."""
    if not torch.cuda.is_available() or neighbor_chunk < 1 or max_entries_per_width < 1:
        raise ValueError('CUDA and positive explicit holdout budgets required')
    additional_widths = tuple(additional_widths)
    if (len(set(additional_widths)) != len(additional_widths) or
            any(type(n) is not int or not 2 <= n <= 256 for n in additional_widths)):
        raise ValueError('distinct supported additional holdout widths required')
    db = Path(db).resolve()
    if not db.is_file():
        raise FileNotFoundError(db)
    connection = open_readonly_holdout_snapshot(db)
    try:
        manifest_row = connection.execute(
            "SELECT value FROM metadata WHERE key='manifest'").fetchone()
        seal_row = connection.execute(
            "SELECT value FROM metadata WHERE key='holdout_seal'").fetchone()
        if manifest_row is None or seal_row is None:
            raise ValueError('sealed own stream required')
        manifest, seal = json.loads(manifest_row[0]), json.loads(seal_row[0])
        if (manifest.get('schema') != SCHEMA or
                manifest['compiler_source_sha256'] != source_hashes() or
                manifest['dataset_source_sha256'] != data_source_hashes() or
                seal['dev_roots'] != manifest['expected_dev_roots'] or
                seal['test_roots'] != manifest['expected_test_roots']):
            raise ValueError('holdout source or count manifest drift')
        by_width = defaultdict(list)
        counts = defaultdict(int)
        for split, matrix_hash, identity, raw, audit_json, offsets_json, root_digest in connection.execute(
                "SELECT split,matrix_hash,matrix_json,record_json,audit_json,"
                "suffix_offsets_json,root_digest FROM roots WHERE split IN ('dev','test') "
                "ORDER BY split,epoch,position"):
            if (hashlib.sha256(identity.encode('ascii')).hexdigest() != matrix_hash or
                    hashlib.sha256(canonical((identity, raw, audit_json,
                                              offsets_json)).encode('utf-8')).hexdigest()
                    != root_digest):
                raise ValueError('holdout root digest mismatch')
            record = decode_record(raw)
            if record.split != split or canonical(record.state.key) != identity:
                raise ValueError('holdout root identity or split mismatch')
            by_width[record.state.n].append(record.state)
            counts[split] += 1
        if (counts['dev'] != seal['dev_roots'] or
                counts['test'] != seal['test_roots']):
            raise ValueError('sealed root counts changed')
    finally:
        connection.close()
    historical, historical_sources = _portable_historical_states(stage17_root)
    if (_historical_hashes_by_input(historical_sources) !=
            _historical_hashes_by_input(seal['historical_source_sha256']) or
            len(historical) != seal['historical_roots']):
        raise ValueError('historical own input drift')
    for state in historical:
        by_width[state.n].append(state)
    banks = {}
    widths = {}
    view_count = 0
    for n, states in sorted(by_width.items()):
        roots = _pack_states(states, n)
        views = declared_finite_views(roots)
        view_count += int(views.shape[0])
        bank = GpuExactHoldout.from_frozen_roots(
            views, neighbor_chunk=neighbor_chunk,
            max_entries=max_entries_per_width)
        banks[n] = bank
        widths[n] = {'roots': len(states), 'stored_forbidden':
                     int(bank.sorted_rows.shape[0])}
    if view_count != seal['finite_symmetry_views']:
        raise ValueError('GPU and sealed CPU finite holdout views disagree')
    # All sealed dev/test and pinned historical roots were checked above.
    # CNOT neighbors and declared finite views preserve matrix width.
    # Therefore a missing dimension has an exactly empty projection, rather
    # than an omitted admission gate or a newly sampled holdout split.
    for n in additional_widths:
        if n not in banks:
            banks[n] = GpuExactHoldout.empty_projection(n)
            widths[n] = {'roots': 0, 'stored_forbidden': 0,
                         'projection': 'absent_in_verified_sealed_root_dimensions'}
    return banks, {'scope': 'declared_finite_views_plus_complete_onehop',
                   'database_read_scope':'read_only_transaction_including_committed_WAL',
                   'holdout_seal_sha256': hashlib.sha256(seal_row[0].encode('utf-8')).hexdigest(),
                   'dev_roots': counts['dev'], 'test_roots': counts['test'],
                   'historical_roots': len(historical),
                   'finite_symmetry_views': view_count, 'widths': widths}
