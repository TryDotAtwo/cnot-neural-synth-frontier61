"""Same native matrices through actual reader and full CUDA word replay."""
import argparse
import hashlib
import json
from dataclasses import asdict, replace
from pathlib import Path
import torch
from ..data.guarded_family_dispatch_v1 import make_exact_root
from ..data.stream_reader_v13 import decode_record
from ..gpu.record_batch_v13 import own_records_to_cuda


def main():
    if not Path('/marimo').is_dir() or not torch.cuda.is_available():
        raise SystemExit('Molab CUDA required')
    parser = argparse.ArgumentParser()
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    data = Path('/marimo/frontier61_recovery_v14/resource_words_native.json').read_bytes()
    assert hashlib.sha256(data).hexdigest() == '1fabac0224301ee346f2bd83b2b2f21aeb8378e4b60b956ba0c9ec3a979b32e0'
    cases = []
    for entry in json.loads(data)['cases']:
        raw = entry['audit']['upper_bound_certificate']
        n = raw['start']['n']
        seed = entry['audit']['seed']
        record, audit = make_exact_root('stage38_one_excess', seed, n, 'train')
        assert list(record.state.packed_rows) == raw['start']['packed_rows']
        assert decode_record(json.dumps(asdict(record))) == record
        batch = own_records_to_cuda((record,))
        torch.cuda.synchronize()
        assert batch.exact_distances == (n+1,)
        negatives = 0
        for bad in (replace(record, exact_distance=n),
                    replace(record, exact_evidence='wrong'),
                    replace(record, verified_words=(replace(record.verified_words[0],
                        gates=record.verified_words[0].gates[:-1]),))):
            try:
                own_records_to_cuda((bad,))
            except ValueError:
                negatives += 1
            else:
                raise AssertionError('corrupted bracket admitted')
        cases.append({'n': n, 'seed': seed, 'record': asdict(record), 'audit': audit,
                      'same_native_matrix': True, 'full_cuda_replay': True,
                      'negative_rejections': negatives,
                      'original_contraction_status': entry['status']})
        print(json.dumps({'n': n, 'exact_distance': n+1, 'full_cuda_replay': True,
                          'negative_rejections': negatives}), flush=True)
    report = {'schema': 'own_native_bracket_admission_v1', 'accepted': True,
              'cases': cases, 'production_training_launched': False,
              'scope': 'own seeded diagnostic matrices; not BB benchmark targets',
              'amplitude_count': 'not_computed'}
    with args.report.open('x') as out:
        out.write(json.dumps(report, indent=2)+'\n')


if __name__ == '__main__':
    main()
