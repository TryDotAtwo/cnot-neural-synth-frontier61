"""Molab CUDA compact closure equivalence on all14 own diagnostic widths.

This is index correctness, not training or benchmark synthesis quality.
"""
import argparse
from dataclasses import asdict
import json
from pathlib import Path
from time import perf_counter
import torch
from ..contracts import AlphabetSpec,MatrixState
from ..data.stream_reader_v13 import decode_record
from ..data.stream_solver_dataset_v13 import SIZES,data_source_hashes
from ..gpu.compact_onehop_bank import CompactOneHopBank
from ..gpu.holdout import GpuExactHoldout


def packed(states):
    n=states[0].n
    mask=(1<<64)-1
    def signed(word):return word-(1<<64) if word&(1<<63) else word
    return torch.tensor([[[signed((row>>(64*slot))&mask)
                          for slot in range((n+63)//64)] for row in state.packed_rows]
                        for state in states],device='cuda',dtype=torch.int64)


def audit_width(record):
    n=record.state.n
    roots=packed((record.state,MatrixState.identity(AlphabetSpec.all_to_all(n))))
    entries=2*(1+n*(n-1))
    torch.cuda.reset_peak_memory_stats()
    started=perf_counter()
    compact=CompactOneHopBank.from_roots(roots,action_chunk=256,max_entries=entries)
    torch.cuda.synchronize()
    compact_seconds=perf_counter()-started
    compact_peak=torch.cuda.max_memory_allocated()
    expanded=GpuExactHoldout.from_frozen_roots(roots,neighbor_chunk=256,max_entries=entries)
    checked=0
    for start in range(0,entries,512):
        queries=expanded.sorted_rows[start:start+512]
        if not bool(compact.matches(queries,query_chunk=128,candidate_chunk=16).all()):
            raise AssertionError('full closure member missed by compact index')
        checked+=len(queries)
    # Queries outside the indexed closure are checked against the complete
    # expanded reference. Never infer a negative result just from its hash.
    generator=torch.Generator(device='cuda').manual_seed(601+n)
    queries=roots.repeat(64,1,1)
    for _ in range(6):
        control=torch.randint(n,(len(queries),),device='cuda',generator=generator)
        target=torch.randint(n-1,(len(queries),),device='cuda',generator=generator)
        target+= (target>=control).to(torch.int64)
        ids=torch.arange(len(queries),device='cuda')
        queries[ids,target]^=queries[ids,control]
    expected=expanded.matches(queries)
    if not torch.equal(compact.matches(queries),expected):
        raise AssertionError('compact membership differs from full-matrix oracle')
    # Signed overflow fingerprints must also agree after descriptor replay.
    for start in range(0,entries,512):
        matrices=compact.reconstruct(compact.sorted_codes[start:start+512])
        actual=(matrices*compact.hash_weights[None]).flatten(1).sum(1)
        if not torch.equal(actual,compact.sorted_hashes[start:start+512]):
            raise AssertionError('descriptor fingerprint drift')
    torch.cuda.synchronize()
    result={'n':n,'entries':entries,'full_members_checked':checked,
            'mixed_queries_checked':len(queries),'negative_queries':int((~expected).sum()),
            'compact_build_seconds':compact_seconds,'compact_build_peak_allocated_bytes':compact_peak,
            'compact_index_bytes':sum(t.numel()*t.element_size() for _,t in compact.contract_tensors()),
            'expanded_rows_bytes':expanded.sorted_rows.numel()*expanded.sorted_rows.element_size(),
            'end_to_end_seconds':perf_counter()-started,'accepted':True}
    del compact,expanded,roots,queries
    torch.cuda.empty_cache()
    return result


def main():
    if not Path('/marimo').is_dir() or not torch.cuda.is_available():
        raise SystemExit('Molab CUDA required')
    parser=argparse.ArgumentParser();parser.add_argument('--report',type=Path,required=True)
    args=parser.parse_args()
    baseline=json.loads(Path('/marimo/frontier61_recovery_v16/joint_source_panel_native.json').read_text())
    if baseline['stage']!='completed' or not baseline['all_admitted'] or baseline['source_sha256']!=data_source_hashes():
        raise ValueError('verified complete v16 own source panel required')
    cases=[]
    for n in SIZES:
        entry=next(c for c in baseline['cases'] if c['n']==n and c['kind']=='stage38_one_excess')
        record=decode_record(json.dumps(entry['record']))
        case=audit_width(record);cases.append(case)
        print(json.dumps(case),flush=True)
    # Deliberate fingerprint collisions on all GL3 queries on real CUDA.
    from ..data.exact_small import build_exact_small
    alphabet=AlphabetSpec.all_to_all(3)
    states=tuple(build_exact_small(3,alphabet).distances)
    roots=packed((MatrixState.identity(alphabet),))
    collision=CompactOneHopBank.from_roots(roots,action_chunk=2,max_entries=7,
        hash_weights=torch.zeros((3,1),device='cuda',dtype=torch.int64))
    oracle=GpuExactHoldout.from_matrices(collision.reconstruct(torch.arange(7,device='cuda')),
        hash_weights=torch.zeros((3,1),device='cuda',dtype=torch.int64))
    queries=packed(states)
    assert torch.equal(collision.matches(queries,candidate_chunk=2,query_chunk=17),oracle.matches(queries))
    report={'schema':'own_native_compact_onehop_equivalence_v1','accepted':True,'cases':cases,
            'all_gl3_forced_collision_queries':168,'device':torch.cuda.get_device_name(),
            'torch':torch.__version__,'production_training_launched':False,
            'scope':'two roots per width, complete all-to-all onehop, not full frozen1792 panel'}
    with args.report.open('x') as out:out.write(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'accepted':True,'widths':len(cases),'collision_queries':168}),flush=True)


if __name__=='__main__':main()
