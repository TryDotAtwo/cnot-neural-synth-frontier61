"""Native replay of retained UB words on the three unchanged v12 limit roots."""
import argparse,hashlib,json,os
from dataclasses import asdict
from pathlib import Path
from time import perf_counter
from ..data.stage38_one_excess_exact_v1 import generate
from ..data.guarded_family_dispatch_v1 import GuardedGenerationLimit
from ..contracts import AlphabetSpec,MatrixState,Gate,WordCertificate
from ..words import verify_word
from ..data.stream_solver_dataset_v13 import data_source_hashes

def main():
    if not Path('/marimo').is_dir():raise SystemExit('Molab native execution required')
    parser=argparse.ArgumentParser()
    parser.add_argument('--baseline-report',type=Path,required=True)
    parser.add_argument('--report',type=Path,required=True)
    args=parser.parse_args()
    if args.report.exists():raise FileExistsError(args.report)
    baseline=json.loads(args.baseline_report.read_text())
    cases=[c for c in baseline['cases'] if c['status']=='resource_limit']
    if [(c['kind'],c['n'],c['seed']) for c in cases]!=[('stage38_one_excess',n,1510038+n) for n in (108,122,144)]:
        raise ValueError('three unchanged native limit roots required')
    report={'schema':'own_native_resource_word_replay_v1','scope':'generated UB only; exact contraction remains limited; no root admission',
            'baseline_sha256':hashlib.sha256(args.baseline_report.read_bytes()).hexdigest(),
            'source_sha256':data_source_hashes(),'cases':[],'stage':'running','production_training_launched':False}
    def publish():
        tmp=args.report.with_suffix('.tmp');tmp.write_text(json.dumps(report,indent=2)+'\n');os.replace(tmp,args.report)
    publish()
    for case in cases:
        started=perf_counter();n=case['n'];seed=case['seed']
        result=generate(seed,n,split='dev')
        if result.status!='resource_limit' or result.distance is not None:raise ValueError('changed limit admission status')
        if json.loads(json.dumps(asdict(result.state)))!=case['audit']['state']:raise ValueError('matrix drift')
        verify_word(result.word,AlphabetSpec.all_to_all(n))
        audit=json.loads(json.dumps(GuardedGenerationLimit(case['kind'],result,seed,'dev').audit))
        raw=audit['upper_bound_certificate']
        def matrix(value):return MatrixState(value['n'],tuple(value['packed_rows']),value['alphabet_id'])
        word=WordCertificate(matrix(raw['start']),matrix(raw['end']),tuple(Gate(**g) for g in raw['gates']),raw['physical_cost'],raw['producer'],raw['lineage_id'])
        verify_word(word,AlphabetSpec.all_to_all(n))
        if word!=result.word or audit['exact_distance'] is not None or audit['fallback_used']:raise ValueError('serialized UB audit drift')
        entry={'n':n,'seed':seed,'upper_bound':word.physical_cost,'status':'resource_limit',
               'matrix_matches_baseline':True,'serialized_word_verified':True,'audit':audit,'seconds':perf_counter()-started}
        report['cases'].append(entry);publish()
        print(json.dumps({k:v for k,v in entry.items() if k!='audit'}),flush=True)
    report['stage']='completed';report['accepted']=True;publish()
    print(json.dumps({'report':str(args.report),'accepted':True,'tests':3}),flush=True)

if __name__=='__main__':main()
