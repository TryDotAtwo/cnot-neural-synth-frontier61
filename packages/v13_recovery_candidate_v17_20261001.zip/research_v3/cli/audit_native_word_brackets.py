"""Certify identical saved native UB words independently; retain count limits."""
import argparse,hashlib,json
from pathlib import Path
from ..contracts import AlphabetSpec,MatrixState,Gate,WordCertificate
from ..data.one_excess_word_bracket_v1 import certify,verify

def main():
    if not Path('/marimo').is_dir():raise SystemExit('Molab native execution required')
    parser=argparse.ArgumentParser();parser.add_argument('--report',type=Path,required=True)
    args=parser.parse_args()
    baseline=Path('/marimo/frontier61_recovery_v14/resource_words_native.json');data=baseline.read_bytes()
    if hashlib.sha256(data).hexdigest()!='1fabac0224301ee346f2bd83b2b2f21aeb8378e4b60b956ba0c9ec3a979b32e0':raise ValueError('native UB source drift')
    inputs=json.loads(data);cases=[]
    for entry in inputs['cases']:
        raw=entry['audit']['upper_bound_certificate']
        def matrix(v):return MatrixState(v['n'],tuple(v['packed_rows']),v['alphabet_id'])
        word=WordCertificate(matrix(raw['start']),matrix(raw['end']),tuple(Gate(**g) for g in raw['gates']),raw['physical_cost'],raw['producer'],raw['lineage_id'])
        certificate=certify(word,AlphabetSpec.all_to_all(word.start.n));verify(certificate,word,AlphabetSpec.all_to_all(word.start.n))
        cases.append({'n':word.start.n,'certificate':certificate,'contraction_status':entry['status'],'full_word':raw})
        print(json.dumps({'n':word.start.n,'exact_distance':certificate['exact_distance'],'missing_control_targets':len(certificate['missing_control_targets']),'contraction_status':entry['status']}),flush=True)
    report={'schema':'own_native_one_excess_word_brackets_v1','accepted':True,'source_UB_sha256':hashlib.sha256(data).hexdigest(),'cases':cases,'scope':'same own source-diagnostic matrices, not historical BB codes; independent LB+UB certificate, no amplitude count','production_training_launched':False,'dataset_admission_changed':False}
    with args.report.open('x') as out:out.write(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'report':str(args.report),'accepted':True,'cases':len(cases)}),flush=True)

if __name__=='__main__':main()
