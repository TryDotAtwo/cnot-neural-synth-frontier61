"""Independent stage37 necessity + full UB word bracket. Not amplitude counting.

Dataset admission is decided separately by the source-gated reader.
L>=r because each changed row must be targeted. At L=r every such row is
updated once, so every control equals an initial or final row. A missing
required delta excludes L=r. A verified r+1 word then proves d=r+1 globally
for the full unit all-to-all alphabet. Dense contraction limits remain limits.
"""
from dataclasses import asdict
import hashlib,json
from pathlib import Path
from ..contracts import AlphabetSpec,MatrixState
from ..words import verify_word
from .stage37_zero_excess_exact_v1 import SOURCE_NOTES_SHA256

PRIMARY='artifacts/frontier61_source_v1/cnot_research_journal/stage37_general_graded_kernel/37_exact_zero_excess_propagator_ru.md'

def certify(word,alphabet):
    if alphabet!=AlphabetSpec.all_to_all(word.start.n):raise ValueError('full unit all-to-all alphabet required')
    if word.end!=MatrixState.identity(alphabet):raise ValueError('full identity endpoint required')
    path=Path(__file__).resolve().parents[1]/PRIMARY
    if hashlib.sha256(path.read_bytes()).hexdigest()!=SOURCE_NOTES_SHA256:raise ValueError('stage37 primary source drift')
    verify_word(word,alphabet)
    a=word.start.packed_rows;b=word.end.packed_rows
    changed=tuple(i for i in range(len(a)) if a[i]!=b[i]);r=len(changed)
    if word.physical_cost!=r+1:raise ValueError('verified r+1 word required; generator length alone is not distance')
    missing=tuple(i for i in changed if all(a[i]^b[i] not in (a[j],b[j]) for j in range(len(a)) if j!=i))
    if not missing:raise ValueError('saturated length not independently excluded')
    payload=json.dumps(asdict(word),sort_keys=True,separators=(',',':')).encode()
    return {'schema':'own_one_excess_word_bracket_v1','scope_id':alphabet.id,
            'state_key':word.start.key,'changed_rows':changed,'excluded_length':r,
            'missing_control_targets':missing,'missing_deltas':tuple(a[i]^b[i] for i in missing),
            'lower_bound':r+1,'upper_bound':word.physical_cost,'exact_distance':r+1,
            'word_sha256':hashlib.sha256(payload).hexdigest(),'primary_theorem_sha256':SOURCE_NOTES_SHA256,
            'proof':'changed_row_LB_plus_missing_control_exclusion_plus_verified_full_word',
            'amplitude_count':'not_computed'}

def verify(certificate,word,alphabet):
    if certificate!=certify(word,alphabet):raise ValueError('one-excess bracket certificate drift')
    return True
