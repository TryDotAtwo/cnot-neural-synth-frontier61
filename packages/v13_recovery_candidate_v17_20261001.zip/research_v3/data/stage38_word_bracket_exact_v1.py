"""Own seeded one-excess targets, certified by stage37 necessity and full word.

The original stage38 amplitude contraction remains a separate adapter.
This route computes distance, not amplitude counts.
"""
import random
from .stage23_forest_exact_v1 import ForestResult
from .stage37_zero_excess_exact_v1 import SOURCE_NOTES_SHA256
from .one_excess_word_bracket_v1 import certify, verify
from ..contracts import AlphabetSpec, MatrixState, Gate, WordCertificate


def generate(seed, n, *, split, max_attempts=1000):
    if type(seed) is not int or type(n) is not int or n < 2 or split not in ('train','dev','test'):
        raise ValueError('invalid one-excess generator input')
    if type(max_attempts) is not int or max_attempts < 1:
        raise ValueError('explicit positive candidate budget required')
    rng = random.Random(seed)
    alphabet = AlphabetSpec.all_to_all(n)
    state = MatrixState.identity(alphabet)
    for attempt in range(max_attempts):
        rows = [1 << i for i in range(n)]
        targets = list(range(n)) + [rng.randrange(n)]
        rng.shuffle(targets)
        forward = []
        for target in targets:
            control = rng.randrange(n-1)
            if control >= target:
                control += 1
            rows[target] ^= rows[control]
            forward.append(Gate(control, target))
        if sum(row != 1 << i for i, row in enumerate(rows)) != n:
            continue
        state = MatrixState(n, tuple(rows), alphabet.id)
        word = WordCertificate(state, MatrixState.identity(alphabet), tuple(reversed(forward)),
            n+1, 'stage38_word_bracket_exact_v1', f'stage38-generated:{seed}:{n}:{attempt}')
        # The necessary delta test excludes saturated length without counting paths.
        if not any(all(rows[i] ^ (1 << i) not in (rows[j], 1 << j)
                       for j in range(n) if j != i) for i in range(n)):
            continue
        certificate = certify(word, alphabet)
        return ForestResult('exact', state, alphabet.id, n+1, word,
            {'full_unit_all_to_all': True, 'source_notes_sha256': SOURCE_NOTES_SHA256,
             'amplitude_count': 'not_computed'},
            {'generator_attempt': attempt, 'word_bracket': certificate})
    return ForestResult('resource_limit', state, alphabet.id, None, None,
        {'generator_max_attempts': max_attempts}, {},
        'one-excess candidate budget exhausted; no infeasibility claim')


def verify_result(result, alphabet):
    if result.status != 'exact' or result.word is None:
        return False
    if result.state != result.word.start or result.scope_id != alphabet.id:
        raise ValueError('bracket state/scope mismatch')
    certificate = result.witness['word_bracket']
    verify(certificate, result.word, alphabet)
    if result.distance != certificate['exact_distance']:
        raise ValueError('bracket distance mismatch')
    if result.hypotheses != {'full_unit_all_to_all': True,
                            'source_notes_sha256': SOURCE_NOTES_SHA256,
                            'amplitude_count': 'not_computed'}:
        raise ValueError('bracket hypotheses drift')
    return True
