import tempfile
from pathlib import Path
from types import SimpleNamespace
import unittest
import torch
from research_v3.contracts import AlphabetSpec
from research_v3.data.model_exposure_journal_v1 import ModelExposureJournal
from research_v3.gpu.compact_onehop_bank import CompactOneHopBank


class CompactExposureBankTests(unittest.TestCase):
    def test_refresh_contract_binds_each_compact_index_tensor(self):
        from research_v3.train.neural_refresh_solver_v13 import NeuralRefreshSolver
        from research_v3.train.component_contract_v13 import component_contract
        import hashlib,inspect
        source=str(Path(inspect.getsourcefile(NeuralRefreshSolver)).resolve())
        sources={source:hashlib.sha256(Path(source).read_bytes()).hexdigest()}
        bank=CompactOneHopBank.from_roots(torch.tensor([[[1],[2],[4]]],dtype=torch.int64),
                                         action_chunk=2,max_entries=7)
        solver=NeuralRefreshSolver(torch.nn.Linear(1,1),
            search_config=dict(beam_width=1,shortlist=1,max_depth=1,inference_batch=1,max_expanded=1),
            field_config=dict(mc_samples=1,mc_seed=1,max_pair_states=1,head='qhat'),
            source_sha256=sources,holdout_banks={3:bank})
        before=component_contract(solver,sources)
        for _,tensor in bank.contract_tensors():
            saved=tensor.clone()
            tensor.reshape(-1)[0]^=1
            self.assertNotEqual(component_contract(solver,sources),before)
            tensor.copy_(saved)
            self.assertEqual(component_contract(solver,sources),before)

    def test_duplicate_closure_set_equality_and_snapshot_after_audit(self):
        roots=torch.tensor([[[1],[2],[4]],[[1],[3],[4]]],dtype=torch.int64)
        bank=CompactOneHopBank.from_roots(roots,action_chunk=2,max_entries=14)
        matrices=bank.reconstruct(torch.arange(14,dtype=torch.int64))
        alphabet=AlphabetSpec.all_to_all(3)
        keys={(3,alphabet.id,tuple(int(v) for v in m[:,0])) for m in matrices}
        self.assertLess(len(keys),14)
        with tempfile.TemporaryDirectory() as directory:
            journal=ModelExposureJournal(Path(directory)/'exposures.sqlite',forbidden_keys=keys)
            try:
                before=journal.state_dict()
                journal.verify_packed_banks({3:bank},chunk_size=2)
                self.assertEqual(journal.state_dict(),before)
                self.assertFalse(journal.connection.in_transaction)
                journal.verify_packed_banks({3:SimpleNamespace(sorted_rows=matrices)},chunk_size=3)
                self.assertEqual(journal.state_dict(),before)
                receipt=journal.snapshot(Path(directory)/'snapshot.sqlite')
                self.assertEqual(receipt['state'],before)
                self.assertEqual(receipt['split_audit']['set_counts']['forbidden'],len(keys))
                wrong=SimpleNamespace(sorted_rows=matrices[:1])
                with self.assertRaises(ValueError):journal.verify_packed_banks({3:wrong},chunk_size=1)
                self.assertFalse(journal.connection.in_transaction)
                journal.verify_packed_banks({3:bank},chunk_size=1)
            finally:journal.close()


if __name__=='__main__':unittest.main()
