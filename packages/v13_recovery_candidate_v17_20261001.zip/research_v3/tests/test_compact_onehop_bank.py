import unittest
import torch
from research_v3.contracts import AlphabetSpec,MatrixState
from research_v3.data.exact_small import build_exact_small
from research_v3.words import apply
from research_v3.gpu.compact_onehop_bank import CompactOneHopBank


class CompactOneHopTests(unittest.TestCase):
    def test_all_gl3_queries_full_descriptors_and_deliberate_hash_collisions(self):
        alphabet=AlphabetSpec.all_to_all(3)
        states=tuple(build_exact_small(3,alphabet).distances)
        roots=(MatrixState.identity(alphabet),states[16],states[69])
        tensor=torch.tensor([[list((row,)) for row in root.packed_rows] for root in roots],dtype=torch.int64)
        queries=torch.tensor([[list((row,)) for row in state.packed_rows] for state in states],dtype=torch.int64)
        expected={root.key for root in roots}
        expected.update(apply(root,gate,alphabet).key for root in roots for gate in alphabet.allowed)
        for weights in (None,torch.zeros((3,1),dtype=torch.int64)):
            bank=CompactOneHopBank.from_roots(tensor,action_chunk=2,max_entries=21,hash_weights=weights)
            answers=bank.matches(queries,candidate_chunk=2,query_chunk=17).tolist()
            self.assertEqual(answers,[state.key in expected for state in states])
            recovered=bank.reconstruct(torch.arange(21,dtype=torch.int64))
            actual={tuple(int(x) for x in m[:,0]) for m in recovered}
            self.assertEqual(actual,{key[2] for key in expected})
            fingerprints=(recovered*bank.hash_weights[None]).flatten(1).sum(1)
            ordered=bank.reconstruct(bank.sorted_codes)
            self.assertTrue(torch.equal((ordered*bank.hash_weights[None]).flatten(1).sum(1),bank.sorted_hashes))
            self.assertEqual(bank.matches(queries.reshape(2,84,3,1)).shape,(2,84))

    def test_caps_and_input_ownership(self):
        root=torch.tensor([[[1],[2],[4]]],dtype=torch.int64)
        with self.assertRaises(MemoryError):
            CompactOneHopBank.from_roots(root,action_chunk=2,max_entries=6)
        weights=torch.ones((3,1),dtype=torch.int64)
        bank=CompactOneHopBank.from_roots(root,action_chunk=2,max_entries=7,hash_weights=weights)
        root.zero_();weights.zero_()
        self.assertTrue(bank.matches(torch.tensor([[[1],[2],[4]]],dtype=torch.int64)).item())
        self.assertEqual(bank.sorted_codes.numel(),7)
        with self.assertRaises(ValueError):bank.reconstruct(torch.tensor([7]))
        with self.assertRaises(ValueError):bank.matches(bank.roots,candidate_chunk=0)


if __name__=='__main__':unittest.main()
