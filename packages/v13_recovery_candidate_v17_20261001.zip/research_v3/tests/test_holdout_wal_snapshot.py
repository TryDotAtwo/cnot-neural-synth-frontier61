import hashlib,sqlite3,tempfile,unittest
from pathlib import Path
from research_v3.gpu.frozen_bank_v13 import open_readonly_holdout_snapshot

class HoldoutWalSnapshotTests(unittest.TestCase):
    def test_committed_wal_visible_and_read_transaction_consistent(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'sealed.sqlite'
            writer=sqlite3.connect(path)
            reader=None
            try:
                writer.execute('PRAGMA journal_mode=WAL')
                writer.execute('CREATE TABLE roots(id INTEGER PRIMARY KEY)')
                writer.commit();writer.execute('PRAGMA wal_checkpoint(TRUNCATE)')
                writer.execute('INSERT INTO roots VALUES(1)');writer.commit()
                wal=Path(str(path)+'-wal')
                before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (path,wal)}
                old=sqlite3.connect(path.as_uri()+'?immutable=1',uri=True)
                try:self.assertEqual(old.execute('SELECT COUNT(*) FROM roots').fetchone()[0],0)
                finally:old.close()
                reader=open_readonly_holdout_snapshot(path)
                self.assertEqual(reader.execute('SELECT COUNT(*) FROM roots').fetchone()[0],1)
                with self.assertRaises(sqlite3.OperationalError):reader.execute('INSERT INTO roots VALUES(3)')
                self.assertEqual({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (path,wal)},before)
                writer.execute('INSERT INTO roots VALUES(2)');writer.commit()
                self.assertEqual(reader.execute('SELECT COUNT(*) FROM roots').fetchone()[0],1)
                reader.close();reader=open_readonly_holdout_snapshot(path)
                self.assertEqual(reader.execute('SELECT COUNT(*) FROM roots').fetchone()[0],2)
            finally:
                if reader is not None:reader.close()
                writer.close()

if __name__=='__main__':unittest.main()
