import unittest
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch
from research_v3.data.one_excess_word_bracket_v1 import certify,verify
from research_v3.data.exact_small import build_exact_small
from research_v3.contracts import AlphabetSpec

class WordBracketTests(unittest.TestCase):
    def test_complete_gl3_exact_distances_and_rejection(self):
        alphabet=AlphabetSpec.all_to_all(3);catalog=build_exact_small(3,alphabet);accepted=0
        for state,distance in catalog.distances.items():
            word=catalog.certificate(state)
            try:certificate=certify(word,alphabet)
            except ValueError:continue
            self.assertEqual(certificate['exact_distance'],distance)
            self.assertTrue(verify(certificate,word,alphabet));accepted+=1
            with self.assertRaisesRegex(ValueError,'certificate drift'):
                verify(dict(certificate,exact_distance=distance+1),word,alphabet)
        self.assertEqual(accepted,75)
    def test_word_alphabet_and_source_guards(self):
        alphabet=AlphabetSpec.all_to_all(2);catalog=build_exact_small(2,alphabet)
        word=next(catalog.certificate(s) for s,d in catalog.distances.items() if d==3)
        with self.assertRaises(ValueError):certify(replace(word,gates=word.gates[:-1],physical_cost=2),alphabet)
        with self.assertRaises(ValueError):certify(word,AlphabetSpec(2,alphabet.allowed,(2,2),'weighted'))
        with patch.object(Path,'read_bytes',return_value=b'drift'):
            with self.assertRaisesRegex(ValueError,'primary source drift'):certify(word,alphabet)
    def test_limit_stays_limited_despite_separate_bracket(self):
        from research_v3.data.stage38_one_excess_exact_v1 import generate
        result=generate(1510046,8,split='dev',max_entries=1)
        certificate=certify(result.word,AlphabetSpec.all_to_all(8))
        self.assertEqual(certificate['exact_distance'],9)
        self.assertEqual(result.status,'resource_limit');self.assertIsNone(result.distance)
        self.assertEqual(certificate['amplitude_count'],'not_computed')

if __name__=='__main__':unittest.main()
