import hashlib
import json
from dataclasses import asdict
from pathlib import Path
import tempfile
import unittest
from research_v3.cli.audit_readonly_stream_v13 import audit
from research_v3.data.guarded_family_dispatch_v1 import make_exact_root
from research_v3.data.stream_solver_dataset_v13 import open_store,canonical


class ReadonlyAuditTests(unittest.TestCase):
    def test_committed_wal_full_word_snapshot_and_partial_not_complete(self):
        with tempfile.TemporaryDirectory() as temporary:
            path=Path(temporary)/'roots.sqlite'
            connection,_=open_store(path,seed_base=3700,expected_dev_roots=1792,expected_test_roots=1792)
            try:
                connection.execute('PRAGMA wal_autocheckpoint=0')
                record,producer=make_exact_root('stage38_one_excess',5,8,'dev')
                identity=canonical(record.state.key)
                raw=canonical(asdict(record)); pa=canonical(producer); offsets=canonical(())
                digest=hashlib.sha256(canonical((identity,raw,pa,offsets)).encode()).hexdigest()
                with connection:
                    connection.execute('INSERT INTO roots VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
                        (hashlib.sha256(identity.encode('ascii')).hexdigest(),identity,'dev',0,0,0,
                         'guarded_exact',8,5,raw,pa,offsets,digest))
                files=(path,Path(str(path)+'-wal'))
                before=[hashlib.sha256(p.read_bytes()).hexdigest() for p in files]
                result=audit(path)
                self.assertEqual(result['root_count'],1)
                self.assertEqual(result['certificates_replayed'],1)
                self.assertFalse(result['complete_sealed_holdout'])
                self.assertEqual(before,[hashlib.sha256(p.read_bytes()).hexdigest() for p in files])
                with self.assertRaises(ValueError):audit(path,require_complete=True)
                with connection:
                    row=connection.execute("SELECT value FROM metadata WHERE key='manifest'").fetchone()
                    manifest=json.loads(row[0]); manifest['dataset_source_sha256']={}
                    connection.execute("UPDATE metadata SET value=? WHERE key='manifest'",(canonical(manifest),))
                with self.assertRaisesRegex(ValueError,'source drift'):audit(path)
            finally:
                connection.close()


if __name__=='__main__':unittest.main()
