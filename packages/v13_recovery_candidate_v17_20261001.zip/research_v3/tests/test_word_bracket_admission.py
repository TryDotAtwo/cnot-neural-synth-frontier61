import json
import unittest
from dataclasses import asdict, replace
from research_v3.contracts import AlphabetSpec
from research_v3.data.guarded_family_dispatch_v1 import make_exact_root
from research_v3.data.stage38_one_excess_exact_v1 import generate as contraction_generate
from research_v3.data.stage38_word_bracket_exact_v1 import generate, verify_result
from research_v3.data.stream_reader_v13 import decode_record, validate_exact
from research_v3.gpu.record_batch_v13 import validate_own_dev_records


class BracketAdmissionTests(unittest.TestCase):
    def test_same_seed_targets_and_actual_reader_gpu_acceptance(self):
        for seed in range(12):
            with self.subTest(seed=seed):
                record, audit = make_exact_root('stage38_one_excess', seed, 8, 'dev')
                old = contraction_generate(seed, 8, split='dev', max_entries=1)
                self.assertEqual(record.state, old.state)
                self.assertEqual(decode_record(json.dumps(asdict(record))), record)
                validate_own_dev_records((record,))
                self.assertEqual(audit['hypotheses']['amplitude_count'], 'not_computed')
                self.assertFalse(audit['solver_called'])

    def test_corrupted_label_source_and_word_rejected(self):
        record, _ = make_exact_root('stage38_one_excess', 5, 8, 'dev')
        for bad in (replace(record, exact_distance=8),
                    replace(record, exact_distance=True),
                    replace(record, exact_evidence='wrong'),
                    replace(record, verified_words=(replace(record.verified_words[0],
                        gates=record.verified_words[0].gates[:-1]),))):
            with self.subTest(bad=bad.exact_evidence):
                with self.assertRaises(ValueError):
                    validate_own_dev_records((bad,))

    def test_adapter_rejects_changed_hypotheses_and_certificate(self):
        result = generate(5, 8, split='dev')
        alphabet = AlphabetSpec.all_to_all(8)
        for bad in (replace(result, hypotheses={}),
                    replace(result, distance=8),
                    replace(result, witness={'word_bracket': {}})):
            with self.assertRaises(ValueError):
                verify_result(bad, alphabet)


if __name__ == '__main__':
    unittest.main()
