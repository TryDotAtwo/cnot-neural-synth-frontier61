import unittest
from research_v3.contracts import AlphabetSpec, Gate, MatrixState
from research_v3.data.exact_small import build_exact_small
from research_v3.data.generators import record_from_word, generate
from research_v3.data.replay import Replay
from research_v3.data.splits import SplitPolicy, Exposures


class DataTests(unittest.TestCase):
    def test_nongeodesic_suffix_not_rank_label(self):
        from dataclasses import replace
        from research_v3.data.solver_programs import solution_suffix_at
        a = AlphabetSpec.all_to_all(2)
        parent = replace(record_from_word(a, (Gate(0, 1),) * 3,
                                          'own:nongeodesic', 17), split='train')
        suffix = solution_suffix_at(parent, 1)
        self.assertEqual(suffix.state, MatrixState.identity(a))
        self.assertEqual(suffix.upper_bound, 2)
        self.assertIsNone(suffix.exact_distance)
        self.assertIsNone(suffix.exact_evidence)
        self.assertEqual(suffix.seed, parent.seed)
        self.assertEqual(suffix.split, 'train')
        replay = Replay(a)
        replay.merge((suffix,))
        self.assertIsNone(replay.records[suffix.state.key].exact_distance)

    def test_macro_successor_overlap_excludes_whole_parent(self):
        a = AlphabetSpec.all_to_all(3)
        root = record_from_word(a, (), 'train:macro', 17)
        held = record_from_word(a, (Gate(0, 1), Gate(1, 2)), 'test:macro', 18)
        policy = SplitPolicy({held.state.key})
        self.assertEqual(policy.filter_full_backup((root,), a)[1]['rejected_parents'], 0)
        accepted, report = policy.filter_full_backup((root,), a,
                                                     macro_successors=lambda state: (held.state,))
        self.assertEqual(accepted, [])
        self.assertEqual(report, {'rejected_parents': 1, 'neighbors_removed': 0})

    def test_paid_basis_compiler_checks_full_operator_and_cost(self):
        from research_v3.data.paid_basis import compile_example
        a = AlphabetSpec.all_to_all(8)
        block = [[1] * 4 for _ in range(4)]
        record, audit = compile_example(a, block, (0, 1, 2, 3), (4, 5, 6, 7), seed=1)
        self.assertEqual(record.state.packed_rows, (1, 2, 4, 8, 31, 47, 79, 143))
        self.assertEqual(record.upper_bound, 2 * audit['preparation'] + audit['core'])
        self.assertGreater(audit['preparation'], 0)
        self.assertLess(record.upper_bound, 16)
        self.assertIsNone(record.exact_distance)

    def test_known_symmetry_overlap_is_excluded(self):
        from research_v3.data.splits import known_symmetry_keys
        a = AlphabetSpec.all_to_all(3)
        root = record_from_word(a, (Gate(0, 1), Gate(1, 2)), 'test:1', 1)
        keys = known_symmetry_keys((root.state,), a, permutations=((2, 1, 0),))
        from research_v3.symmetry import map_problem
        mapped = map_problem(root.state, a, 'transpose').state
        self.assertIn(mapped.key, keys)
        self.assertGreater(len(keys), 1)

    def test_exact_ingestion_checks_global_distance_certificate(self):
        a = AlphabetSpec.all_to_all(3)
        catalog = build_exact_small(3, a)
        replay = Replay(a)
        replay.ingest_exact(catalog)
        self.assertEqual(len(replay.records), 168)
        self.assertTrue(all(r.exact_distance == r.upper_bound for r in replay.records.values()))
        corrupted = build_exact_small(3, a)
        state = next(s for s, d in corrupted.distances.items() if d > 0)
        corrupted.distances[state] += 1
        with self.assertRaises(ValueError):
            Replay(a).ingest_exact(corrupted)

    def test_incomplete_catalog_cannot_be_ingested_as_exact(self):
        a = AlphabetSpec.all_to_all(3)
        with self.assertRaises(ValueError):
            Replay(a).ingest_exact(build_exact_small(3, a, max_states=5))

    def test_exact_catalog_counts_and_full_certificates(self):
        from research_v3.words import verify_word
        for n, count in ((2, 6), (3, 168), (4, 20160)):
            a = AlphabetSpec.all_to_all(n)
            catalog = build_exact_small(n, a)
            self.assertEqual(catalog.status, 'complete')
            self.assertEqual(len(catalog.distances), count)
            for state, distance in catalog.distances.items():
                cert = catalog.certificate(state)
                verify_word(cert, a)
                self.assertEqual(cert.physical_cost, distance)

    def test_resource_limit_is_not_infeasible(self):
        a = AlphabetSpec.all_to_all(3)
        catalog = build_exact_small(3, a, max_states=4)
        self.assertEqual(catalog.status, 'resource_limit')
        self.assertLessEqual(len(catalog.distances), 4)

    def test_walk_return_has_ub_not_exact(self):
        a = AlphabetSpec.all_to_all(2)
        record = record_from_word(a, (Gate(0, 1), Gate(0, 1)), 'walk:1', 1)
        self.assertEqual(record.state, MatrixState.identity(a))
        self.assertEqual(record.upper_bound, 2)
        self.assertIsNone(record.exact_distance)

    def test_same_state_minimum_verified_ub(self):
        a = AlphabetSpec.all_to_all(2)
        short = record_from_word(a, (Gate(0, 1),), 'walk:1', 1)
        long = record_from_word(a, (Gate(0, 1),) * 3, 'walk:2', 2)
        replay = Replay(a)
        replay.merge([long, short])
        self.assertEqual(replay.records[short.state.key].upper_bound, 1)
        self.assertEqual(replay.lineages[short.state.key], {'walk:1', 'walk:2'})

    def test_restricted_certificate_not_global(self):
        restricted = AlphabetSpec(2, (Gate(0, 1),), (1,), 'one_way')
        record = record_from_word(restricted, (Gate(0, 1),), 'restricted:1', 1)
        with self.assertRaisesRegex(ValueError, 'alphabet'):
            Replay(AlphabetSpec.all_to_all(2)).merge([record])

    def test_unsupported_family_not_exact(self):
        with self.assertRaises(NotImplementedError):
            generate('unverified_stage38', seed=1, n=3, count=1, steps=4)

    def test_neighbor_exposure_excludes_parent(self):
        a = AlphabetSpec.all_to_all(2)
        root = record_from_word(a, (), 'train:1', 1)
        held = record_from_word(a, (Gate(0, 1),), 'test:1', 2)
        policy = SplitPolicy({held.state.key})
        accepted, report = policy.filter_full_backup([root], a)
        self.assertEqual(accepted, [])
        self.assertEqual(report['rejected_parents'], 1)
        exposures = Exposures()
        exposures.observe('forward', held.state)
        audit = policy.audit([root], exposures)
        self.assertTrue(audit['label_held_out'])
        self.assertFalse(audit['strict_unseen'])


if __name__ == '__main__':
    unittest.main()
