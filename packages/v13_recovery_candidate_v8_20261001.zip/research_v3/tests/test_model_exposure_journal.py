import tempfile,unittest
from pathlib import Path
from unittest.mock import patch
import torch
from research_v3.contracts import AlphabetSpec,MatrixState,MatrixBatch
from research_v3.features.registry import FeatureRegistry,FeaturePolicy
from research_v3.model.field import FusionDistanceField
from research_v3.data.model_exposure_journal_v1 import ModelExposureJournal,batch_keys

class ModelExposureJournalTests(unittest.TestCase):
    def setUp(self):
        threads=torch.get_num_threads();torch.set_num_threads(1)
        self.addCleanup(torch.set_num_threads,threads)
        self.alphabet=AlphabetSpec.all_to_all(3)
        self.state=MatrixState(3,(1,3,7),self.alphabet.id)
        self.registry=FeatureRegistry();self.policy=FeaturePolicy(('A01','B01'))
        self.model=FusionDistanceField([self.registry.specs[k] for k in self.policy.enabled_ids],d=8,pair_d=4,blocks=1,heads=2,ffn=16,fusion_blocks=1).double()
        self.batch=MatrixBatch.from_states((self.state,))
        self.packet=self.registry.build((self.state,),self.policy)
    def test_actual_full_field_forward_backward_and_durable_restore(self):
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'exposures.sqlite'
            journal=ModelExposureJournal(path)
            with journal.attach_stem(self.model.stem):
                output=self.model(self.batch,self.packet)
                self.assertEqual(journal.keys('forward'),{self.state.key})
                self.assertFalse(journal.keys('gradient'))
                output.value.sum().backward()
                self.assertEqual(journal.keys('gradient'),{self.state.key})
                self.assertGreater(sum(float(p.grad.abs().sum()) for p in self.model.parameters() if p.grad is not None),0)
            saved=journal.state_dict();journal.close()
            restored=ModelExposureJournal(path)
            try:restored.load_state_dict(saved)
            finally:restored.close()
    def test_forbidden_batch_rejected_before_stem_computation(self):
        with tempfile.TemporaryDirectory() as directory:
            journal=ModelExposureJournal(Path(directory)/'exposures.sqlite',forbidden_keys=(self.state.key,))
            try:
                with journal.attach_stem(self.model.stem),patch.object(self.model.stem,'forward',wraps=self.model.stem.forward) as forward:
                    with self.assertRaisesRegex(ValueError,'forbidden full matrix'):
                        self.model(self.batch,self.packet)
                    forward.assert_not_called()
                self.assertEqual(journal.state_dict()['events'],0)
            finally:journal.close()
    def test_actual_packed_bank_and_seal_are_pinned_to_journal(self):
        from types import SimpleNamespace
        from research_v3.train.component_contract_v13 import component_contract
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'exposures.sqlite'
            journal=ModelExposureJournal(path,forbidden_keys=(self.state.key,),holdout_seal_sha256='a'*64)
            try:
                bank=SimpleNamespace(sorted_rows=torch.tensor(self.state.packed_rows,dtype=torch.int64).reshape(1,3,1))
                journal.verify_packed_banks({3:bank})
                raw=journal.immutable_contract()
                accepted=component_contract(journal,raw['source_sha256'])
                self.assertEqual(accepted['config']['holdout_seal_sha256'],'a'*64)
                wrong=SimpleNamespace(sorted_rows=torch.tensor([1,2,4],dtype=torch.int64).reshape(1,3,1))
                with self.assertRaisesRegex(ValueError,'packed holdout bank'):
                    journal.verify_packed_banks({3:wrong})
            finally:journal.close()
            with self.assertRaisesRegex(ValueError,'holdout seal changed'):
                ModelExposureJournal(path,forbidden_keys=(self.state.key,),holdout_seal_sha256='b'*64)

    def test_materialized_set_tamper_cannot_restore_checkpoint(self):
        with tempfile.TemporaryDirectory() as directory:
            journal=ModelExposureJournal(Path(directory)/'exposures.sqlite')
            try:
                journal.observe('forward',(self.state.key,))
                saved=journal.state_dict()
                journal.connection.execute('DELETE FROM observed');journal.connection.commit()
                with self.assertRaisesRegex(ValueError,'materialized sets'):
                    journal.load_state_dict(saved)
            finally:journal.close()

    def test_full_key_beyond_64_bits_and_empty_bank_identity(self):
        alphabet=AlphabetSpec.all_to_all(65)
        first=MatrixState.identity(alphabet)
        rows=list(first.packed_rows);rows[0]^=1<<64
        second=MatrixState(65,tuple(rows),alphabet.id)
        keys=batch_keys(MatrixBatch.from_states((first,second)))
        self.assertEqual(keys,(first.key,second.key))
        with tempfile.TemporaryDirectory() as directory:
            path=Path(directory)/'exposures.sqlite';journal=ModelExposureJournal(path)
            journal.observe('label',keys)
            self.assertEqual(journal.keys('label'),set(keys))
            saved=journal.state_dict()
            journal.connection.execute("UPDATE events SET kind='forward'")
            journal.connection.commit()
            with self.assertRaisesRegex(ValueError,'content drift'):journal.load_state_dict(saved)
            journal.close()
            with self.assertRaisesRegex(ValueError,'forbidden bank changed'):
                ModelExposureJournal(path,forbidden_keys=(first.key,))

if __name__=='__main__':unittest.main()
