"""Native CUDA integration gate. Skips on CPU are not acceptance."""
import tempfile,unittest
from pathlib import Path
import torch
from research_v3.contracts import AlphabetSpec,MatrixState
from research_v3.features.registry import FeatureRegistry
from research_v3.model.field import FusionDistanceField
from research_v3.gpu.field_slice import gpu_field_value
from research_v3.data.model_exposure_journal_v1 import ModelExposureJournal

@unittest.skipUnless(torch.cuda.is_available(),'native CUDA session required')
class MolabModelExposureTests(unittest.TestCase):
    def test_actual_cuda_field_forward_backward_is_durable_and_separate(self):
        registry=FeatureRegistry()
        model=FusionDistanceField([registry.specs[k] for k in ('A01','B01')],d=8,pair_d=4,blocks=1,heads=2,ffn=16,fusion_blocks=1).cuda()
        alphabet=AlphabetSpec.all_to_all(3)
        state=MatrixState(3,(1,3,7),alphabet.id)
        rows=torch.tensor(state.packed_rows,device='cuda',dtype=torch.int64).reshape(1,3,1)
        with tempfile.TemporaryDirectory() as directory:
            journal=ModelExposureJournal(Path(directory)/'exposures.sqlite')
            try:
                with journal.attach_stem(model.stem):
                    value=gpu_field_value(model,rows,mc_samples=0)
                    self.assertEqual(journal.keys('forward'),{state.key})
                    self.assertFalse(journal.keys('gradient'))
                    value.sum().backward();torch.cuda.synchronize()
                    self.assertEqual(journal.keys('gradient'),{state.key})
                    self.assertGreater(sum(float(p.grad.abs().sum()) for p in model.parameters() if p.grad is not None),0)
                journal.load_state_dict(journal.state_dict())
            finally:journal.close()

if __name__=='__main__':unittest.main()
