"""Own source-gated exact-family dispatch; no fallback on oracle limits."""
from dataclasses import asdict
from importlib import import_module
from ..contracts import AlphabetSpec
from .records import SampleRecord

# Order is frozen in the dataset manifest. Each block keeps the same width
# schedule; only the exact-family stratum rotates, leaving its quarter intact.
FAMILY_SPECS = (
    ('stage18_bipartite', 'stage18_bipartite_exact_v1', 'stage18_bipartite_exact_v1', 'acuaviva_2608.03825v1_notes_sha256:', 'SOURCE_NOTES_SHA256'),
    ('stage35_pair', 'stage35_pair_exact_v1', 'stage35_pair_exact_v1', 'stage35_pair_theorem_sha256:', 'SOURCE_SHA256'),
    ('stage37_zero_excess', 'stage37_zero_excess_generator_v1', 'stage37_zero_excess_exact_v1', 'stage37_zero_excess_theorem_sha256:', 'SOURCE_NOTES_SHA256'),
    ('stage23_forest', 'stage23_forest_exact_v1', 'stage23_forest_exact_v1', 'stage23_forest_theorem_sha256:', 'SOURCE_NOTES_SHA256'),
    ('stage24_moving_root', 'stage24_moving_root_exact_v1', 'stage24_moving_root_exact_v1', 'stage24_moving_root_theorem_sha256:', 'SOURCE_NOTES_SHA256'),
    ('stage25_swap_forest', 'stage25_swap_forest_exact_v1', 'stage25_swap_forest_exact_v1', 'stage25_swap_forest_theorem_sha256:', 'SOURCE_NOTES_SHA256'),
    ('stage36_saturated_frame', 'stage36_saturated_frame_exact_v1', 'stage36_saturated_frame_exact_v1', 'stage36_saturated_frame_theorem_sha256:', 'SOURCE_NOTES_SHA256'),
    ('stage38_one_excess', 'stage38_one_excess_exact_v1', 'stage38_one_excess_exact_v1', 'stage38_one_excess_theorem_sha256:', 'SOURCE_NOTES_SHA256'),
)
EXACT_FAMILIES = tuple(spec[0] for spec in FAMILY_SPECS)

class GuardedGenerationLimit(RuntimeError):
    """Explicit non-exact generation outcome, never an infeasibility claim."""
    def __init__(self,kind,result,seed,split):
        self.audit={'family':'guarded_exact','exact_kind':kind,'status':result.status,
                    'seed':seed,'split':split,'hypotheses':result.hypotheses,
                    'witness':result.witness,'reason':result.reason,
                    'exact_distance':None,'fallback_used':False,
                    'state':asdict(result.state) if getattr(result,'state',None) is not None else None,
                    'upper_bound_certificate':asdict(result.word) if getattr(result,'word',None) is not None else None}
        super().__init__(f'{kind}: {result.status}; no exact label or family replacement')

def select_family(index, width_count, outer_family_count):
    if type(index) is not int or index<0 or width_count<1 or outer_family_count<1:
        raise ValueError('invalid exact-family schedule')
    return EXACT_FAMILIES[(index // (width_count*outer_family_count)) % len(EXACT_FAMILIES)]

def make_exact_root(kind,seed,n,split):
    specs={spec[0]:spec for spec in FAMILY_SPECS}
    if kind not in specs:raise ValueError('unregistered exact family')
    _,generator_name,adapter_name,prefix,sha_name=specs[kind]
    generator=import_module('.'+generator_name,__package__)
    adapter=import_module('.'+adapter_name,__package__)
    result=generator.generate(seed,n,split=split)
    if result.status!='exact':
        raise GuardedGenerationLimit(kind,result,seed,split)
    if not adapter.verify_result(result,AlphabetSpec.all_to_all(n)):
        raise ValueError('guarded exact generation failed full-word and theorem check')
    source_sha=getattr(adapter,sha_name)
    record=SampleRecord(result.state,(result.word,),f'{adapter_name}:{split}:{seed}:{n}',
                        seed,adapter_name,split,exact_distance=result.distance,
                        exact_evidence=prefix+source_sha)
    audit={'family':'guarded_exact','exact_kind':kind,'scope_id':result.scope_id,
           'source_sha256':source_sha,'hypotheses':result.hypotheses,
           'witness':asdict(result)['witness'],'exact_distance':result.distance,
           'verified_word':True,'selected_producer':result.word.producer,
           'selected_length':result.word.physical_cost,'solver_called':False,
           'solver_status':'not_called_exact_certificate'}
    return record,audit
